# Inventário NISAR L2 GCOV sobre a área de estudo

Fonte: API de busca do ASF (metadados públicos). 56 produtos cruzam o recorte lon -60,35 a -58,85; lat -3,85 a -2,85.
Para comparar retroespalhamento entre datas, use produtos do mesmo grupo (mesma trilha, frame, direção, modo, polarizações e versão de processamento).

| Trilha | Frame | Direção | Modo | Polarização | CRID | Produtos (completos) | Período | Coleções |
|---|---|---|---|---|---|---|---|---|
| 31 | 176 | ascending | 2005 | HH+HV | P05023 | 8 (8) | 2026-06-28 a 2026-10-14 | PROVISIONAL_V1 |
| 140 | 90 | descending | 4005 | HH+HV | P05023 | 8 (8) | 2026-06-23 a 2026-10-09 | PROVISIONAL_V1 |
| 132 | 176 | ascending | 4005 | HH+HV | P05023 | 7 (7) | 2026-08-10 a 2026-10-21 | PROVISIONAL_V1 |
| 68 | 90 | descending | 2005 | HH+HV | P05023 | 5 (5) | 2026-06-18 a 2026-10-16 | PROVISIONAL_V1 |
| 68 | 90 | descending | 2005 | HH | P05023 | 5 (5) | 2026-06-30 a 2026-10-04 | PROVISIONAL_V1 |
| 132 | 175 | ascending | 2005 | HH+HV | P05023 | 5 (5) | 2026-08-10 a 2026-10-21 | PROVISIONAL_V1 |
| 140 | 91 | descending | 2005 | HH+HV | P05023 | 3 (3) | 2026-07-05 a 2026-10-09 | PROVISIONAL_V1 |
| 140 | 90 | descending | 4005 | HH+HV | P05036 | 2 (2) | 2026-10-21 a 2026-11-02 | V1 |
| 140 | 91 | descending | 2005 | HH | P05023 | 2 (2) | 2026-09-03 a 2026-09-27 | PROVISIONAL_V1 |
| 31 | 176 | ascending | 2005 | HH+HV | P05036 | 1 (1) | 2026-10-26 a 2026-10-26 | V1 |
| 68 | 90 | descending | 2005 | HH | P05036 | 1 (1) | 2026-10-28 a 2026-10-28 | V1 |
| 68 | 90 | descending | 2005 | HH | X05009 | 1 (1) | 2025-11-02 a 2025-11-02 | BETA_V1 |
| 132 | 175 | ascending | 0505 | HH | P05023 | 1 (1) | 2026-07-17 a 2026-07-17 | PROVISIONAL_V1 |
| 132 | 176 | ascending | 0005 | ? | P05023 | 1 (1) | 2026-07-17 a 2026-07-17 | PROVISIONAL_V1 |
| 140 | 91 | descending | 2005 | HH+HV | P05036 | 1 (1) | 2026-11-02 a 2026-11-02 | V1 |
| 132 | 176 | ascending | 0505 | HH | P05023 | 1 (0) | 2026-07-17 a 2026-07-17 | PROVISIONAL_V1 |
| 140 | 91 | descending | 4005 | HH+HV | P05036 | 1 (0) | 2026-11-02 a 2026-11-02 | V1 |
| 140 | 91 | descending | 4005 | HH+HV | P05023 | 3 (0) | 2026-07-05 a 2026-10-09 | PROVISIONAL_V1 |

## Pares recomendados para a análise calibrada (quando o acesso Earthdata funcionar)

- Trilha 31, frame 176 (ascending, P05023): **2026-07-10 × 2026-10-14**. mesma trilha, frame, direção, modo, polarização HH+HV e CRID; julho (cheia) × fim de setembro/outubro (vazante e fogo); frames completos.
- Trilha 140, frame 90 (descending, P05023): **2026-07-17 × 2026-10-09**. mesma trilha, frame, direção, modo, polarização HH+HV e CRID; julho (cheia) × fim de setembro/outubro (vazante e fogo); frames completos.
- Trilha 68, frame 90 (descending, P05023): **2026-07-12 × 2026-10-16**. mesma trilha, frame, direção, modo, polarização HH+HV e CRID; julho (cheia) × fim de setembro/outubro (vazante e fogo); frames completos.
- Trilha 140, frame 91 (descending, P05023): **2026-07-05 × 2026-10-09**. mesma trilha, frame, direção, modo, polarização HH+HV e CRID; julho (cheia) × fim de setembro/outubro (vazante e fogo); frames completos.

Observações:
- CRID P05023 = coleção PROVISIONAL; P05036 = coleção V1 (validada a partir de nov/2026). Não misture versões na mesma comparação.
- A qualidade de cada produto (QA_SUMMARY.csv, QA_REPORT.pdf) exige login Earthdata e não foi conferida.
- O par usado nas prévias do app é trilha 140, frame 90: 2026-07-17 × 2026-10-09.
