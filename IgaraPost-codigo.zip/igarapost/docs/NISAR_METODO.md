# NISAR no IgaraPost: método, parâmetros e situação

Atualizado em 14/11/2026 (versão 0.2.0).

## 1. O que o app mostra hoje: exploração visual das prévias (browse)

**Situação: executado com dados reais. Experimental, sem validação ambiental.**

| Item | Valor |
|---|---|
| Produto | NISAR L2 GCOV (prévias `*_LATLON.png` públicas do ASF) |
| Par | trilha 140, frame 90, descendente, modo 4005, HH+HV, CRID P05023 (PROVISIONAL): **2026-07-17 × 2026-10-09** |
| Série | 10 passagens da mesma trilha/frame, de 2026-06-23 a 2026-11-02 (as duas últimas com CRID P05036) |
| Recorte | lon −60,35 a −58,85; lat −3,85 a −2,85 |
| Georreferência | ajuste afim pelo contorno (WKT) do ASF, resíduo médio de 0,6 e 1,0 px; conferido contra a camada NISAR GCOV do NASA GIBS (deslocamento −4 px, igual nas duas datas) |
| Grade de saída | 1/650° (~170 m), vizinho mais próximo |
| Segmentação | limiar de Otsu sobre o brilho de cada prévia (por data) |
| Classes | escuro→claro, claro→escuro, escuro nas duas, sem dados |
| Scripts | `process_nisar_browse.py`, `fire_radar_overlap.py`, `nisar_by_municipio.py` |

**Limites.** As prévias têm realce de contraste por imagem: não são gamma0 e não permitem comparar dB. As áreas
calculadas descrevem a **segmentação das imagens**, não água, queimada ou seca. "Escuro" pode ser água parada, solo
liso, pasto seco ou área queimada. Vento e chuva deixam a água clara, e floresta alagada fica muito clara.

**Conferência independente (exploratória).** 60% dos 4.742 focos NPP-375 entre as duas datas, em pixels que estavam
claros em A, ficam a até 500 m de um pixel que passou a aparecer escuro, contra 25% de 20.000 pontos aleatórios nas mesmas
condições. Há uma confusão óbvia: o fogo se concentra em pastos e roças, que mudam por outros motivos. O resultado indica
uma relação a investigar, não causa.

## 2. Análise calibrada (gamma0) com os arquivos .h5

**Situação: script preparado e testado só com dados sintéticos. NÃO executado com dados reais.**
O login Earthdata configurado no ambiente foi recusado pelo servidor da NASA (o mesmo vale para os relatórios de qualidade
QA_SUMMARY.csv e QA_REPORT.pdf, que também exigem login).

`scripts/process_nisar_gcov.py`:

1. Lê só a janela da área de estudo (HHHH, HVHV, mask, numberOfLooks) via `earthaccess`, sem baixar o arquivo todo (~7 GB).
2. Verifica a comparabilidade (trilha, frame, direção, polarizações, CRID). Trilha ou direção diferentes interrompem o processamento; CRID diferente gera aviso.
3. Alinha as grades: se forem diferentes, reprojeta B na grade de A (média em potência linear).
4. Aplica a máscara de qualidade: valor ≤ 0 ou NaN; `mask` em `--invalid-mask` (padrão `0,255`, **confirme o significado na especificação JPL D-102274**); `numberOfLooks < --min-looks`.
5. Faz multi-look em blocos de `--looks` (padrão 5) em potência linear. Um bloco só vale com pelo menos `--min-valid-frac` (padrão 0,5) de pixels válidos.
6. Calcula dB e a razão logarítmica `dB(B) − dB(A)`. As classes de mudança usam o limiar `--thr` (padrão 3 dB). Emite um aviso se o HV mediano ficar abaixo de −26 dB, perto do nível de ruído.
7. Grava GeoTIFF (dB A, dB B, diferença), PNG em EPSG:4326 para o app e `gcov_summary.json` com todos os parâmetros, checagens e avisos.
8. Com `--fires`, faz a conferência independente com os focos do INPE.

Teste sintético (`python3 tests/test_gcov_pipeline.py <pasta>`): 9 de 9 verificações OK. O teste cobre grades deslocadas 50 m, máscaras `mask=0` e `numberOfLooks=0`, a queda de 6 dB recuperada (597 km² contra ~600 esperados), a ausência de mudança espúria e o aviso de CRID.

### Para executar quando o acesso funcionar
1. Crie ou confirme a conta em https://urs.earthdata.nasa.gov e autorize o aplicativo do ASF no seu perfil.
2. Grave `~/.netrc` com `machine urs.earthdata.nasa.gov login USUARIO password SENHA` (nunca no repositório).
3. Rode:
```bash
python3 scripts/process_nisar_gcov.py --a <URL .h5 de 2026-07-17> --b <URL .h5 de 2026-10-09> --out out/nisar_gcov --fires out/fires_NPP-375.json
```
4. Confira os avisos e os relatórios QA de cada produto antes de publicar qualquer número no app.

As URLs estão em `app/public/data/nisar/nisar_summary.json` (campo `granules.*.download`). Os pares recomendados estão em `docs/NISAR_INVENTARIO.md`.

## 3. Umidade do solo (SME2)

Não usada. Segundo a documentação do ASF, o produto ainda é PROVISIONAL (não há coleção validada) e os valores em
vegetação densa (mais de 5 kg/m² de água na vegetação, caso da floresta) são marcados como pouco confiáveis. O app não
converte retroespalhamento em umidade do solo e não diagnostica seca com duas imagens.

## 4. Relação com relatos

No detalhe de cada relato dentro do recorte, o app informa:
- se a observação é anterior, intermediária ou posterior às duas imagens comparadas;
- as passagens processadas mais próximas, antes e depois, com a distância em dias.

## 5. Próximos passos científicos
1. Rodar a análise calibrada no par recomendado e comparar com a segmentação das prévias.
2. Validar com evidências independentes: nível do rio em Manaus (Porto de Manaus/ANA), mapas de área queimada (por exemplo, MODIS MCD64A1 ou INPE AQ1km), imagens ópticas sem nuvem e visitas de campo.
3. Repetir nos outros grupos comparáveis (trilhas 31/176 e 68/90) para verificar se a mudança se mantém com outra geometria.
