# IgaraPost: roteiro de apresentação (≈ 5 min)

Ordem: problema → público → solução → dados → demonstração → impacto. Os números abaixo vêm dos arquivos processados em 14/11/2026 (veja o README). Não arredonde para cima e não chame de "alerta".

---

## 1. Problema (40 s)
**Fala.** "Em Manaus e no entorno, quem mora na beira do rio percebe a seca e a fumaça antes de qualquer boletim. Os satélites também registram, mas os dados ficam espalhados em portais técnicos. E o relato de quem vive ali raramente encontra o dado do satélite."

**Evidência (dados reais da área do app):**
- Focos de calor do satélite de referência do INPE (AQUA_M-T): 47 em julho, 339 em agosto, **1.351 em setembro** e 918 em outubro de 2026. No sensor VIIRS (NPP-375): 205, 1.391, 6.569 e 7.060.
- Cemaden, IIS-3 de Manaus: Normal em junho, Fraca em julho, Moderada em agosto, **Severa em setembro e outubro** de 2026.
- Contexto adicional (fontes indicadas pela equipe): NASA Earth Observatory, *Intense, Widespread Drought Grips South America* e *Fires Arrive in the Amazon Rainforest*.

Lembrete: foco não é incêndio nem área queimada; o IIS vale para o município inteiro.

## 2. Público (20 s)
Moradores de comunidades ribeirinhas, rurais e urbanas; estudantes, professores e pesquisadores; organizações ambientais, comunicadores e gestores locais.

## 3. Solução (40 s)
"O IgaraPost é uma rede social por território e por tema, ligada a um mapa. Você acompanha a sua região, vê relatos e dados, explora as evidências no mapa, publica o que observou e conversa com a comunidade."

O diferencial são três tipos de informação sempre identificados: **relato da comunidade (não verificado)**, **fonte oficial** e **análise experimental NISAR**. Popularidade não vira confirmação científica.

## 4. Dados (60 s)
- **NISAR** (centro do desafio *Dancing with the SARs*): produto L2 GCOV, trilha 140, frame 90, 10 passagens entre 23/06 e 02/11/2026. Comparamos 17/07 (perto da cheia) e 09/10 (vazante e pico de focos): mesma órbita, mesma geometria, HH+HV, mesma versão (P05023).
- Resultado: em 18.372 km² com dados, **573 km² passaram a aparecer escuros** no radar e **410 km² deixaram de aparecer escuros**.
- Teste exploratório: **60%** dos 4.742 focos NPP-375 do período ficam a até 500 m de uma área que escureceu, contra **25%** de pontos ao acaso. É uma relação a investigar, não causa: fogo se concentra em pastos e roças, que mudam por outros motivos.
- **INPE** para focos (satélite de referência separado do VIIRS). **Cemaden** para seca (IIS-1, 3 e 6 por município).
- Frequências diferentes (instantâneo, 12 dias, mensal): o app compara por proximidade no espaço e no tempo e mostra o período de cada dado.

## 5. Demonstração (2 min)
Siga o "Percurso de demonstração" do README:
1. Feed com selos e um post oficial do INPE (fonte e data visíveis).
2. Seguir "Autazes e Rio Madeira" e filtrar "Regiões e temas que sigo".
3. Publicar um relato de fumaça perto do Careiro da Várzea (data da observação, local aproximado).
4. Detalhe: dados próximos (focos ±3 dias, IIS do mês, radar a 1 km) e o aviso de causalidade. Comentar e salvar.
5. Mapa centralizado no relato; ligar seca e NISAR; mostrar a legenda com fonte e data.
6. Explorador NISAR: deslizar entre as datas, camada de mudança com focos e metadados.
7. Recarregar a página: o relato continua (armazenamento deste aparelho).

Plano B se a internet falhar: o app funciona localmente (`npm run build`, depois `npx vite preview`). Os dados ficam em `app/public/data` e o fundo do mapa é local.

## 6. Impacto e limites (40 s)
**Benefício pretendido:** facilitar a troca de informações, a compreensão das mudanças e o acompanhamento de regiões. **Ainda não foi avaliado com usuários.** Esse é o próximo passo, com escolas e comunidades do Careiro e de Autazes.

**Limites que dizemos em voz alta:**
- A análise NISAR usa imagens de visualização, não retroespalhamento calibrado. O script para os arquivos .h5 está pronto e aguarda o acesso Earthdata.
- Duas imagens não diagnosticam seca; não convertemos radar em umidade do solo (o SME2 é provisório e pouco confiável em floresta densa).
- Relatos e comunidades da demonstração são fictícios; a persistência é só no aparelho.
- O app não publica alertas oficiais nem aciona emergência.

---

## Respostas ao guia do evento

| Critério | Resposta curta |
|---|---|
| Contexto | Manaus, Iranduba, Careiro da Várzea, Careiro e Autazes (AM), na seca e na temporada de fogo de 2026; afeta comunidades ribeirinhas, rurais e urbanas. |
| Evidência | Focos INPE (jul–nov/2026), IIS Cemaden (jun–out/2026), série NISAR (10 passagens), artigos do NASA Earth Observatory. |
| Foco | Protótipo navegável, uma área pequena, um par NISAR comparável, dados reais de fogo e seca. |
| Problema | Relatos locais e dados de satélite não se encontram e são difíceis de entender. |
| Público | Comunidades, educação e pesquisa, organizações e gestores locais. |
| Solução | Rede social por território e tema, com mapa e origem identificada de cada informação. |
| Dados | NISAR GCOV (mudança no radar), INPE (focos), Cemaden (seca), relatos (observação). |
| Demonstração | Percurso de 7 passos acima; 24 verificações automáticas aprovadas. |
| Impacto | Benefício pretendido e limites declarados; avaliação com usuários pendente. |

## Checklist final
- [x] Problema delimitado
- [x] Alinhamento com *Dancing with the SARs* (NISAR GCOV, comparação de datas, visualização interativa)
- [x] Fontes identificadas (README §5 e tela Sobre)
- [x] Protótipo acessível (link publicado; compartilhar pelo menu Share antes de enviar; ou publicar `app/dist/` num site estático)
- [x] Valor da ideia explicado
- [ ] Créditos e contribuições registrados (preencher a tabela do README §5)
- [ ] Links e submissão conferidos no portal do Space Apps
