package br.edu.uea.ventonorte.igarapost;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
