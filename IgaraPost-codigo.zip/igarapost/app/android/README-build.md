# Build Android

Se o Gradle falhar com "Could not parse POM ... repo.maven.apache.org" (HTTP 429), crie `~/.gradle/init.d/mirror.gradle`:

```groovy
def mirror = "https://maven-central.storage-download.googleapis.com/maven2/"
settingsEvaluated { s -> s.pluginManagement.repositories { maven { url mirror } } }
allprojects {
  buildscript.repositories { maven { url mirror } }
  repositories { maven { url mirror } }
}
```

Ícones e telas de abertura: `python3 scripts/make_android_assets.py android/app/src/main/res` (na pasta `app/`).
