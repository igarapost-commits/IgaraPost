import { defineConfig } from "vite";
import pkg from "./package.json";

// Dois modos de build:
//  - padrão: app independente (GitHub Pages, Netlify, servidor estático) com React/Leaflet empacotados;
//  - "artifact": React, ReactDOM e Leaflet ficam externos (carregados do cdnjs) e o JS sai em um único
//    arquivo IIFE, como exige a página publicada no claude.ai.
export default defineConfig(({ mode }) => ({
  base: "./",
  define: { __APP_VERSION__: JSON.stringify(pkg.version) },
  esbuild: { jsx: "transform", jsxFactory: "React.createElement", jsxFragment: "React.Fragment" },
  build: mode === "artifact"
    ? {
        outDir: "dist-artifact",
        cssCodeSplit: false,
        rollupOptions: {
          external: ["react", "react-dom", "react-dom/client", "leaflet"],
          output: {
            format: "iife",
            entryFileNames: "app.js",
            assetFileNames: "app.[ext]",
            globals: { react: "React", "react-dom": "ReactDOM", "react-dom/client": "ReactDOM", leaflet: "L" },
          },
        },
      }
    : { outDir: "dist" },
}));
