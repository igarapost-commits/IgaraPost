import React from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";
import { AppProvider } from "./ctx";
import { Icon } from "./Icon";
import { Feed } from "./Feed";
import { PostDetail } from "./PostDetail";
import { MapView } from "./MapView";
import { Compose } from "./Compose";
import { NisarExplorer } from "./NisarExplorer";
import { About, Profile } from "./pages";
import { HowTo } from "./HowTo";
import { startSync } from "./sync";
import { goBack, previousScreen, startNav } from "./nav";
import { initTheme } from "./theme";
import { startI18n } from "./i18n/dom";
import { startIntro } from "./intro";

function currentHash() {
  const h = location.hash || "#feed";
  return LEGACY[h] ?? h;
}
function useHash() {
  const [h, set] = React.useState(currentHash);
  React.useEffect(() => {
    const f = () => {
      const legacy = LEGACY[location.hash];
      if (legacy) history.replaceState(null, "", legacy);
      set(currentHash());
    };
    window.addEventListener("hashchange", f);
    return () => window.removeEventListener("hashchange", f);
  }, []);
  return h;
}

/** Logo do projeto (public/igarapost-logo.png). */
const LOGO = "igarapost-logo.png";

const TABS = [
  ["#feed", "Feed", "feed"],
  ["#mapa", "Mapa", "map"],
  ["#relatar", "Relatar", "plus"],
  ["#perfil", "Perfil", "user"],
] as const;

/** Endereços antigos continuam funcionando (links salvos, notificações, testes). */
const LEGACY: Record<string, string> = { "#publicar": "#relatar", "#comunidades": "#feed", "#perfil-dados": "#perfil-configuracoes", "#perfil-conta": "#perfil-configuracoes" };

function Shell() {
  const h = useHash();
  let view: React.ReactNode;
  let tab = "#feed";
  let wide = false;
  if (h.startsWith("#post-")) view = <PostDetail key={h} id={h.slice(6).replace(/#.*$/, "")} />;
  else if (h.startsWith("#editar-")) {
    view = <Compose key={h} editId={h.slice(8)} />;
    tab = "#perfil";
  } else if (h === "#mapa") {
    view = <MapView />;
    tab = "#mapa";
  } else if (h === "#relatar") {
    view = <Compose key="new" />;
    tab = "#relatar";
  } else if (h.startsWith("#perfil")) {
    view = <Profile tab={h.slice(8) || undefined} />;
    tab = "#perfil";
  } else if (h === "#nisar") {
    view = <NisarExplorer />;
    tab = "#mapa";
    wide = true;
  } else if (h === "#sobre") {
    view = <About />;
    tab = "#perfil";
  } else if (h === "#como-funciona") {
    view = <HowTo />;
    tab = "";
  } else view = <Feed />;

  React.useEffect(() => {
    const titles: Record<string, string> = { "#mapa": "Mapa", "#relatar": "Relatar", "#perfil": "Perfil", "#perfil-meus": "Meus relatos", "#perfil-configuracoes": "Configurações", "#nisar": "Explorador NISAR", "#sobre": "Sobre nós", "#como-funciona": "Como o aplicativo funciona" };
    document.title = `IgaraPost${titles[h] ? " · " + titles[h] : ""}`;
  }, [h]);

  return (
    <div className="shell">
      <header className="topbar">
        {previousScreen() && (
          <button className="btn sm ghost back-btn" onClick={goBack} aria-label="Voltar">
            <Icon name="back" />
          </button>
        )}
        <a className="brand" href="#feed" aria-label="IgaraPost, início">
          <img src={LOGO} alt="" width={34} height={34} />
          <b className="brand-word">
            Igara<span>Post</span>
          </b>
        </a>
        <span className="grow" />
        <a className="btn sm ghost about-link" href="#como-funciona" aria-current={h === "#como-funciona" ? "page" : undefined}>
          <Icon name="help" /> <span>Como o aplicativo funciona</span>
        </a>
      </header>
      {h === "#mapa" ? view : <main className={`main ${wide ? "wide" : ""}`}>{view}</main>}
      <nav className="bottomnav" aria-label="Navegação principal">
        {TABS.map(([href, label, icon]) => (
          <a key={href} href={href} aria-current={tab === href ? "page" : undefined} className={href === "#relatar" ? "publish" : ""}>
            <span className="ico-wrap">
              <Icon name={icon} />
            </span>
            {label}
          </a>
        ))}
      </nav>
    </div>
  );
}

startNav();
startI18n();
startIntro();
initTheme();
startSync();
createRoot(document.getElementById("root")!).render(
  <AppProvider>
    <Shell />
  </AppProvider>,
);
