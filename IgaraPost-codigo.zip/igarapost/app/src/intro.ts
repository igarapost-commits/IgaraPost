/**
 * Abertura animada: a marcação e a animação ficam no index.html (aparecem no
 * primeiro quadro). Aqui só tiramos a abertura do caminho quando ela termina,
 * ou antes, se a pessoa tocar na tela.
 */
export function startIntro() {
  const el = document.getElementById("intro");
  const html = document.documentElement;
  const done = () => {
    el?.remove();
    html.classList.remove("intro-on");
  };
  if (!el || html.classList.contains("no-intro")) return done();
  el.addEventListener("animationend", (e) => {
    const n = (e as AnimationEvent).animationName;
    if (e.target === el && (n === "introOut" || n === "introSkip")) done();
  });
  el.addEventListener(
    "pointerdown",
    () => {
      el.classList.add("skip");
    },
    { once: true },
  );
  // garantia: some mesmo se a animação não rodar
  window.setTimeout(done, 4500);
}
