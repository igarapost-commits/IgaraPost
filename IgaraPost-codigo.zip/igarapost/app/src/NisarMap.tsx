import { LOCALE } from "./i18n/lang";
import React from "react";
import L from "leaflet";
import type { NisarSummary } from "./data";
import { DATA, fmtDay, useData } from "./data";
import type { Post } from "./types";
import { Icon } from "./Icon";
import { CATEGORIES } from "./seed";
import { layerDate } from "./sars/layers";
import { NISAR_START, nisarChangeLayer, nisarTileMatrix, nisarWindowLayers, windowDays } from "./sars/nasaTiles";
import { AMAZON_REGIONS, inRegion, regionBounds } from "./sars/regions";
import { useLive } from "./sars/live";
import { addAppBase, googleKey } from "./sars/googleTiles";
import { SARS } from "./sars/config";
import { useStore } from "./store";

type Basemap = Record<string, { file: string; bounds: [[number, number], [number, number]] }>;
type Fonte = "mundo" | "regiao";
type View = "deslizar" | "mudanca";

const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]!);
const daysAgo = (n: number) => layerDate(n);

/**
 * Explorador NISAR no próprio mapa.
 *  - Mundo: compara duas datas do radar em qualquer lugar (camada NISAR da NASA GIBS, mosaicos de 12 dias).
 *  - Estudo de Região: escolhe uma região da floresta amazônica, enquadra o mapa nela e compara as datas,
 *    com os focos e relatos da região.
 */
export function NisarMap({ nisar, posts }: { nisar: NisarSummary; posts: Post[] }) {
  const live = useLive();
  const [fonte, setFonte] = React.useState<Fonte>("mundo");
  const [regionId, setRegionId] = React.useState("manaus");
  const region = AMAZON_REGIONS.find((r) => r.id === regionId)!;
  // só a comparação deslizando A × B (a "camada de mudança" saiu)
  const [view] = React.useState<View>("deslizar");
  const [endB, setEndB] = React.useState(() => daysAgo(0));
  const [endA, setEndA] = React.useState(() => daysAgo(36));
  const [pos, setPos] = React.useState(50);
  const [showPosts, setShowPosts] = React.useState(true);
  const [state, setState] = React.useState<"" | "carregando" | "ok">("");
  const [progress, setProgress] = React.useState<[number, number]>([0, 0]);
  const [baseReady, setBaseReady] = React.useState(false);
  const basemap = useData<Basemap>("basemap/basemap.json");
  const host = React.useRef<HTMLDivElement>(null);
  const map = React.useRef<L.Map>();
  const groups = React.useRef<Record<string, L.LayerGroup>>({});
  const effView: View = fonte === "mundo" ? "deslizar" : view;
  const swipe = effView === "deslizar";
  const posRef = React.useRef(pos);
  posRef.current = pos;
  const swipeRef = React.useRef(swipe);
  swipeRef.current = swipe;

  // recorta as duas camadas na posição da divisória (A à esquerda, B à direita)
  const clip = React.useCallback(() => {
    const m = map.current;
    if (!m) return;
    const a = m.getPane("nisA"),
      b = m.getPane("nisB");
    if (!a || !b) return;
    if (!swipeRef.current) {
      a.style.clip = b.style.clip = "";
      return;
    }
    const size = m.getSize();
    const nw = m.containerPointToLayerPoint([0, 0]),
      se = m.containerPointToLayerPoint(size);
    const x = nw.x + (size.x * posRef.current) / 100;
    a.style.clip = `rect(${nw.y}px, ${x}px, ${se.y}px, ${nw.x}px)`;
    b.style.clip = `rect(${nw.y}px, ${se.x}px, ${se.y}px, ${x}px)`;
  }, []);

  React.useEffect(() => {
    if (!host.current || map.current) return;
    const m = L.map(host.current, { zoomControl: false, minZoom: 2, maxZoom: 18, worldCopyJump: true });
    L.control.zoom({ position: "bottomright" }).addTo(m);
    m.attributionControl.setPrefix(false);
    m.attributionControl.addAttribution(SARS.attribution);
    m.fitBounds(regionBounds(AMAZON_REGIONS[0]));
    m.createPane("nisA").style.zIndex = "410";
    m.createPane("nisB").style.zIndex = "420";
    ["offline", "base", "a", "b", "regiao", "posts"].forEach((k) => (groups.current[k] = L.layerGroup().addTo(m)));
    m.on("move zoom resize", clip);
    map.current = m;
    const fallback = window.setTimeout(() => setBaseReady(true), 5000); // não espera para sempre por um fundo lento
    return () => {
      window.clearTimeout(fallback);
      m.remove();
      map.current = undefined;
    };
  }, [clip]);

  // 1º o fundo; as demais camadas só depois que ele aparece
  // mesmo fundo do mapa principal: Google Maps (com chave) e, na falta dele, a NASA
  const dayKey = layerDate(1);
  const gkey = useStore().prefs.googleKey;
  React.useEffect(() => {
    const g = groups.current.base;
    if (!g || !map.current) return;
    return addAppBase(map.current, g, googleKey() ? "google" : "mundo", () => void 0, () => setBaseReady(true));
  }, [dayKey, gkey]);
  React.useEffect(() => {
    const g = groups.current.offline,
      bm = basemap.data?.bluemarble;
    if (!g || !bm) return;
    // vai num painel abaixo dos blocos: só aparece onde não há fundo online (sem internet)
    const pane = map.current!.getPane("reservaPane") ?? map.current!.createPane("reservaPane");
    pane.style.zIndex = "150";
    const o = L.imageOverlay(DATA + "basemap/" + bm.file, bm.bounds, { interactive: false, pane: "reservaPane" }).addTo(g);
    return () => void g.removeLayer(o);
  }, [basemap.data]);

  // região escolhida: enquadra e contorna
  React.useEffect(() => {
    const g = groups.current.regiao,
      m = map.current;
    if (!g || !m) return;
    g.clearLayers();
    if (fonte !== "regiao") return;
    const b = regionBounds(region);
    m.fitBounds(b, { padding: [12, 12] });
    L.rectangle(b, { color: "#b9a3ff", weight: 2, dashArray: "6 4", fill: false, interactive: false }).addTo(g);
  }, [fonte, region]);

  // camadas A e B (ou a camada de mudança)
  React.useEffect(() => {
    const ga = groups.current.a,
      gb = groups.current.b;
    if (!ga || !gb || !baseReady) return;
    ga.clearLayers();
    gb.clearLayers();
    let alive = true;
    setState("carregando");
    void nisarTileMatrix().then((m) => {
      if (!alive) return;
      if (effView === "mudanca") {
        setProgress([0, 0]);
        nisarChangeLayer(endA, endB, m, { pane: "nisB", bounds: regionBounds(region), onProgress: (d, t) => alive && setProgress([d, t]) }).addTo(gb);
      } else {
        nisarWindowLayers(endA, m, { pane: "nisA" }).forEach((t) => t.addTo(ga));
        nisarWindowLayers(endB, m, { pane: "nisB" }).forEach((t) => t.addTo(gb));
      }
      setState("ok");
    });
    window.setTimeout(clip, 0);
    return () => {
      alive = false;
    };
  }, [effView, endA, endB, nisar, region, baseReady, clip]);

  React.useEffect(clip, [pos, swipe, clip]);

  // relatos da comunidade: balão que abre por toque e se ajusta dentro do mapa
  React.useEffect(() => {
    const g = groups.current.posts;
    if (!g || !baseReady) return;
    g.clearLayers();
    if (!showPosts) return;
    posts
      .filter((p) => p.kind === "community" && p.lat != null && p.lon != null)
      .forEach((p) =>
        L.circleMarker([p.lat!, p.lon!], { radius: 7, color: "#1b6c97", weight: 3, fillColor: "#fff", fillOpacity: 1 })
          .bindPopup(`<b>${esc(CATEGORIES[p.category].short)}${p.municipio ? " · " + esc(p.municipio) : ""}</b><br>${esc(p.text.length > 140 ? p.text.slice(0, 140) + "…" : p.text)}<br><a href="#post-${p.id}">Abrir relato</a>`, {
            maxWidth: 240,
            minWidth: 160,
            autoPanPadding: [16, 16],
            className: "nisar-popup",
          })
          .addTo(g),
      );
  }, [posts, showPosts, baseReady]);

  // arrastar a bolinha (ou a linha) da comparação; o mapa não se mexe enquanto isso
  const wrapRef = React.useRef<HTMLDivElement>(null);
  const startDrag = (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const el = e.currentTarget as HTMLElement;
    el.setPointerCapture?.(e.pointerId);
    const move = (ev: PointerEvent) => {
      const r = wrapRef.current?.getBoundingClientRect();
      if (!r) return;
      setPos(Math.max(0, Math.min(100, ((ev.clientX - r.left) / r.width) * 100)));
    };
    const up = () => {
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerup", up);
      el.removeEventListener("pointercancel", up);
    };
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerup", up);
    el.addEventListener("pointercancel", up);
  };

  const daysA = windowDays(endA),
    daysB = windowDays(endB);
  const labelA = daysA.length ? `A · ${fmtDay(endA)}` : "A · sem dados";
  const labelB = daysB.length ? `B · ${fmtDay(endB)}` : "B · sem dados";
  const regFires = fonte === "regiao" ? live.fires.filter((f) => inRegion(region, f.lat, f.lon)).length : 0;
  const regPosts = fonte === "regiao" ? posts.filter((p) => p.kind === "community" && p.lat != null && inRegion(region, p.lat, p.lon!)).length : 0;

  return (
    <section className="stack nisar-map-section" aria-label="Comparação de datas do radar NISAR no mapa">
      <div className="segmented two" role="radiogroup" aria-label="Fonte das imagens">
        <button role="radio" aria-checked={fonte === "mundo"} className={fonte === "mundo" ? "on" : ""} onClick={() => setFonte("mundo")}>
          <Icon name="map" size={16} /> Mundo (NASA GIBS)
        </button>
        <button role="radio" aria-checked={fonte === "regiao"} className={fonte === "regiao" ? "on" : ""} onClick={() => setFonte("regiao")}>
          <Icon name="radar" size={16} /> Estudo de Região
        </button>
      </div>
      {fonte === "regiao" && (
        <>
          <label className="field">
            <span>Região da floresta amazônica</span>
            <select id="nx-regiao" className="input" value={regionId} onChange={(e) => setRegionId(e.target.value)}>
              {AMAZON_REGIONS.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name}
                </option>
              ))}
            </select>
            <span className="small muted">
              {region.note} Na região agora: {regFires.toLocaleString(LOCALE)} foco(s) de fogo ativo nas últimas 48 h (NASA FIRMS) e {regPosts} relato(s) da comunidade.
            </span>
          </label>
        </>
      )}
      <div className="nisar-dates">
            <label className="field">
              <span>Data A</span>
              <input id="nx-a" className="input" type="date" value={endA} max={daysAgo(0)} min={NISAR_START} onChange={(e) => e.target.value && setEndA(e.target.value)} />
            </label>
            <label className="field">
              <span>Data B</span>
              <input id="nx-b" className="input" type="date" value={endB} max={daysAgo(0)} min={NISAR_START} onChange={(e) => e.target.value && setEndB(e.target.value)} />
            </label>
          </div>
      <div className="nisar-map-wrap" ref={wrapRef}>
        <div ref={host} className="nisar-map nasa-map" role="application" aria-label="Mapa do radar NISAR" />
        {swipe && (
          <>
            <div className="swipe-line" style={{ left: `${pos}%` }} onPointerDown={startDrag}>
              <span
                className="swipe-knob"
                role="slider"
                tabIndex={0}
                aria-label="Arraste para comparar as datas A e B"
                aria-valuemin={0}
                aria-valuemax={100}
                aria-valuenow={Math.round(pos)}
                onKeyDown={(e) => {
                  if (e.key === "ArrowLeft") setPos((v) => Math.max(0, v - 5));
                  if (e.key === "ArrowRight") setPos((v) => Math.min(100, v + 5));
                }}
              >
                ⇆
              </span>
            </div>
            <span className="compare-tag" style={{ left: 8 }}>
              {labelA}
            </span>
            <span className="compare-tag" style={{ right: 8 }}>
              {labelB}
            </span>
          </>
        )}
        {!baseReady && <span className="nisar-map-status">Carregando o mapa…</span>}
        {baseReady && state === "carregando" && <span className="nisar-map-status">Carregando o radar…</span>}
        {baseReady && effView === "mudanca" && state === "ok" && progress[1] > 0 && progress[0] < progress[1] && (
          <span className="nisar-map-status">
            Calculando a mudança: {progress[0]}/{progress[1]} blocos
          </span>
        )}
      </div>
      <label className="toggle small" style={{ fontWeight: 500 }}>
        <input id="nx-posts" type="checkbox" checked={showPosts} onChange={(e) => setShowPosts(e.target.checked)} /> Relatos da comunidade (toque para ver)
      </label>
      <div className="swatches">
        {effView === "mudanca" ? (
          <>
            <span className="swatch">
              <i style={{ background: "rgb(40,200,230)" }} />
              passou a aparecer escuro (de A para B)
            </span>
            <span className="swatch">
              <i style={{ background: "rgb(230,120,20)" }} />
              deixou de aparecer escuro
            </span>
            <span className="swatch">
              <i style={{ background: "rgb(30,90,160)" }} />
              escuro nas duas datas (provável água)
            </span>
          </>
        ) : (
          <>
            <span className="swatch">
              <i style={{ background: "#9be59f" }} />
              verde: vegetação (HV forte)
            </span>
            <span className="swatch">
              <i style={{ background: "#e7b6ea" }} />
              rosa/magenta: solo, pasto, áreas abertas
            </span>
            <span className="swatch">
              <i style={{ background: "#1a0f1c" }} />
              escuro: água parada ou superfície lisa
            </span>
          </>
        )}
      </div>
      <p className="small muted">
        {effView === "mudanca"
          ? "Mudança calculada no seu aparelho, bloco a bloco, comparando as áreas escuras do radar nas duas datas dentro da região. É uma leitura visual da imagem em cor falsa, sem valores calibrados: confirme com outras fontes."
          : `Camada NISAR da NASA GIBS (GCOV provisório, cor falsa), a mesma do NASA Worldview. Cada lado mostra as passagens mais recentes do radar até a data escolhida; onde ele não passou, o lado fica vazio. Datas disponíveis: de ${fmtDay(NISAR_START)} (lançamento do NISAR) até hoje.`}
      </p>
    </section>
  );
}
