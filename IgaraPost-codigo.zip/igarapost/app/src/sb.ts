/**
 * IgaraPost 10 · conexão com o Supabase (rede compartilhada).
 *
 * Usa só fetch (sem biblioteca): Auth em /auth/v1, banco em /rest/v1 e fotos em /storage/v1.
 * A chave publicável vai no cabeçalho `apikey`; a sessão de cada aparelho vai em `Authorization: Bearer`.
 * A segurança fica no banco (regras RLS do arquivo supabase/igarapost-v10.sql): a chave publicável sozinha
 * não lê nem grava nada.
 */
import { ApiError, normalizeUrl } from "./api";
import type { Post, ServerUser } from "./types";

const env = import.meta.env as Record<string, string | undefined>;
export const SB_URL = normalizeUrl(env.VITE_SUPABASE_URL || "https://bwkdeulgxnozixlqpsud.supabase.co");
export const SB_KEY = env.VITE_SUPABASE_KEY || "sb_publishable_csiyruHsD4b_H9jixXLaVQ_-wm24hPX";
const BUCKET = "fotos";

/* ------------------------------ sessão do aparelho ------------------------------ */
/** Guardada fora do estado do app, para a conta continuar a mesma depois de "Apagar os dados deste aparelho". */
const SESSION_KEY = "igarapost:sessao";
export interface Session {
  url: string;
  access_token: string;
  refresh_token: string;
  expires_at: number; // segundos (época Unix)
  user_id: string;
}
let session: Session | undefined;
function readSession(): Session | undefined {
  if (session) return session;
  try {
    const s = JSON.parse(localStorage.getItem(SESSION_KEY) || "null") as Session | null;
    if (s && s.url === SB_URL && s.refresh_token && s.user_id) session = s;
  } catch {
    /* sessão ilegível: cria outra */
  }
  return session;
}
function saveSession(s: Session | undefined) {
  session = s;
  try {
    if (s) localStorage.setItem(SESSION_KEY, JSON.stringify(s));
    else localStorage.removeItem(SESSION_KEY);
  } catch {
    /* sem armazenamento: a sessão vale até fechar o app */
  }
}
export const currentUserId = () => readSession()?.user_id;
export const hasSession = () => !!readSession();

/* ------------------------------ chamada HTTP ------------------------------ */
interface Opts {
  method?: string;
  body?: unknown;
  raw?: Blob;
  headers?: Record<string, string>;
  auth?: boolean; // envia a sessão (padrão: sim)
  timeoutMs?: number;
}

async function http<T>(path: string, o: Opts = {}): Promise<T> {
  const headers: Record<string, string> = { apikey: SB_KEY, ...(o.headers ?? {}) };
  if (o.auth !== false) headers.Authorization = `Bearer ${await accessToken()}`;
  if (o.body !== undefined) headers["Content-Type"] = "application/json";
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), o.timeoutMs ?? 20000);
  let r: Response;
  try {
    r = await fetch(SB_URL + path, {
      method: o.method ?? "GET",
      headers,
      body: o.raw ?? (o.body !== undefined ? JSON.stringify(o.body) : undefined),
      signal: ctl.signal,
    });
  } catch {
    throw new ApiError(0, "Sem conexão com a rede IgaraPost.", "rede");
  } finally {
    clearTimeout(t);
  }
  const text = await r.text();
  let j: unknown = undefined;
  try {
    j = text ? JSON.parse(text) : undefined;
  } catch {
    j = undefined;
  }
  if (!r.ok) throw toError(r.status, j);
  return j as T;
}

/** Erros do Supabase -> mensagens para a pessoa. */
function toError(status: number, j: unknown): ApiError {
  const e = (j ?? {}) as { code?: string; message?: string; msg?: string; error?: string; error_code?: string; error_description?: string; statusCode?: string };
  const code = String(e.code ?? e.error_code ?? e.statusCode ?? "");
  const msg = e.message ?? e.msg ?? e.error_description ?? e.error ?? "";
  if (code === "23505" || code === "409" || /duplicate|already exists/i.test(msg)) return new ApiError(409, "Já enviado.", "existe");
  if (code === "P0001" && /limite/i.test(msg)) return new ApiError(429, msg, "limite");
  if (code === "P0001" || code === "P0002" || code === "22023") return new ApiError(400, msg, code);
  if (status === 401 || code === "PGRST301" || code === "PGRST303" || /jwt/i.test(msg)) return new ApiError(401, "Sessão expirada.", "sessao");
  if (code === "42501" || status === 403) return new ApiError(403, "Sem permissão para isso na rede IgaraPost.", "permissao");
  if (code === "23514" || code === "22P02" || code === "23502") return new ApiError(400, "Algum dado do relato não foi aceito pelo servidor. Confira o texto e tente de novo.", "invalido");
  if (status === 422 && /anonymous/i.test(msg)) return new ApiError(503, "A entrada automática está desligada no servidor.", "anonimo_desligado");
  if (status === 429) return new ApiError(429, "Muitas tentativas. Tente de novo em alguns minutos.", "limite");
  if (status >= 500) return new ApiError(status, "O servidor está com problemas agora. Tente mais tarde.", "servidor");
  return new ApiError(status, msg || `Erro ${status} no servidor.`, code || undefined);
}

/* ------------------------------ entrada automática ------------------------------ */
interface AuthReply {
  access_token: string;
  refresh_token: string;
  expires_in: number;
  expires_at?: number;
  user: { id: string };
}
const toSession = (a: AuthReply): Session => ({
  url: SB_URL,
  access_token: a.access_token,
  refresh_token: a.refresh_token,
  expires_at: a.expires_at ?? Math.floor(Date.now() / 1000) + (a.expires_in || 3600),
  user_id: a.user.id,
});

let refreshing: Promise<string> | undefined;
/** Devolve um token válido: renova perto de vencer; sem sessão, cria a conta anônima do aparelho. */
export function accessToken(force = false): Promise<string> {
  const s = readSession();
  if (s && !force && s.expires_at - 90 > Date.now() / 1000) return Promise.resolve(s.access_token);
  return (refreshing ??= (async () => {
    try {
      const cur = readSession();
      if (cur) {
        try {
          const a = await http<AuthReply>("/auth/v1/token?grant_type=refresh_token", { method: "POST", body: { refresh_token: cur.refresh_token }, auth: false });
          saveSession(toSession(a));
          return a.access_token;
        } catch (e) {
          const err = e as ApiError;
          if (err.network || err.status >= 500 || err.status === 429) throw err;
          // renovação recusada (conta apagada no servidor): cria outra abaixo
          saveSession(undefined);
        }
      }
      const a = await http<AuthReply>("/auth/v1/signup", { method: "POST", body: { data: {} }, auth: false });
      saveSession(toSession(a));
      return a.access_token;
    } finally {
      refreshing = undefined;
    }
  })());
}

/** Chamada autenticada que tenta uma vez de novo se o token tiver vencido no meio do caminho. */
async function q<T>(path: string, o: Opts = {}): Promise<T> {
  try {
    return await http<T>(path, o);
  } catch (e) {
    if ((e as ApiError).status !== 401) throw e;
    await accessToken(true);
    return http<T>(path, o);
  }
}

/* ------------------------------ formatos ------------------------------ */
interface FeedRow {
  id: string;
  author_id: string;
  author_handle: string;
  author_name: string;
  category: Post["category"];
  text: string;
  lang?: Post["lang"] | null;
  lat: number;
  lon: number;
  approx: boolean;
  municipio?: string | null;
  observed_at: string;
  published_at: string;
  edited_at?: string | null;
  community_ids: string[];
  photo_path?: string | null;
  status: "visivel" | "oculto";
  radar?: Post["radar"] | null;
  comment_count: number;
  verified?: boolean;
  author_avatar?: string | null;
}
interface CommentRow {
  id: string;
  post_id: string;
  author_id: string;
  author_handle: string;
  author_name: string;
  text: string;
  lang?: Post["lang"] | null;
  created_at: string;
  author_avatar?: string | null;
}
export const photoUrl = (path: string) => `${SB_URL}/storage/v1/object/public/${BUCKET}/${path.split("/").map(encodeURIComponent).join("/")}`;
const iso = (s: string) => new Date(s).toISOString();

const toPost = (r: FeedRow): Post => ({
  id: r.id,
  kind: "community",
  lang: r.lang ?? undefined,
  authorId: r.author_id,
  author: { id: r.author_id, name: r.author_name, handle: r.author_handle, photo: r.author_avatar ? photoUrl(r.author_avatar) : undefined },
  category: r.category,
  text: r.text,
  lat: r.lat,
  lon: r.lon,
  approx: r.approx,
  municipio: r.municipio ?? undefined,
  observedAt: iso(r.observed_at),
  publishedAt: iso(r.published_at),
  editedAt: r.edited_at ? iso(r.edited_at) : undefined,
  communityIds: r.community_ids ?? [],
  photo: r.photo_path ? photoUrl(r.photo_path) : undefined,
  sync: r.status === "oculto" ? "oculto" : "publicado",
  commentCount: r.comment_count,
  mine: r.author_id === currentUserId(),
  radar: r.radar ?? undefined,
  verified: !!r.verified,
});
const toComment = (r: CommentRow) => ({
  id: r.id,
  postId: r.post_id,
  lang: r.lang ?? undefined,
  authorId: r.author_id,
  author: { id: r.author_id, name: r.author_name, handle: r.author_handle, photo: r.author_avatar ? photoUrl(r.author_avatar) : undefined },
  text: r.text,
  at: iso(r.created_at),
  sync: "publicado" as const,
  mine: r.author_id === currentUserId(),
});

const eq = (v: string) => `eq.${encodeURIComponent(v)}`;
const REP = { Prefer: "return=representation" };

/* ------------------------------ conta ------------------------------ */
export async function me(): Promise<ServerUser> {
  await accessToken();
  const uidv = currentUserId()!;
  const [p, m] = await Promise.all([
    q<{ id: string; handle: string; display_name: string; avatar_path: string | null }[]>(`/rest/v1/profiles?id=${eq(uidv)}&select=id,handle,display_name,avatar_path`),
    q<{ user_id: string }[]>(`/rest/v1/moderators?user_id=${eq(uidv)}&select=user_id`),
  ]);
  if (!p[0]) throw new ApiError(404, "Perfil não encontrado no servidor. Confira se o script do banco foi rodado.", "sem_perfil");
  return { id: p[0].id, handle: p[0].handle, displayName: p[0].display_name, role: m.length ? "moderador" : "usuario", photo: p[0].avatar_path ? photoUrl(p[0].avatar_path) : undefined };
}
export const setDisplayName = (name: string) => updateProfile({ name });

/** Nome de usuário: 3 a 24 caracteres, letras minúsculas sem acento, números, ponto, hífen ou sublinhado. */
export const HANDLE_RE = /^[a-z0-9_.-]{3,24}$/;
export const cleanHandle = (h: string) => h.trim().replace(/^@+/, "").toLowerCase();

/** Muda nome, @ e foto do perfil na rede. `avatar`: data URL nova, null para remover, undefined para manter. */
export async function updateProfile(p: { name?: string; handle?: string; avatar?: string | null }): Promise<ServerUser> {
  await accessToken();
  const uidv = currentUserId();
  if (!uidv) throw new ApiError(401, "Sessão expirada.", "sessao");
  const body: Record<string, unknown> = {};
  if (p.name !== undefined) body.display_name = p.name.slice(0, 40);
  if (p.handle !== undefined) {
    const h = cleanHandle(p.handle);
    if (!HANDLE_RE.test(h)) throw new ApiError(400, "O nome de usuário precisa ter de 3 a 24 caracteres: letras minúsculas sem acento, números, ponto, hífen ou sublinhado.", "handle");
    body.handle = h;
  }
  let oldAvatar: string | null | undefined;
  if (p.avatar !== undefined) {
    const cur = await q<{ avatar_path: string | null }[]>(`/rest/v1/profiles?id=${eq(uidv)}&select=avatar_path`);
    oldAvatar = cur[0]?.avatar_path;
    body.avatar_path = p.avatar === null ? null : p.avatar.startsWith("data:") ? await uploadPhoto(p.avatar, `avatar-${rand()}`) : (pathFromUrl(p.avatar) ?? oldAvatar ?? null);
  }
  if (Object.keys(body).length) {
    try {
      await q(`/rest/v1/profiles?id=${eq(uidv)}`, { method: "PATCH", body });
    } catch (e) {
      const err = e as ApiError;
      if (err.code === "existe") throw new ApiError(409, "Esse nome de usuário já está em uso. Escolha outro.", "handle_em_uso");
      if (err.code === "invalido") throw new ApiError(400, "O nome de usuário precisa ter de 3 a 24 caracteres: letras minúsculas sem acento, números, ponto, hífen ou sublinhado.", "handle");
      throw e;
    }
  }
  if (oldAvatar && oldAvatar !== body.avatar_path) removePhoto(oldAvatar);
  return me();
}

/* ------------------------------ relatos ------------------------------ */
const FEED_COLS = "*";
export async function listPosts(limit = 300): Promise<Post[]> {
  const rows = await q<FeedRow[]>(`/rest/v1/feed?select=${FEED_COLS}&order=published_at.desc&limit=${limit}`);
  return rows.map(toPost);
}
async function getPost(id: string): Promise<Post> {
  const rows = await q<FeedRow[]>(`/rest/v1/feed?select=${FEED_COLS}&id=${eq(id)}`);
  if (!rows[0]) throw new ApiError(404, "Este relato não existe mais no servidor.", "nao_encontrado");
  return toPost(rows[0]);
}

function dataUrlToBlob(d: string): Blob {
  const m = /^data:([^;,]+)(;base64)?,(.*)$/s.exec(d);
  if (!m) throw new ApiError(400, "Foto em formato desconhecido.", "foto");
  const bin = m[2] ? atob(m[3]) : decodeURIComponent(m[3]);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return new Blob([u8], { type: m[1] });
}
const EXT: Record<string, string> = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp" };
/** Envia a foto para fotos/<conta>/<nome>. Reenvio do mesmo nome conta como já enviado. */
async function uploadPhoto(dataUrl: string, name: string): Promise<string> {
  const blob = dataUrlToBlob(dataUrl);
  if (!EXT[blob.type]) throw new ApiError(400, "Use uma foto JPG, PNG ou WebP.", "foto");
  if (blob.size > 2 * 1024 * 1024) throw new ApiError(400, "A foto passou de 2 MB. Escolha outra ou remova a foto.", "foto");
  await accessToken();
  const path = `${currentUserId()}/${name}.${EXT[blob.type]}`;
  try {
    await q(`/storage/v1/object/${BUCKET}/${path}`, { method: "POST", raw: blob, headers: { "Content-Type": blob.type, "cache-control": "31536000" }, timeoutMs: 60000 });
  } catch (e) {
    if ((e as ApiError).code !== "existe") throw e;
  }
  return path;
}
function removePhoto(path?: string | null) {
  if (!path) return;
  void q(`/storage/v1/object/${BUCKET}/${path}`, { method: "DELETE" }).catch(() => undefined);
}
const pathFromUrl = (url?: string) => {
  const pre = `${SB_URL}/storage/v1/object/public/${BUCKET}/`;
  return url && url.startsWith(pre) ? decodeURIComponent(url.slice(pre.length)) : undefined;
};
const rand = () => Math.random().toString(36).slice(2, 8);

export async function createPost(p: Post): Promise<Post> {
  const photo_path = p.photo?.startsWith("data:") ? await uploadPhoto(p.photo, p.id) : (pathFromUrl(p.photo) ?? null);
  try {
    await q(`/rest/v1/posts`, {
      method: "POST",
      body: {
        id: p.id,
        category: p.category,
        text: p.text,
        lang: p.lang ?? null,
        lat: p.lat,
        lon: p.lon,
        approx: !!p.approx,
        municipio: p.municipio ?? null,
        observed_at: p.observedAt,
        community_ids: p.communityIds ?? [],
        photo_path,
        radar: p.radar ?? null,
      },
    });
  } catch (e) {
    if ((e as ApiError).code !== "existe") throw e; // reenvio depois de uma resposta perdida: já está lá
  }
  return getPost(p.id);
}

export type PostPatch = Partial<Pick<Post, "category" | "text" | "lat" | "lon" | "approx" | "observedAt" | "communityIds" | "municipio" | "lang">> & { photo?: string | null };
export async function updatePost(id: string, patch: PostPatch): Promise<Post> {
  const body: Record<string, unknown> = {};
  if (patch.category !== undefined) body.category = patch.category;
  if (patch.text !== undefined) body.text = patch.text;
  if (patch.lang !== undefined) body.lang = patch.lang;
  if (patch.lat !== undefined) body.lat = patch.lat;
  if (patch.lon !== undefined) body.lon = patch.lon;
  if (patch.approx !== undefined) body.approx = patch.approx;
  if (patch.municipio !== undefined) body.municipio = patch.municipio;
  if (patch.observedAt !== undefined) body.observed_at = patch.observedAt;
  if (patch.communityIds !== undefined) body.community_ids = patch.communityIds;
  let oldPath: string | null | undefined;
  if (patch.photo !== undefined) {
    const cur = await q<{ photo_path: string | null }[]>(`/rest/v1/posts?id=${eq(id)}&select=photo_path`);
    oldPath = cur[0]?.photo_path;
    body.photo_path = patch.photo === null ? null : patch.photo.startsWith("data:") ? await uploadPhoto(patch.photo, `${id}-${rand()}`) : (pathFromUrl(patch.photo) ?? oldPath ?? null);
  }
  const rows = await q<unknown[]>(`/rest/v1/posts?id=${eq(id)}`, { method: "PATCH", body, headers: REP });
  if (!rows.length) throw new ApiError(404, "Este relato não existe mais ou não é seu.", "nao_encontrado");
  if (oldPath && oldPath !== body.photo_path) removePhoto(oldPath);
  return getPost(id);
}
export async function setRadar(id: string, radar: Post["radar"]): Promise<Post> {
  const rows = await q<unknown[]>(`/rest/v1/posts?id=${eq(id)}`, { method: "PATCH", body: { radar: radar ?? null }, headers: REP });
  if (!rows.length) throw new ApiError(404, "Este relato não existe mais ou não é seu.", "nao_encontrado");
  return getPost(id);
}
export async function deletePost(id: string): Promise<void> {
  const rows = await q<{ photo_path: string | null }[]>(`/rest/v1/posts?id=${eq(id)}`, { method: "DELETE", headers: REP });
  removePhoto(rows[0]?.photo_path); // zero linhas: já tinha sido apagado
}

/* ------------------------------ comentários ------------------------------ */
export async function listComments(postId: string) {
  const rows = await q<CommentRow[]>(`/rest/v1/comment_feed?select=*&post_id=${eq(postId)}&order=created_at.asc&limit=500`);
  return rows.map(toComment);
}
export async function createComment(c: { id: string; postId: string; text: string; lang?: string }) {
  try {
    await q(`/rest/v1/comments`, { method: "POST", body: { id: c.id, post_id: c.postId, text: c.text, lang: c.lang ?? null } });
  } catch (e) {
    const err = e as ApiError;
    if (err.code === "permissao") throw new ApiError(404, "Este relato não aceita mais comentários (foi apagado ou ocultado).", "nao_encontrado");
    if (err.code !== "existe") throw e;
  }
  const rows = await q<CommentRow[]>(`/rest/v1/comment_feed?select=*&id=${eq(c.id)}`);
  if (!rows[0]) throw new ApiError(404, "Comentário não encontrado.", "nao_encontrado");
  return toComment(rows[0]);
}
export async function deleteComment(id: string): Promise<void> {
  await q(`/rest/v1/comments?id=${eq(id)}`, { method: "DELETE" });
}

/* ------------------------------ denúncias e moderação ------------------------------ */
export async function report(postId: string, reason: string): Promise<void> {
  try {
    await q(`/rest/v1/reports`, { method: "POST", body: { post_id: postId, reason } });
  } catch (e) {
    const err = e as ApiError;
    if (err.code === "existe") return; // a mesma pessoa já denunciou este relato
    if (err.code === "permissao") throw new ApiError(404, "Este relato não existe mais.", "nao_encontrado");
    throw e;
  }
}
export interface MyReportItem {
  id: string;
  post_id: string;
  reason: string;
  status: string;
  created_at: string;
}
export async function myReports(): Promise<MyReportItem[]> {
  await accessToken();
  return q<MyReportItem[]>(`/rest/v1/reports?select=id,post_id,reason,status,created_at&reporter_id=${eq(currentUserId()!)}&order=created_at.desc&limit=100`);
}
export interface ModItem {
  id: string;
  post_id: string;
  reason: string;
  created_at: string;
  status: string;
  reporter: string;
  post_text?: string;
  post_status?: string;
}
export async function moderationQueue(): Promise<ModItem[]> {
  const rows = await q<(Omit<ModItem, "reporter"> & { reporter_handle: string })[]>(`/rest/v1/moderation_queue?select=*&order=created_at.asc&limit=200`);
  return rows.map(({ reporter_handle, ...r }) => ({ ...r, reporter: reporter_handle }));
}
export async function moderate(reportId: string, action: "manter" | "ocultar"): Promise<void> {
  await q(`/rest/v1/rpc/moderate_report`, { method: "POST", body: { report_id: reportId, decision: action === "ocultar" ? "ocultado" : "mantido" } });
}

/* ------------------------------ atividade ------------------------------ */
export interface ActivityItem {
  commentId: string;
  postId: string;
  text: string;
  at: string;
  author: { displayName: string };
  postText: string;
}
export async function activity(): Promise<ActivityItem[]> {
  const rows = await q<{ id: string; post_id: string; text: string; created_at: string; author_name: string; post_text: string }[]>(
    `/rest/v1/activity?select=*&order=created_at.desc&limit=100`,
  );
  return rows.map((r) => ({ commentId: r.id, postId: r.post_id, text: r.text, at: iso(r.created_at), author: { displayName: r.author_name }, postText: r.post_text }));
}

/* ------------------------------ administração ------------------------------ */
export async function setPostStatus(id: string, status: "visivel" | "oculto"): Promise<void> {
  const rows = await q<unknown[]>(`/rest/v1/posts?id=${eq(id)}`, { method: "PATCH", body: { status }, headers: REP });
  if (!rows.length) throw new ApiError(404, "Este relato não existe mais.", "nao_encontrado");
}
export async function verifyPost(id: string, verified = true): Promise<void> {
  const rows = await q<unknown[]>(`/rest/v1/posts?id=${eq(id)}`, { method: "PATCH", body: { verified }, headers: REP });
  if (!rows.length) throw new ApiError(404, "Este relato não existe mais.", "nao_encontrado");
}
/** Fila da administração: relatos visíveis ainda não verificados, do mais antigo para o mais novo. */
export async function unverifiedQueue(): Promise<Post[]> {
  const rows = await q<FeedRow[]>(`/rest/v1/feed?select=*&verified=eq.false&status=eq.visivel&order=published_at.asc&limit=200`);
  return rows.map(toPost);
}

/* ------------------------------ registro da própria pessoa ------------------------------ */
export interface ReportLogItem {
  id: string;
  created_at: string;
  reason: string;
  status: string;
  reviewed_at: string | null;
  post_id: string;
  category: Post["category"] | null;
  municipio: string | null;
  lat: number | null;
  lon: number | null;
  approx: boolean | null;
}
export async function myReportLog(): Promise<ReportLogItem[]> {
  return q<ReportLogItem[]>(`/rest/v1/rpc/my_report_log`, { method: "POST", body: {} });
}
