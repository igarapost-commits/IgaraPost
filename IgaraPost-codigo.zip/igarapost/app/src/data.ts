import { LANG, tr3 } from "./i18n/lang";
import React from "react";

/* ---------------- tipos dos arquivos preparados pelo pipeline (data-pipeline/) ---------------- */
export interface FireFile {
  source: string;
  url: string;
  files: string[];
  retrieved: string;
  t0: string;
  last_detection: string;
  bbox: [number, number, number, number];
  satellite: string;
  municipios: string[];
  rows: [number, number, number, number, number | null, number | null, number | null][];
}
export interface FiresSummary {
  source: string;
  url: string;
  retrieved: string;
  update: string;
  last_detection: string;
  bbox: [number, number, number, number];
  months: string[];
  regional: { scope: string; counts: Record<string, Record<string, number>> };
  municipal: { scope: string; counts: Record<string, Record<string, Record<string, number>>> };
}
export interface Fire {
  lat: number;
  lon: number;
  t: number;
  mun: string;
  frp: number | null;
  semChuva: number | null;
  risco: number | null;
  sat: string;
}
type Geom = { type: "Polygon"; coordinates: number[][][] } | { type: "MultiPolygon"; coordinates: number[][][][] };
/** Arquivo com as geometrias dos municípios (usadas para achar o município de um ponto). Os índices de seca dele não são mais usados. */
export interface CemadenFile {
  source: string;
  url: string;
  wfs: string;
  products: Record<string, Record<string, Record<string, { nivel: number; referencia: string }>>>;
  geometries: Record<string, { uf: string; geometry: Geom }>;
}
export interface NisarMunStats {
  in_study_km2: number;
  valid_km2: number;
  bright_to_dark_km2: number;
  dark_to_bright_km2: number;
  dark_both_km2: number;
}
export interface NisarSummary {
  aoi: { west: number; east: number; south: number; north: number };
  pair: [string, string];
  grid_res_deg: number;
  px_km2: number;
  registration: Record<string, { iou: number; dx: number; dy: number; scale: number; otsu_threshold: number }>;
  stats: { valid_km2: number; dark_A_km2: number; dark_B_km2: number; dark_to_bright_km2: number; bright_to_dark_km2: number; nodata_frac: number };
  series: { date: string; dark_frac: number; dark_km2: number; crid: string }[];
  series_common_km2: number;
  granules: Record<string, { granule: string; crid: string; pge: string; collection: string; pol: string[]; coverage: string; dir: string; path: number; frame: number; start: string; stop: string; download: string; browse: string }>;
  fire_overlap?: { satellite: string; period: [string, string]; n_fires: number; radius_m: number; frac_fires_near_bright_to_dark: number; frac_fires_near_dark_to_bright: number; frac_random_near_bright_to_dark: number; frac_random_near_dark_to_bright: number; n_random: number };
  by_municipio?: Record<string, NisarMunStats>;
  inventory?: {
    n_products: number;
    groups: { path: number; frame: number; direction: string; mode: string; pol: string; crid: string; n: number; n_full: number; first: string; last: string; collections: string[] }[];
    recommended_pairs: { path: number; frame: number; direction: string; crid: string; pair: [string, string]; why: string }[];
  };
}
export interface Manifest {
  generated: string;
  update_mode: string;
  sources: { id: string; name: string; url: string; retrieved: string; period: string; coverage: string; scale: string; update: string }[];
}
export interface PlacesFile {
  source: string;
  places: [string, string, number, number][];
}

export const DATA = "data/";

/* ---------------- carregamento com cache ---------------- */
const cache = new Map<string, Promise<unknown>>();
export function loadJSON<T>(path: string): Promise<T> {
  if (!cache.has(path)) {
    const p = fetch(DATA + path).then((r) => {
      if (!r.ok) throw new Error(`${path}: HTTP ${r.status}`);
      return r.json();
    });
    p.catch(() => cache.delete(path)); // permite tentar de novo depois de uma falha
    cache.set(path, p);
  }
  return cache.get(path) as Promise<T>;
}

/** Recarrega os arquivos de dados do app (usado pelo "arrastar para atualizar"). */
let dataRev = 0;
const revSubs = new Set<() => void>();
export async function reloadData() {
  const paths = [...cache.keys()];
  cache.clear();
  await Promise.allSettled(paths.map((p) => loadJSON(p)));
  dataRev++;
  revSubs.forEach((f) => f());
}
function useDataRev() {
  return React.useSyncExternalStore(
    (cb) => {
      revSubs.add(cb);
      return () => revSubs.delete(cb);
    },
    () => dataRev,
  );
}

export type Load<T> = { data?: T; error?: string; loading: boolean };
export function useData<T>(path: string | null): Load<T> {
  const rev = useDataRev();
  const [st, set] = React.useState<Load<T>>({ loading: !!path });
  React.useEffect(() => {
    if (!path) return set({ loading: false });
    let alive = true;
    set((s) => ({ ...s, loading: true }));
    loadJSON<T>(path)
      .then((d) => alive && set({ data: d, loading: false }))
      // numa recarga que falhe, o que já estava carregado continua na tela
      .catch((e) => alive && set((s) => (s.data ? { data: s.data, loading: false } : { error: String(e.message || e), loading: false })));
    return () => {
      alive = false;
    };
  }, [path, rev]);
  return st;
}

const fireCache = new Map<string, Fire[]>();
export function parseFires(f: FireFile): Fire[] {
  if (fireCache.has(f.satellite)) return fireCache.get(f.satellite)!;
  const t0 = Date.parse(f.t0.replace("Z", ":00Z"));
  const out = f.rows.map((r) => ({ lat: r[0], lon: r[1], t: t0 + r[2] * 60000, mun: f.municipios[r[3]], frp: r[4], semChuva: r[5], risco: r[6], sat: f.satellite }));
  fireCache.set(f.satellite, out);
  return out;
}
export function useFires(sat: string | null) {
  const { data, error, loading } = useData<FireFile>(sat ? `fires_${sat}.json` : null);
  const fires = React.useMemo(() => (data ? parseFires(data) : undefined), [data]);
  return { meta: data, fires, error, loading };
}

/* ---------------- estados de consulta de dados ---------------- */
/**
 * Diferencia os casos que a interface nunca deve confundir:
 *  encontrado     = há registros nos dados consultados
 *  nenhum         = nenhum registro encontrado nos dados consultados (não garante ausência do fenômeno)
 *  sem_periodo    = não há dado para o período pedido
 *  fora           = o local está fora da cobertura da fonte
 *  carregando / falha = arquivo ainda carregando ou não carregou
 */
export type DataStatus = "encontrado" | "nenhum" | "sem_periodo" | "fora" | "carregando" | "falha";
export const ABSENCE_NOTE = "Nenhum registro nos dados consultados não garante que não houve fogo.";

/* ---------------- geografia ---------------- */
export function distKm(aLat: number, aLon: number, bLat: number, bLon: number) {
  const R = 6371,
    r = Math.PI / 180;
  const dLat = (bLat - aLat) * r,
    dLon = (bLon - aLon) * r;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(aLat * r) * Math.cos(bLat * r) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}
function inRing(lon: number, lat: number, ring: number[][]) {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [xi, yi] = ring[i],
      [xj, yj] = ring[j];
    if (yi > lat !== yj > lat && lon < ((xj - xi) * (lat - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}
function inPoly(lon: number, lat: number, poly: number[][][]) {
  if (!inRing(lon, lat, poly[0])) return false;
  for (let k = 1; k < poly.length; k++) if (inRing(lon, lat, poly[k])) return false;
  return true;
}
export function municipioAt(c: CemadenFile | undefined, lat: number, lon: number): string | undefined {
  if (!c) return undefined;
  for (const [nome, { geometry: g }] of Object.entries(c.geometries)) {
    const polys = g.type === "Polygon" ? [g.coordinates] : g.coordinates;
    if (polys.some((p) => inPoly(lon, lat, p))) return nome;
  }
  return undefined;
}
export function municipioBounds(c: CemadenFile, names: string[]): [[number, number], [number, number]] | undefined {
  let s = 90,
    w = 180,
    n = -90,
    e = -180;
  for (const nm of names) {
    const g = c.geometries[nm]?.geometry;
    if (!g) continue;
    const polys = g.type === "Polygon" ? [g.coordinates] : g.coordinates;
    polys.forEach((p) =>
      p[0].forEach(([x, y]) => {
        s = Math.min(s, y);
        n = Math.max(n, y);
        w = Math.min(w, x);
        e = Math.max(e, x);
      }),
    );
  }
  return s < n ? [[s, w], [n, e]] : undefined;
}
export function inBox(lat: number, lon: number, b: [number, number, number, number]) {
  return lon >= b[0] && lon <= b[2] && lat >= b[1] && lat <= b[3];
}

/* ---------------- NISAR: relação temporal com uma observação ---------------- */
export function nisarTiming(s: NisarSummary, obsIso: string) {
  const t = Date.parse(obsIso);
  const at = (d: string) => Date.parse(d + "T22:16:00Z");
  const [a, b] = s.pair;
  const relation = t < at(a) ? "antes" : t <= at(b) ? "entre" : "depois";
  const dates = s.series.map((x) => x.date);
  const before = [...dates].reverse().find((d) => at(d) <= t);
  const after = dates.find((d) => at(d) > t);
  const days = (d: string) => Math.round(Math.abs(at(d) - t) / 864e5);
  const text =
    relation === "antes"
      ? `A observação é anterior às duas imagens comparadas (${fmtDay(a)} e ${fmtDay(b)}). A comparação mostra mudanças que aconteceram depois dela.`
      : relation === "entre"
        ? `A observação fica entre as duas imagens comparadas (${fmtDay(a)} e ${fmtDay(b)}).`
        : `A observação é posterior às duas imagens comparadas (${fmtDay(a)} e ${fmtDay(b)}). A comparação mostra mudanças que aconteceram antes dela.`;
  const near = [before && `passagem anterior mais próxima: ${fmtDay(before)} (${days(before)} dias antes)`, after && `passagem seguinte: ${fmtDay(after)} (${days(after)} dias depois)`]
    .filter(Boolean)
    .join("; ");
  return { relation, text, near: near || "nenhuma passagem processada perto dessa data" };
}

/* ---------------- busca de localidades ---------------- */
export interface PlaceHit {
  name: string;
  type: string;
  lat: number;
  lon: number;
  detail?: string;
}
export const norm = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .trim();
const PLACE_TYPE: Record<string, string> = { city: "cidade", town: "cidade", village: "vila", hamlet: "comunidade", locality: "localidade", municipio: "município" };
export function searchPlaces(q: string, places: PlacesFile | undefined, cem: CemadenFile | undefined, max = 8): PlaceHit[] {
  const n = norm(q);
  if (n.length < 2) return [];
  const hits: (PlaceHit & { score: number })[] = [];
  if (cem)
    for (const nome of Object.keys(cem.geometries)) {
      const nn = norm(nome);
      if (!nn.includes(n)) continue;
      const b = municipioBounds(cem, [nome])!;
      hits.push({ name: nome, type: "município", lat: (b[0][0] + b[1][0]) / 2, lon: (b[0][1] + b[1][1]) / 2, detail: cem.geometries[nome].uf, score: nn.startsWith(n) ? 0 : 1 });
    }
  for (const [name, type, lat, lon] of places?.places ?? []) {
    const nn = norm(name);
    if (!nn.includes(n)) continue;
    hits.push({ name, type: PLACE_TYPE[type] || type, lat, lon, detail: municipioAt(cem, lat, lon), score: (nn.startsWith(n) ? 0 : 2) + (type === "hamlet" ? 0.5 : 0) });
  }
  return hits.sort((a, b) => a.score - b.score || a.name.localeCompare(b.name)).slice(0, max);
}

/* ---------------- datas ---------------- */
const MESES = {
  pt: ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"],
  en: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
  es: ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sept", "oct", "nov", "dic"],
}[LANG];
const MESES_LONGO = {
  pt: ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"],
  en: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
  es: ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"],
}[LANG];
export function fmtDate(iso: string | number, withTime = false) {
  const d = new Date(iso);
  const s = LANG === "en" ? `${MESES[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}` : `${d.getDate()} ${MESES[d.getMonth()]} ${d.getFullYear()}`;
  return withTime ? `${s}${LANG === "en" ? "," : ","} ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}` : s;
}
export const fmtDay = (ymd: string) => fmtDate(ymd + "T12:00:00");
export function fmtMonth(ym: string) {
  const [y, m] = ym.split("-").map(Number);
  return `${MESES_LONGO[m - 1]}/${y}`;
}
export function fmtUTC(t: number) {
  const d = new Date(t);
  const day = LANG === "en" ? `${MESES[d.getUTCMonth()]} ${d.getUTCDate()}, ${d.getUTCFullYear()}` : `${d.getUTCDate()} ${MESES[d.getUTCMonth()]} ${d.getUTCFullYear()}`;
  return `${day}, ${String(d.getUTCHours()).padStart(2, "0")}:${String(d.getUTCMinutes()).padStart(2, "0")} UTC`;
}
export function relTime(iso: string) {
  const s = (Date.now() - Date.parse(iso)) / 1000;
  const ago = (n: number, u: string) => tr3(`há ${n} ${u}`, `${n} ${u} ago`, `hace ${n} ${u}`);
  if (s < 60) return tr3("agora", "just now", "ahora");
  if (s < 3600) return ago(Math.floor(s / 60), "min");
  if (s < 86400) return ago(Math.floor(s / 3600), "h");
  if (s < 86400 * 30) return ago(Math.floor(s / 86400), "d");
  return fmtDate(iso);
}
export function ymOf(iso: string | number) {
  const d = new Date(iso);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

/** Intervalo [início, fim] em ms do filtro de período. "r<início>_<fim>" = janela de um relato. */
export function periodRange(p: string): [number, number] {
  const now = Date.now();
  if (p === "7d") return [now - 7 * 864e5, now];
  if (p === "30d") return [now - 30 * 864e5, now];
  if (p === "90d") return [now - 90 * 864e5, now];
  if (p.startsWith("m")) {
    const [y, m] = p.slice(1).split("-").map(Number);
    return [Date.UTC(y, m - 1, 1), Date.UTC(y, m, 1) - 1];
  }
  if (p.startsWith("r")) {
    const [a, b] = p.slice(1).split("_").map(Number);
    return [a, b];
  }
  return [0, now];
}
export function periodLabel(p: string) {
  const o = PERIOD_OPTIONS.find((x) => x.value === p);
  if (o) return o.label;
  const [a, b] = periodRange(p);
  return `${fmtDate(a)} a ${fmtDate(b)}`;
}
export const PERIOD_OPTIONS: { value: string; label: string }[] = [
  { value: "7d", label: "Últimos 7 dias" },
  { value: "30d", label: "Últimos 30 dias" },
  { value: "90d", label: "Últimos 90 dias" },
  { value: "m2026-07", label: "Julho de 2026" },
  { value: "m2026-08", label: "Agosto de 2026" },
  { value: "m2026-09", label: "Setembro de 2026" },
  { value: "m2026-10", label: "Outubro de 2026" },
  { value: "m2026-11", label: "Novembro de 2026" },
  { value: "all", label: "Todo o período" },
];
