/**
 * Tipo de ocorrência. Os seis primeiros são os oferecidos no formulário "Relatar"
 * "falta_chuva", "cheia" e "reducao_agua" (secas e cheias) saíram do app na 0.5.0: ficam no tipo só para não quebrar
 * relatos antigos guardados no aparelho, que deixam de aparecer. "impacto" é de versões anteriores.
 */
export type Category = "fumaca" | "queimada" | "enchente" | "falta_chuva" | "cheia" | "outro" | "reducao_agua" | "impacto";
export const REPORT_CATEGORIES: Category[] = ["fumaca", "queimada", "enchente", "outro"];

/** Resultado da conferência do relato com os dados do SARS (ver sars/radar.ts). */
export type RadarStatus = "no_radar" | "fora_do_radar" | "nao_verificado" | "confirmado";
export interface RadarCheck {
  status: RadarStatus;
  detail: string;
  checkedAt: string;
  evidence?: { kind: "focos" | "imagem" | "seca"; n?: number; nearestKm?: number; layer?: string; date?: string };
  /** última reconferência que não trouxe dado novo */
  recheckedAt?: string;
  /** primeira conferência, guardada quando o estado muda */
  firstCheck?: Omit<RadarCheck, "firstCheck">;
}

/** Origem da informação: define o selo exibido e como ela pode ser interpretada. */
export type PostKind =
  | "community" // relato da comunidade (não verificado)
  | "official" // publicação da equipe elaborada com dados de fonte oficial (INPE)
  | "nisar" // análise experimental da equipe com dados NISAR
  | "explainer"; // publicação explicativa

/**
 * Onde o relato está, de fato:
 *  local     = salvo apenas neste aparelho (modo sem servidor)
 *  pendente  = salvo no aparelho, aguardando conexão para envio
 *  enviando  = envio em andamento
 *  falhou    = o servidor recusou; precisa de correção ou nova tentativa
 *  publicado = confirmado pelo servidor, visível para outras pessoas
 *  oculto    = publicado, mas ocultado após revisão de denúncia
 */
export type SyncState = "local" | "pendente" | "enviando" | "falhou" | "publicado" | "oculto";

export interface Author {
  id: string;
  name: string;
  handle?: string;
  example?: boolean;
  role?: string;
  /** foto de perfil (data URL pequena, guardada só no aparelho) */
  photo?: string;
  /** frase curta sobre a pessoa */
  bio?: string;
  /** cidade ou comunidade */
  place?: string;
}

export interface Post {
  id: string;
  /** idioma em que o texto foi escrito (pt, en ou es); quando falta, é detectado pelo texto */
  lang?: string;
  kind: PostKind;
  authorId: string;
  author?: Author; // posts do servidor trazem o autor
  category: Category;
  title?: string;
  text: string;
  photo?: string; // dataURL (local/pendente) ou URL absoluta (servidor)
  lat?: number;
  lon?: number;
  approx?: boolean;
  municipio?: string;
  observedAt: string;
  publishedAt: string;
  communityIds: string[];
  example?: boolean;
  /** abrangência de publicações com números: regional, municipal etc. */
  scopeLabel?: string;
  source?: { name: string; url?: string; period: string; retrieved?: string; note?: string; method?: string };
  cta?: { label: string; hash: string };
  editedAt?: string;
  sync?: SyncState;
  syncError?: string;
  commentCount?: number;
  mine?: boolean;
  /** conferência com o SARS feita no envio e refeita em Perfil › Meus relatos */
  radar?: RadarCheck;
  /** conferido pela administração */
  verified?: boolean;
}

export interface Comment {
  id: string;
  /** idioma em que o comentário foi escrito; quando falta, é detectado pelo texto */
  lang?: string;
  postId: string;
  authorId: string;
  author?: Author;
  text: string;
  at: string;
  example?: boolean;
  sync?: SyncState;
  mine?: boolean;
}

export interface Community {
  id: string;
  name: string;
  kind: "territorio" | "tema";
  description: string;
  municipios?: string[];
  categories?: Category[];
}

export interface Report {
  id: string;
  postId: string;
  reason: string;
  at: string;
  status: "pendente" | "mantido" | "ocultado";
}

/** "7d" | "30d" | "90d" | "all" | "mAAAA-MM" | "r<inicioMs>_<fimMs>" */
export type Period = string;

/** all | following | mun:<nome> | com:<id> */
export type Scope = string;

export interface Filters {
  scope: Scope;
  category: Category | "all";
  period: Period;
  kinds: PostKind[];
  examples: boolean;
}

/** Dados do formulário de publicação (também usados como rascunho). */
export interface DraftData {
  editId?: string;
  step: 1 | 2 | 3;
  category?: Category;
  text: string;
  observedAt: string; // valor do input datetime-local
  lat?: number;
  lon?: number;
  approx: boolean;
  photo?: string;
  /** precisão informada pelo GPS do aparelho, em metros */
  accuracyM?: number;
  communityIds: string[];
  radar?: RadarCheck;
  savedAt?: string;
}

export type OutboxOp =
  | { op: "createPost"; post: Post }
  | { op: "updatePost"; id: string; patch: Omit<Partial<Post>, "photo"> & { photo?: string | null } }
  | { op: "deletePost"; id: string }
  | { op: "createComment"; comment: Comment }
  | { op: "deleteComment"; id: string; postId: string }
  | { op: "report"; postId: string; reason: string }
  | { op: "setFollows"; ids: string[] }
  | { op: "setRadar"; id: string; radar: RadarCheck };

export type OutboxItem = OutboxOp & { qid: string; state: "pendente" | "enviando" | "falhou"; error?: string; attempts: number; createdAt: string };

export interface ServerUser {
  id: string;
  handle: string;
  displayName: string;
  role: "usuario" | "moderador";
  /** foto de perfil na rede (link público) */
  photo?: string;
}
