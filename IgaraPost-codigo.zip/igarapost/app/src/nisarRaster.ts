import type { NisarSummary } from "./data";
import { DATA } from "./data";

/**
 * Lê a camada de mudança NISAR (PNG preparado pelo pipeline) num canvas para consultar a classe
 * de cada pixel. Cores (definidas em process_nisar_browse.py):
 *   laranja  (230,120,20) = escuro -> claro    azul-claro (40,200,230) = claro -> escuro
 *   azul     (30,90,160)  = escuro nas duas    cinza (128,128,128) = sem dados em uma das datas
 *   transparente = claro nas duas datas
 */
let raster: Promise<ImageData> | undefined;
function load(): Promise<ImageData> {
  if (!raster)
    raster = new Promise((res, rej) => {
      const img = new Image();
      img.onload = () => {
        const c = document.createElement("canvas");
        c.width = img.naturalWidth;
        c.height = img.naturalHeight;
        const g = c.getContext("2d")!;
        g.drawImage(img, 0, 0);
        res(g.getImageData(0, 0, c.width, c.height));
      };
      img.onerror = () => rej(new Error("camada NISAR indisponível"));
      img.src = DATA + "nisar/nisar_change_dark.png";
    });
  return raster;
}

export interface NisarPoint {
  inside: boolean;
  center?: "estavel_claro" | "estavel_escuro" | "escureceu" | "clareou" | "sem_dados";
  km2: { escureceu: number; clareou: number; estavel_escuro: number; sem_dados: number; total: number };
}

export async function nisarAt(s: NisarSummary, lat: number, lon: number, radiusKm = 1): Promise<NisarPoint> {
  const empty = { escureceu: 0, clareou: 0, estavel_escuro: 0, sem_dados: 0, total: 0 };
  const { west, east, south, north } = s.aoi;
  if (lon < west || lon > east || lat < south || lat > north) return { inside: false, km2: empty };
  const im = await load();
  const res = s.grid_res_deg;
  const cls = (x: number, y: number) => {
    const i = (y * im.width + x) * 4,
      d = im.data;
    if (d[i + 3] === 0) return "estavel_claro" as const;
    if (d[i] === 230 && d[i + 1] === 120) return "clareou" as const;
    if (d[i] === 40 && d[i + 1] === 200) return "escureceu" as const;
    if (d[i] === 30 && d[i + 1] === 90) return "estavel_escuro" as const;
    return "sem_dados" as const;
  };
  const cx = Math.floor((lon - west) / res),
    cy = Math.floor((north - lat) / res);
  const r = Math.ceil(radiusKm / (res * 111.32));
  const km2 = { ...empty };
  for (let y = cy - r; y <= cy + r; y++)
    for (let x = cx - r; x <= cx + r; x++) {
      if (x < 0 || y < 0 || x >= im.width || y >= im.height || (x - cx) ** 2 + (y - cy) ** 2 > r * r) continue;
      const c = cls(x, y);
      km2.total += s.px_km2;
      if (c !== "estavel_claro") km2[c] += s.px_km2;
    }
  return { inside: true, center: cls(Math.min(cx, im.width - 1), Math.min(cy, im.height - 1)), km2 };
}

export const NISAR_CLASS_LABEL: Record<string, string> = {
  estavel_claro: "sem mudança (claro nas duas datas)",
  estavel_escuro: "escuro nas duas datas (provável água)",
  escureceu: "passou a aparecer escuro",
  clareou: "deixou de aparecer escuro",
  sem_dados: "sem dados em uma das datas",
};
