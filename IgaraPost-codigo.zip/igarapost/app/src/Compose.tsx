import React from "react";
import type { DraftData, Post, RadarCheck } from "./types";
import { REPORT_CATEGORIES } from "./types";
import { Icon } from "./Icon";
import { detectLang } from "./i18n/userText";
import { LANG } from "./i18n/lang";
import { go, useApp } from "./ctx";
import { commit, setSoft, StorageError, uid, useStore } from "./store";
import { bgStyle, CATEGORIES, CATEGORY_BG, COMMUNITIES, inReportArea, POST_BORDER, REPORT_AREA_MSG } from "./seed";
import { fmtDate, municipioAt, searchPlaces, useData, type PlaceHit, type PlacesFile } from "./data";
import { LocationPicker } from "./MapView";
import { draftLocation } from "./draft";
import { enqueue, usePeoplePosts } from "./sync";
import { RadarChip } from "./PostCard";
import { radarCheck } from "./sars/radar";
import { useLive } from "./sars/live";
import { SARS } from "./sars/config";

function localInput(d: Date) {
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
}

/** Reduz a foto para no máximo 960 px e JPEG ~70% antes de salvar ou enviar. */
function compress(file: File): Promise<string> {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const s = Math.min(1, 960 / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * s);
      c.height = Math.round(img.height * s);
      c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      res(c.toDataURL("image/jpeg", 0.7));
    };
    img.onerror = () => rej(new Error("Não foi possível ler essa imagem."));
    img.src = url;
  });
}
const kb = (dataUrl: string) => Math.round((dataUrl.length * 3) / 4 / 1024);

export function LocalitySearch({ onPick, id = "loc-search" }: { onPick: (lat: number, lon: number, name: string, hit: PlaceHit) => void; id?: string }) {
  const { cemaden } = useApp();
  const places = useData<PlacesFile>("osm/places.json");
  const [q, setQ] = React.useState("");
  const hits = searchPlaces(q, places.data, cemaden);
  return (
    <div className="stack" style={{ gap: 6 }}>
      <input id={id} className="input" type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Busque município ou comunidade (ex.: Careiro, Lago do Rei)" autoComplete="off" />
      {places.error && <span className="small muted">Lista de comunidades indisponível; a busca usa só os municípios.</span>}
      {q.length >= 2 && (
        <ul className="hits" role="listbox">
          {hits.map((h) => (
            <li key={`${h.name}-${h.lat}`}>
              <button
                type="button"
                onClick={() => {
                  onPick(h.lat, h.lon, h.name, h);
                  setQ("");
                }}
              >
                <b>{h.name}</b> <span className="muted small">{[h.type, h.detail].filter(Boolean).join(" · ")}</span>
              </button>
            </li>
          ))}
          {!hits.length && <li className="small muted">Nada encontrado com esse nome. Toque no mapa para escolher o local.</li>}
        </ul>
      )}
    </div>
  );
}

const STEPS = ["O que aconteceu", "Onde e quando", "Foto e envio"];

type Geo = { state: "idle" | "buscando" | "ok" | "erro"; msg?: string; accuracy?: number };

/**
 * Tela "Relatar": notificação de uma ocorrência ambiental que ainda não aparece no radar do SARS.
 * 1) tipo + descrição; 2) local exato (GPS, mapa ou busca) e data, com conferência automática no SARS;
 * 3) foto e revisão. O rascunho fica gravado no aparelho a cada alteração.
 */
export function Compose({ editId }: { editId?: string }) {
  const st = useStore();
  const { cemaden, cemadenFailed, toast } = useApp();
  const live = useLive();
  const people = usePeoplePosts();
  const editing = editId ? people.find((p) => p.id === editId && p.mine) : undefined;
  const shared = !!st.server.url; // sem conta ainda (primeira vez sem internet): vai para a fila e sai sozinho depois
  const fromDraft = st.draft && (st.draft.editId ?? undefined) === editId ? st.draft : undefined;

  const blank = (): DraftData => ({ step: 1, text: "", observedAt: localInput(new Date()), lat: draftLocation.lat, lon: draftLocation.lon, approx: false, communityIds: [] });
  const initial = (): DraftData => {
    if (fromDraft) return fromDraft;
    if (editing)
      return {
        editId,
        step: 1,
        category: editing.category,
        text: editing.text,
        observedAt: localInput(new Date(editing.observedAt)),
        lat: editing.lat,
        lon: editing.lon,
        approx: !!editing.approx,
        photo: editing.photo,
        communityIds: editing.communityIds,
        radar: editing.radar,
      };
    return blank();
  };
  const [d, setD] = React.useState<DraftData>(initial);
  const set = (patch: Partial<DraftData>) => setD((x) => ({ ...x, ...patch }));
  const [err, setErr] = React.useState("");
  // o rascunho é salvo em silêncio; só uma falha ao salvar aparece na tela
  const [draftErr, setDraftErr] = React.useState("");
  // atalho de horário escolhido; o campo de data e hora só fica editável em "Personalizar"
  const [timePreset, setTimePreset] = React.useState<"agora" | "cedo" | "ontem" | "custom">(() => (editId || fromDraft ? "custom" : "agora"));
  const [geo, setGeo] = React.useState<Geo>({ state: "idle" });
  const [busy, setBusy] = React.useState(false);
  const [checking, setChecking] = React.useState(false);
  const fileCam = React.useRef<HTMLInputElement>(null);
  const fileGal = React.useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    draftLocation.lat = undefined;
    draftLocation.lon = undefined;
  }, []);

  // rascunho: grava no aparelho e só diz "salvo" se a gravação foi confirmada
  const firstRun = React.useRef(true);
  React.useEffect(() => {
    if (firstRun.current) {
      firstRun.current = false;
      return;
    }
    const h = window.setTimeout(() => {
      const draft = { ...d, savedAt: new Date().toISOString() };
      try {
        commit((s) => ({ ...s, draft }));
        setDraftErr("");
      } catch (e) {
        setDraftErr(`O rascunho não pôde ser guardado no aparelho: ${(e as StorageError).message} O que você preencheu continua nesta tela.`);
      }
    }, 700);
    return () => window.clearTimeout(h);
  }, [d]);

  const hasLoc = d.lat != null && d.lon != null && isFinite(d.lat) && isFinite(d.lon);
  const mun = hasLoc ? municipioAt(cemaden, d.lat!, d.lon!) : undefined;
  React.useEffect(() => {
    if (!mun || editing) return;
    const sug = COMMUNITIES.filter((c) => c.municipios?.includes(mun)).map((c) => c.id);
    setD((x) => ({ ...x, communityIds: Array.from(new Set([...x.communityIds, ...sug])) }));
  }, [mun, editing]);

  // conferência com o SARS: refeita quando muda o tipo, o local ou a data
  const liveOk = live.mode === "ao_vivo" || live.mode === "polling" || live.mode === "direto";
  const checkKey = d.category && hasLoc && isFinite(Date.parse(d.observedAt)) ? `${d.category}|${d.lat!.toFixed(4)}|${d.lon!.toFixed(4)}|${d.observedAt}` : "";
  const lastKey = React.useRef(editing && editing.radar ? `${editing.category}|${editing.lat?.toFixed(4)}|${editing.lon?.toFixed(4)}|${localInput(new Date(editing.observedAt))}` : "");
  React.useEffect(() => {
    if (!checkKey || d.step < 2 || checkKey === lastKey.current) return;
    let alive = true;
    const h = window.setTimeout(async () => {
      setChecking(true);
      try {
        const r = await radarCheck({ category: d.category!, lat: d.lat!, lon: d.lon!, observedAt: new Date(d.observedAt).toISOString() }, { fires: live.fires, liveOk, cemaden, cemadenFailed });
        if (!alive) return;
        lastKey.current = checkKey;
        set({ radar: r });
      } finally {
        if (alive) setChecking(false);
      }
    }, 900);
    return () => {
      alive = false;
      window.clearTimeout(h);
    };
    // os focos ao vivo entram na conferência, mas uma atualização deles sozinha não refaz a consulta
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [checkKey, d.step, liveOk, cemaden]);

  if (editId && !editing) return <div className="empty panel">Só é possível editar relatos feitos por você. Ele pode já ter sido excluído.</div>;

  const validStep = (n: number): string => {
    if (n >= 1) {
      if (!d.category) return "Escolha o tipo de ocorrência.";
      if (d.text.trim().length < 10) return "Descreva com pelo menos 10 caracteres.";
    }
    if (n >= 2) {
      if (!hasLoc) return "Marque o local da ocorrência: use o GPS, toque no mapa ou busque a localidade.";
      if (!inReportArea(d.lat!, d.lon!)) return REPORT_AREA_MSG;
      const t = Date.parse(d.observedAt);
      if (!isFinite(t)) return "Informe quando você observou.";
      if (t > Date.now() + 5 * 60000) return "A data da observação não pode estar no futuro.";
    }
    return "";
  };
  const next = () => {
    const e = validStep(d.step);
    setErr(e);
    if (!e) set({ step: (d.step + 1) as 2 | 3 });
    window.scrollTo(0, 0);
  };

  const useDevice = () => {
    if (!("geolocation" in navigator)) return setGeo({ state: "erro", msg: "Este aparelho não oferece localização. Toque no mapa ou busque a localidade." });
    setGeo({ state: "buscando", msg: "Buscando sua posição pelo GPS…" });
    navigator.geolocation.getCurrentPosition(
      (p) => {
        const acc = Math.round(p.coords.accuracy);
        set({ lat: Math.round(p.coords.latitude * 1e6) / 1e6, lon: Math.round(p.coords.longitude * 1e6) / 1e6, accuracyM: acc, approx: false });
        setGeo({ state: "ok", accuracy: acc, msg: acc > 200 ? `Posição recebida, mas com pouca precisão (cerca de ${acc} m). Vá para céu aberto e tente de novo, ou ajuste no mapa.` : `Posição exata recebida (precisão de cerca de ${acc} m).` });
      },
      (e) =>
        setGeo({
          state: "erro",
          msg: e.code === e.PERMISSION_DENIED ? "A localização não foi permitida. Libere nas configurações do aparelho ou marque o local no mapa." : "Não foi possível obter a posição agora. Tente de novo ou marque o local no mapa.",
        }),
      { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 },
    );
  };

  const onPhoto = async (f?: File) => {
    if (!f) return;
    try {
      set({ photo: await compress(f) });
    } catch (x) {
      setErr(String((x as Error).message));
    }
  };

  const send = (asLocal: boolean) => {
    const e = validStep(2);
    if (e) return setErr(e);
    setErr("");
    setBusy(true);
    const r = (v: number) => (d.approx ? Math.round(v / 0.02) * 0.02 : Math.round(v * 1e5) / 1e5);
    const lat = r(d.lat!),
      lon = r(d.lon!);
    const radar: RadarCheck = d.radar ?? { status: "nao_verificado", detail: `A conferência com o ${SARS.name} não terminou antes do envio. Ela é refeita em Perfil › Meus relatos.`, checkedAt: new Date().toISOString() };
    const post: Post = {
      id: editing?.id ?? uid("p"),
      kind: "community",
      authorId: asLocal ? "me" : (st.server.user?.id ?? "me"),
      category: d.category!,
      text: d.text.trim(),
      lang: detectLang(d.text) ?? LANG,
      photo: d.photo,
      lat,
      lon,
      approx: d.approx,
      municipio: municipioAt(cemaden, lat, lon) ?? mun,
      observedAt: new Date(d.observedAt).toISOString(),
      publishedAt: editing?.publishedAt ?? new Date().toISOString(),
      communityIds: d.communityIds,
      editedAt: editing ? new Date().toISOString() : undefined,
      radar,
    };
    try {
      if (asLocal || editing?.sync === "local") {
        commit((s) => ({ ...s, posts: editing ? s.posts.map((p) => (p.id === post.id ? post : p)) : [post, ...s.posts], draft: undefined }));
        toast(editing ? "Alterações salvas neste aparelho" : "Relato salvo neste aparelho");
      } else if (editing) {
        const photo = d.photo === editing.photo ? undefined : d.photo ? d.photo : null;
        enqueue({ op: "updatePost", id: post.id, patch: { category: post.category, text: post.text, lat, lon, approx: post.approx, observedAt: post.observedAt, communityIds: post.communityIds, ...(photo !== undefined ? { photo } : {}) } });
        if (radar !== editing.radar) enqueue({ op: "setRadar", id: post.id, radar });
        setSoft((s) => ({ ...s, draft: undefined }));
        toast(navigator.onLine ? "Enviando alterações…" : "Sem internet: as alterações saem quando a conexão voltar");
      } else {
        enqueue({ op: "createPost", post });
        setSoft((s) => ({ ...s, draft: undefined }));
        toast(navigator.onLine ? "Enviando relato…" : "Sem internet: o relato sai quando a conexão voltar");
      }
      go(`#post-${post.id}`);
    } catch (x) {
      // nada foi gravado: o formulário continua preenchido para tentar de novo
      setErr(x instanceof StorageError ? x.message : `Não foi possível salvar: ${String(x)}`);
    } finally {
      setBusy(false);
    }
  };

  const dest: "shared" | "local" = shared && editing?.sync !== "local" ? "shared" : "local";
  const cat = d.category ? CATEGORIES[d.category] : undefined;

  const radarPanel = (
    <div className={`radar-panel ${checking ? "checking" : d.radar?.status ?? "vazio"}`} role="status" aria-live="polite">
      {!d.category || !hasLoc ? (
        null
      ) : checking ? (
        <span className="small">
          <span className="spin" aria-hidden /> Conferindo com o {SARS.name}…
        </span>
      ) : d.radar ? (
        <>
          <RadarChip r={d.radar} />
          <b>
            {d.radar.status === "fora_do_radar"
              ? "Os satélites e sensores ainda não registram isso aqui."
              : d.radar.status === "no_radar"
                ? `O ${SARS.name} já mostra algo parecido perto daqui.`
                : "Não deu para conferir agora."}
          </b>
          <span className="small">{d.radar.detail}</span>
          <span className="small muted">
            {d.radar.status === "fora_do_radar"
              ? "Seu relato é a informação que falta: ele aparece no mapa com o selo “Fora do radar”."
              : d.radar.status === "no_radar"
                ? "Seu relato continua importante: ele diz o que está acontecendo no chão."
                : "Você pode relatar mesmo assim."}{" "}
            Conferido {fmtDate(d.radar.checkedAt, true)}.
          </span>
        </>
      ) : null}
    </div>
  );

  return (
    <div className="stack compose" style={{ gap: 16 }}>
      <header className="compose-hero">
        <h1>{editing ? "Editar relato" : "Relatar uma ocorrência"}</h1>
        <p className="small muted">Em perigo, ligue 193 (Bombeiros) ou 199 (Defesa Civil). O IgaraPost não é canal de emergência.</p>
      </header>
      <ol className="stepper" aria-label="Etapas">
        {STEPS.map((s, i) => (
          <li key={s} aria-current={d.step === i + 1 ? "step" : undefined} className={d.step > i + 1 ? "done" : ""}>
            <button type="button" onClick={() => (i + 1 < d.step || !validStep(i) ? set({ step: (i + 1) as 1 | 2 | 3 }) : setErr(validStep(i)))}>
              <span className="n">{i + 1}</span> {s}
            </button>
          </li>
        ))}
      </ol>

      {d.step === 1 && (
        <section className="stack" aria-label="O que aconteceu">
          <div className="field">
            <span id="type-label">Tipo de ocorrência</span>
            <div className="type-grid" role="radiogroup" aria-labelledby="type-label">
              {REPORT_CATEGORIES.map((k) => {
                const c = CATEGORIES[k];
                const on = d.category === k;
                return (
                  <button
                    type="button"
                    role="radio"
                    aria-checked={on}
                    key={k}
                    className={`type-tile ${on ? "on" : ""} ${CATEGORY_BG[k] ? `has-bg bg-${k}` : ""}`}
                    style={{ ["--tc" as string]: c.color, ["--tile-border" as string]: POST_BORDER[k] ?? c.color, ...(CATEGORY_BG[k] ? bgStyle(CATEGORY_BG[k]!, [0.12, 0.42, 0.82]) : {}) }}
                    onClick={() => set({ category: k })}
                  >
                    <span className="type-ico">
                      <Icon name={c.icon} size={24} />
                    </span>
                    <b>{c.label}</b>
                    {c.hint && <span className="small muted">{c.hint}</span>}
                  </button>
                );
              })}
            </div>
            {editing && !REPORT_CATEGORIES.includes(editing.category) && d.category === editing.category && (
              <span className="small muted">Este relato usa o tipo antigo “{CATEGORIES[editing.category].label}”. Você pode mantê-lo ou escolher um dos tipos acima.</span>
            )}
          </div>
          <label className="field">
            <span>Descreva o que você viu</span>
            <textarea
              id="c-text"
              className="input"
              rows={4}
              maxLength={1000}
              value={d.text}
              onChange={(e) => set({ text: e.target.value })}
              placeholder={d.category === "enchente" ? "Ex.: A água subiu de madrugada e chegou à escola da comunidade." : "Ex.: Fumaça forte desde o fim da tarde, vindo do lado do ramal."}
            />
            <span className="small muted">{d.text.length}/1000 · sem dados pessoais de outras pessoas</span>
          </label>
        </section>
      )}

      {d.step === 2 && (
        <section className="stack" aria-label="Onde e quando">
          <div className="field">
            <span>Onde?</span>
            <button type="button" className={`btn ${hasLoc && geo.state === "ok" ? "" : "primary"} gps-btn`} onClick={useDevice} disabled={geo.state === "buscando"}>
              {geo.state === "buscando" ? <span className="spin" aria-hidden /> : <Icon name="locate" />} {geo.state === "ok" ? "Atualizar localização" : "Usar minha localização"}
            </button>
            {geo.msg && <span className={`small ${geo.state === "erro" || (geo.accuracy ?? 0) > 200 ? "warn-text" : "muted"}`}>{geo.msg}</span>}
            <LocationPicker lat={d.lat} lon={d.lon} onPick={(lat, lon) => set({ lat, lon, accuracyM: undefined })} />
            <LocalitySearch onPick={(lat, lon) => set({ lat, lon, accuracyM: undefined })} id="c-search" />
            <p className="small">
              {hasLoc ? (
                <>
                  <Icon name="pin" size={14} /> {mun ?? "Local marcado"} · {d.lat!.toFixed(5)}, {d.lon!.toFixed(5)}
                  {d.accuracyM ? ` · GPS ±${d.accuracyM} m` : ""}
                </>
              ) : (
                "Nenhum local marcado ainda."
              )}
            </p>
            <label className="toggle" style={{ fontWeight: 500 }}>
              <input id="c-approx" type="checkbox" checked={d.approx} onChange={(e) => set({ approx: e.target.checked })} /> Mostrar só o local aproximado (~2 km)
            </label>
            <details>
              <summary className="small">Digitar coordenadas</summary>
              <div className="filters-row" style={{ marginTop: 8 }}>
                <label className="field">
                  <span>Latitude</span>
                  <input id="c-lat" className="input" inputMode="decimal" value={d.lat ?? ""} onChange={(e) => set({ lat: e.target.value === "" ? undefined : Number(e.target.value.replace(",", ".")), accuracyM: undefined })} placeholder="-3.1190" />
                </label>
                <label className="field">
                  <span>Longitude</span>
                  <input id="c-lon" className="input" inputMode="decimal" value={d.lon ?? ""} onChange={(e) => set({ lon: e.target.value === "" ? undefined : Number(e.target.value.replace(",", ".")), accuracyM: undefined })} placeholder="-60.0210" />
                </label>
              </div>
            </details>
          </div>
          <div className="field">
            <span>Quando você observou?</span>
            <div className="row time-chips" role="group" aria-label="Atalhos de horário">
              {(
                [
                  ["agora", "Agora", () => new Date()],
                  ["cedo", "Hoje cedo", () => new Date(new Date().setHours(7, 0, 0, 0))],
                  ["ontem", "Ontem", () => new Date(Date.now() - 864e5)],
                  ["custom", "Personalizar", null],
                ] as const
              ).map(([k, l, f]) => (
                <button
                  key={k}
                  type="button"
                  className="chip"
                  aria-pressed={timePreset === k}
                  onClick={() => {
                    setTimePreset(k);
                    if (f) set({ observedAt: localInput(f()) });
                    else window.setTimeout(() => document.getElementById("c-obs")?.focus(), 0);
                  }}
                >
                  {l}
                </button>
              ))}
            </div>
            <input
              id="c-obs"
              className="input"
              type="datetime-local"
              value={d.observedAt}
              max={localInput(new Date())}
              disabled={timePreset !== "custom"}
              onChange={(e) => set({ observedAt: e.target.value })}
            />
          </div>
          {radarPanel}
        </section>
      )}

      {d.step === 3 && (
        <section className="stack" aria-label="Foto e envio">
          <div className="stack photo-section">
            <span className="field-label">Foto (opcional)</span>
            <div className="photo-pick">
              <button type="button" className="btn photo-btn" onClick={() => fileCam.current?.click()}>
                <Icon name="camera" size={26} />
                <span>Tirar foto</span>
              </button>
              <button type="button" className="btn photo-btn" onClick={() => fileGal.current?.click()}>
                <Icon name="image" size={26} />
                <span>Escolher da galeria</span>
              </button>
            </div>
            <input ref={fileCam} id="c-photo-cam" type="file" accept="image/*" capture="environment" hidden onChange={(e) => onPhoto(e.target.files?.[0])} />
            <input ref={fileGal} id="c-photo" type="file" accept="image/*" hidden onChange={(e) => onPhoto(e.target.files?.[0])} />
            {d.photo && (
              <div className="row photo-chosen">
                <img className="photo-preview" src={d.photo} alt="Prévia da foto" />
                <span className="small muted grow">{d.photo.startsWith("data:") ? `${kb(d.photo)} KB depois de reduzida` : "foto já enviada"}</span>
                <button type="button" className="btn sm danger" onClick={() => set({ photo: undefined })}>
                  Remover foto
                </button>
              </div>
            )}
            <p className="small muted photo-hint">Evite rostos e placas de carro.</p>
          </div>
          <div className="panel review" aria-label="Revisão">
            <span className="eyebrow">Revise antes de relatar</span>
            <p className="row" style={{ gap: 8 }}>
              {cat && (
                <span style={{ color: cat.color, display: "inline-flex" }}>
                  <Icon name={cat.icon} />
                </span>
              )}
              <b>{cat?.label}</b>
            </p>
            <p style={{ whiteSpace: "pre-line" }}>{d.text}</p>
            <dl className="kv small">
              <dt>Observado em</dt>
              <dd>{fmtDate(d.observedAt, true)}</dd>
              <dt>Local</dt>
              <dd>
                {mun ?? "fora dos municípios do entorno de Manaus"} · {hasLoc ? `${d.lat!.toFixed(5)}, ${d.lon!.toFixed(5)}` : "—"}
                {d.approx ? " · local aproximado (~2 km)" : " · local exato"}
              </dd>
              <dt>{SARS.name}</dt>
              <dd>{d.radar ? <RadarChip r={d.radar} /> : checking ? "conferindo…" : "não conferido"}</dd>
            </dl>
          </div>
        </section>
      )}

      {err && (
        <div className="callout warn" role="alert">
          {err}
        </div>
      )}
      <div className="row compose-actions">
        {d.step > 1 && (
          <button type="button" className="btn" onClick={() => set({ step: (d.step - 1) as 1 | 2 })}>
            Voltar
          </button>
        )}
        {d.step < 3 ? (
          <button type="button" className="btn primary" onClick={next}>
            Continuar
          </button>
        ) : (
          <button type="button" className="btn primary" disabled={busy} onClick={() => send(dest === "local")}>
            <Icon name="send" /> {editing ? "Salvar alterações" : dest === "shared" ? "Relatar" : "Relatar neste aparelho"}
          </button>
        )}
        <a className="btn ghost" href={editing ? `#post-${editing.id}` : "#feed"}>
          Cancelar
        </a>
      </div>
      {draftErr && (
        <p className="small" role="alert" style={{ color: "var(--danger)" }}>
          {draftErr}
        </p>
      )}
      {!editing && (st.draft?.text || st.draft?.category) && (
        <button
          type="button"
          className="linkish small discard-draft"
          onClick={() => {
            setSoft((s) => ({ ...s, draft: undefined }));
            setD({ ...blank(), lat: undefined, lon: undefined });
            lastKey.current = "";
            firstRun.current = true;
            toast("Rascunho descartado");
          }}
        >
          Descartar rascunho
        </button>
      )}
    </div>
  );
}
