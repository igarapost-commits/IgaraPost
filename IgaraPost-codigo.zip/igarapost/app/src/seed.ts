import { LOCALE } from "./i18n/lang";
import type { Author, Category, Comment, Community, Post } from "./types";
import type { FiresSummary, NisarSummary } from "./data";
import { fmtDate, fmtDay, fmtMonth, norm } from "./data";

export const CATEGORIES: Record<Category, { label: string; short: string; color: string; icon: string; hint?: string }> = {
  fumaca: { label: "Fumaça", short: "Fumaça", color: "var(--smoke)", icon: "smoke", hint: "Céu encoberto, cheiro de queimado, olhos ardendo" },
  queimada: { label: "Queimada", short: "Queimada", color: "var(--fire)", icon: "flame", hint: "Fogo em mata, pasto, roça ou capoeira" },
  enchente: { label: "Enchente", short: "Enchente", color: "var(--flood)", icon: "flood", hint: "Água invadindo casas, ruas ou roças de repente" },
  falta_chuva: { label: "Seca", short: "Seca", color: "var(--drought)", icon: "sun", hint: "Falta de chuva, rio ou lago baixo, solo rachado" },
  cheia: { label: "Cheia", short: "Cheia", color: "var(--water)", icon: "wave", hint: "Rio acima do normal, várzea alagada por semanas" },
  outro: { label: "Outro", short: "Outro", color: "var(--muted)", icon: "more" },
  // categorias de versões anteriores (exibidas em relatos antigos; não aparecem no formulário)
  reducao_agua: { label: "Redução da água (rio, lago, igarapé)", short: "Água baixa", color: "var(--water)", icon: "drop" },
  impacto: { label: "Impacto percebido (saúde, transporte, roça)", short: "Impacto", color: "var(--impact)", icon: "alert" },
};

/** Área onde relatos são aceitos (Brasil; a mesma regra vale no servidor). */
export const REPORT_AREA = { s: -34, n: 6, w: -75, e: -34 };
export const inReportArea = (lat: number, lon: number) => lat >= REPORT_AREA.s && lat <= REPORT_AREA.n && lon >= REPORT_AREA.w && lon <= REPORT_AREA.e;
export const REPORT_AREA_MSG = "O local precisa ficar no Brasil. Confira o ponto marcado ou as coordenadas.";

/**
 * Secas e cheias saíram do app (0.5.0). As chaves continuam no tipo só para relatos antigos guardados no aparelho
 * não quebrarem a tela, mas esses relatos não aparecem em lugar nenhum.
 */
export const REMOVED_CATEGORIES = new Set<Category>(["falta_chuva", "cheia", "reducao_agua"]);
export const isRemoved = (p: { category: Category }) => REMOVED_CATEGORIES.has(p.category);

/** Imagens de fundo (pasta public/bg) dos relatos e publicações de cada tipo e dos botões do Relatar. */
export const CATEGORY_BG: Partial<Record<Category, string>> = { fumaca: "bg/fumaca.jpg", enchente: "bg/enchente.jpg", queimada: "bg/queimada.jpg", outro: "bg/outro.jpg" };
/** Tipos cujas publicações no feed levam imagem de fundo. */
export const POST_BG_CATEGORIES = new Set<Category>(["fumaca", "enchente", "queimada", "outro"]);
/**
 * Véu liso (sem degradê) por cima da imagem de cada tipo, só o bastante para o texto claro ficar legível:
 * a foto da fumaça é clara e precisa de mais véu; a da enchente e a do "Outro" já são escuras.
 */
export const POST_VEIL: Partial<Record<Category, number>> = { fumaca: 0.5, queimada: 0.32, enchente: 0.18, outro: 0.12 };
/** Cor da borda de cada tipo, tirada da própria imagem: laranja, cinza, azul-marinho do fundo e verde-escuro do "Outro". */
export const POST_BORDER: Partial<Record<Category, string>> = { queimada: "#e8641a", fumaca: "#9aa1a6", enchente: "#2f4278", outro: "#2b5a5f" };
/**
 * Fundo e borda de um cartão (publicação do feed ou item de Meus relatos) conforme o tipo. Os cartões usam versões
 * das imagens sem a logo da Vento Norte embutida (bg/<tipo>-post.jpg): a logo entra à parte, sempre branca, do mesmo
 * tamanho e no mesmo canto, sem ficar tingida pelo véu ou pela cor de cada foto.
 */
export function cardBg(c: Category): { className: string; style: Record<string, string>; cornerLogo: boolean } | undefined {
  if (!POST_BG_CATEGORIES.has(c)) return undefined;
  return { className: `has-bg bg-${c}`, style: { ...flatBg(`bg/${c}-post.jpg`, POST_VEIL[c] ?? 0.3), "--post-border": POST_BORDER[c] ?? "transparent" }, cornerLogo: true };
}
/** Fundo liso: imagem com um véu uniforme (sem degradê). */
export const flatBg = (url: string, veil: number) => ({
  backgroundImage: `linear-gradient(rgba(6,13,23,${veil}), rgba(6,13,23,${veil})), url(${url})`,
});
/** Fundo com véu escuro por cima da imagem: o texto fica legível nos dois temas. */
export const bgStyle = (url: string, veil: [number, number, number]) => ({
  backgroundImage: `linear-gradient(180deg, rgba(6,13,23,${veil[0]}) 0%, rgba(6,13,23,${veil[1]}) 42%, rgba(6,13,23,${veil[2]}) 100%), url(${url})`,
});

export function sameKind(c: Category, wanted: Category) {
  return c === wanted;
}

export const COMMUNITIES: Community[] = [
  { id: "manaus-entorno", name: "Manaus e entorno", kind: "territorio", description: "Manaus, Iranduba e Careiro da Várzea: encontro dos rios Negro e Solimões.", municipios: ["Manaus", "Iranduba", "Careiro da Várzea"] },
  { id: "careiro-varzea", name: "Várzea do Careiro", kind: "territorio", description: "Comunidades de várzea do Careiro da Várzea e do Careiro: lagos, paranás e criação de gado.", municipios: ["Careiro da Várzea", "Careiro"] },
  { id: "autazes", name: "Autazes e Rio Madeira", kind: "territorio", description: "Autazes, Nova Olinda do Norte e Borba.", municipios: ["Autazes", "Nova Olinda do Norte", "Borba"] },
  { id: "iranduba", name: "Iranduba e Manaquiri", kind: "territorio", description: "Margem direita do Rio Negro e do Solimões: roças, olarias e lagos.", municipios: ["Iranduba", "Manaquiri", "Manacapuru"] },
  { id: "fumaca-saude", name: "Fumaça e saúde", kind: "tema", description: "Fumaça, qualidade do ar e efeitos na saúde, em qualquer lugar da região.", categories: ["fumaca", "impacto"] },
  { id: "rios-enchente", name: "Rios e enchentes", kind: "tema", description: "Rios, lagos e igarapés que transbordam e áreas alagadas.", categories: ["enchente"] },
  { id: "radar-nisar", name: "Ciência com radar (NISAR)", kind: "tema", description: "Para entender e discutir o que o radar do satélite NISAR mostra sobre a região." },
];

/** Municípios com contagem do INPE no app (Amazonas). */
export const MUNICIPIOS = ["Manaus", "Iranduba", "Careiro da Várzea", "Careiro", "Autazes", "Manaquiri", "Manacapuru", "Itacoatiara", "Nova Olinda do Norte", "Borba", "Rio Preto da Eva", "Presidente Figueiredo"];

export const TEAM: Author = { id: "equipe", name: "Equipe IgaraPost", role: "Vento Norte · UEA" };
export const AUTHORS: Record<string, Author> = {
  equipe: TEAM,
};

/* ------------------------------ abrangência ------------------------------ */
export interface ScopeInfo {
  label: string;
  municipios: string[] | null; // null = sem recorte municipal
  categories: Category[] | null; // comunidades temáticas
  communityId?: string;
}
export function scopeInfo(scope: string, follows: string[]): ScopeInfo {
  if (scope.startsWith("mun:")) return { label: scope.slice(4), municipios: [scope.slice(4)], categories: null };
  if (scope.startsWith("com:")) {
    const c = COMMUNITIES.find((x) => x.id === scope.slice(4));
    if (c) return { label: c.name, municipios: c.municipios ?? null, categories: c.categories ?? null, communityId: c.id };
  }
  if (scope === "following") {
    const fol = COMMUNITIES.filter((c) => follows.includes(c.id));
    const mun = [...new Set(fol.flatMap((c) => c.municipios ?? []))];
    return { label: "Regiões e temas que sigo", municipios: mun.length ? mun : null, categories: null };
  }
  return { label: "Toda a área do app", municipios: null, categories: null };
}

/** O app não traz mais relatos nem comentários de exemplo: só os explicativos da equipe. */
export const EXAMPLE_POSTS: Post[] = [];
export const EXAMPLE_COMMENTS: Comment[] = [];

/* ======================= publicações da equipe a partir de DADOS REAIS ======================= */
const slug = (s: string) => norm(s).replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
const joinNames = (a: string[]) => (a.length <= 1 ? a.join("") : `${a.slice(0, -1).join(", ")} e ${a[a.length - 1]}`);

/**
 * Publicações com números calculados no navegador a partir dos arquivos importados.
 * Com recorte municipal, os números são RECALCULADOS para os municípios escolhidos (contagem do
 * município inteiro). Sem recorte, a publicação é identificada como "Resumo regional".
 */
export function buildDataPosts(o: { fires?: FiresSummary; nisar?: NisarSummary; scope: ScopeInfo }): Post[] {
  const posts: Post[] = [];
  const { fires, nisar, scope } = o;
  const muns = scope.municipios;
  const suffix = muns ? `--${slug(muns.join("-"))}` : "";
  if (fires) {
    const avail = muns ? muns.filter((m) => fires.municipal.counts[m]) : [];
    const missing = muns ? muns.filter((m) => !fires.municipal.counts[m]) : [];
    for (const ym of fires.months) {
      const partial = ym === fires.months[fires.months.length - 1] && fires.last_detection.slice(0, 7) === ym && !fires.last_detection.endsWith("-31");
      const end = Date.UTC(+ym.slice(0, 4), +ym.slice(5, 7), 1) - 1;
      const endIso = partial ? fires.last_detection.replace(" UTC", ":00Z").replace(" ", "T") : new Date(end).toISOString();
      let text: string, scopeLabel: string;
      if (muns) {
        if (!avail.length) continue; // nenhum dos municípios tem contagem neste arquivo
        const sum = (sat: string) => avail.reduce((t, m) => t + (fires.municipal.counts[m][sat]?.[ym] ?? 0), 0);
        scopeLabel = `Contagem municipal · ${joinNames(avail)}`;
        text =
          `${joinNames(avail)}: ${sum("AQUA_M-T")} focos detectados pelo satélite de referência do INPE (AQUA_M-T) e ${sum("NPP-375")} pelo sensor VIIRS (NPP-375), considerando o município inteiro.` +
          (missing.length ? `\n\nSem contagem disponível para ${joinNames(missing)} (fora dos dados baixados).` : "");
      } else {
        const reg = fires.regional.counts;
        const top = Object.entries(fires.municipal.counts)
          .map(([m, v]) => [m, v["AQUA_M-T"]?.[ym] ?? 0] as const)
          .filter(([, n]) => n > 0)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 3);
        scopeLabel = "Resumo regional · área do app";
        text =
          `Na área do app: ${reg["AQUA_M-T"]?.[ym] ?? 0} focos do satélite de referência do INPE (AQUA_M-T) e ${reg["NPP-375"]?.[ym] ?? 0} do VIIRS (NPP-375).` +
          (top.length ? `\n\nMunicípios com mais focos AQUA_M-T (contagem do município inteiro): ${top.map(([m, n]) => `${m} ${n}`).join(", ")}.` : "");
      }
      posts.push({
        id: `inpe-${ym}${suffix}`,
        kind: "official",
        authorId: "equipe",
        category: "queimada",
        title: `Focos de calor em ${fmtMonth(ym)}${partial ? " (até " + fmtDate(endIso) + ")" : ""}`,
        text,
        scopeLabel,
        observedAt: endIso,
        publishedAt: fires.retrieved.replace("Z", ":00Z"),
        communityIds: ["manaus-entorno", "autazes", "careiro-varzea", "iranduba"],
        source: {
          name: "INPE, Programa Queimadas (dados abertos)",
          url: "https://data.inpe.br/queimadas/dados-abertos/",
          period: `${fmtMonth(ym)}${partial ? `, até ${fires.last_detection}` : ""}`,
          retrieved: fires.retrieved,
          note: "Elaborado pela equipe IgaraPost com os arquivos abertos do INPE; não é uma publicação do INPE.",
          method: `Contagem de registros (focos) por satélite, sem somar satélites. ${muns ? fires.municipal.scope : fires.regional.scope}. Um foco é um pixel com fogo ativo na passagem do satélite: não é um incêndio nem área queimada.`,
        },
        cta: { label: "Ver focos no mapa", hash: "#mapa" },
      });
    }
  }
  if (nisar) {
    const [a, b] = nisar.pair;
    let st: { valid_km2: number; bright_to_dark_km2: number; dark_to_bright_km2: number } | undefined = nisar.stats;
    let scopeLabel = "Resumo regional · recorte do estudo NISAR";
    if (muns) {
      const ok = muns.filter((m) => nisar.by_municipio?.[m]);
      if (ok.length) {
        const s = ok.map((m) => nisar.by_municipio![m]);
        st = { valid_km2: s.reduce((t, x) => t + x.valid_km2, 0), bright_to_dark_km2: s.reduce((t, x) => t + x.bright_to_dark_km2, 0), dark_to_bright_km2: s.reduce((t, x) => t + x.dark_to_bright_km2, 0) };
        scopeLabel = `Recorte municipal · parte de ${joinNames(ok)} dentro do estudo`;
      } else st = undefined;
    }
    if (st) {
      const f = (n: number) => n.toLocaleString(LOCALE, { maximumFractionDigits: 1 });
      posts.push({
        id: `nisar-par${suffix}`,
        kind: "nisar",
        authorId: "equipe",
        category: "outro",
        title: `Radar NISAR: ${fmtDay(a)} × ${fmtDay(b)}`,
        text:
          `Exploração visual experimental das prévias (browse) de duas passagens do NISAR na mesma órbita. Na área com imagem nas duas datas (${f(st.valid_km2)} km²), a segmentação marcou ${f(st.bright_to_dark_km2)} km² que passaram a aparecer escuros e ${f(st.dark_to_bright_km2)} km² que deixaram de aparecer escuros.` +
          `\n\nSão áreas da segmentação das imagens, não área de água ou de queimada. Precisam de validação antes de qualquer interpretação ambiental.`,
        scopeLabel,
        observedAt: b + "T22:16:00Z",
        publishedAt: "2026-11-14T15:00:00Z",
        communityIds: ["radar-nisar", "manaus-entorno", "rios-enchente"],
        source: {
          name: "NASA/ISRO NISAR, L2 GCOV (prévias browse), via ASF",
          url: "https://search.asf.alaska.edu/",
          period: `passagens de ${fmtDay(a)} e ${fmtDay(b)}`,
          retrieved: "2026-11-14T16:39Z",
          note: "Análise experimental da equipe IgaraPost. Não usa valores calibrados de retroespalhamento.",
          method: "Prévias georreferenciadas pelo contorno do ASF e conferidas com o NASA GIBS; pixels escuros e claros separados por limiar automático (Otsu) em cada data; comparação pixel a pixel numa grade de ~170 m.",
        },
        cta: { label: "Abrir Explorador NISAR", hash: "#nisar" },
      });
    }
  }
  return posts;
}

/** Publicações explicativas (texto da equipe, sem números). */
export const EXPLAINERS: Post[] = [
  {
    id: "exp-foco",
    kind: "explainer",
    authorId: "equipe",
    category: "queimada",
    title: "Foco de calor, incêndio e área queimada não são a mesma coisa",
    text: "Foco de calor: um pixel de imagem de satélite em que o sensor detectou fogo ativo no momento da passagem. Pode representar uma queimada pequena ou parte de um incêndio grande.\n\nEvento de fogo ou incêndio: o fogo que acontece no chão, que pode durar dias e gerar muitos focos.\n\nÁrea queimada: a superfície que já queimou, medida com outros métodos.\n\nPor isso, no IgaraPost os focos aparecem separados por satélite e não somamos satélites diferentes.",
    observedAt: "2026-11-14T13:00:00Z",
    publishedAt: "2026-11-14T13:00:00Z",
    communityIds: ["radar-nisar", "fumaca-saude"],
    source: { name: "Equipe IgaraPost, com base nas Perguntas Frequentes do INPE", url: "https://data.inpe.br/queimadas/portal/faq/", period: "texto explicativo" },
  },
  {
    id: "exp-radar",
    kind: "explainer",
    authorId: "equipe",
    category: "outro",
    title: "Como o radar do NISAR enxerga a Amazônia",
    text: "O NISAR é um satélite da NASA e da ISRO (agência espacial da Índia) com radar de abertura sintética (SAR). Ele envia micro-ondas e mede o que volta, o chamado retroespalhamento. Funciona de dia, de noite e através das nuvens e da fumaça.\n\nNo radar banda L, floresta costuma aparecer clara; água parada e solo liso, escuros; floresta alagada pode ficar muito clara. Escurecer no radar não quer dizer, sozinho, que queimou, secou ou virou água.\n\nO radar não detecta fogo ativo: isso é papel dos sensores térmicos usados pelo INPE.",
    observedAt: "2026-11-14T13:05:00Z",
    publishedAt: "2026-11-14T13:05:00Z",
    communityIds: ["radar-nisar"],
    source: { name: "Equipe IgaraPost, com base na documentação NISAR (NASA/ASF)", url: "https://science.nasa.gov/mission/nisar/", period: "texto explicativo" },
    cta: { label: "Abrir Explorador NISAR", hash: "#nisar" },
  },
];

export const SOURCE_SHORT = (p: Post) => (p.source?.name.startsWith("INPE") ? "INPE" : p.kind === "nisar" ? "NISAR" : "");
