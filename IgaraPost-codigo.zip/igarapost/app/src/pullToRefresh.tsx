import React from "react";
import { Icon } from "./Icon";

const THRESHOLD = 70; // px puxados para disparar
const MAX = 110;

/**
 * Arrastar para baixo no topo da página para atualizar. Só reage a toques que começam com a página
 * rolada até o topo e que descem mais do que vão para os lados (não atrapalha a rolagem de chips).
 */
export function PullToRefresh({ onRefresh }: { onRefresh: () => Promise<unknown> }) {
  const [pull, setPull] = React.useState(0);
  const [busy, setBusy] = React.useState(false);
  const start = React.useRef<{ x: number; y: number } | null>(null);
  const pullRef = React.useRef(0);
  const busyRef = React.useRef(false);
  const cb = React.useRef(onRefresh);
  cb.current = onRefresh;

  React.useEffect(() => {
    const down = (e: TouchEvent) => {
      if (busyRef.current || window.scrollY > 0 || e.touches.length !== 1) return (start.current = null);
      const t = (e.target as HTMLElement | null)?.closest?.(".sheet, .sheet-backdrop, input, textarea, select");
      if (t) return (start.current = null);
      start.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    };
    const move = (e: TouchEvent) => {
      if (!start.current) return;
      const dy = e.touches[0].clientY - start.current.y,
        dx = Math.abs(e.touches[0].clientX - start.current.x);
      if (dy <= 0 || dx > dy || window.scrollY > 0) {
        if (pullRef.current) set(0);
        return;
      }
      if (e.cancelable) e.preventDefault(); // evita o "repuxo" nativo enquanto puxa
      set(Math.min(MAX, dy * 0.5));
    };
    const up = async () => {
      if (!start.current) return;
      start.current = null;
      if (pullRef.current >= THRESHOLD && !busyRef.current) {
        busyRef.current = true;
        setBusy(true);
        set(THRESHOLD * 0.8);
        try {
          await cb.current();
        } finally {
          busyRef.current = false;
          setBusy(false);
          set(0);
        }
      } else set(0);
    };
    const set = (v: number) => {
      pullRef.current = v;
      setPull(v);
    };
    window.addEventListener("touchstart", down, { passive: true });
    window.addEventListener("touchmove", move, { passive: false });
    window.addEventListener("touchend", up);
    window.addEventListener("touchcancel", up);
    return () => {
      window.removeEventListener("touchstart", down);
      window.removeEventListener("touchmove", move);
      window.removeEventListener("touchend", up);
      window.removeEventListener("touchcancel", up);
    };
  }, []);

  const ready = pull >= THRESHOLD;
  return (
    <>
      <div className={`ptr ${busy ? "busy" : ""} ${pull ? "show" : ""}`} style={{ transform: `translate(-50%, ${pull - 44}px)` }} aria-hidden={!busy}>
        <span style={{ transform: busy ? undefined : `rotate(${pull * 3}deg)`, display: "inline-flex" }} className={ready || busy ? "ready" : ""}>
          <Icon name="refresh" size={20} />
        </span>
      </div>
      <span className="sr-only" role="status" aria-live="polite">
        {busy ? "Atualizando o feed…" : ""}
      </span>
    </>
  );
}
