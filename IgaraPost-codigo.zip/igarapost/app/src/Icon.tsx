import React from "react";

const P: Record<string, string> = {
  chevron: "M6 9l6 6 6-6",
  bell: "M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10.3 21a1.94 1.94 0 0 0 3.4 0",
  copy: "M9 9h10v10H9zM5 15V5h10",
  globe: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM3 12h18M12 3c2.5 2.6 3.8 5.6 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.6-3.8-9s1.3-6.4 3.8-9z",
  feed: "M4 5h16M4 12h16M4 19h10",
  map: "M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2Zm0 0v14m6-12v14",
  plus: "M12 5v14M5 12h14",
  people: "M16 19v-1a4 4 0 0 0-8 0v1M12 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm7 8v-1a3 3 0 0 0-2-2.8M17 5.2a3 3 0 0 1 0 5.6M5 19v-1a3 3 0 0 1 2-2.8M7 5.2a3 3 0 0 0 0 5.6",
  user: "M20 20a8 8 0 0 0-16 0M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z",
  flame: "M12 21c4 0 7-2.7 7-6.6 0-3.3-2.2-5.2-3.6-7.4-.6 1.7-1.6 2.7-2.6 3.2C13 6.8 11.5 4.3 9 3c.4 3-1.8 5.1-3 7-1 1.5-1 2.7-1 4.4C5 18.3 8 21 12 21Zm0 0c-1.7 0-3-1.2-3-2.8 0-1.9 1.6-2.9 2.3-4.4.7 1 3.7 2.4 3.7 4.4 0 1.6-1.3 2.8-3 2.8Z",
  smoke: "M7 18h10a4 4 0 0 0 .5-8A5.5 5.5 0 0 0 7 8.5 4.75 4.75 0 0 0 7 18Z",
  sun: "M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm0-14v2m0 16v2M4.2 4.2l1.4 1.4m12.8 12.8 1.4 1.4M2 12h2m16 0h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4",
  drop: "M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11Zm-3 16h6",
  alert: "M12 4 2.5 20h19L12 4Zm0 6v4m0 3h.01",
  image: "M4 5h16v14H4V5Zm0 11 5-5 4 4 2-2 5 5M15.5 9.5h.01",
  more: "M5 11.2a.8.8 0 1 0 0 1.6.8.8 0 1 0 0-1.6Zm7 0a.8.8 0 1 0 0 1.6.8.8 0 1 0 0-1.6Zm7 0a.8.8 0 1 0 0 1.6.8.8 0 1 0 0-1.6Z",
  dot: "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z",
  heart: "M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10Z",
  comment: "M4 5h16v11H9l-5 4V5Z",
  bookmark: "M6 3h12v18l-6-4-6 4V3Z",
  flag: "M5 21V4m0 0h11l-2 4 2 4H5",
  radar: "M12 12 19 5M12 21a9 9 0 1 1 9-9M12 17a5 5 0 1 1 5-5M12 12h.01",
  help: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm-2.6-11.6a2.7 2.7 0 0 1 5.2 1c0 1.8-2.6 2.3-2.6 4M12 17h.01",
  info: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0-11v6m0-9h.01",
  layers: "m12 3 9 5-9 5-9-5 9-5Zm-9 9 9 5 9-5M3 16l9 5 9-5",
  locate: "M12 2v3m0 14v3M2 12h3m14 0h3M12 18a6 6 0 1 0 0-12 6 6 0 0 0 0 12Zm0-4a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z",
  close: "M6 6l12 12M18 6 6 18",
  edit: "M4 20h4L19 9l-4-4L4 16v4Zm10-14 4 4",
  trash: "M4 7h16M9 7V4h6v3m-8 0 1 13h8l1-13",
  pin: "M12 21s7-6.2 7-12A7 7 0 0 0 5 9c0 5.8 7 12 7 12Zm0-9a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z",
  clock: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0-13v5l3 2",
  send: "M4 12 20 4l-6 16-3-7-7-1Z",
  back: "M15 5l-7 7 7 7",
  camera: "M4 8h3l2-3h6l2 3h3v11H4V8Zm8 9a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z",
  check: "M5 12l5 5L20 7",
  link: "M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1",
  filter: "M4 5h16l-6 8v6l-4-2v-4L4 5Z",
  search: "M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14Zm5-2 4 4",
  flood: "M3 15c2 0 2-1.5 4.5-1.5S9.5 15 12 15s2.5-1.5 4.5-1.5S19 15 21 15M3 19c2 0 2-1.5 4.5-1.5S9.5 19 12 19s2.5-1.5 4.5-1.5S19 19 21 19M6 11V7l6-4 6 4v4",
  wave: "M2 10c2.5 0 2.5-2 5-2s2.5 2 5 2 2.5-2 5-2 2.5 2 5 2M2 15c2.5 0 2.5-2 5-2s2.5 2 5 2 2.5-2 5-2 2.5 2 5 2M2 20c2.5 0 2.5-2 5-2s2.5 2 5 2 2.5-2 5-2 2.5 2 5 2",
  satellite: "M13 7 9 3 5 7l4 4m4-4 4 4-4 4m-4-8 8 8m-4 4 4 4 4-4-4-4M7 17a4 4 0 0 0 4 4M4 17a7 7 0 0 0 7 7",
  history: "M3 12a9 9 0 1 0 3-6.7M3 4v5h5m4-1v5l3 2",
  refresh: "M20 11a8 8 0 0 0-14.8-4M4 4v4h4m-4 5a8 8 0 0 0 14.8 4M20 20v-4h-4",
  settings: "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm7.4-3a7.4 7.4 0 0 0-.1-1.2l2-1.6-2-3.4-2.4 1a7.6 7.6 0 0 0-2-1.2L14.5 2h-4l-.4 2.6a7.6 7.6 0 0 0-2 1.2l-2.4-1-2 3.4 2 1.6a7.4 7.4 0 0 0 0 2.4l-2 1.6 2 3.4 2.4-1a7.6 7.6 0 0 0 2 1.2l.4 2.6h4l.4-2.6a7.6 7.6 0 0 0 2-1.2l2.4 1 2-3.4-2-1.6c.1-.4.1-.8.1-1.2Z",
  moon: "M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5Z",
  phone: "M8 3h8a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Zm3 15h2",
};

/** `filled`: preenche o desenho (coração de apoiado, marcador de salvo). */
export function Icon({ name, size, title, filled }: { name: string; size?: number; title?: string; filled?: boolean }) {
  return (
    <svg
      className="ico"
      viewBox="0 0 24 24"
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      style={size ? { width: size, height: size } : undefined}
      aria-hidden={title ? undefined : true}
      role={title ? "img" : undefined}
    >
      {title && <title>{title}</title>}
      <path d={P[name] || P.dot} />
    </svg>
  );
}
