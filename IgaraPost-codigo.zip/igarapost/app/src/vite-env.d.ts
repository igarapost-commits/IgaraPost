/// <reference types="vite/client" />
interface ImportMetaEnv {
  readonly VITE_SUPABASE_URL?: string;
  readonly VITE_SUPABASE_KEY?: string;
  readonly VITE_APP_VERSION?: string;
  readonly VITE_SARS_NAME?: string;
  readonly VITE_SARS_WMTS_URL?: string;
  readonly VITE_SARS_LIVE_URL?: string;
  readonly VITE_SARS_FIRMS_CSV?: string;
  readonly VITE_GOOGLE_MAPS_KEY?: string;
}
declare const __APP_VERSION__: string;
