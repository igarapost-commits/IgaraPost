import { LOCALE } from "./i18n/lang";
import React from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { go, useApp, type MapContext } from "./ctx";
import { setSoft, useStore } from "./store";
import { Icon } from "./Icon";
import { CATEGORIES, COMMUNITIES, scopeInfo } from "./seed";
import { SARS } from "./sars/config";
import { categoryEvent, EVENT_ORDER, EVENTS, layerDate, REFERENCE_LAYERS, SARS_LAYERS, wmtsUrl, type EnvEvent, type SarsLayer } from "./sars/layers";
import { addAppBase, APP_BASES, googleKey, type AppBase } from "./sars/googleTiles";
import { addHlsDetail, HLS_MIN_ZOOM, nisarTileMatrix, nisarWindowLayers, smallTiles, windowDays, type BaseUsed } from "./sars/nasaTiles";
import { LIVE_LABEL, refreshLive, useLive } from "./sars/live";
import { RADAR_LABEL } from "./sars/radar";
import { draftLocation } from "./draft";
import { LocalitySearch } from "./Compose";
import { DATA, distKm, fmtDate, fmtDay, fmtUTC, municipioBounds, useData, type PlacesFile } from "./data";
import { useOnline } from "./sync";

type Basemap = Record<string, { file: string; layer: string; zoom: number; bounds: [[number, number], [number, number]] }>;
type Lines = { source: string; lines: { k: "rio" | "via"; n: string; c: [number, number][] }[] };
/** preferências antigas (0.2.0–0.3.2): fundos que não são da NASA passam para o satélite do dia */
const LEGACY_BASE: Record<string, AppBase> = { simples: "google", satelite: "google", osm: "google-mapa", offline: "google" };
type LayerHealth = "carregando" | "ok" | "falha";

const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]!);
const CAT_HEX: Record<string, string> = { queimada: "#cf4419", fumaca: "#5f6f76", enchente: "#1f5fbf", impacto: "#9b3569", outro: "#56695d" };
const PIN_PATHS: Record<string, string> = {
  flame: "M12 21c4 0 7-2.7 7-6.6 0-3.3-2.2-5.2-3.6-7.4-.6 1.7-1.6 2.7-2.6 3.2C13 6.8 11.5 4.3 9 3c.4 3-1.8 5.1-3 7-1 1.5-1 2.7-1 4.4C5 18.3 8 21 12 21Z",
  smoke: "M7 18h10a4 4 0 0 0 .5-8A5.5 5.5 0 0 0 7 8.5 4.75 4.75 0 0 0 7 18Z",
  sun: "M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm0-14v2m0 16v2M2 12h2m16 0h2",
  drop: "M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11Z",
  alert: "M12 4 2.5 20h19L12 4Zm0 6v4m0 3h.01",
  flood: "M3 15c2 0 2-1.5 4.5-1.5S9.5 15 12 15s2.5-1.5 4.5-1.5S19 15 21 15M3 19c2 0 2-1.5 4.5-1.5S9.5 19 12 19s2.5-1.5 4.5-1.5S19 19 21 19M6 11V7l6-4 6 4v4",
  wave: "M2 10c2.5 0 2.5-2 5-2s2.5 2 5 2 2.5-2 5-2 2.5 2 5 2M2 15c2.5 0 2.5-2 5-2s2.5 2 5 2 2.5-2 5-2 2.5 2 5 2",
  dot: "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z",
};
export function pinIcon(color: string, icon: string, example?: boolean, offRadar?: boolean) {
  return L.divIcon({
    className: "",
    iconSize: [30, 30],
    iconAnchor: [15, 30],
    popupAnchor: [0, -28],
    html: `<div class="pin ${example ? "example" : ""} ${offRadar ? "off-radar" : ""}" style="background:${color}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${PIN_PATHS[icon] || PIN_PATHS.dot}"/></svg></div>`,
  });
}
const OSM_URL = "https://tile.openstreetmap.org/{z}/{x}/{y}.png";
const OSM_ATTR = '© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">colaboradores do OpenStreetMap</a>';

/** Rios, vias e nomes de lugares (OSM) desenhados a partir de arquivos do app: funcionam sem internet. */
function addVectorLayers(m: L.Map, lines: Lines | undefined, places: PlacesFile | undefined, g: L.LayerGroup, labels: L.LayerGroup, dark: boolean) {
  g.clearLayers();
  if (lines) {
    const rios = lines.lines.filter((l) => l.k === "rio").map((l) => l.c.map(([x, y]) => [y, x] as [number, number]));
    const vias = lines.lines.filter((l) => l.k === "via").map((l) => l.c.map(([x, y]) => [y, x] as [number, number]));
    L.polyline(rios, { color: dark ? "#6fb7e0" : "#4a90c2", weight: 1.6, opacity: 0.85, interactive: false }).addTo(g);
    L.polyline(vias, { color: dark ? "#e8d9a8" : "#b08a3e", weight: 1.3, opacity: 0.8, interactive: false }).addTo(g);
  }
  const draw = () => {
    labels.clearLayers();
    if (!places) return;
    const z = m.getZoom(),
      b = m.getBounds().pad(0.1);
    for (const [name, type, lat, lon] of places.places) {
      const minZ = type === "city" || type === "town" ? 7 : type === "village" ? 10 : 11.5;
      if (z < minZ || !b.contains([lat, lon])) continue;
      L.marker([lat, lon], { interactive: false, keyboard: false, icon: L.divIcon({ className: `place-label ${type}`, html: esc(name), iconAnchor: [-4, 6] }) }).addTo(labels);
    }
  };
  const prev = (m as unknown as { _igDraw?: () => void })._igDraw;
  if (prev) m.off("zoomend moveend", prev); // só remove o próprio ouvinte (off sem função removeria todos)
  (m as unknown as { _igDraw?: () => void })._igDraw = draw;
  m.on("zoomend moveend", draw);
  draw();
}

/** Agrupamento simples por grade de pixels: muitos relatos próximos viram um círculo com o número. */
function clusterPosts(m: L.Map, g: L.LayerGroup, items: { lat: number; lon: number; marker: () => L.Marker }[]) {
  g.clearLayers();
  const z = m.getZoom();
  const cells = new Map<string, typeof items>();
  for (const it of items) {
    const p = m.project([it.lat, it.lon], z);
    const k = `${Math.floor(p.x / 56)}:${Math.floor(p.y / 56)}`;
    cells.set(k, [...(cells.get(k) || []), it]);
  }
  const out: Record<string, L.Marker> = {};
  cells.forEach((list) => {
    if (list.length === 1 || z >= 13) {
      list.forEach((it) => it.marker().addTo(g));
      return;
    }
    const lat = list.reduce((s, x) => s + x.lat, 0) / list.length,
      lon = list.reduce((s, x) => s + x.lon, 0) / list.length;
    L.marker([lat, lon], { icon: L.divIcon({ className: "", html: `<div class="cluster">${list.length}</div>`, iconSize: [36, 36], iconAnchor: [18, 18] }), title: `${list.length} relatos` })
      .on("click", () => m.fitBounds(L.latLngBounds(list.map((x) => [x.lat, x.lon] as [number, number])).pad(0.4), { maxZoom: 13 }))
      .addTo(g);
  });
  return out;
}

const ago = (t?: number) => {
  if (!t) return "—";
  const m = Math.round((Date.now() - t) / 60000);
  return m < 1 ? "agora" : m < 60 ? `há ${m} min` : m < 1440 ? `há ${Math.round(m / 60)} h` : fmtDate(t, true);
};
const dayLabel = (ymd: string) => fmtDay(ymd);

/**
 * Mapa-múndi do SARS: SOMENTE dados da NASA (fundo e camadas da NASA GIBS, como no NASA Worldview, e focos
 * de fogo ativo da NASA FIRMS). Os relatos da comunidade aparecem por cima.
 */
export function MapView() {
  const { posts, filters, cemaden, mapContext, setMapContext } = useApp();
  const st = useStore();
  const online = useOnline();
  const live = useLive();
  const basemap = useData<Basemap>("basemap/basemap.json");
  // 0.3.8: o fundo padrão é o Google Maps (camadas da NASA por cima); "mundo" salvo nas versões anteriores vira Google
  // o padrão é a Blue Marble da NASA (sem nuvens); um fundo só é lembrado se a pessoa escolheu outro em Camadas
  const savedBase = (st.prefs.mapBaseChosen ? LEGACY_BASE[st.prefs.mapBase ?? ""] ?? st.prefs.mapBase : undefined) as AppBase | undefined;
  // Sem chave do Google (o caso normal), o fundo é sempre da NASA e as opções do Google nem aparecem.
  const hasGoogle = !!googleKey();
  const baseOpts = (Object.keys(APP_BASES) as AppBase[]).filter((b) => hasGoogle || !b.startsWith("google"));
  const [base, setBase] = React.useState<AppBase>(() => (savedBase && baseOpts.includes(savedBase) ? savedBase : "bluemarble"));
  const [googleFail, setGoogleFail] = React.useState("");
  const [baseUsed, setBaseUsed] = React.useState<BaseUsed>();
  /** o fundo carrega primeiro; focos, camadas e relatos entram depois (ou após 5 s, se o fundo demorar) */
  const [baseReady, setBaseReady] = React.useState(false);
  React.useEffect(() => {
    const t = window.setTimeout(() => setBaseReady(true), 5000);
    return () => window.clearTimeout(t);
  }, []);
  const offline = baseUsed?.kind === "offline";
  /** filtros de evento: cada um liga as camadas da NASA daquele evento e os relatos do mesmo tipo */
  const [events, setEvents] = React.useState<Record<EnvEvent, boolean>>({ fumaca: false, queimada: false, enchente: false });
  const toggleEvent = (e: EnvEvent) => setEvents((x) => ({ ...x, [e]: !x[e] }));
  // nomes e litoral da NASA ficam desligados por padrão: são mais 3 camadas de blocos disputando a conexão com o fundo
  const [layers, setLayers] = React.useState({ posts: true, ref: false, nisar: false, nisarOpacity: 0.85, hls: true });
  const [nisarState, setNisarState] = React.useState<"" | "carregando" | "ok" | "indisponivel">("");
  const set = (p: Partial<typeof layers>) => setLayers((x) => ({ ...x, ...p }));
  const [panel, setPanel] = React.useState<"" | "layers" | "search">("");
  const [health, setHealth] = React.useState<Record<string, LayerHealth>>({});
  const [rev, setRev] = React.useState(0); // troca de tempos em tempos para recarregar as imagens
  const host = React.useRef<HTMLDivElement>(null);
  const map = React.useRef<L.Map>();
  const groups = React.useRef<Record<string, L.LayerGroup>>({});
  const renderer = React.useRef(L.canvas({ padding: 0.3 }));
  const markerById = React.useRef<Record<string, () => L.Marker>>({});

  // janela de 12 dias do radar NISAR: termina hoje, ou no dia do relato quando o mapa vem de uma publicação
  const nisarEnd = mapContext?.observedAt ? mapContext.observedAt.slice(0, 10) : layerDate(0);
  const nisarDays = windowDays(nisarEnd);
  /** data pedida a cada camada: a do relato (contexto) ou hoje − atraso da fonte */
  const dateOf = React.useCallback((lagDays: number) => (mapContext?.observedAt ? mapContext.observedAt.slice(0, 10) : layerDate(lagDays)), [mapContext?.observedAt, rev]); // eslint-disable-line react-hooks/exhaustive-deps

  // cria o mapa uma vez: mapa-múndi, sem trava de área
  React.useEffect(() => {
    if (!host.current || map.current) return;
    const m = L.map(host.current, { zoomControl: false, minZoom: 2, maxZoom: 18, worldCopyJump: true, maxBoundsViscosity: 1 });
    m.setMaxBounds([
      [-85, -540],
      [85, 540],
    ]);
    L.control.zoom({ position: "bottomright" }).addTo(m);
    m.setView([-3.3, -59.7], 6);
    m.attributionControl.setPrefix(false);
    m.attributionControl.addAttribution(SARS.attribution); // dados da NASA, separados da atribuição do fundo
    ["offline", "base", "detail", "sars", "nisar", "ref", "outline", "fires", "posts", "probe"].forEach((k) => (groups.current[k] = L.layerGroup().addTo(m)));
    map.current = m;
    return () => {
      m.remove();
      map.current = undefined;
    };
  }, []);

  // atualização periódica das imagens (as fontes diárias são completadas ao longo do dia)
  React.useEffect(() => {
    const t = window.setInterval(() => document.visibilityState === "visible" && setRev((r) => r + 1), SARS.tileRefreshMs);
    return () => window.clearInterval(t);
  }, []);
  // fundo: imagem de satélite da NASA (WMTS) com reservas por bloco (sars/nasaTiles.ts). Só é refeito quando
  // muda o tipo de fundo ou o dia; nada é apagado enquanto o mapa está aberto.
  const dayKey = layerDate(1);
  React.useEffect(() => {
    const g = groups.current.base;
    if (!g) return;
    setGoogleFail("");
    return addAppBase(map.current!, g, base, setBaseUsed, () => setBaseReady(true), setGoogleFail);
  }, [base, dayKey, st.prefs.googleKey]);
  // detalhe ao aproximar: imagens de 30 m da NASA (HLS) por cima do satélite do dia, a partir do zoom HLS_MIN_ZOOM
  const [zoom, setZoom] = React.useState(6);
  const [outlineName, setOutlineName] = React.useState("");
  React.useEffect(() => {
    const m = map.current;
    if (!m) return;
    const f = () => setZoom(m.getZoom());
    m.on("zoomend", f);
    return () => void m.off("zoomend", f);
  }, []);
  React.useEffect(() => {
    const g = groups.current.detail;
    if (!g || !layers.hls || !baseReady || base.startsWith("google")) return;
    return addHlsDetail(g);
  }, [layers.hls, baseReady, base, dayKey]);
  // reserva sem internet: Blue Marble do entorno de Manaus guardada no app, por baixo de tudo
  React.useEffect(() => {
    const g = groups.current.offline,
      bm = basemap.data?.bluemarble;
    if (!g || !bm) return;
    // vai num painel abaixo dos blocos: só aparece onde não há fundo online (sem internet)
    const pane = map.current!.getPane("reservaPane") ?? map.current!.createPane("reservaPane");
    pane.style.zIndex = "150";
    const o = L.imageOverlay(DATA + "basemap/" + bm.file, bm.bounds, { interactive: false, pane: "reservaPane" }).addTo(g);
    return () => void g.removeLayer(o);
  }, [basemap.data]);
  const chooseBase = (b: AppBase) => {
    setBase(b);
    setSoft((s) => ({ ...s, prefs: { ...s.prefs, mapBase: b, mapBaseChosen: true } }));
  };

  // litoral, fronteiras e nomes (NASA GIBS)
  React.useEffect(() => {
    const g = groups.current.ref;
    if (!g) return;
    g.clearLayers();
    if (!layers.ref || offline || !baseReady || baseUsed?.kind === "google") return;
    REFERENCE_LAYERS.forEach((r, i) => L.tileLayer(wmtsUrl(r.layer, r.tms, r.ext), { ...smallTiles(r.maxNative), maxZoom: 18, zIndex: 40 + i, crossOrigin: true }).addTo(g));
  }, [layers.ref, offline, baseReady, baseUsed?.kind]);

  // camadas de imagem dos eventos (NASA GIBS, WMTS)
  const activeLayers = SARS_LAYERS.filter((l) => events[l.event]);
  const activeKey = activeLayers.map((l) => l.id).join(",");
  React.useEffect(() => {
    const g = groups.current.sars;
    if (!g) return;
    g.clearLayers();
    if (!baseReady) return;
    activeLayers.forEach((l, i) => {
      let ok = 0,
        err = 0;
      setHealth((h) => ({ ...h, [l.id]: "carregando" }));
      const t = L.tileLayer(wmtsUrl(l.layer, l.tms, l.ext, dateOf(l.lagDays)), { opacity: l.opacity, ...smallTiles(l.maxNative), minZoom: l.minZoom ?? 0, maxZoom: 18, zIndex: 10 + i, crossOrigin: true });
      t.on("tileload", () => {
        if (!ok++) setHealth((h) => ({ ...h, [l.id]: "ok" }));
      });
      t.on("tileerror", () => {
        if (++err >= 3 && !ok) setHealth((h) => ({ ...h, [l.id]: "falha" }));
      });
      t.addTo(g);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeKey, dateOf, baseReady]);

  // focos de fogo ativo (NASA FIRMS, últimas 48 h). São dezenas de milhares de pontos na América do Sul: desenhar
  // todos travava o mapa no celular (fundo preto, blocos parados). Agora só a área visível é desenhada e, quando há
  // muitos focos, os vizinhos na tela viram um único círculo (maior conforme a quantidade). Os balões são montados
  // só quando tocados.
  const drawFires = React.useCallback(() => {
    const m = map.current,
      g = groups.current.fires;
    if (!m || !g) return;
    g.clearLayers();
    if (!events.queimada || !baseReady) return;
    const now = Date.now();
    const b = m.getBounds().pad(0.1);
    const vis = live.fires.filter((f) => b.contains([f.lat, f.lon]));
    const color = (t: number) => {
      const age = (now - t) / 3600_000;
      return age < 6 ? "#ff3d00" : age < 24 ? "#ff7a1a" : "#ffad4d";
    };
    const popup = (f: (typeof vis)[number]) => () =>
      `<b>Foco de fogo ativo · ${esc(f.sat)}</b><br>${fmtUTC(f.t)} (${ago(f.t)})${f.frp != null ? `<br>Potência radiativa (FRP): ${f.frp} MW` : ""}<br><span class="muted">NASA FIRMS</span>`;
    if (vis.length <= 1200) {
      for (const f of vis)
        L.circleMarker([f.lat, f.lon], { renderer: renderer.current, radius: 4, color: "#5a1a00", weight: 0.6, fillColor: color(f.t), fillOpacity: 0.95 })
          .bindPopup(popup(f))
          .addTo(g);
    } else {
      const cell = 14; // px na tela
      const bins = new Map<string, { lat: number; lon: number; n: number; t: number }>();
      for (const f of vis) {
        const pt = m.latLngToContainerPoint([f.lat, f.lon]);
        const k = `${Math.floor(pt.x / cell)}:${Math.floor(pt.y / cell)}`;
        const c = bins.get(k);
        if (c) {
          c.lat += f.lat;
          c.lon += f.lon;
          c.n++;
          c.t = Math.max(c.t, f.t);
        } else bins.set(k, { lat: f.lat, lon: f.lon, n: 1, t: f.t });
      }
      for (const c of bins.values()) {
        const lat = c.lat / c.n,
          lon = c.lon / c.n;
        L.circleMarker([lat, lon], { renderer: renderer.current, radius: Math.min(7, 2.5 + Math.log2(c.n)), color: "#5a1a00", weight: 0.6, fillColor: color(c.t), fillOpacity: 0.9 })
          .bindPopup(() => `<b>${c.n} foco(s) de fogo ativo aqui</b><br>o mais recente ${ago(c.t)}`)
          .addTo(g);
      }
    }
    // destaque só para alguns focos novos visíveis
    const fresh = new Set(live.freshIds);
    vis
      .filter((f) => fresh.has(f.id))
      .slice(0, 30)
      .forEach((f) => L.marker([f.lat, f.lon], { interactive: false, keyboard: false, icon: L.divIcon({ className: "", html: '<div class="pulse"></div>', iconSize: [24, 24], iconAnchor: [12, 12] }) }).addTo(g));
  }, [live.fires, live.freshIds, events.queimada, baseReady]);
  React.useEffect(() => {
    drawFires();
    const m = map.current;
    let t: number | undefined;
    const h = () => {
      window.clearTimeout(t);
      t = window.setTimeout(drawFires, 120);
    };
    m?.on("moveend", h);
    return () => {
      window.clearTimeout(t);
      m?.off("moveend", h);
    };
  }, [drawFires]);

  // consulta de um ponto: o que os dados da NASA mostram ali
  const probe = React.useCallback(
    async (lat: number, lon: number) => {
      const m = map.current;
      if (!m) return;
      const liveOk = live.mode === "ao_vivo" || live.mode === "polling" || live.mode === "direto";
      const nLive = live.fires.filter((f) => distKm(lat, lon, f.lat, f.lon) <= 10).length;
      const liveTxt = liveOk ? (nLive ? `<b>${nLive} foco(s) de fogo ativo</b> a até 10 km nas últimas 48 h (NASA FIRMS)` : "Nenhum foco de fogo ativo a até 10 km nas últimas 48 h (NASA FIRMS).") : `Focos NASA FIRMS: ${LIVE_LABEL[live.mode].toLowerCase()}`;
      const nis = layers.nisar ? `Radar NISAR ligado: passagens de ${dayLabel(nisarDays[0])} a ${dayLabel(nisarDays[nisarDays.length - 1])}.` : "";
      const on = activeLayers.map((l) => `${l.title.toLowerCase()} (${dayLabel(dateOf(l.lagDays))})`);
      const html = `<div class="stack" style="gap:6px"><b>Ponto no mapa</b><span class="muted">${lat.toFixed(4)}, ${lon.toFixed(4)}</span>
        <span>${liveTxt}</span>${nis ? `<span>${esc(nis)}</span>` : ""}
        ${on.length ? `<span class="muted small">Camadas ligadas: ${esc(on.join("; "))}</span>` : ""}
        <button class="btn sm primary" data-publish="${lat},${lon}">Relatar</button></div>`;
      L.popup({ maxWidth: 300 }).setLatLng([lat, lon]).setContent(html).openOn(m);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [layers.nisar, nisarEnd, live.fires, live.mode, activeKey, dateOf],
  );
  React.useEffect(() => {
    const m = map.current;
    if (!m) return;
    const h = (e: L.LeafletMouseEvent) => probe(e.latlng.lat, e.latlng.lng);
    m.on("click", h);
    const onPop = (e: L.PopupEvent) => {
      e.popup
        .getElement()
        ?.querySelectorAll<HTMLButtonElement>("[data-publish]")
        .forEach((b) =>
          b.addEventListener("click", () => {
            const [la, lo] = b.dataset.publish!.split(",").map(Number);
            draftLocation.lat = la;
            draftLocation.lon = lo;
            go("#relatar");
          }),
        );
    };
    m.on("popupopen", onPop);
    return () => {
      m.off("click", h);
      m.off("popupopen", onPop);
    };
  }, [probe]);

  // NISAR (radar NASA/ISRO) global, pela NASA GIBS: mosaico dos últimos 12 dias (ou dos 12 dias até o relato)
  React.useEffect(() => {
    const g = groups.current.nisar;
    g?.clearLayers();
    if (!layers.nisar || !g || !baseReady) return setNisarState("");
    let alive = true;
    setNisarState("carregando");
    void nisarTileMatrix().then((m) => {
      if (!alive) return;
      nisarWindowLayers(nisarEnd, m, { opacity: layers.nisarOpacity }).forEach((t) => t.addTo(g));
      setNisarState("ok");
    });
    return () => {
      alive = false;
    };
  }, [layers.nisar, layers.nisarOpacity, nisarEnd, rev, baseReady]);

  // relatos (agrupados quando muitos ficam próximos), filtrados pelos eventos ligados
  const pendingFocus = React.useRef<string | undefined>();
  /** Abre a marcação do relato vindo de "Mapa" na publicação, por cima dos agrupamentos. */
  const focusPending = () => {
    const id = pendingFocus.current,
      m = map.current;
    const mk = id && markerById.current[id];
    if (!m || !mk) return;
    pendingFocus.current = undefined;
    const marker = mk().addTo(groups.current.probe);
    window.setTimeout(() => marker.openPopup(), 60);
  };
  const anyEvent = EVENT_ORDER.some((e) => events[e]);
  const visiblePosts = React.useMemo(
    () =>
    {
      // o mapa mostra todos os relatos; só os botões de evento do topo filtram
      const list = posts.filter((p) => {
        if (p.lat == null || p.lon == null || p.kind !== "community") return false;
        if (mapContext?.postId === p.id) return true;
        const ev = categoryEvent(p.category);
        return !anyEvent || !ev || events[ev];
      });
      // o relato que abriu o mapa ("Mapa" na publicação) aparece mesmo fora dos filtros atuais
      const ctx = mapContext?.postId ? posts.find((p) => p.id === mapContext.postId && p.kind === "community" && p.lat != null && p.lon != null) : undefined;
      return ctx && !list.includes(ctx) ? [...list, ctx] : list;
    },
    [posts, events, anyEvent, mapContext?.postId],
  );
  const redrawPosts = React.useCallback(() => {
    const m = map.current,
      g = groups.current.posts;
    if (!m || !g) return;
    markerById.current = {};
    if (!layers.posts || !baseReady) return g.clearLayers();
    const items = visiblePosts.map((p) => {
      const c = CATEGORIES[p.category];
      const off = p.radar?.status === "fora_do_radar";
      const mk = () =>
        L.marker([p.lat!, p.lon!], { icon: pinIcon(CAT_HEX[p.category], c.icon, p.example, off), title: c.short, keyboard: true }).bindPopup(
          `<div class="stack" style="gap:6px"><span class="badge community">Relato da comunidade · não verificado</span>${p.example ? '<span class="badge example">Exemplo fictício</span>' : ""}${p.radar ? `<span class="badge radar ${p.radar.status}">${esc(RADAR_LABEL[p.radar.status])}</span>` : ""}
          <b>${esc(c.short)}${p.municipio ? " · " + esc(p.municipio) : ""}</b><span>${esc(p.text.slice(0, 160))}${p.text.length > 160 ? "…" : ""}</span>
          <span class="muted">Observado em ${fmtDate(p.observedAt, true)}${p.approx ? " · local aproximado" : ""}</span>
          <a class="btn sm" href="#post-${p.id}">Abrir relato e comentários</a></div>`,
        );
      markerById.current[p.id] = mk;
      return { lat: p.lat!, lon: p.lon!, marker: mk };
    });
    clusterPosts(m, g, items);
    focusPending();
  }, [visiblePosts, layers.posts, baseReady]);
  React.useEffect(() => {
    redrawPosts();
    const m = map.current;
    m?.on("zoomend", redrawPosts);
    return () => {
      m?.off("zoomend", redrawPosts);
    };
  }, [redrawPosts]);

  // o contexto de um relato vale só para esta visita ao mapa: ao sair da aba, o mapa volta ao normal
  React.useEffect(() => () => setMapContext(undefined), [setMapContext]);
  // relato excluído (ou escondido) enquanto o contexto estava ativo: o mapa não fica preso no local dele
  React.useEffect(() => {
    if (mapContext?.postId && !posts.some((p) => p.id === mapContext.postId)) setMapContext(undefined);
  }, [mapContext?.postId, posts, setMapContext]);

  // contexto vindo de uma publicação: centraliza, abre o relato e liga o evento correspondente
  React.useEffect(() => {
    const m = map.current;
    if (!m || !mapContext) return;
    const post = posts.find((p) => p.id === mapContext.postId);
    const ev = post ? categoryEvent(post.category) : null;
    if (ev) setEvents((x) => ({ ...x, [ev]: true }));
    m.setView([mapContext.lat, mapContext.lon], 13);
    const g = groups.current.probe;
    g.clearLayers();
    L.circle([mapContext.lat, mapContext.lon], { radius: 5000, color: "#5ab4e3", weight: 1.5, fill: false, dashArray: "4 4", interactive: false }).addTo(g);
    // a marcação do relato abre assim que os marcadores existirem (o fundo do mapa pode ainda estar carregando)
    pendingFocus.current = mapContext.postId;
    focusPending();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mapContext]);

  const myRegion = () => {
    const m = map.current;
    if (!m || !cemaden) return;
    const si = scopeInfo(filters.scope, st.follows);
    const muns = si.municipios ?? COMMUNITIES.filter((c) => st.follows.includes(c.id)).flatMap((c) => c.municipios ?? []);
    const b = muns.length ? municipioBounds(cemaden, muns) : undefined;
    if (b) m.fitBounds(b, { padding: [20, 20] });
    else m.setView([-3.3, -59.7], 8);
  };
  const world = () => map.current?.setView([-8, -40], 2);

  const baseTxt = offline ? "Blue Marble (sem internet)" : baseUsed?.kind === "google" ? baseUsed.label : baseUsed?.kind === "dia" ? `${baseUsed.label} · ${dayLabel(baseUsed.date)}` : baseUsed?.kind === "bluemarble" ? "Blue Marble" : "carregando…";
  const dateStrip = [
    `Fundo: ${baseTxt}${layers.hls && zoom >= HLS_MIN_ZOOM && !base.startsWith("google") ? " + detalhe NASA HLS (30 m)" : ""}`,
    events.queimada ? `Focos: ${live.fires.length.toLocaleString(LOCALE)} / 48 h` : null,
    ...activeLayers.map((l) => `${EVENTS[l.event].label}: ${dayLabel(dateOf(l.lagDays))}`),
    layers.nisar ? `NISAR: até ${dayLabel(nisarEnd)}` : null,
  ].filter(Boolean) as string[];
  const liveStale = live.receivedAt && Date.now() - live.receivedAt > SARS.staleMs;

  const layerSrc = (l: SarsLayer) => (
    <span className="layer-src">
      {`${l.source} · ${dayLabel(dateOf(l.lagDays))}`}{" "}
      {health[l.id] === "falha" ? <b className="warn-text">Não carregou: sem internet ou sem imagem para essa data.</b> : health[l.id] === "carregando" ? "Carregando…" : null}
    </span>
  );

  return (
    <div className="mapwrap">
      <div ref={host} className="map nasa-map" role="application" aria-label="Mapa-múndi com dados da NASA" />
      <div className="event-bar" role="group" aria-label={`Eventos no mapa (${SARS.name})`}>
        {EVENT_ORDER.map((e) => (
          <button key={e} className={`chip event-chip ${e}`} aria-pressed={events[e]} onClick={() => toggleEvent(e)} style={{ ["--ec" as string]: EVENTS[e].color }}>
            <Icon name={EVENTS[e].icon} size={15} /> {EVENTS[e].label}
          </button>
        ))}
      </div>
      <div className="map-bottom-stack">
        {mapContext && (
          <div className="map-context" role="status">
            <div className="row" style={{ justifyContent: "space-between", flexWrap: "nowrap" }}>
              <b>Contexto do relato: {mapContext.label}</b>
              <button className="btn sm ghost" onClick={() => setMapContext(undefined)} aria-label="Sair do contexto do relato">
                <Icon name="close" />
              </button>
            </div>
            {mapContext.observedAt && <span>Observado em {fmtDate(mapContext.observedAt, true)}. Camadas da NASA do dia da observação; círculo de 5 km.</span>}
          </div>
        )}
        {outlineName && (
          <div className="outline-chip" role="status">
            <span className="grow">
              Limite de <b>{outlineName}</b>
            </span>
            <button
              className="btn sm ghost"
              onClick={() => {
                groups.current.outline.clearLayers();
                setOutlineName("");
              }}
              aria-label="Tirar o limite do município"
            >
              <Icon name="close" />
            </button>
          </div>
        )}
        {events.queimada && (
          <div className={`live-pill ${live.mode} ${liveStale ? "stale" : ""}`} role="status" aria-live="polite">
            <span className="dot" aria-hidden />
            <span className="grow">
              <b>{LIVE_LABEL[live.mode]}</b>
              {live.receivedAt ? ` · atualizado ${ago(live.receivedAt)}` : ""}
              {live.mode === "falha" ? " · detalhes em Camadas" : ""}
            </span>
            <button className="btn sm ghost" onClick={refreshLive} aria-label="Atualizar focos">
              <Icon name="refresh" />
            </button>
          </div>
        )}
        <div className="map-ctrl map-tools" role="toolbar" aria-label="Ferramentas do mapa">
          <button className="btn tool" onClick={() => setPanel(panel === "search" ? "" : "search")} aria-expanded={panel === "search"} aria-label="Buscar lugar">
            <Icon name="search" /> <span>Buscar</span>
          </button>
          <button className="btn tool" onClick={myRegion} aria-label="Minha região">
            <Icon name="locate" /> <span>Região</span>
          </button>
          <button className="btn tool" onClick={world} aria-label="Ver o mundo">
            <Icon name="map" /> <span>Mundo</span>
          </button>
          <button className="btn tool" onClick={() => setPanel(panel === "layers" ? "" : "layers")} aria-expanded={panel === "layers"} aria-label="Camadas e legenda">
            <Icon name="layers" /> <span>Camadas</span>
          </button>
          <a className="btn tool" href="#nisar" aria-label="Explorador NISAR">
            <Icon name="radar" /> <span>NISAR</span>
          </a>
        </div>
      </div>
      {dateStrip.length > 0 && (
        <div className="date-strip" aria-label="Datas das camadas">
          {dateStrip.map((s) => (
            <span key={s}>{s}</span>
          ))}
        </div>
      )}
      {panel === "search" && (
        <div className="sheet" role="dialog" aria-label="Buscar lugar">
          <div className="section-title">
            <h2>Buscar município ou comunidade</h2>
            <button className="btn sm ghost" onClick={() => setPanel("")} aria-label="Fechar busca">
              <Icon name="close" />
            </button>
          </div>
          <LocalitySearch
            id="map-search"
            onPick={(lat, lon, name, hit) => {
              const m = map.current!;
              // município ou cidade: desenha o limite do município e enquadra o território inteiro
              const og = groups.current.outline;
              og.clearLayers();
              const mun = hit.type === "município" ? hit.name : hit.type === "cidade" ? hit.detail : undefined;
              const geom = mun ? cemaden?.geometries[mun]?.geometry : undefined;
              if (mun && geom) {
                const shape = L.geoJSON(geom as never, { interactive: false, style: { color: "#5ab4e3", weight: 3, opacity: 0.95, dashArray: "7 5", fill: true, fillColor: "#5ab4e3", fillOpacity: 0.08 } });
                L.geoJSON(geom as never, { interactive: false, style: { color: "#08121f", weight: 6, opacity: 0.35, fill: false } }).addTo(og); // contorno escuro por baixo: a linha aparece sobre nuvens e mata
                shape.addTo(og);
                m.fitBounds(shape.getBounds(), { padding: [24, 24], maxZoom: 11 });
                setOutlineName(mun);
              } else {
                setOutlineName("");
                m.setView([lat, lon], 10);
              }
              const g = groups.current.probe;
              g.clearLayers();
              L.marker([lat, lon], { icon: pinIcon("#1b6c97", "dot") })
                .bindTooltip(esc(name), { permanent: true, direction: "top", offset: [0, -28] })
                .addTo(g);
              setPanel("");
              void probe(lat, lon);
            }}
          />
        </div>
      )}
      {panel === "layers" && (
        <div className="sheet" role="dialog" aria-label="Camadas e legenda">
          <div className="section-title">
            <h2>Camadas da NASA</h2>
            <button className="btn sm ghost" onClick={() => setPanel("")} aria-label="Fechar camadas">
              <Icon name="close" />
            </button>
          </div>
          <div className="legend">
            {EVENT_ORDER.map((e) => {
              const ls = SARS_LAYERS.filter((l) => l.event === e);
              return (
                <div key={e} className="legend-item">
                  <label className="toggle">
                    <input id={`ly-ev-${e}`} type="checkbox" checked={events[e]} onChange={() => toggleEvent(e)} />
                    <span style={{ color: EVENTS[e].color, display: "inline-flex" }}>
                      <Icon name={EVENTS[e].icon} size={16} />
                    </span>{" "}
                    {EVENTS[e].label}
                  </label>
                  {e === "queimada" && (
                    <>
                      <span className="small">
                        <b>Focos de fogo ativo (NASA FIRMS, VIIRS)</b>
                      </span>
                      <div className="swatches">
                        <span className="swatch">
                          <i className="dot" style={{ background: "#ff3d00" }} />
                          até 6 h
                        </span>
                        <span className="swatch">
                          <i className="dot" style={{ background: "#ff7a1a" }} />
                          até 24 h
                        </span>
                        <span className="swatch">
                          <i className="dot" style={{ background: "#ffad4d" }} />
                          até 48 h
                        </span>
                      </div>
                      <span className="layer-src">
                        {`${live.fires.length} focos nas últimas 48 h · ${live.source}`}
                        {live.mode === "falha" || live.mode === "desligado" ? ` · ${LIVE_LABEL[live.mode]}` : ""}
                      </span>
                    </>
                  )}
                  {ls.map((l) => (
                    <div key={l.id} className="stack" style={{ gap: 4 }}>
                      <span className="small">
                        <b>{l.title}</b>
                      </span>
                      <div className="swatches">
                        {l.legend.map((s) => (
                          <span key={s.label} className="swatch">
                            <i style={{ background: s.color }} />
                            {s.label}
                          </span>
                        ))}
                      </div>
                      {layerSrc(l)}
                    </div>
                  ))}
                  {e === "enchente" && (
                    <>
                      <label className="toggle small">
                        <input id="ly-nisar" type="checkbox" checked={layers.nisar} onChange={(ev) => set({ nisar: ev.target.checked })} /> Radar NISAR (NASA/ISRO)
                      </label>
                      {layers.nisar && (
                        <>
                          <label className="field small">
                            <span>Opacidade</span>
                            <input id="ly-nisar-op" className="range" type="range" min={0.2} max={1} step={0.05} value={layers.nisarOpacity} onChange={(ev) => set({ nisarOpacity: Number(ev.target.value) })} />
                          </label>
                          <span className="layer-src">
                            {`Verde = vegetação · rosa/magenta = solo e áreas abertas · escuro = água parada · até ${dayLabel(nisarEnd)}`}{" "}
                            {nisarState === "carregando" ? "Carregando…" : null}{" "}
                            <a href="#nisar">Comparar datas no Explorador NISAR</a>
                          </span>
                        </>
                      )}
                    </>
                  )}
                </div>
              );
            })}
            <div className="legend-item">
              <label className="toggle">
                <input id="ly-posts" type="checkbox" checked={layers.posts} onChange={(e) => set({ posts: e.target.checked })} /> Relatos da comunidade
              </label>
              <span className="layer-src">
                {`Borda pulsante = fora do radar do ${SARS.name} · ${visiblePosts.length} no filtro atual`}
              </span>
            </div>
            <div className="legend-item">
              <span className="toggle">Fundo do mapa (NASA)</span>
              <div className="row">
                {baseOpts.map((b) => (
                  <button key={b} className="chip" aria-pressed={base === b && !offline} onClick={() => chooseBase(b)}>
                    {APP_BASES[b].label}
                  </button>
                ))}
              </div>
              <span className="layer-src">
                {base.startsWith("google") && googleKey() && googleFail ? `O Google não respondeu (${googleFail}); usando o fundo da NASA. ` : ""}
                {!online ? "Você está sem conexão: sem internet, só a imagem Blue Marble do entorno de Manaus fica disponível." : ""}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/** Minimapa para escolher o local de um relato (usa o mapa online, com o offline por baixo). */
export function LocationPicker({ lat, lon, onPick }: { lat?: number; lon?: number; onPick: (lat: number, lon: number) => void }) {
  const host = React.useRef<HTMLDivElement>(null);
  const map = React.useRef<L.Map>();
  const mk = React.useRef<L.Marker>();
  const lines = useData<Lines>("osm/lines.json");
  const places = useData<PlacesFile>("osm/places.json");
  const cb = React.useRef(onPick);
  cb.current = onPick;
  React.useEffect(() => {
    if (!host.current || map.current) return;
    const m = L.map(host.current, { minZoom: 3, maxZoom: 18 }).setView([lat ?? -3.2, lon ?? -59.9], lat != null ? 15 : 8);
    m.attributionControl.setPrefix(false);
    const g = L.layerGroup().addTo(m);
    (m as unknown as { _ig: L.LayerGroup })._ig = g;
    if (navigator.onLine) L.tileLayer(OSM_URL, { maxZoom: 19, attribution: OSM_ATTR }).addTo(m); // ruas e nomes ajudam a marcar o ponto exato
    m.on("click", (e: L.LeafletMouseEvent) => cb.current(e.latlng.lat, e.latlng.lng));
    map.current = m;
    host.current.classList.add("map-simple");
    return () => {
      m.remove();
      map.current = undefined;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  React.useEffect(() => {
    const m = map.current;
    if (m && (lines.data || places.data)) addVectorLayers(m, lines.data, places.data, (m as unknown as { _ig: L.LayerGroup })._ig, L.layerGroup().addTo(m), false);
  }, [lines.data, places.data]);
  React.useEffect(() => {
    const m = map.current;
    if (!m) return;
    if (lat == null || lon == null || !isFinite(lat) || !isFinite(lon)) {
      mk.current?.remove();
      mk.current = undefined;
      return;
    }
    if (!mk.current) mk.current = L.marker([lat, lon], { icon: pinIcon("#1b6c97", "dot") }).addTo(m);
    else mk.current.setLatLng([lat, lon]);
    if (!m.getBounds().contains([lat, lon]) || m.getZoom() < 13) m.setView([lat, lon], Math.max(m.getZoom(), 15));
  }, [lat, lon]);
  return <div ref={host} className="minimap" role="application" aria-label="Toque no mapa para escolher o local da observação" />;
}

export type { MapContext };
