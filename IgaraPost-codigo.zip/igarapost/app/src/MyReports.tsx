import { LOCALE } from "./i18n/lang";
import React from "react";
import type { Post, RadarCheck, RadarStatus } from "./types";
import { Icon } from "./Icon";
import { ExpandPicker } from "./ExpandPicker";
import { go, useApp } from "./ctx";
import { commit, StorageError, useStore } from "./store";
import { cardBg, CATEGORIES, isRemoved } from "./seed";
import { fmtDate, relTime } from "./data";
import { enqueue, processOutbox, SYNC_LABEL, usePeoplePosts } from "./sync";
import { CornerLogo, RadarChip, SyncChip } from "./PostCard";
import { radarCheck, RADAR_LABEL, recheckStatus } from "./sars/radar";
import { getLive, useLive } from "./sars/live";
import { SARS } from "./sars/config";

/** Relatos da própria pessoa: deste aparelho, da fila de envio e do servidor. */
export function useMyReports(): Post[] {
  const st = useStore();
  const people = usePeoplePosts();
  return React.useMemo(
    () => people.filter((p) => !isRemoved(p) && (p.mine || p.authorId === "me" || (st.server.user && p.authorId === st.server.user.id))).sort((a, b) => Date.parse(b.observedAt) - Date.parse(a.observedAt)),
    [people, st.server.user],
  );
}

/** Grava o novo resultado da conferência: no aparelho (relato local) ou pela fila de envio. */
function saveRadar(p: Post, radar: RadarCheck) {
  if (p.sync === "local") commit((s) => ({ ...s, posts: s.posts.map((x) => (x.id === p.id ? { ...x, radar } : x)) }));
  else enqueue({ op: "setRadar", id: p.id, radar });
}

type FilterKey = "todos" | "fora" | "confirmado" | "enviado" | "aguardando" | "falha";
const FILTERS: [FilterKey, string][] = [
  ["todos", "Todos"],
  ["fora", "Fora do radar"],
  ["confirmado", "Confirmados"],
  ["enviado", "Enviados"],
  ["aguardando", "Não enviados"],
  ["falha", "Com falha"],
];
const match = (p: Post, f: FilterKey) =>
  f === "todos" ||
  (f === "fora" && p.radar?.status === "fora_do_radar") ||
  (f === "confirmado" && p.radar?.status === "confirmado") ||
  (f === "enviado" && (p.sync === "publicado" || p.sync === "oculto")) ||
  (f === "aguardando" && (p.sync === "pendente" || p.sync === "enviando" || p.sync === "local")) ||
  (f === "falha" && p.sync === "falhou");

/** Pode valer a pena conferir de novo: ainda sem confirmação e observado há menos de 14 dias. */
const RECHECK_AFTER_MS = 30 * 60_000;
function needsRecheck(p: Post, now = Date.now()) {
  if (p.lat == null || p.lon == null) return false;
  if (now - Date.parse(p.observedAt) > 14 * 864e5) return false;
  const st: RadarStatus | undefined = p.radar?.status;
  if (st === "no_radar" || st === "confirmado") return false;
  const last = Date.parse(p.radar?.recheckedAt ?? p.radar?.checkedAt ?? "1970-01-01");
  return now - last > RECHECK_AFTER_MS;
}

export function MyReports() {
  const { cemaden, cemadenFailed, toast } = useApp();
  const live = useLive();
  const mine = useMyReports();
  const [filter, setFilter] = React.useState<FilterKey>("todos");
  const [busy, setBusy] = React.useState<Record<string, boolean>>({});
  const [autoMsg, setAutoMsg] = React.useState("");
  const liveOk = live.mode === "ao_vivo" || live.mode === "polling" || live.mode === "direto";

  const recheck = React.useCallback(
    async (p: Post, quiet = false) => {
      if (p.lat == null || p.lon == null) return;
      setBusy((b) => ({ ...b, [p.id]: true }));
      try {
        const L = getLive();
        const now = await radarCheck({ category: p.category, lat: p.lat, lon: p.lon, observedAt: p.observedAt }, { fires: L.fires, liveOk: L.mode === "ao_vivo" || L.mode === "polling" || L.mode === "direto", cemaden, cemadenFailed });
        const next = recheckStatus(p.radar, now);
        saveRadar(p, next);
        if (!quiet) toast(next.status === "confirmado" ? `O ${SARS.name} passou a mostrar esse evento.` : next.recheckedAt && next.status !== "nao_verificado" ? "Conferido de novo: sem dado novo." : `Conferido: ${RADAR_LABEL[next.status]}.`);
      } catch (e) {
        if (!quiet) toast(e instanceof StorageError ? e.message : `Não foi possível conferir agora: ${(e as Error).message}`);
      } finally {
        setBusy((b) => ({ ...b, [p.id]: false }));
      }
    },
    [cemaden, cemadenFailed, toast],
  );

  // ao abrir (e quando os dados ao vivo chegam), confere de novo os relatos recentes que ainda estão fora do radar
  const autoDone = React.useRef(false);
  React.useEffect(() => {
    if (autoDone.current || !liveOk || !cemaden) return;
    autoDone.current = true;
    const list = mine.filter((p) => needsRecheck(p)).slice(0, 5);
    if (!list.length) return;
    setAutoMsg(`Conferindo ${list.length} relato(s) recente(s) com o ${SARS.name}…`);
    void (async () => {
      for (const p of list) await recheck(p, true);
      setAutoMsg(`Relatos recentes conferidos de novo com o ${SARS.name} às ${new Date().toLocaleTimeString(LOCALE, { hour: "2-digit", minute: "2-digit" })}.`);
    })();
  }, [liveOk, cemaden, mine, recheck]);

  const count = (f: FilterKey) => mine.filter((p) => match(p, f)).length;
  const list = mine.filter((p) => match(p, filter));

  if (!mine.length)
    return (
      <div className="empty panel stack" style={{ alignItems: "center" }}>
        <Icon name="history" size={28} />
        <b>Você ainda não relatou nenhuma ocorrência.</b>
        <a className="btn primary" href="#relatar">
          <Icon name="plus" /> Relatar
        </a>
      </div>
    );

  return (
    <section className="stack" aria-label="Meus relatos">
      <div className="report-summary">
        <button className="stat" aria-pressed={filter === "todos"} onClick={() => setFilter("todos")}>
          <b>{mine.length}</b>
          <span>relatos</span>
        </button>
        <button className="stat fora" aria-pressed={filter === "fora"} onClick={() => setFilter("fora")}>
          <b>{count("fora")}</b>
          <span>fora do radar</span>
        </button>
        <button className="stat ok" aria-pressed={filter === "confirmado"} onClick={() => setFilter("confirmado")}>
          <b>{count("confirmado")}</b>
          <span>confirmados depois</span>
        </button>
        <button className={`stat ${count("falha") ? "warn" : ""}`} aria-pressed={filter === "aguardando" || filter === "falha"} onClick={() => setFilter(count("falha") ? "falha" : "aguardando")}>
          <b>{count("aguardando") + count("falha")}</b>
          <span>{count("falha") ? `não enviados (${count("falha")} com falha)` : "não enviados"}</span>
        </button>
      </div>
      <div className="xpick-block">
        <ExpandPicker
          id="meus-filtro"
          label="Filtrar meus relatos"
          options={FILTERS.map(([k, l]) => ({ key: k, label: k !== "todos" ? `${l} (${count(k)})` : l }))}
          value={filter}
          onChange={setFilter}
        />
      </div>
      {autoMsg && (
        <p className="small muted" role="status">
          {autoMsg}
        </p>
      )}
      {count("falha") > 0 && (
        <div className="callout warn small row" style={{ justifyContent: "space-between" }}>
          <span>{count("falha")} relato(s) com falha no envio. Abra para corrigir ou tente de novo.</span>
          <button className="btn sm" onClick={() => processOutbox(true)}>
            Tentar de novo
          </button>
        </div>
      )}
      <div className="list">
        {list.map((p) => (
          <ReportItem key={p.id} p={p} busy={!!busy[p.id]} onRecheck={() => recheck(p)} />
        ))}
        {!list.length && <div className="empty panel small">Nenhum relato com esse filtro.</div>}
      </div>
    </section>
  );
}

function ReportItem({ p, busy, onRecheck }: { p: Post; busy: boolean; onRecheck: () => void }) {
  const { setMapContext } = useApp();
  const cat = CATEGORIES[p.category];
  const r = p.radar;
  const steps: { at: string; label: string; tone?: "ok" | "warn" | "info" }[] = [{ at: p.observedAt, label: "Ocorrência observada" }];
  steps.push({ at: p.publishedAt, label: p.sync === "local" ? "Relato salvo neste aparelho" : p.sync === "pendente" || p.sync === "enviando" || p.sync === "falhou" ? "Relato registrado no aparelho" : "Relato enviado" });
  const first = r?.firstCheck ?? r;
  if (first) steps.push({ at: first.checkedAt, label: `Conferência com o ${SARS.name}: ${RADAR_LABEL[first.status]}`, tone: first.status === "fora_do_radar" ? "warn" : "info" });
  if (r && r.firstCheck && r.status !== r.firstCheck.status) steps.push({ at: r.checkedAt, label: RADAR_LABEL[r.status], tone: r.status === "confirmado" ? "ok" : "info" });
  if (r?.recheckedAt) steps.push({ at: r.recheckedAt, label: "Conferido de novo: sem dado novo" });
  if (p.editedAt) steps.push({ at: p.editedAt, label: "Relato editado" });
  if (p.sync === "falhou") steps.push({ at: new Date().toISOString(), label: `Falha no envio${p.syncError ? `: ${p.syncError}` : ""}`, tone: "warn" });
  if (p.sync === "oculto") steps.push({ at: p.editedAt ?? p.publishedAt, label: "Ocultado para outras pessoas após revisão", tone: "warn" });
  steps.sort((a, b) => Date.parse(a.at) - Date.parse(b.at));

  const showOnMap = () => {
    if (p.lat == null || p.lon == null) return;
    setMapContext({ postId: p.id, lat: p.lat, lon: p.lon, observedAt: p.observedAt, label: `${cat.short} · ${p.municipio ?? "local do relato"}` });
    go("#mapa");
  };

  // mesmo fundo e borda das publicações do feed, conforme o tipo do relato
  const bg = cardBg(p.category);
  return (
    <article className={`panel report-item ${r?.status ?? ""} ${bg?.className ?? ""}`} style={bg?.style} aria-label={`${cat.label}, observado em ${fmtDate(p.observedAt, true)}`}>
      {bg?.cornerLogo && <CornerLogo />}
      <div className="ri-head">
        <span className="ri-ico" style={{ color: cat.color }} aria-hidden>
          <Icon name={cat.icon} size={20} />
        </span>
        <div className="grow" style={{ minWidth: 0 }}>
          <b>
            {cat.label}
            {p.municipio ? ` · ${p.municipio}` : ""}
          </b>
          <div className="small muted">
            Observado em {fmtDate(p.observedAt, true)} · relatado {relTime(p.publishedAt)}
          </div>
        </div>
        <SyncChip p={p} />
      </div>
      <p className="text clamp small" translate="no">
        {p.text}
      </p>
      <div className="row" style={{ gap: 6 }}>
        {r ? <RadarChip r={r} /> : <span className="badge radar nao_verificado">Sem conferência com o {SARS.name}</span>}
      </div>
      {r && r.status !== "nao_verificado" && <p className="small muted">{r.detail}</p>}
      <details className="ri-history">
        <summary className="small">Histórico e status</summary>
        <ol className="timeline">
          {steps.map((s, i) => (
            <li key={i} className={s.tone}>
              <span className="small muted">{fmtDate(s.at, true)}</span>
              <span className="small">{s.label}</span>
            </li>
          ))}
          <li className="now">
            <span className="small muted">Agora</span>
            <span className="small">
              Envio: <b>{SYNC_LABEL[p.sync ?? "publicado"]}</b>
            </span>
          </li>
        </ol>
      </details>
      <div className="row ri-actions">
        <a className="btn sm" href={`#post-${p.id}`}>
          Abrir
        </a>
        <a className="btn sm" href={`#editar-${p.id}`}>
          <Icon name="edit" /> Editar
        </a>
        <button className="btn sm" onClick={onRecheck} disabled={busy || p.lat == null}>
          {busy ? <span className="spin" aria-hidden /> : <Icon name="refresh" />} Conferir de novo
        </button>
        <button className="btn sm" onClick={showOnMap} disabled={p.lat == null}>
          <Icon name="map" /> Mapa
        </button>
      </div>
    </article>
  );
}
