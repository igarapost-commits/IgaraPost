/** Local escolhido no mapa para um novo relato (passado do Mapa para o formulário Relatar). */
export const draftLocation: { lat?: number; lon?: number } = {};
