/**
 * Tradução da interface: o app é escrito em português e, em inglês ou
 * espanhol, cada texto que aparece na tela (e os atributos aria-label,
 * placeholder, title e alt) passa pelo dicionário do idioma. Funciona
 * também em popups do mapa, avisos e janelas de confirmação.
 * Conteúdo escrito pelas pessoas fica dentro de [translate="no"] e não é traduzido.
 */
import { LANG } from "./lang";
import { STRINGS } from "./strings";

type Pat = { re: RegExp; out: string };
const norm = (s: string) => s.replace(/\s+/g, " ").trim();
const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

let exact = new Map<string, string>();
let lower = new Map<string, string>();
let pats: Pat[] = [];
function compile(dict: Record<string, string>) {
  exact = new Map();
  lower = new Map();
  pats = [];
  const withPh: [string, string][] = [];
  for (const [k0, v] of Object.entries(dict)) {
    const k = norm(k0);
    if (/\{\d\}/.test(k)) withPh.push([k, v]);
    else {
      exact.set(k, v);
      if (!lower.has(k.toLowerCase())) lower.set(k.toLowerCase(), v);
    }
  }
  // padrões mais específicos (mais texto fixo) primeiro
  withPh.sort((a, b) => b[0].replace(/\{\d\}/g, "").length - a[0].replace(/\{\d\}/g, "").length);
  for (const [k, v] of withPh) {
    const parts = k.split(/(\{\d\})/);
    const re = new RegExp("^" + parts.map((p) => (/^\{\d\}$/.test(p) ? "(.*?)" : esc(p))).join("") + "$", "s");
    // reordena as capturas pela ordem dos marcadores na chave
    const order = parts.filter((p) => /^\{\d\}$/.test(p)).map((p) => Number(p[1]));
    let out = v;
    order.forEach((n, i) => (out = out.split(`{${n}}`).join(`\u0000${i}\u0000`)));
    pats.push({ re, out });
  }
}

export function translate(s: string, depth = 0): string | null {
  const k = norm(s);
  if (!k) return null;
  const hit = exact.get(k);
  if (hit != null) return hit;
  // mesma frase com outra caixa (ex.: "todo o período" vindo de toLowerCase())
  const lo = lower.get(k.toLowerCase());
  if (lo != null) return k[0] !== k[0].toUpperCase() ? lo[0].toLowerCase() + lo.slice(1) : lo;
  if (depth > 4) return null;
  for (const p of pats) {
    const m = p.re.exec(k);
    if (!m) continue;
    const out = p.out.replace(/\u0000(\d+)\u0000/g, (_, i) => {
      const v = m[Number(i) + 1];
      return translate(v, depth + 1) ?? v;
    });
    // padrão genérico ("{0} · {1}") que não mudou nada: segue procurando
    if (out !== k) return out;
  }
  return null;
}
/** Traduz um texto inteiro; se não houver entrada, tenta linha por linha. */
export function translateText(s: string): string {
  const t = translate(s);
  if (t != null) return t;
  return s
    .split("\n")
    .map((l) => {
      const x = translate(l);
      return x == null ? l : l.replace(norm(l), x);
    })
    .join("\n");
}

const ATTRS = ["aria-label", "placeholder", "title", "alt", "aria-valuetext"];
/** texto original (português) e o que pusemos no nó */
const texts = new WeakMap<Text, { o: string; out: string }>();
const attrs = new WeakMap<Element, Record<string, string>>();
const missing = new Set<string>();
const looksPt = (s: string) => /[A-Za-zÀ-ú]/.test(s);

function skip(el: Element | null): boolean {
  for (let e = el; e; e = e.parentElement) {
    const tag = e.tagName;
    if (tag === "SCRIPT" || tag === "STYLE" || tag === "TEXTAREA" || tag === "CODE") return true;
    if (e.getAttribute("translate") === "no") return true;
    if (e.classList.contains("leaflet-tile-pane")) return true;
  }
  return false;
}
const origOf = (n: Text) => {
  const cur = n.nodeValue ?? "";
  const rec = texts.get(n);
  return rec && rec.out === cur ? rec.o : cur;
};
function put(n: Text, o: string, out: string) {
  texts.set(n, { o, out });
  if (n.nodeValue !== out) n.nodeValue = out;
}
function single(n: Text, o: string) {
  if (!looksPt(o)) return put(n, o, o);
  const t = translate(o);
  if (t == null) {
    missing.add(norm(o));
    return put(n, o, o);
  }
  put(n, o, o.match(/^\s*/)![0] + t + o.match(/\s*$/)![0]);
}
/**
 * O React escreve uma frase com valores no meio como vários nós de texto
 * vizinhos ("Raio de ", "15", " km, de ", …). Traduzimos a frase inteira
 * (com {0}, {1}… no lugar dos valores) e, se não houver entrada, nó por nó.
 */
function doText(n: Text) {
  const rec = texts.get(n);
  if (rec && rec.out === n.nodeValue) return;
  const parent = n.parentNode as Element | null;
  if (!parent || skip(parent as Element)) return put(n, n.nodeValue ?? "", n.nodeValue ?? "");
  let a: Node = n;
  while (a.previousSibling && a.previousSibling.nodeType === 3) a = a.previousSibling;
  const run: Text[] = [];
  for (let x: Node | null = a; x && x.nodeType === 3; x = x.nextSibling) run.push(x as Text);
  const origs = run.map(origOf);
  if (run.length > 1) {
    const joined = origs.join("");
    if (looksPt(joined)) {
      const t = translate(joined);
      if (t != null) {
        const out = joined.match(/^\s*/)![0] + t + joined.match(/\s*$/)![0];
        run.forEach((x, i) => put(x, origs[i], i === 0 ? out : ""));
        return;
      }
      missing.add("RUN " + norm(joined));
    }
  }
  run.forEach((x, i) => single(x, origs[i]));
}
function doAttr(el: Element, a: string) {
  const cur = el.getAttribute(a);
  if (cur == null) return;
  const rec = attrs.get(el) ?? {};
  if (rec[a] === cur) return;
  // o texto digitado num campo não é traduzido, mas o placeholder do campo é
  if (!looksPt(cur) || skip(el.tagName === "TEXTAREA" ? el.parentElement : el)) {
    rec[a] = cur;
    attrs.set(el, rec);
    return;
  }
  const t = translate(cur);
  if (t == null) missing.add(norm(cur));
  rec[a] = t ?? cur;
  attrs.set(el, rec);
  if (t != null && t !== cur) el.setAttribute(a, t);
}
function walk(root: Node) {
  if (root.nodeType === 3) return doText(root as Text);
  if (root.nodeType !== 1 && root.nodeType !== 11) return;
  if (root.nodeType === 1) {
    const el = root as Element;
    for (const a of ATTRS) if (el.hasAttribute(a)) doAttr(el, a);
    if (skip(el)) return;
  }
  const tw = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, {
    acceptNode: (n) => (n.nodeType === 1 && (n as Element).tagName !== "TEXTAREA" && skip(n as Element) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT),
  });
  for (let n = tw.nextNode(); n; n = tw.nextNode()) {
    if (n.nodeType === 3) doText(n as Text);
    else for (const a of ATTRS) if ((n as Element).hasAttribute(a)) doAttr(n as Element, a);
  }
}

export function startI18n() {
  document.documentElement.lang = LANG === "pt" ? "pt-BR" : LANG;
  if (LANG === "pt") return;
  const col = LANG === "en" ? 0 : 1;
  const dict: Record<string, string> = {};
  for (const part of STRINGS) for (const [pt, en, es] of part) dict[pt] = [en, es][col];
  compile(dict);
  const obs = new MutationObserver((ms) => {
    for (const m of ms) {
      if (m.type === "characterData") doText(m.target as Text);
      else if (m.type === "attributes") doAttr(m.target as Element, m.attributeName!);
      else m.addedNodes.forEach(walk);
    }
  });
  obs.observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  walk(document.documentElement);
  const wrap = <F extends (msg?: string, ...r: never[]) => unknown>(f: F) =>
    ((msg?: unknown, ...rest: never[]) => f.call(window, typeof msg === "string" ? translateText(msg) : (msg as string), ...rest)) as F;
  window.alert = wrap(window.alert);
  window.confirm = wrap(window.confirm);
  window.prompt = wrap(window.prompt);
  (window as unknown as { __i18nMissing: Set<string> }).__i18nMissing = missing;
}

/** Para os testes: carrega o dicionário de um idioma sem mexer na página. */
export function loadDict(l: "en" | "es") {
  const col = l === "en" ? 0 : 1;
  const dict: Record<string, string> = {};
  for (const part of STRINGS) for (const [pt, en, es] of part) dict[pt] = [en, es][col];
  compile(dict);
}
