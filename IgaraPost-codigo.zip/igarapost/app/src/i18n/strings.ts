import { CORE } from "./s_core";
import { DETAIL } from "./s_detail";
import { PAGES } from "./s_pages";
import { MAP } from "./s_map";
import { HELP } from "./s_help";
import { SEED } from "./s_seed";
import { HOWTO } from "./s_howto";
/** Todas as tabelas de tradução, na ordem: as últimas sobrescrevem as primeiras em chaves repetidas. */
export const STRINGS: [string, string, string][][] = [CORE, DETAIL, PAGES, MAP, HELP, SEED, HOWTO];
