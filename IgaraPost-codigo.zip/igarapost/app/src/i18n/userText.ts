/**
 * Relatos e comentários ficam no idioma em que foram escritos.
 * Aqui: detectar o idioma de um texto (sem internet) e traduzir sob pedido
 * ("Ver tradução"). A tradução é feita pelo serviço gratuito MyMemory.
 */
import { LANG, type Lang } from "./lang";

const WORDS: Record<Lang, string[]> = {
  pt: "não que de do da dos das em no na nos nas um uma com para por mais muito está estão foi são tem isso esse essa aqui ontem hoje fumaça água perto também mas ao às você eu nós rio casa ainda agora já fogo chuva cedo tarde cheiro olhos alguém sabe vi está".split(" "),
  es: "que de del el los las en un una con para por más muy está están fue son tiene esto ese esa aquí ayer hoy humo agua cerca también pero al usted yo nosotros río casa todavía ahora ya fuego lluvia temprano tarde y se hay olor ojos alguien sabe vi".split(" "),
  en: "the and is are was were of to in on at a an with for by more very this that here yesterday today smoke water near also but you i we river house still now already fire rain early there it from have has smell eyes someone saw".split(" "),
};
const SETS = Object.fromEntries(Object.entries(WORDS).map(([k, v]) => [k, new Set(v)])) as Record<Lang, Set<string>>;

/** Idioma provável do texto (português, inglês ou espanhol) ou null se não der para saber. */
export function detectLang(text: string): Lang | null {
  const t = text.toLowerCase();
  const score: Record<Lang, number> = { pt: 0, en: 0, es: 0 };
  for (const w of t.match(/[a-zà-ÿ]+/g) ?? []) for (const l of ["pt", "en", "es"] as Lang[]) if (SETS[l].has(w)) score[l]++;
  score.pt += 2 * ((t.match(/[ãõç]|ão\b|ões\b|ç/g) ?? []).length);
  score.es += 3 * ((t.match(/[ñ¿¡]|ción\b|ciones\b/g) ?? []).length);
  const order = (Object.entries(score) as [Lang, number][]).sort((a, b) => b[1] - a[1]);
  const [best, second] = order;
  if (best[1] < 2 || best[1] === second[1]) return null;
  return best[0];
}

/** Idioma de um relato/comentário: o salvo junto, ou o detectado. */
export function textLang(text: string, saved?: string): Lang | null {
  const d = detectLang(text);
  if (d) return d;
  return saved === "pt" || saved === "en" || saved === "es" ? saved : null;
}

/** Precisa do botão "Ver tradução"? */
export const needsTranslation = (text: string, saved?: string) => {
  const l = textLang(text, saved);
  return !!l && l !== LANG;
};

const CACHE_KEY = "igarapost:traducoes";
const cache = new Map<string, string>();
try {
  const saved = JSON.parse(localStorage.getItem(CACHE_KEY) || "[]") as [string, string][];
  saved.forEach(([k, v]) => cache.set(k, v));
} catch {
  /* sem cache */
}
function remember(k: string, v: string) {
  cache.set(k, v);
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify([...cache].slice(-150)));
  } catch {
    /* cheio: fica só na memória */
  }
}

/** Divide em pedaços de até ~450 bytes (o MyMemory aceita 500), sem cortar frases quando possível. */
function chunks(text: string): string[] {
  const enc = new TextEncoder();
  const bytes = (s: string) => enc.encode(s).length;
  const out: string[] = [];
  let cur = "";
  for (const sent of text.match(/[^.!?\n]+[.!?]*\s*|\n+/g) ?? [text]) {
    if (bytes(cur + sent) <= 450) {
      cur += sent;
      continue;
    }
    if (cur) out.push(cur);
    cur = "";
    if (bytes(sent) <= 450) cur = sent;
    else
      for (const w of sent.split(/(\s+)/)) {
        if (bytes(cur + w) > 450) {
          out.push(cur);
          cur = "";
        }
        cur += w;
      }
  }
  if (cur) out.push(cur);
  return out.filter((c) => c.trim());
}

const CODE: Record<Lang, string> = { pt: "pt-BR", en: "en-US", es: "es-ES" };
function decode(s: string) {
  const el = document.createElement("textarea");
  el.innerHTML = s;
  return el.value;
}

export class TranslateError extends Error {
  constructor(public kind: "offline" | "limite" | "falha") {
    super(kind);
  }
}

/** Traduz um texto escrito por alguém para o idioma do app. Devolve o texto e a origem da tradução. */
export async function translateUser(text: string, from: Lang, to: Lang = LANG): Promise<{ text: string; via: "app" | "mymemory" }> {
  const key = `${from}|${to}|${text}`;
  const hit = cache.get(key);
  if (hit) return { text: hit, via: "mymemory" };
  if (typeof navigator !== "undefined" && navigator.onLine === false) throw new TranslateError("offline");
  const parts: string[] = [];
  for (const c of chunks(text)) {
    if (!c.trim() || /^\s+$/.test(c)) {
      parts.push(c);
      continue;
    }
    let res: Response;
    try {
      const ctl = new AbortController();
      const t = setTimeout(() => ctl.abort(), 15000);
      res = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(c.trim())}&langpair=${CODE[from]}|${CODE[to]}`, { signal: ctl.signal });
      clearTimeout(t);
    } catch {
      throw new TranslateError("offline");
    }
    if (res.status === 429) throw new TranslateError("limite");
    if (!res.ok) throw new TranslateError("falha");
    const j = (await res.json().catch(() => null)) as { responseStatus?: number | string; responseData?: { translatedText?: string } } | null;
    const tr = j?.responseData?.translatedText ?? "";
    if (Number(j?.responseStatus) === 429 || /MYMEMORY WARNING|YOU USED ALL AVAILABLE FREE TRANSLATIONS/i.test(tr)) throw new TranslateError("limite");
    if (Number(j?.responseStatus) !== 200 || !tr || /QUERY LENGTH LIMIT|INVALID LANGUAGE PAIR/i.test(tr)) throw new TranslateError("falha");
    parts.push(decode(tr) + (/\s$/.test(c) ? c.match(/\s+$/)![0] : ""));
  }
  const out = parts.join("").trim();
  remember(key, out);
  return { text: out, via: "mymemory" };
}
