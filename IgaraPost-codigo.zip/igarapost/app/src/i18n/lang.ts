/** Idioma da interface. Fica salvo neste aparelho; trocar recarrega a tela. */
export type Lang = "pt" | "en" | "es";
const KEY = "igarapost:lang";
export const LANGS: [Lang, string][] = [
  ["pt", "Português (Brasil)"],
  ["en", "English"],
  ["es", "Español"],
];
/**
 * Idioma do celular: o primeiro da lista de preferências do sistema que o app tem
 * (português, espanhol ou inglês, de qualquer país). Outro idioma: inglês.
 */
export function deviceLang(langs: readonly string[] = typeof navigator !== "undefined" ? (navigator.languages?.length ? navigator.languages : [navigator.language]) : []): Lang {
  for (const tag of langs) {
    const base = (tag || "").toLowerCase().split(/[-_]/)[0];
    if (base === "pt" || base === "es" || base === "en") return base;
  }
  return "en";
}
/** A escolha feita em Configurações vale primeiro; sem escolha, segue o idioma do celular. */
export const LANG: Lang = (() => {
  try {
    const v = localStorage.getItem(KEY);
    if (v === "pt" || v === "en" || v === "es") return v;
  } catch {
    /* sem armazenamento: segue o celular */
  }
  return deviceLang();
})();
/** Código usado em datas e números (toLocaleString). */
export const LOCALE = ({ pt: "pt-BR", en: "en-US", es: "es-ES" } as const)[LANG];
export function setLang(l: Lang) {
  if (l === LANG) return;
  try {
    localStorage.setItem(KEY, l);
    // a troca de idioma recarrega a tela: não repete a abertura
    sessionStorage.setItem("igarapost:semIntro", "1");
  } catch {
    /* ignora */
  }
  location.reload();
}
/** Escolhe o texto do idioma atual (para trechos montados no código). */
export const tr3 = (pt: string, en: string, es: string) => (LANG === "en" ? en : LANG === "es" ? es : pt);
