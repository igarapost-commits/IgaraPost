import React from "react";
import { Icon } from "./Icon";
import { RADAR_LABEL } from "./sars/radar";
import type { RadarStatus } from "./types";

/**
 * Página "Como o aplicativo funciona": guia de tudo o que o app faz, área por área.
 * Cada item é [rótulo em negrito, frase]. As frases ficam inteiras para a tradução (i18n/s_howto.ts).
 */

type Item = [string | null, string];
type Step = { icon: string; title: string; href?: string; go?: string; items: Item[] };

const STEPS: Step[] = [
  {
    icon: "feed",
    title: "Feed: o que está acontecendo",
    href: "#feed",
    go: "Abrir o Feed",
    items: [
      ["Abertura:", "toda vez que o app abre, aparece a abertura animada com o logo do IgaraPost e “Uma realização Vento Norte”. Toque na tela para pular."],
      ["Fixados no topo:", "as publicações explicativas da equipe ensinam a usar o app e a ler os dados e ficam sempre em cima. Abaixo vêm os relatos da comunidade, do mais recente para o mais antigo."],
      ["Botão de tema:", "o botão ao lado de Filtros mostra o tema escolhido. Toque nele para abrir as opções (Tudo, Fumaça, Queimadas ou Enchentes) e escolher uma."],
      ["Filtros:", "escolha a região ou o tema que você acompanha, o período da observação, o tema e a origem da informação (relatos da comunidade ou explicativos). “Limpar” volta ao padrão."],
      ["Atualizar:", "arraste a tela para baixo. O Feed também se atualiza sozinho a cada minuto."],
      ["Em cada publicação:", "Apoiar mostra que o relato é útil, Comentar abre a conversa, Mapa mostra o local no mapa com as camadas da NASA do dia da observação e Salvar guarda a publicação no seu Perfil. Textos longos têm “Ver mais”."],
      ["Selos:", "cada publicação mostra o tipo (relato da comunidade ou explicativo), o tema, o local e a situação da conferência com o SARS."],
    ],
  },
  {
    icon: "info",
    title: "Detalhe da publicação",
    items: [
      ["Comentários:", "o botão Comentar abre a publicação direto na conversa. Escreva o que você viu ou uma informação que ajude; você pode apagar os seus comentários."],
      ["Denunciar:", "se uma publicação tiver informação falsa, local errado, dados pessoais, ofensa ou propaganda, toque em Denunciar e escolha o motivo."],
      ["Excluir:", "nos seus próprios relatos aparece o botão para excluir."],
    ],
  },
  {
    icon: "map",
    title: "Mapa: dados da NASA em tempo real",
    href: "#mapa",
    go: "Abrir o Mapa",
    items: [
      ["Eventos:", "o mapa abre sem nada ligado. Os botões do topo ligam e desligam cada camada: Fumaça (aerossóis), Queimadas (focos de fogo ativo da NASA FIRMS, últimas 48 h) e Enchentes (áreas inundadas e água vista pelo radar, incluindo o NISAR)."],
      ["Focos de fogo:", "aparecem agrupados quando há muitos juntos; aproxime para ver cada um e toque para ver o horário e a potência. A cor mostra há quanto tempo o foco foi detectado. O aviso “Ao vivo” no topo indica que os focos estão sendo atualizados."],
      ["Buscar:", "encontra município, cidade ou comunidade. Ao escolher um município, o mapa desenha o limite dele com uma linha tracejada."],
      ["Região e Mundo:", "Região enquadra os municípios da região ou do tema escolhido nos Filtros do Feed; Mundo mostra a visão geral."],
      ["Camadas:", "mostra a legenda das cores, a data e a fonte de cada camada, a opacidade e o fundo do mapa (NASA Blue Marble ou o satélite do dia)."],
      ["NISAR:", "abre o Explorador NISAR."],
      ["Imagem detalhada:", "ao aproximar bastante, o mapa usa imagens de 30 m da NASA (HLS, satélites Landsat e Sentinel-2) dos últimos dias."],
      ["Toque no mapa:", "mostra o que os dados da NASA indicam naquele ponto e permite relatar algo ali."],
      ["Relatos no mapa:", "aparecem como marcadores (todos os relatos; os botões de evento do topo escolhem os tipos). Borda pulsante quer dizer que o relato está fora do radar. A faixa embaixo informa a data das imagens."],
      ["Sem internet:", "o mapa mostra a imagem Blue Marble do entorno de Manaus guardada no app."],
    ],
  },
  {
    icon: "radar",
    title: "Explorador NISAR: antes e depois",
    href: "#nisar",
    go: "Abrir o Explorador NISAR",
    items: [
      ["Mundo:", "escolha a Data A (antes) e a Data B (depois), de 2025 até hoje, e arraste a bolinha no meio do mapa para comparar as duas imagens do radar em qualquer lugar."],
      ["Estudo de Região:", "escolha uma região da Amazônia. O mapa enquadra a região, mostra os focos de fogo e os relatos dela e calcula, no seu aparelho, onde a superfície passou a aparecer escura ou deixou de aparecer escura."],
      ["Cores do radar:", "verde é vegetação, rosa/magenta é solo e áreas abertas e escuro é água parada ou superfície lisa."],
      ["Análise do entorno de Manaus:", "mostra as áreas que mudaram, a relação com os focos de fogo, um gráfico com todas as passagens (toque no gráfico para ver cada uma), a conferência da qualidade do par de imagens e os relatos na área do estudo."],
      ["Leitura com cuidado:", "é uma exploração visual experimental: escurecer no radar não prova, sozinho, que houve queimada ou água."],
    ],
  },
  {
    icon: "plus",
    title: "Relatar: o que o satélite não viu",
    href: "#relatar",
    go: "Fazer um relato",
    items: [
      ["1. O que aconteceu:", "escolha o tipo (Fumaça, Queimada, Enchente ou Outro) e descreva o que viu, sem nomes ou dados pessoais de outras pessoas."],
      ["2. Onde e quando:", "use o GPS (o app mostra a precisão), toque no mapinha, busque a localidade ou digite as coordenadas. Se preferir, mostre para outras pessoas só o local aproximado (cerca de 2 km). Para a hora, use Agora, Hoje cedo ou Ontem; para outro dia, toque em Personalizar."],
      ["3. Foto e envio:", "tire uma foto ou escolha da galeria (ela é reduzida antes de enviar) e revise tudo antes de relatar."],
      ["Conferência com o SARS:", "com o tipo e o local marcados, o app confere sozinho se os dados da NASA já mostram o evento perto do ponto. Se não mostram, o relato ganha o selo “Fora do radar”, que é justamente a informação mais valiosa."],
      ["Rascunho:", "o que você preenche fica guardado no aparelho; dá para sair e voltar depois. “Descartar rascunho” apaga."],
      ["Quem vê:", "todas as pessoas que usam o app. Não é preciso criar conta."],
      ["Sem internet:", "o relato fica guardado e é enviado quando a conexão voltar."],
    ],
  },
  {
    icon: "user",
    title: "Perfil: seus relatos e ajustes",
    href: "#perfil",
    go: "Abrir o Perfil",
    items: [
      ["Editar perfil:", "troque a foto (aparece para todos), o nome, o nome de usuário (@, sem repetir o de outra pessoa), a cidade ou comunidade e o texto sobre você."],
      ["Meus relatos:", "mostra quantos relatos estão fora do radar, quantos foram confirmados depois e quantos ainda não foram enviados. O botão de filtro abre as opções (Todos, Fora do radar, Confirmados, Enviados, Não enviados, Com falha)."],
      ["Em cada relato seu:", "Histórico e status mostra cada etapa; Abrir, Editar e Mapa levam ao relato. Conferir de novo verifica se a NASA passou a mostrar o evento; ao abrir Meus relatos, os relatos recentes também são conferidos sozinhos."],
      ["Atividade:", "mostra quando outras pessoas comentam nos seus relatos."],
      ["Salvos:", "guarda as publicações que você salvou."],
      ["Revisão:", "só para a administração: fila de moderação com as denúncias e os relatos não verificados."],
      ["Configurações:", "idioma, aparência, conexão com a rede, avisos (relato verificado), fila de envio e Meu registro (seus relatos e denúncias com data, horário e local, para copiar)."],
      ["Administração:", "o perfil com o nome IgaraPost administra o app: verifica relatos e pode ocultar ou excluir qualquer relato ou comentário."],
      ["Sobre nós:", "o botão no fim do Perfil mostra a equipe, as fontes de dados e os créditos."],
    ],
  },
  {
    icon: "globe",
    title: "Idiomas e tradução",
    items: [
      ["Idioma do app:", "o app abre no idioma do celular (português, inglês ou espanhol; em outro idioma, abre em inglês). Para trocar, vá em Perfil › Configurações. O app inteiro muda, inclusive o mapa e as publicações da equipe."],
      ["Relatos e comentários:", "ficam sempre no idioma em que foram escritos. Quando estão em outro idioma, aparece o botão “Ver tradução”; toque de novo em “Ver original” para voltar."],
      ["Como a tradução funciona:", "as publicações da equipe já aparecem no idioma escolhido. Os relatos e comentários das pessoas são traduzidos só quando você toca em “Ver tradução”, e isso precisa de internet."],
    ],
  },
];

const STATUS: [RadarStatus, string][] = [
  ["fora_do_radar", "quando você relatou, os dados oficiais não mostravam o evento perto do ponto. Não quer dizer que o relato esteja errado."],
  ["confirmado", "estava fora do radar e, numa nova conferência, os dados passaram a mostrar o evento."],
  ["no_radar", "os dados oficiais já mostravam o evento perto do ponto quando você relatou."],
  ["nao_verificado", "não foi possível conferir agora (sem internet ou sem dado para esse tipo de evento)."],
];

export function HowTo() {
  return (
    <div className="stack howto" style={{ gap: 18 }}>
      <div className="stack" style={{ gap: 6 }}>
        <span className="eyebrow">Guia completo</span>
        <h1>Como o aplicativo funciona</h1>
        <p>O IgaraPost junta dados de satélite e radar da NASA com o que as pessoas veem no lugar. Você acompanha fumaça, queimadas e enchentes no mapa e relata o que os satélites ainda não mostraram.</p>
      </div>

      <ol className="howto-steps">
        {STEPS.map((s, i) => (
          <li key={s.title} className="panel howto-step">
            <div className="howto-head">
              <span className="howto-num" aria-hidden>
                {i + 1}
              </span>
              <span className="howto-ico" aria-hidden>
                <Icon name={s.icon} size={20} />
              </span>
              <h2>{s.title}</h2>
            </div>
            <ul>
              {s.items.map(([b, t], j) => (
                <li key={j}>
                  {b && <b>{b}</b>} <span>{t}</span>
                </li>
              ))}
            </ul>
            {s.href && (
              <a className="btn sm" href={s.href}>
                {s.go} →
              </a>
            )}
          </li>
        ))}
      </ol>

      <section className="panel stack" style={{ gap: 8 }}>
        <h2>O que significa a situação de um relato</h2>
        <dl className="howto-status">
          {STATUS.map(([k, v]) => (
            <div key={k}>
              <dt>
                <span className={`badge radar ${k}`}>{RADAR_LABEL[k]}</span>
              </dt>
              <dd>{v}</dd>
            </div>
          ))}
        </dl>
      </section>

      <div className="callout warn small">O IgaraPost não publica alertas oficiais e não aciona serviços de emergência. Em situação de perigo, ligue 193 (Bombeiros) ou 199 (Defesa Civil).</div>
    </div>
  );
}
