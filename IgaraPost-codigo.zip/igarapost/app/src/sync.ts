import React from "react";
import { ApiError } from "./api";
import * as sb from "./sb";
import { checkVerified } from "./notify";
import { commit, getState, setSoft, uid, useStore, type LocalState } from "./store";
import type { Comment, OutboxItem, OutboxOp, Post } from "./types";

/* ------------------------------ conexão ------------------------------ */
export function useOnline() {
  const [on, set] = React.useState(() => navigator.onLine);
  React.useEffect(() => {
    const a = () => set(true),
      b = () => set(false);
    window.addEventListener("online", a);
    window.addEventListener("offline", b);
    return () => {
      window.removeEventListener("online", a);
      window.removeEventListener("offline", b);
    };
  }, []);
  return on;
}


/* ------------------------------ fila de envio ------------------------------ */
/** Coloca uma operação na fila. Grava e confere antes de retornar (lança StorageError se não gravar). */
export function enqueue(op: OutboxOp) {
  const item = { ...op, qid: uid("q"), state: "pendente", attempts: 0, createdAt: new Date().toISOString() } as OutboxItem;
  commit((s) => {
    let outbox = s.outbox;
    if (op.op === "setFollows") outbox = outbox.filter((x) => x.op !== "setFollows"); // só a última vale
    if (op.op === "deletePost") {
      // se a criação ainda não foi enviada, basta cancelar tudo localmente
      const pendingCreate = outbox.find((x) => x.op === "createPost" && x.post.id === op.id);
      if (pendingCreate) return { ...s, outbox: outbox.filter((x) => !((x.op === "createPost" && x.post.id === op.id) || (x.op === "updatePost" && x.id === op.id))) };
    }
    if (op.op === "updatePost") {
      const create = outbox.find((x) => x.op === "createPost" && x.post.id === op.id && x.state !== "enviando");
      if (create && create.op === "createPost") {
        // ainda não enviado: atualiza o próprio pedido de criação
        const merged = { ...create, state: "pendente" as const, error: undefined, post: { ...create.post, ...op.patch, photo: op.patch.photo === null ? undefined : (op.patch.photo ?? create.post.photo) } };
        return { ...s, outbox: outbox.map((x) => (x === create ? merged : x)) };
      }
    }
    if (op.op === "setRadar") {
      // ainda não enviado: a conferência vai junto com o próprio relato
      const create = outbox.find((x) => x.op === "createPost" && x.post.id === op.id && x.state !== "enviando");
      if (create && create.op === "createPost") return { ...s, outbox: outbox.map((x) => (x === create ? { ...create, post: { ...create.post, radar: op.radar } } : x)) };
      outbox = outbox.filter((x) => !(x.op === "setRadar" && x.id === op.id && x.state !== "enviando")); // só a última conferência vale
    }
    if (op.op === "deleteComment") {
      const pc = outbox.find((x) => x.op === "createComment" && x.comment.id === op.id);
      if (pc) return { ...s, outbox: outbox.filter((x) => x !== pc) };
    }
    return { ...s, outbox: [...outbox, item] };
  });
  void processOutbox();
}

function setItem(qid: string, patch: Partial<OutboxItem>) {
  setSoft((s) => ({ ...s, outbox: s.outbox.map((x) => (x.qid === qid ? ({ ...x, ...patch } as OutboxItem) : x)) }));
}
function done(qid: string, apply?: (s: LocalState) => LocalState) {
  // o servidor já confirmou: remover da fila. Se a gravação local falhar, a fila em memória é
  // atualizada mesmo assim (reenvios são idempotentes porque o id é gerado no aparelho).
  setSoft((s) => {
    const n = { ...s, outbox: s.outbox.filter((x) => x.qid !== qid) };
    return apply ? apply(n) : n;
  });
}

let running = false;
export async function processOutbox(retryFailed = false): Promise<void> {
  if (running) return;
  const s0 = getState();
  if (!s0.server.url || !s0.server.token || !s0.outbox.length) return;
  running = true;
  try {
    if (retryFailed) setSoft((s) => ({ ...s, outbox: s.outbox.map((x) => (x.state === "falhou" ? { ...x, state: "pendente", error: undefined } : x)) }));
    for (const item of [...getState().outbox]) {
      if (item.state === "falhou") continue;
      setItem(item.qid, { state: "enviando", attempts: item.attempts + 1 });
      try {
        await send(item);
      } catch (e) {
        const err = e instanceof ApiError ? e : new ApiError(0, String(e));
        if (err.network || err.status >= 500 || err.status === 429 || err.status === 408) {
          setItem(item.qid, { state: "pendente", error: err.network ? "Aguardando conexão." : err.message });
          break; // tenta de novo mais tarde, na mesma ordem
        }
        if (err.status === 401 || err.status === 503) {
          setItem(item.qid, { state: "pendente", error: "Reconectando à rede IgaraPost…" });
          setSoft((s) => ({ ...s, server: { ...s.server, token: undefined } }));
          void ensureDeviceAccount();
          break;
        }
        setItem(item.qid, { state: "falhou", error: err.message });
      }
    }
  } finally {
    running = false;
  }
}

async function send(item: OutboxItem) {
  const putPost = (sp: Post) => (s: LocalState) => ({ ...s, server: { ...s.server, posts: [sp, ...s.server.posts.filter((x) => x.id !== sp.id)] } });
  switch (item.op) {
    case "createPost":
      return done(item.qid, putPost(await sb.createPost(item.post)));
    case "updatePost":
      return done(item.qid, putPost(await sb.updatePost(item.id, item.patch)));
    case "deletePost":
      await sb.deletePost(item.id);
      return done(item.qid, (s) => ({ ...s, server: { ...s.server, posts: s.server.posts.filter((x) => x.id !== item.id) } }));
    case "createComment": {
      const c = item.comment;
      const sc = await sb.createComment({ id: c.id, postId: c.postId, text: c.text, lang: c.lang });
      return done(item.qid, (s) => {
        const cur = s.server.comments[c.postId]?.list ?? [];
        const posts = s.server.posts.map((p) => (p.id === c.postId && !cur.some((x) => x.id === sc.id) ? { ...p, commentCount: (p.commentCount ?? 0) + 1 } : p));
        return { ...s, server: { ...s.server, posts, comments: { ...s.server.comments, [c.postId]: { list: [...cur.filter((x) => x.id !== sc.id), sc], fetchedAt: new Date().toISOString() } } } };
      });
    }
    case "deleteComment":
      await sb.deleteComment(item.id);
      return done(item.qid, (s) => {
        const cur = s.server.comments[item.postId];
        return cur ? { ...s, server: { ...s.server, comments: { ...s.server.comments, [item.postId]: { ...cur, list: cur.list.filter((x) => x.id !== item.id) } } } } : s;
      });
    case "report":
      await sb.report(item.postId, item.reason);
      return done(item.qid);
    case "setRadar":
      return done(item.qid, putPost(await sb.setRadar(item.id, item.radar)));
    case "setFollows":
      return done(item.qid); // comunidades seguidas ficam só no aparelho
  }
}

/* ------------------------------ leitura ------------------------------ */
export type FetchState = { state: "ok" | "carregando" | "sem_conexao" | "erro" | "sem_servidor"; message?: string; at?: string };

export async function refreshFeed(): Promise<FetchState> {
  const s = getState().server;
  if (!s.url) return { state: "sem_servidor" };
  try {
    if (!s.token) await ensureDeviceAccount();
    const posts = await sb.listPosts(300);
    checkVerified(posts);
    const at = new Date().toISOString();
    setSoft((st) => ({ ...st, server: { ...st.server, posts, fetchedAt: at } }));
    return { state: "ok", at };
  } catch (e) {
    const err = e as ApiError;
    return { state: err.network ? "sem_conexao" : "erro", message: err.message, at: s.fetchedAt };
  }
}

export async function fetchComments(postId: string): Promise<FetchState> {
  const s = getState().server;
  if (!s.url) return { state: "sem_servidor" };
  try {
    const list = await sb.listComments(postId);
    const at = new Date().toISOString();
    setSoft((st) => ({
      ...st,
      server: {
        ...st.server,
        posts: st.server.posts.map((p) => (p.id === postId ? { ...p, commentCount: list.length } : p)),
        comments: { ...st.server.comments, [postId]: { list, fetchedAt: at } },
      },
    }));
    return { state: "ok", at };
  } catch (e) {
    const err = e as ApiError;
    return { state: err.network ? "sem_conexao" : "erro", message: err.message, at: s.comments[postId]?.fetchedAt };
  }
}

/* ------------------------------ conta automática do aparelho ------------------------------ */
/**
 * Cada aparelho entra sozinho na rede IgaraPost na primeira vez que abre o app com internet (conta anônima do
 * Supabase: sem e-mail, sem senha). Não há tela de login: a pessoa só relata, e os relatos aparecem para todos.
 * A sessão fica guardada à parte, para a conta continuar a mesma depois de "Apagar os dados deste aparelho".
 */
let ensuring: Promise<void> | undefined;
export function ensureDeviceAccount(): Promise<void> {
  const s = getState().server;
  if (!s.url || (typeof navigator !== "undefined" && !navigator.onLine)) return Promise.resolve();
  if (s.token && s.user && s.user.id === sb.currentUserId()) return Promise.resolve();
  return (ensuring ??= (async () => {
    try {
      const token = await sb.accessToken();
      let user = await sb.me();
      const local = getState().me;
      // o que a pessoa já tinha no perfil do aparelho (nome e foto) passa para a rede
      const change = {
        ...(local.name && local.name !== "Você" && user.displayName === "Pessoa da comunidade" ? { name: local.name } : {}),
        ...(local.photo && !user.photo ? { avatar: local.photo } : {}),
      };
      if (Object.keys(change).length) user = await sb.updateProfile(change).catch(() => user);
      setSoft((st) => ({
        ...st,
        server: { ...st.server, token, user, ...(st.server.user && st.server.user.id !== user.id ? { posts: [], comments: {} } : {}) },
      }));
      void processOutbox(true);
    } catch {
      /* sem servidor agora: o app segue funcionando no aparelho e tenta de novo ao voltar a conexão */
    } finally {
      ensuring = undefined;
    }
  })());
}

/** Atualiza o papel (moderação) e o nome guardados, por exemplo depois de virar moderador no painel. */
export async function refreshMe(): Promise<void> {
  if (!getState().server.token) return ensureDeviceAccount();
  try {
    const user = await sb.me();
    setSoft((st) => ({ ...st, server: { ...st.server, user } }));
  } catch {
    /* sem conexão: mantém o que já sabia */
  }
}

export function startSync() {
  const tick = () => {
    void processOutbox();
  };
  void ensureDeviceAccount().then(() => {
    void refreshMe();
    void refreshFeed();
  });
  window.addEventListener("online", () => {
    void ensureDeviceAccount();
    void processOutbox();
    void refreshFeed();
  });
  document.addEventListener("visibilitychange", () => document.visibilityState === "visible" && tick());
  window.setInterval(() => getState().outbox.some((x) => x.state === "pendente") && tick(), 30000);
  // com o aviso de verificação ligado, confere a rede a cada 90 s enquanto o app está aberto (em qualquer tela)
  window.setInterval(() => {
    const s = getState();
    if (s.prefs.notifyVerified && s.server.token && document.visibilityState === "visible") void refreshFeed();
  }, 90000);
  tick();
}

/* ------------------------------ conta ------------------------------ */
export async function updateDisplayName(name: string) {
  const user = await sb.setDisplayName(name);
  commit((s) => ({ ...s, server: { ...s.server, user } }));
}

/* ------------------------------ visão combinada ------------------------------ */
/** Relatos de pessoas visíveis neste aparelho, cada um com o seu estado real de envio. */
export function usePeoplePosts(): Post[] {
  const st = useStore();
  return React.useMemo(() => {
    const local = st.posts.map((p) => ({ ...p, sync: "local" as const, mine: true }));
    const shared = st.server.url ? st.server.posts : [];
    const deleting = new Set(st.outbox.filter((x) => x.op === "deletePost").map((x) => (x as { id: string }).id));
    const updates = new Map(st.outbox.filter((x) => x.op === "updatePost").map((x) => [(x as { id: string }).id, x]));
    const radars = new Map(st.outbox.filter((x) => x.op === "setRadar").map((x) => [(x as { id: string }).id, (x as OutboxItem & { op: "setRadar" }).radar]));
    const pending = st.outbox
      .filter((x) => x.op === "createPost")
      .map((x) => {
        const o = x as OutboxItem & { op: "createPost" };
        return { ...o.post, sync: o.state, syncError: o.error, mine: true } as Post;
      });
    const pids = new Set(pending.map((p) => p.id));
    const sh = shared
      .filter((p) => !pids.has(p.id) && !deleting.has(p.id))
      .map((p) => {
        const u = updates.get(p.id) as (OutboxItem & { op: "updatePost" }) | undefined;
        const rd = radars.get(p.id);
        if (rd) p = { ...p, radar: rd };
        if (!u) return p;
        const { photo, ...rest } = u.patch;
        return { ...p, ...rest, photo: photo === null ? undefined : (photo ?? p.photo), sync: u.state, syncError: u.error } as Post;
      });
    return [...pending, ...sh, ...local];
  }, [st.posts, st.server.posts, st.server.url, st.outbox]);
}

/** Comentários de uma publicação: do servidor (cache), da fila de envio e os locais. */
export function useComments(postId: string, exampleOrLocal: boolean): Comment[] {
  const st = useStore();
  return React.useMemo(() => {
    const local = st.comments.filter((c) => c.postId === postId).map((c) => ({ ...c, sync: c.example ? undefined : ("local" as const) }));
    if (exampleOrLocal || !st.server.url) return local;
    const server = st.server.comments[postId]?.list ?? [];
    const deleting = new Set(st.outbox.filter((x) => x.op === "deleteComment").map((x) => (x as { id: string }).id));
    const pending = st.outbox
      .filter((x) => x.op === "createComment" && x.comment.postId === postId)
      .map((x) => ({ ...(x as OutboxItem & { op: "createComment" }).comment, sync: x.state, mine: true }) as Comment);
    const ids = new Set(pending.map((c) => c.id));
    return [...server.filter((c) => !ids.has(c.id) && !deleting.has(c.id)), ...pending, ...local].sort((a, b) => Date.parse(a.at) - Date.parse(b.at));
  }, [st.comments, st.server.comments, st.server.url, st.outbox, postId, exampleOrLocal]);
}

export const SYNC_LABEL: Record<string, string> = {
  local: "Salvo só neste aparelho",
  pendente: "Aguardando conexão",
  enviando: "Enviando…",
  falhou: "Falha no envio",
  publicado: "Enviado",
  oculto: "Ocultado após revisão",
};
