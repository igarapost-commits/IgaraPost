import React from "react";
import { SB_URL } from "./sb";
import type { Author, Comment, DraftData, Filters, OutboxItem, Post, Report, ServerUser } from "./types";

/**
 * Armazenamento no aparelho (localStorage).
 *
 * Regra principal: `commit()` só altera o estado depois de GRAVAR e CONFERIR a gravação (lê de volta
 * e compara). Se a gravação falhar (sem espaço, armazenamento bloqueado, janela privada), lança
 * StorageError e o estado continua como estava. Assim nenhuma tela anuncia "salvo" ou "publicado"
 * para algo que só existe na memória temporária.
 *
 * `setSoft()` é usado só para preferências e caches (ex.: feed baixado do servidor): se não gravar,
 * o app continua funcionando e o aviso "armazenamento indisponível" aparece no Perfil.
 */
export interface LocalState {
  v: 2;
  me: Author; // perfil local (modo sem servidor)
  posts: Post[]; // relatos salvos só neste aparelho (modo local)
  comments: Comment[]; // comentários locais (modo local, ou em exemplos fictícios)
  likes: string[];
  saves: string[];
  follows: string[];
  reports: Report[]; // denúncias no modo local
  hidden: string[]; // ocultados após revisão local
  draft?: DraftData;
  outbox: OutboxItem[]; // operações aguardando envio ao servidor
  server: {
    url: string;
    token?: string;
    user?: ServerUser;
    posts: Post[]; // última cópia do feed compartilhado
    fetchedAt?: string;
    comments: Record<string, { list: Comment[]; fetchedAt: string }>;
  };
  prefs: { filters?: Filters; mapBase?: string; mapBaseChosen?: boolean; googleKey?: string; theme?: "auto" | "light" | "dark"; notifyVerified?: boolean };
}

const KEY = "igarapost:v2";
const OLD_KEY = "igarapost:v1";
const DEFAULT_URL = SB_URL; // rede compartilhada IgaraPost (Supabase)

const fresh = (): LocalState => ({
  v: 2,
  me: { id: "me", name: "Você" },
  posts: [],
  comments: [],
  likes: [],
  saves: [],
  follows: ["manaus-entorno"],
  reports: [],
  hidden: [],
  outbox: [],
  server: { url: DEFAULT_URL, posts: [], comments: {} },
  prefs: {},
});

export class StorageError extends Error {
  constructor(public reason: "cheio" | "bloqueado" | "conferencia") {
    super(
      reason === "cheio"
        ? "Não há espaço no aparelho para salvar. Remova a foto ou apague relatos antigos em Perfil › Meus dados."
        : reason === "bloqueado"
          ? "Este navegador está bloqueando o armazenamento. Nada pode ser salvo neste aparelho."
          : "A gravação não pôde ser confirmada. Tente de novo.",
    );
  }
}

/**
 * Até a versão 8 não havia rede: os relatos ficavam só no aparelho. Ao abrir a 10 pela primeira vez, eles (e os
 * comentários feitos neles) entram na fila de envio e vão para a rede sozinhos, como qualquer relato novo.
 */
function fromV8(s: LocalState): LocalState {
  const base = { ...fresh(), ...s, server: fresh().server, prefs: { ...s.prefs } };
  const OK = ["fumaca", "queimada", "enchente", "outro"];
  const posts = (s.posts ?? []).filter((p) => p.kind === "community");
  const ids = new Set(posts.map((p) => p.id));
  const at = new Date().toISOString();
  const item = <T,>(op: T) => ({ ...op, qid: uid("q"), state: "pendente" as const, attempts: 0, createdAt: at });
  const outbox = [
    ...(s.outbox ?? []),
    ...posts.map((p) => item({ op: "createPost" as const, post: { ...p, category: OK.includes(p.category) ? p.category : "outro", sync: undefined, mine: undefined } })),
    ...(s.comments ?? []).filter((c) => ids.has(c.postId)).map((c) => item({ op: "createComment" as const, comment: { ...c, sync: undefined } })),
  ] as OutboxItem[];
  return { ...base, posts: (s.posts ?? []).filter((p) => !ids.has(p.id)), comments: (s.comments ?? []).filter((c) => !ids.has(c.postId)), outbox };
}

let storageOk = true;
function load(): LocalState {
  try {
    const raw = window.localStorage.getItem(KEY);
    if (raw) {
      const s = JSON.parse(raw);
      if (s.server?.url === DEFAULT_URL) return { ...fresh(), ...s, server: { ...fresh().server, ...s.server }, prefs: { ...s.prefs } };
      return fromV8(s);
    }
    const old = window.localStorage.getItem(OLD_KEY); // migra dados da versão 0.1
    if (old) {
      const o = JSON.parse(old);
      return {
        ...fresh(),
        me: o.me ?? fresh().me,
        posts: (o.posts ?? []).map((p: Post) => ({ ...p, sync: "local" as const })),
        comments: o.comments ?? [],
        likes: o.likes ?? [],
        saves: o.saves ?? [],
        follows: o.follows ?? fresh().follows,
        reports: o.reports ?? [],
        hidden: o.hidden ?? [],
      };
    }
  } catch {
    storageOk = false;
  }
  return fresh();
}

let state: LocalState = load();
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());

/** Grava e confere. Lança StorageError sem alterar o estado se falhar. */
function write(next: LocalState) {
  const json = JSON.stringify(next);
  try {
    window.localStorage.setItem(KEY, json);
  } catch (e) {
    storageOk = false;
    const name = (e as DOMException)?.name || "";
    throw new StorageError(/quota/i.test(name) || /quota/i.test(String(e)) ? "cheio" : "bloqueado");
  }
  let back: string | null = null;
  try {
    back = window.localStorage.getItem(KEY);
  } catch {
    /* tratado abaixo */
  }
  if (back !== json) {
    storageOk = false;
    throw new StorageError("conferencia");
  }
  storageOk = true;
}

export function commit(fn: (s: LocalState) => LocalState) {
  const next = fn(state);
  write(next);
  state = next;
  emit();
}

/** Para caches e preferências: atualiza a memória mesmo se a gravação falhar. */
export function setSoft(fn: (s: LocalState) => LocalState) {
  state = fn(state);
  try {
    write(state);
  } catch {
    /* storageOk já marcado como false */
  }
  emit();
}

export function storageAvailable() {
  return storageOk;
}
export function getState() {
  return state;
}
export function resetAll() {
  try {
    window.localStorage.removeItem(KEY);
    window.localStorage.removeItem(OLD_KEY);
  } catch {
    /* ignore */
  }
  const keepServer = fresh().server;
  state = { ...fresh(), server: keepServer };
  emit();
}
export function useStore(): LocalState {
  return React.useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => state,
  );
}

export function uid(p: string) {
  return `${p}-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}
export const toggleIn = (list: string[], id: string) => (list.includes(id) ? list.filter((x) => x !== id) : [...list, id]);

/** Bytes aproximados usados pelo app no armazenamento local. */
export function storageUsage() {
  try {
    return (window.localStorage.getItem(KEY) || "").length * 2;
  } catch {
    return 0;
  }
}

/** Modo de armazenamento real, para exibir na interface. */
export function storageMode(s: LocalState): "local" | "compartilhado" {
  return s.server.url && s.server.token ? "compartilhado" : "local";
}
