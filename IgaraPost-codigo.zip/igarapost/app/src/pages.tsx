import React from "react";
import { Icon } from "./Icon";
import { useApp } from "./ctx";
import { resetAll, setSoft, storageAvailable, useStore } from "./store";
import { Avatar, PostCard } from "./PostCard";
import { EditProfile } from "./EditProfile";
import { fmtDate } from "./data";
import { CATEGORIES } from "./seed";
import type { Post } from "./types";
import type { ApiError } from "./api";
import * as sb from "./sb";
import { processOutbox, refreshFeed, refreshMe, SYNC_LABEL, useOnline } from "./sync";
import { MyReports, useMyReports } from "./MyReports";
import { buildMyLog, copyText } from "./myLog";
import { askPermission, notices, systemNotifications } from "./notify";
import { SARS } from "./sars/config";
import { EVENTS, SARS_LAYERS } from "./sars/layers";
import { RADAR_LABEL } from "./sars/radar";
import { setTheme, THEME_OPTIONS } from "./theme";
import { LANG, LANGS, setLang } from "./i18n/lang";

/* ---------------- atividade (comentários nos meus relatos) ---------------- */
function Activity() {
  const st = useStore();
  const [items, setItems] = React.useState<{ commentId: string; postId: string; text: string; at: string; author: { displayName: string }; postText: string }[]>();
  const [msg, setMsg] = React.useState("");
  React.useEffect(() => {
    if (!st.server.token) return;
    sb.activity()
      .then(setItems)
      .catch((e: ApiError) => setMsg(e.network ? "Sem conexão: não foi possível buscar a atividade." : e.message));
  }, [st.server.url, st.server.token]);
  const own = notices();
  if (!st.server.token && !own.length) return <div className="empty panel">Ainda ninguém comentou nos seus relatos.</div>;
  return (
    <div className="list">
      {own.map((n) => (
        <a key={n.id} className="panel activity verified-notice" href={`#post-${n.postId}`}>
          <span className="small muted">
            <Icon name="check" size={14} /> Relato verificado pela administração · {fmtDate(n.at, true)}
          </span>
          <span translate="no">“{n.postText}”</span>
        </a>
      ))}
      {msg && <p className="small muted">{msg}</p>}
      {!items && !msg && <p className="small">Carregando…</p>}
      {items?.length === 0 && !own.length && <div className="empty panel">Ainda ninguém comentou nos seus relatos.</div>}
      {items?.map((i) => (
        <a key={i.commentId} className="panel activity" href={`#post-${i.postId}`}>
          <span className="small muted">
            {i.author.displayName} comentou em “{i.postText}” · {fmtDate(i.at, true)}
          </span>
          <span>{i.text}</span>
        </a>
      ))}
    </div>
  );
}

/* ---------------- revisão (só a administração) ---------------- */
function Review() {
  const st = useStore();
  const { findPost, toast } = useApp();
  const [reports, setReports] = React.useState<sb.ModItem[]>();
  const [unverified, setUnverified] = React.useState<Post[]>();
  const [msg, setMsg] = React.useState("");
  const [busy, setBusy] = React.useState("");
  const load = React.useCallback(() => {
    if (!st.server.token) return;
    const fail = (e: ApiError) => setMsg(e.network ? "Sem conexão: não foi possível buscar a fila de moderação." : e.message);
    sb.moderationQueue().then(setReports).catch(fail);
    sb.unverifiedQueue().then(setUnverified).catch(fail);
  }, [st.server.token]);
  React.useEffect(load, [load]);
  const run = async (key: string, f: () => Promise<void>, done: string) => {
    setBusy(key);
    try {
      await f();
      toast(done);
      load();
      void refreshFeed();
    } catch (e) {
      toast((e as ApiError).message);
    } finally {
      setBusy("");
    }
  };
  return (
    <div className="stack">
      <h3>Fila de moderação</h3>
      {msg && <p className="small muted">{msg}</p>}
      <section className="stack" aria-labelledby="fila-denuncias">
        <h4 id="fila-denuncias">Denúncias ({reports?.length ?? "…"})</h4>
        {reports?.length === 0 && <div className="empty panel small">Nenhuma denúncia pendente.</div>}
        {reports?.map((r) => (
          <div key={r.id} className="panel stack" style={{ gap: 6 }}>
            <b>{r.reason}</b>
            <a className="small" href={`#post-${r.post_id}`}>
              “{(r.post_text || findPost(r.post_id)?.text || r.post_id).slice(0, 140)}”
            </a>
            <span className="small muted">
              @{r.reporter} · {fmtDate(r.created_at, true)}
            </span>
            <div className="row">
              <button className="btn sm" disabled={!!busy} onClick={() => run(r.id, () => sb.moderate(r.id, "manter"), "Publicação mantida")}>
                Manter
              </button>
              <button className="btn sm danger" disabled={!!busy} onClick={() => run(r.id, () => sb.moderate(r.id, "ocultar"), "Publicação ocultada")}>
                Ocultar
              </button>
            </div>
          </div>
        ))}
      </section>
      <section className="stack" aria-labelledby="fila-relatos">
        <h4 id="fila-relatos">Relatos não verificados ({unverified?.length ?? "…"})</h4>
        {unverified?.length === 0 && <div className="empty panel small">Nenhum relato para verificar.</div>}
        {unverified?.map((p) => (
          <div key={p.id} className="panel stack queue-post" style={{ gap: 6 }}>
            <div className="row" style={{ gap: 10, flexWrap: "nowrap", alignItems: "flex-start" }}>
              {p.photo && <img src={p.photo} alt="" width={64} height={64} loading="lazy" />}
              <a className="grow small" href={`#post-${p.id}`} style={{ minWidth: 0 }}>
                <b>{CATEGORIES[p.category]?.short ?? p.category}</b> · {p.municipio ?? `${p.lat?.toFixed(3)}, ${p.lon?.toFixed(3)}`}
                <br />
                <span translate="no">{p.text.slice(0, 160)}</span>
              </a>
            </div>
            <span className="small muted">
              {p.author?.name} @{p.author?.handle} · {fmtDate(p.observedAt, true)}
            </span>
            <div className="row">
              <button className="btn sm primary" disabled={!!busy} onClick={() => run(p.id, () => sb.verifyPost(p.id), "Relato verificado")}>
                <Icon name="check" size={16} /> Verificar
              </button>
              <button className="btn sm danger" disabled={!!busy} onClick={() => run(p.id, () => sb.setPostStatus(p.id, "oculto"), "Publicação ocultada")}>
                Ocultar
              </button>
            </div>
          </div>
        ))}
      </section>
    </div>
  );
}

/* ---------------- rede IgaraPost ---------------- */
function NetworkAccount() {
  const st = useStore();
  const online = useOnline();
  const user = st.server.user;
  return (
    <section className="panel stack" aria-labelledby="rede-titulo">
      <h3 id="rede-titulo" className="row" style={{ gap: 8 }}>
        <Icon name="globe" size={18} /> Rede IgaraPost
      </h3>
      <p className="small">
        {user ? (
          <>
            <span className="status-ok">Conectado</span>
            {user.role === "moderador" ? " · administração" : ""}
          </>
        ) : online ? (
          "Conectando…"
        ) : (
          "Sem internet. Os relatos são enviados quando a conexão voltar."
        )}
      </p>
    </section>
  );
}

/* ---------------- avisos ---------------- */
function Notices() {
  const st = useStore();
  const { toast } = useApp();
  const on = !!st.prefs.notifyVerified;
  const toggle = async () => {
    const next = !on;
    setSoft((s) => ({ ...s, prefs: { ...s.prefs, notifyVerified: next } }));
    if (next) {
      const sys = await askPermission();
      toast(sys ? "Aviso ligado" : "Aviso ligado: ele aparece dentro do app");
    }
  };
  return (
    <section className="panel stack" aria-labelledby="avisos-titulo">
      <h3 id="avisos-titulo" className="row" style={{ gap: 8 }}>
        <Icon name="bell" size={18} /> Avisos
      </h3>
      <label className="row check-row" style={{ gap: 10, flexWrap: "nowrap" }}>
        <input id="aviso-verificado" type="checkbox" checked={on} onChange={toggle} />
        <span className="small">Avisar quando um relato meu for verificado pela administração</span>
      </label>
      {on && !systemNotifications() && <span className="small muted">Neste aparelho, o aviso aparece dentro do app.</span>}
    </section>
  );
}

/* ---------------- meu registro (relatos e denúncias da própria pessoa) ---------------- */
function MyLog() {
  const { toast, findPost } = useApp();
  const mine = useMyReports();
  const [text, setText] = React.useState<string>();
  const [busy, setBusy] = React.useState(false);
  const make = async () => {
    setBusy(true);
    try {
      setText(await buildMyLog(mine, findPost));
    } finally {
      setBusy(false);
    }
  };
  return (
    <section className="panel stack" aria-labelledby="registro-titulo">
      <h3 id="registro-titulo" className="row" style={{ gap: 8 }}>
        <Icon name="history" size={18} /> Meu registro
      </h3>
      <p className="small muted">Seus relatos e denúncias, com data, horário e local.</p>
      <div className="row">
        <button id="gerar-registro" className="btn sm" disabled={busy} onClick={make}>
          {busy ? <span className="spin" aria-hidden /> : <Icon name="history" size={16} />} {text ? "Gerar de novo" : "Gerar registro"}
        </button>
        {text && (
          <button className="btn sm" onClick={async () => toast((await copyText(text)) ? "Registro copiado" : "Não foi possível copiar")}>
            <Icon name="copy" size={16} /> Copiar
          </button>
        )}
      </div>
      {text && (
        <pre className="log-box" translate="no" aria-label="Registro">
          {text}
        </pre>
      )}
    </section>
  );
}

/* ---------------- meus dados ---------------- */
function MyData() {
  const st = useStore();
  const { toast } = useApp();
  const [confirm, setConfirm] = React.useState(false);
  const theme = st.prefs.theme ?? "auto";
  return (
    <div className="stack">
      <section className="panel stack" aria-labelledby="idioma-titulo">
        <h3 id="idioma-titulo" className="row" style={{ gap: 8 }}>
          <Icon name="globe" size={18} /> Idioma
        </h3>
        <div className="segmented" role="radiogroup" aria-labelledby="idioma-titulo" translate="no">
          {LANGS.map(([k, l]) => (
            <button key={k} role="radio" lang={k === "pt" ? "pt-BR" : k} aria-checked={LANG === k} className={LANG === k ? "on" : ""} onClick={() => setLang(k)}>
              {l.replace(" (Brasil)", "")}
            </button>
          ))}
        </div>
      </section>
      <section className="panel stack" aria-labelledby="tema-titulo">
        <h3 id="tema-titulo">Aparência</h3>
        <div className="segmented" role="radiogroup" aria-labelledby="tema-titulo">
          {THEME_OPTIONS.map(([k, l]) => (
            <button key={k} role="radio" aria-checked={theme === k} className={theme === k ? "on" : ""} onClick={() => setTheme(k)}>
              <Icon name={k === "auto" ? "phone" : k === "light" ? "sun" : "moon"} size={16} /> {l}
            </button>
          ))}
        </div>
      </section>
      <NetworkAccount />
      <Notices />
      <MyLog />
      {!storageAvailable() && <div className="callout warn">O armazenamento deste aparelho está indisponível ou cheio. Novos rascunhos e relatos não serão salvos até liberar espaço.</div>}
      {st.outbox.length > 0 && (
        <section className="stack">
          <h3>Fila de envio</h3>
          {st.outbox.map((x) => (
            <div key={x.qid} className="panel small row" style={{ justifyContent: "space-between" }}>
              <span>
                {{ createPost: "Novo relato", updatePost: "Edição de relato", setRadar: "Conferência com o SARS", deletePost: "Exclusão de relato", createComment: "Comentário", deleteComment: "Exclusão de comentário", report: "Denúncia", setFollows: "Comunidades acompanhadas" }[x.op]} ·{" "}
                <b>{SYNC_LABEL[x.state]}</b>
                {x.error ? ` · ${x.error}` : ""}
              </span>
              {x.state === "falhou" && (
                <button className="btn sm danger" onClick={() => setSoft((s) => ({ ...s, outbox: s.outbox.filter((y) => y.qid !== x.qid) }))}>
                  Descartar
                </button>
              )}
            </div>
          ))}
          <button className="btn sm" style={{ alignSelf: "flex-start" }} onClick={() => processOutbox(true)}>
            Tentar enviar agora
          </button>
        </section>
      )}
      {!confirm ? (
        <button className="btn danger" style={{ alignSelf: "flex-start" }} onClick={() => setConfirm(true)}>
          <Icon name="trash" /> Apagar os dados deste aparelho
        </button>
      ) : (
        <div className="confirm">
          <b>Apagar tudo deste aparelho?</b>
          <span className="small">Rascunho, fila de envio, apoios e salvos serão apagados. O que já foi publicado continua na rede.</span>
          <div className="row">
            <button
              className="btn danger"
              onClick={() => {
                resetAll();
                setConfirm(false);
                toast("Dados deste aparelho apagados");
              }}
            >
              Apagar
            </button>
            <button className="btn" onClick={() => setConfirm(false)}>
              Cancelar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------------- perfil ---------------- */
const TABS = [
  ["meus", "Meus relatos", "history"],
  ["atividade", "Atividade", "comment"],
  ["salvos", "Salvos", "bookmark"],
  ["revisao", "Revisão", "flag"],
  ["configuracoes", "Configurações", "settings"],
] as const;
export function Profile({ tab: tab0 }: { tab?: string }) {
  const st = useStore();
  const { posts, findPost } = useApp();
  const mine = useMyReports();
  // a Revisão (fila de moderação) só existe para a administração
  const isAdmin = st.server.user?.role === "moderador";
  React.useEffect(() => void refreshMe(), [tab0]); // quem passou a administrar vê a Revisão sem reinstalar
  const tabs = TABS.filter((t) => t[0] !== "revisao" || isAdmin);
  const tab = (tabs.find((t) => t[0] === (tab0 === "dados" ? "configuracoes" : tab0))?.[0] ?? "meus") as (typeof TABS)[number][0];
  // mantém a barra de seções onde a pessoa deixou e só rola o necessário para mostrar a seção escolhida
  const menuRef = React.useRef<HTMLElement>(null);
  React.useEffect(() => {
    const nav = menuRef.current;
    const el = nav?.querySelector<HTMLElement>('[aria-current="page"]');
    if (!nav || !el) return;
    const left = el.offsetLeft - nav.offsetLeft,
      right = left + el.offsetWidth;
    if (left < nav.scrollLeft) nav.scrollTo({ left: left - 8, behavior: "smooth" });
    else if (right > nav.scrollLeft + nav.clientWidth) nav.scrollTo({ left: right - nav.clientWidth + 8, behavior: "smooth" });
  }, [tab]);
  const saved = st.saves.map((id) => posts.find((p) => p.id === id) ?? findPost(id)).filter(Boolean) as typeof posts;
  const name = st.server.user?.displayName ?? st.me.name;
  const [editing, setEditing] = React.useState(false);
  return (
    <div className="stack profile-page" style={{ gap: 16 }}>
      <div className="profile-head">
        <Avatar a={{ ...st.me, name, photo: st.me.photo ?? st.server.user?.photo }} size={64} />
        <div className="grow" style={{ minWidth: 0 }}>
          <h1>{name}</h1>
          <p className="small muted">
            {[st.server.user ? `@${st.server.user.handle}` : null, st.me.place, `${mine.length} relato(s)`].filter(Boolean).join(" · ")}
          </p>
          {st.me.bio && <p className="small profile-bio">{st.me.bio}</p>}
          <button id="edit-profile" className="btn sm edit-profile-btn" onClick={() => setEditing(true)}>
            <Icon name="edit" /> Editar perfil
          </button>
        </div>
      </div>
      {editing && <EditProfile onClose={() => setEditing(false)} />}
      <nav ref={menuRef} className="profile-menu" aria-label="Seções do perfil">
        {tabs.map(([k, l, ic]) => (
          <a key={k} href={k === "meus" ? "#perfil" : `#perfil-${k}`} aria-current={tab === k ? "page" : undefined}>
            <Icon name={ic} size={18} />
            <span>{l}</span>
            {k === "meus" && mine.length > 0 && <span className="count">{mine.length}</span>}
          </a>
        ))}
      </nav>
      {tab === "meus" && <MyReports />}
      {tab === "atividade" && <Activity />}
      {tab === "salvos" && (
        <div className="feed">
          {saved.length === 0 && <div className="empty panel">Nenhuma publicação salva.</div>}
          {saved.map((p) => (
            <PostCard key={p.id} p={p} />
          ))}
        </div>
      )}
      {tab === "revisao" && <Review />}
      {tab === "configuracoes" && <MyData />}
      <footer className="profile-footer">
        <a className="btn about-link about-fixed" href="#sobre">
          <Icon name="info" /> Sobre nós
        </a>
      </footer>
    </div>
  );
}

/* ---------------- sobre ---------------- */
export function About() {
  const { manifest } = useApp();
  const sources = (manifest?.sources ?? []).filter((x) => x.id !== "cemaden");
  return (
    <div className="stack about prose" style={{ gap: 20 }}>
      <div className="stack" style={{ gap: 6 }}>
        <div className="about-logos">
          <img className="about-logo" src="igarapost-logo.png" alt="Logo do IgaraPost: barco num igarapé, com a mata ao fundo" width={120} height={120} />
          <img className="about-logo" src="vento-norte-redonda.png" alt="Logo da equipe Vento Norte, da UEA: foguete sobre o horizonte, com estrelas" width={120} height={120} />
        </div>
        <span className="eyebrow">NASA Space Apps Challenge · Dancing with the SARs</span>
        <h1>Sobre nós</h1>
        <p>
          O IgaraPost é uma rede de monitoramento colaborativo de fumaça, queimadas e enchentes. O mapa do {SARS.name} junta camadas de satélite e radar da NASA, focos de fogo em tempo quase real e os relatos de
          quem está no local, principalmente do que ainda está <b>fora do radar</b> dos sensores oficiais.
        </p>
        <figure className="team-photo">
          <img src="equipe-vento-norte.jpg" alt="Equipe Vento Norte, da UEA, segurando a bandeira da equipe" width={1200} height={797} loading="lazy" decoding="async" />
          <figcaption className="small muted">Equipe de desenvolvimento · Vento Norte (UEA)</figcaption>
        </figure>
        <p className="muted">
          Feito pela equipe Vento Norte, da Universidade do Estado do Amazonas (UEA). Versão {__APP_VERSION__}.
        </p>
      </div>

      <section className="stack">
        <h2>Como ler cada publicação</h2>
        <p>
          <span className="badge community">Relato da comunidade · não verificado</span> é o que alguém viu ou sentiu no lugar. Apoios e comentários mostram interesse, mas não confirmam o relato.
        </p>
        <p>
          <span className="badge community verified">Relato da comunidade · verificado</span> quer dizer que a administração do IgaraPost conferiu o relato.
        </p>
        <p>
          <span className="badge explainer">Explicativo</span> é um texto da equipe que ensina a ler os dados. Essas publicações ficam fixadas no topo do Feed.
        </p>
        <p>
          <span className="badge radar fora_do_radar">{RADAR_LABEL.fora_do_radar}</span> quer dizer que, no momento do relato, os dados do {SARS.name} não mostravam esse evento perto do ponto. Isso não significa que
          o relato esteja errado: satélites deixam passar fogo pequeno, fumaça local e enchentes sob nuvens.
        </p>
        <p>
          <span className="badge radar confirmado">{RADAR_LABEL.confirmado}</span> quer dizer que o relato estava fora do radar e, numa nova conferência, o {SARS.name} passou a mostrar o evento perto do ponto.
        </p>
        <div className="callout warn small">O IgaraPost não publica alertas oficiais e não aciona serviços de emergência. Em situação de perigo, ligue 193 (Bombeiros) ou 199 (Defesa Civil).</div>
      </section>

      <section className="stack">
        <h2>{SARS.name}: de onde vêm os dados do mapa</h2>
        <p>
          {SARS.description} O mapa usa somente dados da NASA e precisa de internet. Sem conexão, aparece a imagem Blue Marble do entorno de Manaus guardada no app.
        </p>
        <p>
          <b>Queimadas.</b> Os focos de fogo ativo vêm da NASA FIRMS, a partir dos satélites VIIRS NOAA-20 e NOAA-21. Cobrem as últimas 48 horas, são lidos a cada 10 minutos e cada ponto representa cerca de 375 m.
        </p>
        {SARS_LAYERS.map((l) => (
          <p key={l.id}>
            <b>
              {EVENTS[l.event].label} · {l.title}.
            </b>{" "}
            Fonte: {l.source}, com {l.sensor}. Atualização {l.cadence}; escala {l.scale}.
          </p>
        ))}
        <p>
          <b>Fundo do mapa.</b> A imagem em cor natural do dia vem da NASA GIBS (VIIRS NOAA-20, com outros satélites de reserva), com litoral, fronteiras e nomes de lugares. É atualizada todos os dias e cobre o
          mundo todo.
        </p>
      </section>

      <section className="stack">
        <h2>Dados do entorno de Manaus</h2>
        {!manifest && <p className="muted">Carregando a lista de fontes…</p>}
        {sources.map((x) => (
          <p key={x.id}>
            <a href={x.url} target="_blank" rel="noreferrer">
              <b>{x.name}</b>
            </a>
            . Período: {x.period}. Cobertura: {x.coverage}; escala: {x.scale}. Obtido em {fmtDate(x.retrieved.replace("Z", ":00Z"), true)} (atualização {x.update}).
          </p>
        ))}
      </section>

      <section className="stack">
        <h2>O que é real e o que está pendente</h2>
        <p>
          <span className="status-ok">Dados reais:</span> focos do INPE (1º de julho a 13 de novembro de 2026), prévias do radar NISAR (10 passagens, de junho a novembro de 2026) e localidades, rios e vias do
          OpenStreetMap.
        </p>
        <p>
          <span className="status-ok">Exploração experimental:</span> a separação claro/escuro das prévias do NISAR e o teste de proximidade com os focos de fogo. Ainda precisam de validação.
        </p>
        <p>
          <span className="status-no">Pendente:</span> análise com retroespalhamento calibrado (arquivos GCOV .h5, pois o acesso Earthdata não funcionou), atualização automática
          dos arquivos do entorno de Manaus (as camadas do {SARS.name} já são atualizadas ao vivo) e avaliação com usuários.
        </p>
      </section>

      <section className="stack">
        <h2>Créditos</h2>
        <p>
          INPE (Programa Queimadas); NASA/JPL e ISRO (missão NISAR), com dados distribuídos pelo ASF DAAC; NASA GIBS (VIIRS, MODIS, OPERA DSWx-S1 com dados Copernicus Sentinel-1 e Blue Marble); NASA FIRMS; ©
          colaboradores do OpenStreetMap (ODbL). Software livre: React, Vite, Leaflet e Capacitor.
        </p>
      </section>
    </div>
  );
}
