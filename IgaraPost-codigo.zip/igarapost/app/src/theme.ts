import React from "react";
import { getState, setSoft, useStore } from "./store";

/** Tema escolhido pela pessoa: "auto" acompanha o tema do aparelho. */
export type ThemePref = "auto" | "light" | "dark";
export const THEME_OPTIONS: [ThemePref, string][] = [
  ["auto", "Automático"],
  ["light", "Claro"],
  ["dark", "Escuro"],
];

const mq = () => window.matchMedia?.("(prefers-color-scheme: dark)");
const resolve = (p: ThemePref) => (p === "auto" ? !!mq()?.matches : p === "dark");

/** Aplica o tema na página: atributo data-theme (lido pelo CSS) e cor da barra do navegador. */
export function applyTheme(p: ThemePref = getState().prefs.theme ?? "auto") {
  const root = document.documentElement;
  if (p === "auto") delete root.dataset.theme;
  else root.dataset.theme = p;
  const dark = resolve(p);
  root.style.colorScheme = dark ? "dark" : "light";
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", dark ? "#0f1c2c" : "#1b6c97");
}

export function setTheme(p: ThemePref) {
  setSoft((s) => ({ ...s, prefs: { ...s.prefs, theme: p } }));
  applyTheme(p);
}

/** Liga o tema salvo e acompanha a troca de tema do aparelho no modo automático. */
export function initTheme() {
  applyTheme();
  mq()?.addEventListener?.("change", () => applyTheme());
}

/** true quando a interface está no modo escuro (escolhido ou herdado do aparelho). */
export function useIsDark() {
  const pref = useStore().prefs.theme ?? "auto";
  const [sys, setSys] = React.useState(() => !!mq()?.matches);
  React.useEffect(() => {
    const m = mq();
    const f = () => setSys(!!m?.matches);
    m?.addEventListener?.("change", f);
    return () => m?.removeEventListener?.("change", f);
  }, []);
  return pref === "auto" ? sys : pref === "dark";
}
