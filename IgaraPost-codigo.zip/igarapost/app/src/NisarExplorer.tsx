import { LOCALE } from "./i18n/lang";
import React from "react";
import { useApp } from "./ctx";
import { Icon } from "./Icon";
import { fmtDate, fmtDay, nisarTiming } from "./data";
import { NisarMap } from "./NisarMap";

/** Curva suave que passa por todos os pontos sem inventar picos (interpolação monotônica de Fritsch–Carlson). */
function smoothPath(xs: number[], ys: number[]) {
  const n = xs.length;
  if (n < 2) return "";
  const dx = xs.slice(1).map((x, i) => x - xs[i]);
  const sl = ys.slice(1).map((y, i) => (y - ys[i]) / (dx[i] || 1));
  const m = ys.map((_, i) => (i === 0 ? sl[0] : i === n - 1 ? sl[n - 2] : sl[i - 1] * sl[i] <= 0 ? 0 : (3 * (dx[i - 1] + dx[i])) / ((2 * dx[i] + dx[i - 1]) / sl[i - 1] + (dx[i] + 2 * dx[i - 1]) / sl[i])));
  let d = `M${xs[0].toFixed(1)},${ys[0].toFixed(1)}`;
  for (let i = 0; i < n - 1; i++) {
    const h = dx[i] / 3;
    d += `C${(xs[i] + h).toFixed(1)},${(ys[i] + m[i] * h).toFixed(1)} ${(xs[i + 1] - h).toFixed(1)},${(ys[i + 1] - m[i + 1] * h).toFixed(1)} ${xs[i + 1].toFixed(1)},${ys[i + 1].toFixed(1)}`;
  }
  return d;
}
const MESES = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
const km = (v: number) => v.toLocaleString(LOCALE, { maximumFractionDigits: 0 });
const dia = (iso: string) => `${Number(iso.slice(8, 10))} ${MESES[Number(iso.slice(5, 7)) - 1]}`;

/** Área segmentada como escura em cada passagem do radar: linha suave, área em degradê e toque para ver o valor. */
function SeriesChart({ series, pair }: { series: { date: string; dark_km2: number; crid: string }[]; pair: [string, string] }) {
  const boxRef = React.useRef<HTMLDivElement>(null);
  const [W, setW] = React.useState(360);
  const [hover, setHover] = React.useState<number>();
  React.useEffect(() => {
    const el = boxRef.current;
    if (!el) return;
    const f = () => setW(Math.max(260, Math.round(el.clientWidth)));
    f();
    const ro = new ResizeObserver(f);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  const H = 230,
    m = { l: 44, r: 16, t: 26, b: 34 };
  const t = series.map((x) => Date.parse(x.date + "T12:00:00Z"));
  const y = series.map((x) => x.dark_km2);
  const t0 = Math.min(...t),
    t1 = Math.max(...t);
  // escala com folga e marcas "redondas"
  const lo = Math.min(...y),
    hi = Math.max(...y);
  const step = [50, 100, 200, 250, 500, 1000].find((s) => (hi - lo) / s <= 4) ?? 1000;
  const ymin = Math.floor((lo - step * 0.3) / step) * step,
    ymax = Math.ceil((hi + step * 0.3) / step) * step;
  const X = (v: number) => m.l + ((v - t0) / (t1 - t0 || 1)) * (W - m.l - m.r);
  const Y = (v: number) => H - m.b - ((v - ymin) / (ymax - ymin || 1)) * (H - m.t - m.b);
  const xs = t.map(X),
    ys = y.map(Y);
  const line = smoothPath(xs, ys);
  const ticks: number[] = [];
  for (let v = ymin; v <= ymax + 1e-9; v += step) ticks.push(v);
  // marcas do eixo X: início de cada mês dentro da série
  const months: { x: number; label: string }[] = [];
  const d0 = new Date(t0);
  for (let d = new Date(Date.UTC(d0.getUTCFullYear(), d0.getUTCMonth() + 1, 1)); d.getTime() <= t1; d = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1)))
    months.push({ x: X(d.getTime()), label: MESES[d.getUTCMonth()] });
  const crid = series.findIndex((x, i) => i > 0 && x.crid !== series[i - 1].crid);
  const sel = series.map((x) => pair.includes(x.date));
  const pick = (clientX: number) => {
    const r = boxRef.current?.querySelector("svg")?.getBoundingClientRect();
    if (!r) return;
    const px = ((clientX - r.left) / r.width) * W;
    let best = 0;
    xs.forEach((x, i) => Math.abs(x - px) < Math.abs(xs[best] - px) && (best = i));
    setHover(best);
  };
  const hv = hover != null ? series[hover] : undefined;
  return (
    <div className="series-chart" ref={boxRef}>
      <svg
        className="chart"
        viewBox={`0 0 ${W} ${H}`}
        width={W}
        height={H}
        role="img"
        aria-label={`Área de superfície escura no radar em ${series.length} passagens, de ${dia(series[0].date)} a ${dia(series[series.length - 1].date)}: de ${km(lo)} a ${km(hi)} km²`}
        onPointerMove={(e) => pick(e.clientX)}
        onPointerDown={(e) => pick(e.clientX)}
        onPointerLeave={() => setHover(undefined)}
      >
        <defs>
          <linearGradient id="nisar-area" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--nisar)" stopOpacity="0.32" />
            <stop offset="100%" stopColor="var(--nisar)" stopOpacity="0.02" />
          </linearGradient>
        </defs>
        {ticks.map((v) => (
          <g key={v}>
            <line className="grid" x1={m.l} x2={W - m.r} y1={Y(v)} y2={Y(v)} />
            <text x={m.l - 8} y={Y(v) + 4} textAnchor="end">
              {km(v)}
            </text>
          </g>
        ))}
        <text x={m.l - 8} y={m.t - 12} textAnchor="start" className="unit">
          km² escuros
        </text>
        {months.map((mo) => (
          <g key={mo.label + mo.x}>
            <line className="axis" x1={mo.x} x2={mo.x} y1={H - m.b} y2={H - m.b + 5} />
            <text x={mo.x} y={H - m.b + 18} textAnchor="middle">
              {mo.label}
            </text>
          </g>
        ))}
        <line className="axis" x1={m.l} x2={W - m.r} y1={H - m.b} y2={H - m.b} />
        {crid > 0 && (
          <g className="crid">
            <line x1={(xs[crid - 1] + xs[crid]) / 2} x2={(xs[crid - 1] + xs[crid]) / 2} y1={m.t} y2={H - m.b} />
            <text x={(xs[crid - 1] + xs[crid]) / 2 - 4} y={m.t + 10} textAnchor="end">
              nova versão de processamento
            </text>
          </g>
        )}
        <path d={`${line}L${xs[xs.length - 1].toFixed(1)},${H - m.b}L${xs[0].toFixed(1)},${H - m.b}Z`} fill="url(#nisar-area)" />
        <path className="line smooth" d={line} />
        {hv && <line className="cross" x1={xs[hover!]} x2={xs[hover!]} y1={m.t} y2={H - m.b} />}
        {series.map((x, i) => (
          <circle key={x.date} className={`pt ${sel[i] ? "sel" : ""} ${hover === i ? "hov" : ""}`} cx={xs[i]} cy={ys[i]} r={sel[i] || hover === i ? 5.5 : 4} />
        ))}
        {series.map((x, i) =>
          sel[i] ? (
            <text key={"l" + x.date} className="pair-label" x={xs[i]} y={ys[i] - 11} textAnchor={xs[i] > W - 60 ? "end" : xs[i] < m.l + 30 ? "start" : "middle"}>
              {x.date === pair[0] ? "A" : "B"} · {km(x.dark_km2)}
            </text>
          ) : null,
        )}
      </svg>
      <div className="chart-tip" aria-live="polite">
        {hv ? (
          <>
            <b>{dia(hv.date)}</b>: {km(hv.dark_km2)} km² escuros{pair.includes(hv.date) ? ` (data ${hv.date === pair[0] ? "A" : "B"} do par)` : ""}
          </>
        ) : (
          <span className="muted">Toque ou passe o dedo no gráfico para ver cada passagem.</span>
        )}
      </div>
    </div>
  );
}

export function NisarExplorer() {
  const { nisar, posts } = useApp();
  const aoi = nisar?.aoi;

  if (!nisar || !aoi) return <div className="empty panel">Carregando análise NISAR…</div>;
  const [a, b] = nisar.pair;
  const ga = nisar.granules[a],
    gb = nisar.granules[b];
  const s = nisar.stats;
  const ov = nisar.fire_overlap;

  return (
    <div className="stack prose" style={{ gap: 18 }}>
      <div className="stack" style={{ gap: 6 }}>
        <span className="badge nisar" style={{ alignSelf: "flex-start" }}>
          <Icon name="radar" size={13} /> Exploração visual experimental · NISAR
        </span>
        <h1>Explorador NISAR</h1>
        <p className="muted">
          Compare duas datas do radar NISAR (NASA/ISRO), de 2025 até hoje, em qualquer lugar do mapa. No <b>Estudo de Região</b>, escolha uma região da floresta amazônica para comparar as datas e ver os focos e os
          relatos dela.
        </p>
      </div>

      <NisarMap nisar={nisar} posts={posts} />

      <section className="stack">
        <h2>O que a segmentação das prévias mostra</h2>
        <p className="small muted">
          Áreas calculadas a partir da separação claro/escuro das imagens de prévia. Descrevem as imagens, não o terreno: precisam de validação (dados calibrados, campo, outras fontes) antes de qualquer interpretação como
          água ou queimada.
        </p>
        <div className="stat-grid">
          <div className="stat">
            <b>{s.valid_km2.toLocaleString(LOCALE)} km²</b>
            <span>área com dados nas duas datas ({((1 - s.nodata_frac) * 100).toFixed(0)}% do recorte)</span>
          </div>
          <div className="stat">
            <b style={{ color: "var(--water)" }}>{s.bright_to_dark_km2.toLocaleString(LOCALE)} km²</b>
            <span>segmentados como “passou a aparecer escuro”</span>
          </div>
          <div className="stat">
            <b style={{ color: "var(--fire)" }}>{s.dark_to_bright_km2.toLocaleString(LOCALE)} km²</b>
            <span>segmentados como “deixou de aparecer escuro”</span>
          </div>
          <div className="stat">
            <b>
              {s.dark_A_km2.toLocaleString(LOCALE)} → {s.dark_B_km2.toLocaleString(LOCALE)}
            </b>
            <span>km² segmentados como escuros (A → B)</span>
          </div>
        </div>
        {ov && (
          <div className="callout nisar small">
            <b>Fogo e radar, uma relação a investigar.</b> Dos {ov.n_fires.toLocaleString(LOCALE)} focos NPP-375 detectados entre as duas datas em áreas que estavam claras em A,{" "}
            <b>{(ov.frac_fires_near_bright_to_dark * 100).toFixed(0)}%</b> ficam a até {ov.radius_m} m de um pixel que passou a aparecer escuro. Para {ov.n_random.toLocaleString(LOCALE)} pontos sorteados ao acaso nas
            mesmas condições, a proporção é {(ov.frac_random_near_bright_to_dark * 100).toFixed(0)}%. Queimadas podem reduzir o retroespalhamento (menos vegetação), mas os focos se concentram em pastos e roças,
            que também mudam por outros motivos (colheita, solo exposto). Não atribuímos a mudança ao fogo sem verificação em campo ou mapa de área queimada.
          </div>
        )}
      </section>

      <section className="stack">
        <h2>Superfície escura em todas as passagens</h2>
        <p className="small muted">
          Mesmo recorte, trilha 140, {nisar.series.length} passagens (área comum: {nisar.series_common_km2.toLocaleString(LOCALE)} km²). Os pontos cheios são o par comparado acima. A série é curta e o limiar é
          calculado por imagem, então pequenas variações não significam tendência.
        </p>
        <SeriesChart series={nisar.series} pair={nisar.pair} />
      </section>

      <section className="stack">
        <h2>Como foi feito</h2>
        <ol className="small" style={{ margin: 0, paddingLeft: 20, display: "flex", flexDirection: "column", gap: 6 }}>
          <li>
            Buscamos no ASF todos os produtos <b>NISAR L2 GCOV</b> que cobrem Manaus e escolhemos o par mais comparável: mesma trilha (140), mesmo frame (90), mesma direção (descendente), mesmo modo (DHDH, HH e
            HV) e mesma versão de processamento (CRID {ga.crid}).
          </li>
          <li>
            Usamos as imagens de pré-visualização (browse) públicas desses produtos: composição em cores com R e B = HH e G = HV. O arquivo científico (.h5) exige login Earthdata, que ainda não conseguimos usar.
          </li>
          <li>
            Georreferenciamos cada imagem pelo contorno informado pelo ASF (erro médio de {nisar.registration[a] ? "1 a 2" : "?"} pixels) e conferimos contra a camada NISAR do NASA GIBS: as duas datas tiveram o
            mesmo ajuste ({nisar.registration[a]?.dx} px). Precisão estimada: cerca de 0,2 a 0,4 km.
          </li>
          <li>
            Em cada data, separamos pixels escuros e claros pelo método de Otsu (limiar automático no brilho). Comparamos as duas máscaras pixel a pixel, numa grade de {(nisar.grid_res_deg * 111.32 * 1000).toFixed(0)} m.
          </li>
        </ol>
        <div className="callout warn small">
          <b>Limitações.</b> As imagens browse têm realce de contraste e não são valores calibrados de retroespalhamento (gamma0), por isso não comparamos brilho em dB. “Escuro” nem sempre é água: vento e chuva deixam a
          água rugosa e clara, e floresta alagada fica muito clara. A análise com valores calibrados (arquivos .h5) tem um script preparado no repositório, testado apenas com um arquivo sintético; ainda não foi executada com dados reais porque o acesso Earthdata não funcionou.
        </div>
      </section>

      <section className="stack">
        <h2>Comparabilidade e qualidade do par</h2>
        <p>
          Para comparar duas datas do radar, as imagens precisam ter sido feitas nas mesmas condições. Veja o que foi conferido neste par:
        </p>
        {(
          [
            ["Mesma trilha e frame", ga.path === gb.path && ga.frame === gb.frame, `${ga.path}/${ga.frame} e ${gb.path}/${gb.frame}`],
            ["Mesma direção de órbita", ga.dir === gb.dir, `${ga.dir} e ${gb.dir}`],
            ["Mesmas polarizações", ga.pol.join() === gb.pol.join(), `${ga.pol.join("+")} e ${gb.pol.join("+")}`],
            ["Mesma versão de processamento (CRID)", ga.crid === gb.crid, `${ga.crid} e ${gb.crid}`],
            ["Frame com cobertura completa", ga.coverage === "Full" && gb.coverage === "Full", `${ga.coverage} e ${gb.coverage}`],
            ["Mesmo ajuste geométrico das prévias", nisar.registration[a]?.dx === nisar.registration[b]?.dx && nisar.registration[a]?.dy === nisar.registration[b]?.dy, `deslocamento ${nisar.registration[a]?.dx},${nisar.registration[a]?.dy} e ${nisar.registration[b]?.dx},${nisar.registration[b]?.dy} px`],
            ["Pouca área sem dados (menos de 5%)", s.nodata_frac < 0.05, `${(s.nodata_frac * 100).toFixed(1).replace(".", ",")}% do recorte fica sem dados em uma das datas`],
            ["Valores calibrados (gamma0)", false, "as prévias têm realce de contraste e o arquivo .h5 não foi acessado"],
            ["Máscara de qualidade do produto (mask, numberOfLooks)", false, "não foi aplicada porque fica no arquivo .h5"],
          ] as const
        ).map(([k, ok, v]) => (
          <p key={k}>
            <b className={ok ? "status-ok" : "status-no"}>{ok ? "Sim" : "Não"}</b> · <b>{k}:</b> {v}.
          </p>
        ))}
      </section>

      {nisar.inventory && (
        <section className="stack">
          <h2>Produtos GCOV disponíveis sobre a área</h2>
          <p className="small muted">
            {nisar.inventory.n_products} produtos (metadados públicos do ASF, consultados em 14 nov 2026). Só se comparam datas do mesmo grupo: mesma trilha, frame, direção, modo, polarizações e versão de processamento. A qualidade de
            cada produto (relatórios QA) exige login Earthdata e não foi conferida.
          </p>
          {nisar.inventory.groups
            .filter((g) => g.n >= 2)
            .map((g) => (
              <p key={`${g.path}-${g.frame}-${g.mode}-${g.pol}-${g.crid}`}>
                <b>
                  Trilha {g.path}, frame {g.frame}
                  {g.path === ga.path && g.frame === ga.frame && g.crid === ga.crid && g.pol === ga.pol.join("+") ? " (usado aqui)" : ""}:
                </b>{" "}
                {g.n} produtos de {fmtDay(g.first)} a {fmtDay(g.last)}, órbita {g.direction === "DESCENDING" ? "descendente" : "ascendente"}, polarização {g.pol}, versão {g.crid}.
              </p>
            ))}
          <p className="small muted">
            Pares recomendados para a análise calibrada (julho × fim de set./out., frames completos, HH+HV):{" "}
            {nisar.inventory.recommended_pairs.map((r) => `trilha ${r.path}/${r.frame}: ${fmtDay(r.pair[0])} × ${fmtDay(r.pair[1])}`).join("; ")}.
          </p>
        </section>
      )}

      <section className="stack">
        <h2>Relatos na área do estudo e as datas do radar</h2>
        {(() => {
          const inside = posts.filter((p) => p.kind === "community" && p.lat != null && p.lon != null && p.lon >= aoi.west && p.lon <= aoi.east && p.lat >= aoi.south && p.lat <= aoi.north);
          if (!inside.length) return <p className="small muted">Nenhum relato dentro do recorte com os filtros atuais.</p>;
          return (
            <ul className="small tight">
              {inside.slice(0, 12).map((p) => {
                const tm = nisarTiming(nisar, p.observedAt);
                return (
                  <li key={p.id}>
                    <a href={`#post-${p.id}`}>
                      {p.municipio} · observado em {fmtDate(p.observedAt)}
                      {p.example ? " (exemplo fictício)" : ""}
                    </a>
                    : {tm.relation === "antes" ? "antes das duas imagens" : tm.relation === "entre" ? "entre as duas imagens" : "depois das duas imagens"} ({fmtDay(a)} e {fmtDay(b)}); {tm.near}.
                  </li>
                );
              })}
            </ul>
          );
        })()}
      </section>

      <section className="stack file-ids">
        <h2>Identificação dos arquivos</h2>
        {(
          [
            ["A", ga],
            ["B", gb],
          ] as const
        ).map(([lbl, g]) => (
          <p key={lbl}>
            <b>Imagem {lbl}</b>, de {g.start.replace("T", " ").slice(0, 16)} (UTC): produto GCOV (L2, covariância polarimétrica geocodificada) da coleção <span className="mono">{g.collection}</span>, polarizações {g.pol.join(" + ")}, trilha {g.path},
            frame {g.frame}, órbita {g.dir === "DESCENDING" ? "descendente" : g.dir}, cobertura {g.coverage === "Full" ? "completa" : g.coverage}, versão {g.crid} / {g.pge}. Arquivo <span className="mono">{g.granule}</span>.{" "}
            <a href={g.browse} target="_blank" rel="noreferrer">
              Ver a prévia
            </a>{" "}
            ou{" "}
            <a href={g.download} target="_blank" rel="noreferrer">
              baixar o .h5 (exige login)
            </a>
            .
          </p>
        ))}
        <p className="small muted">
          Créditos: NASA/JPL e ISRO, missão NISAR; dados distribuídos pelo Alaska Satellite Facility (ASF DAAC). Recorte: lon {aoi.west} a {aoi.east}, lat {aoi.south} a {aoi.north}. Processamento:
          data-pipeline/scripts/process_nisar_browse.py.
        </p>
      </section>
      <a className="btn" href="#mapa" style={{ alignSelf: "flex-start" }}>
        <Icon name="map" /> Ver a camada no mapa com focos e enchentes
      </a>
    </div>
  );
}
