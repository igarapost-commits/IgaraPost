/** Configurações › Meu registro: texto com os relatos e as denúncias da própria pessoa (data, horário e local). */
import { CATEGORIES } from "./seed";
import { LANG, LOCALE, tr3 } from "./i18n/lang";
import { translateText } from "./i18n/dom";
import * as sb from "./sb";
import { getState } from "./store";
import { SYNC_LABEL } from "./sync";
import type { Post } from "./types";

const tt = (s: string) => (LANG === "pt" ? s : translateText(s));
const when = (iso: string) => new Date(iso).toLocaleString(LOCALE, { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
function zone() {
  const m = -new Date().getTimezoneOffset();
  const h = String(Math.floor(Math.abs(m) / 60)).padStart(2, "0"),
    mm = String(Math.abs(m) % 60).padStart(2, "0");
  return `UTC${m < 0 ? "−" : "+"}${h}:${mm}`;
}
function place(municipio: string | null | undefined, lat?: number | null, lon?: number | null, approx?: boolean | null) {
  if (lat == null || lon == null) return tr3("local indisponível", "location unavailable", "ubicación no disponible");
  const coords = `${lat.toFixed(5)}, ${lon.toFixed(5)}${approx ? `; ${tr3("aproximado", "approximate", "aproximada")}` : ""}`;
  return municipio ? `${municipio} (${coords})` : coords;
}
const cat = (c?: Post["category"] | null) => (c && CATEGORIES[c] ? tt(CATEGORIES[c].label) : "—");
const RESULT: Record<string, () => string> = {
  pendente: () => tr3("pendente", "pending", "pendiente"),
  mantido: () => tr3("publicação mantida", "post kept", "publicación mantenida"),
  ocultado: () => tr3("publicação ocultada", "post hidden", "publicación ocultada"),
};

/** Monta o registro. `mine` são os relatos da pessoa; as denúncias vêm do servidor e da fila do aparelho. */
export async function buildMyLog(mine: Post[], findPost: (id: string) => Post | undefined): Promise<string> {
  const st = getState();
  const L: string[] = [];
  const name = st.server.user?.displayName ?? st.me.name;
  L.push(`IgaraPost · ${tr3("registro de", "log of", "registro de")} ${name}`);
  L.push(`${tr3("Gerado em", "Generated on", "Generado el")} ${when(new Date().toISOString())} · ${tr3("horários no fuso do aparelho", "times in the device time zone", "horarios en la zona del dispositivo")} (${zone()})`);

  const posts = [...mine].sort((a, b) => Date.parse(b.observedAt) - Date.parse(a.observedAt));
  L.push("", `${tr3("RELATOS", "REPORTS", "REPORTES")} (${posts.length})`);
  posts.forEach((p, i) => {
    L.push(`${i + 1}. ${when(p.observedAt)} · ${cat(p.category)} · ${place(p.municipio, p.lat, p.lon, p.approx)}`);
    // publicado: só a data de envio; nos outros estados (na fila, com falha, ocultado), o estado
    const status = p.sync && p.sync !== "publicado" ? ` · ${tt(SYNC_LABEL[p.sync] ?? p.sync)}` : "";
    const sent = p.sync === "pendente" || p.sync === "enviando" || p.sync === "falhou" ? "" : `${tr3("Enviado em", "Sent on", "Enviado el")} ${when(p.publishedAt)}`;
    L.push(`   ${[sent, status.slice(3)].filter(Boolean).join(" · ")}`);
  });

  let rows: sb.ReportLogItem[] = [];
  let note = "";
  if (st.server.token) {
    try {
      rows = await sb.myReportLog();
    } catch {
      note = tr3("Sem conexão: as denúncias já enviadas não puderam ser buscadas.", "Offline: complaints already sent could not be fetched.", "Sin conexión: no se pudieron obtener las denuncias ya enviadas.");
    }
  }
  const queued = st.outbox.filter((x) => x.op === "report") as { postId: string; reason: string; createdAt: string }[];
  const local = st.reports;
  const total = rows.length + queued.length + local.length;
  L.push("", `${tr3("DENÚNCIAS", "COMPLAINTS", "DENUNCIAS")} (${total})`);
  if (note) L.push(note);
  let n = 0;
  for (const r of rows) {
    L.push(`${++n}. ${when(r.created_at)} · ${tt(r.reason)} · ${tr3("resultado", "result", "resultado")}: ${(RESULT[r.status] ?? (() => r.status))()}${r.reviewed_at ? ` (${when(r.reviewed_at)})` : ""}`);
    L.push(`   ${tr3("Relato denunciado", "Reported post", "Reporte denunciado")}: ${cat(r.category)} · ${place(r.municipio, r.lat, r.lon, r.approx)}`);
  }
  for (const r of [...queued.map((q) => ({ at: q.createdAt, postId: q.postId, reason: q.reason, status: tr3("aguardando envio", "waiting to be sent", "esperando envío") })), ...local.map((x) => ({ at: x.at, postId: x.postId, reason: x.reason, status: (RESULT[x.status] ?? (() => x.status))() }))]) {
    const p = findPost(r.postId);
    L.push(`${++n}. ${when(r.at)} · ${tt(r.reason)} · ${r.status}`);
    L.push(`   ${tr3("Relato denunciado", "Reported post", "Reporte denunciado")}: ${cat(p?.category)} · ${place(p?.municipio, p?.lat, p?.lon, p?.approx)}`);
  }
  if (!posts.length) L.splice(L.indexOf(`${tr3("RELATOS", "REPORTS", "REPORTES")} (0)`) + 1, 0, tr3("Nenhum relato.", "No reports.", "Ningún reporte."));
  if (!total) L.push(tr3("Nenhuma denúncia.", "No complaints.", "Ninguna denuncia."));
  return L.join("\n");
}

/** Copia texto: API moderna e, se não houver, o método antigo (WebView mais velho). */
export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try {
      ok = document.execCommand("copy");
    } catch {
      ok = false;
    }
    ta.remove();
    return ok;
  }
}
