/**
 * Navegação com memória de UMA tela.
 *
 * O histórico do WebView nunca passa de duas entradas: [tela anterior, tela atual]. Voltar (botão "Voltar" do app,
 * gesto ou botão do celular) leva à última tela; dali não há mais para onde voltar, então o botão do celular fecha o
 * app. Assim não se forma uma fila longa de telas.
 *
 * No Android, o botão voltar do celular só chega ao app com o plugin nativo @capacitor/app (ver README): sem
 * ouvintes, ele volta no histórico do WebView quando dá e, quando não dá, fecha o app — exatamente o comportamento
 * acima. Sem o plugin, o botão do celular fecha o app direto e o botão "Voltar" do app continua funcionando.
 */
type NavState = { ig: 1 | 2; prev?: string };

const cur = () => location.hash || "#feed";
/** a mesma tela com outra parte (ex.: #post-1 e #post-1#comentarios) */
const screenOf = (h: string) => h.replace(/^(#[^#]*)#.*$/, "$1");
const emit = () => window.dispatchEvent(new HashChangeEvent("hashchange"));

let depth: 1 | 2 = 1;
let prev: string | null = null;

/** Tela anterior guardada (só uma), ou null se esta é a primeira. */
export const previousScreen = () => prev;

export function navigate(hash: string, opts: { replace?: boolean } = {}) {
  const from = cur();
  if (hash === from) return emit();
  if (opts.replace || screenOf(hash) === screenOf(from)) {
    history.replaceState({ ig: depth, prev: prev ?? undefined } as NavState, "", hash);
    return emit();
  }
  prev = from;
  if (depth === 1) {
    history.pushState({ ig: 2, prev } as NavState, "", hash);
    depth = 2;
  } else history.replaceState({ ig: 2, prev } as NavState, "", hash); // troca a tela atual: a fila não cresce
  emit();
}

/** Volta para a última tela (se houver). */
export function goBack() {
  if (!prev) return;
  if (depth === 2) history.back(); // o popstate abaixo mostra a tela anterior
  else {
    const t = prev;
    prev = null;
    history.replaceState({ ig: 1 } as NavState, "", t);
    emit();
  }
}

export function startNav() {
  // depois de recarregar (troca de idioma), o histórico continua o mesmo: retoma o estado guardado nele
  const s = history.state as NavState | null;
  if (s?.ig === 2) {
    depth = 2;
    prev = s.prev ?? null;
  } else history.replaceState({ ig: 1 } as NavState, "", cur());

  // voltar: caímos na entrada de baixo; ela passa a mostrar a última tela, e a memória fica vazia
  window.addEventListener("popstate", (e) => {
    // só a volta para a entrada de baixo (ig: 1); ir para um endereço novo também dispara popstate, sem estado
    if ((e.state as NavState | null)?.ig !== 1) return;
    const target = prev ?? cur();
    depth = 1;
    prev = null;
    history.replaceState({ ig: 1 } as NavState, "", target);
    emit();
  });

  // links internos (#...) passam por aqui em vez de empilhar entradas no histórico
  document.addEventListener(
    "click",
    (e) => {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      const a = (e.target as Element | null)?.closest?.("a[href^='#']") as HTMLAnchorElement | null;
      if (!a || a.target || a.hasAttribute("download")) return;
      e.preventDefault();
      const href = a.getAttribute("href")!;
      if (screenOf(href) === screenOf(cur())) return; // mesma tela (ex.: Comentar dentro da publicação): só a ação do próprio botão
      navigate(href);
      window.scrollTo(0, 0);
    },
    true,
  );

  // qualquer mudança de endereço feita por fora (ex.: digitada no navegador) também respeita a regra
  window.addEventListener("hashchange", (e) => {
    if (!(e instanceof HashChangeEvent) || !e.isTrusted) return;
    const old = new URL(e.oldURL).hash || "#feed";
    if (old === cur()) return;
    prev = old;
    depth = 2;
    history.replaceState({ ig: 2, prev } as NavState, "", cur());
  });
}
