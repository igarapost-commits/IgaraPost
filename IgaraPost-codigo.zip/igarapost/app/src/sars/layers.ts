import type { Category } from "../types";
import { SARS } from "./config";

/** Eventos ambientais acompanhados pelo SARS (filtros do mapa e tipos de relato). */
export type EnvEvent = "fumaca" | "queimada" | "enchente";

export const EVENT_ORDER: EnvEvent[] = ["fumaca", "queimada", "enchente"];

export const EVENTS: Record<EnvEvent, { label: string; color: string; icon: string; hint: string }> = {
  fumaca: { label: "Fumaça", color: "#5f6f76", icon: "smoke", hint: "Céu encoberto, cheiro de queimado, olhos ardendo." },
  queimada: { label: "Queimadas", color: "#cf4419", icon: "flame", hint: "Fogo ativo em mata, pasto, roça ou capoeira." },
  enchente: { label: "Enchentes", color: "#1f5fbf", icon: "flood", hint: "Água invadindo casas, ruas ou plantações de forma repentina." },
};

/** Categoria do relato correspondente a cada evento. */
export const EVENT_CATEGORY: Record<EnvEvent, Category> = { fumaca: "fumaca", queimada: "queimada", enchente: "enchente" };

/** Evento correspondente a uma categoria (categorias antigas são agrupadas no evento mais próximo). */
export function categoryEvent(c: Category): EnvEvent | null {
  switch (c) {
    case "fumaca":
    case "queimada":
    case "enchente":
      return c;
    default:
      return null;
  }
}

/** Regra para dizer, a partir de alguns pixels da camada, se o evento aparece perto de um ponto. */
export type SampleRule = "qualquer" | "vermelho";

export interface SarsLayer {
  id: string;
  event: EnvEvent;
  title: string;
  /** identificador da camada na NASA GIBS */
  layer: string;
  /** conjunto de níveis WMTS (define o zoom máximo nativo) e formato do bloco */
  tms: string;
  maxNative: number;
  /** zoom mínimo em que a camada aparece (evita blocos sem dado em escalas pequenas) */
  minZoom?: number;
  ext: "png" | "jpg";
  /** dias de atraso típico da fonte (a data pedida é hoje − lagDays, em UTC) */
  lagDays: number;
  opacity: number;
  source: string;
  sensor: string;
  cadence: string;
  /** cobertura e resolução */
  scale: string;
  legend: { color: string; label: string }[];
  note: string;
  sample?: SampleRule;
}

/** Camadas de imagem da NASA GIBS por evento. As queimadas vêm em pontos da NASA FIRMS (sars/live.ts). */
export const SARS_LAYERS: SarsLayer[] = [
  {
    id: "aerossol",
    event: "fumaca",
    title: "Aerossóis na atmosfera (fumaça)",
    layer: "MODIS_Terra_Aerosol_Optical_Depth_3km",
    tms: "GoogleMapsCompatible_Level6",
    maxNative: 6,
    ext: "png",
    lagDays: 1,
    opacity: 0.6,
    source: "NASA GIBS · MODIS Terra",
    sensor: "óptico",
    cadence: "diária",
    scale: "global, ~3 km",
    legend: [
      { color: "#fff7bc", label: "pouco aerossol" },
      { color: "#fe9929", label: "moderado" },
      { color: "#cc4c02", label: "muito aerossol" },
    ],
    note: "Profundidade óptica de aerossóis. Fumaça de queimadas é a principal causa na Amazônia, mas poeira e poluição também contam. Nuvens deixam falhas.",
  },
  {
    id: "inundacao",
    event: "enchente",
    title: "Áreas inundadas (2 dias)",
    layer: "MODIS_Combined_Flood_2-Day",
    tms: "GoogleMapsCompatible_Level9",
    maxNative: 9,
    ext: "png",
    lagDays: 1,
    opacity: 0.85,
    source: "NASA GIBS · LANCE MODIS Flood",
    sensor: "óptico",
    cadence: "diária",
    scale: "global, ~250 m",
    legend: [
      { color: "#e0301e", label: "água fora do normal (inundação)" },
      { color: "#3bb3e6", label: "água de referência" },
    ],
    note: "Compara a água vista nos últimos 2 dias com a água de referência. Nuvens e sombras escondem áreas; na várzea, parte da inundação é sazonal.",
    sample: "vermelho",
  },
  {
    id: "agua-radar",
    event: "enchente",
    title: "Água superficial por radar (Sentinel-1)",
    layer: "OPERA_L3_Dynamic_Surface_Water_Extent-Sentinel-1",
    tms: "GoogleMapsCompatible_Level12",
    maxNative: 12,
    minZoom: 7,
    ext: "png",
    lagDays: 0,
    opacity: 0.8,
    source: "NASA GIBS · OPERA DSWx-S1",
    sensor: "radar de abertura sintética (SAR), banda C",
    cadence: "passagens a cada 6 a 12 dias",
    scale: "quase global, 30 m",
    legend: [
      { color: "#1550d6", label: "água aberta" },
      { color: "#2fa84f", label: "vegetação alagada" },
    ],
    note: "Produto OPERA (NASA/JPL) feito com o radar Sentinel-1: enxerga através de nuvens. Só há imagem nos dias de passagem do satélite; nos outros dias a camada fica vazia. Aparece a partir do zoom regional (aproxime o mapa).",
  },
];

/** Fundos do mapa: só imagens da NASA. */
export type BaseId = "mundo" | "bluemarble";
export const BASEMAPS: Record<BaseId, { label: string; layer: string; tms: string; maxNative: number; ext: "jpg" | "jpeg"; lagDays?: number; note: string }> = {
  mundo: {
    label: "Satélite do dia",
    layer: "VIIRS_NOAA20_CorrectedReflectance_TrueColor",
    tms: "GoogleMapsCompatible_Level9",
    maxNative: 9,
    ext: "jpg",
    lagDays: 1,
    note: "Cor natural montada todo dia com as passagens do VIIRS (NOAA-20; se faltar, NOAA-21, MODIS Aqua ou Terra), como no NASA Worldview. Mostra o dia anterior completo. O Suomi NPP parou de enviar dados em 2 nov 2026.",
  },
  bluemarble: {
    label: "Blue Marble",
    layer: "BlueMarble_NextGeneration",
    tms: "GoogleMapsCompatible_Level8",
    maxNative: 8,
    ext: "jpeg",
    note: "Composição sem nuvens da NASA; não muda com o tempo.",
  },
};

/** Camadas de referência (litoral, fronteiras e nomes de lugares) servidas pela NASA GIBS. */
export const REFERENCE_LAYERS = [
  { id: "linhas", layer: "Reference_Features_15m", tms: "GoogleMapsCompatible_Level13", maxNative: 13, ext: "png" as const },
  { id: "litoral", layer: "Coastlines_15m", tms: "GoogleMapsCompatible_Level13", maxNative: 13, ext: "png" as const },
  { id: "nomes", layer: "Reference_Labels_15m", tms: "GoogleMapsCompatible_Level13", maxNative: 13, ext: "png" as const },
];

/** Modelo de URL WMTS (REST) da NASA GIBS para o Leaflet: {z}/{y}/{x}. */
export function wmtsUrl(layer: string, tms: string, ext: string, date?: string) {
  return `${SARS.wmtsUrl}/${layer}/default/${date ? date + "/" : ""}${tms}/{z}/{y}/{x}.${ext}`;
}

/** Data UTC (AAAA-MM-DD) pedida a uma camada. */
export function layerDate(lagDays: number, now = Date.now()) {
  return new Date(now - lagDays * 864e5).toISOString().slice(0, 10);
}

/** Bloco WMTS e pixel que contêm um ponto, no nível z. */
export function tileOf(lat: number, lon: number, z: number) {
  const n = 2 ** z * 256;
  const px = ((lon + 180) / 360) * n;
  const r = (lat * Math.PI) / 180;
  const py = ((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2) * n;
  return { px, py, metersPerPx: (40075016.686 * Math.cos(r)) / n };
}
