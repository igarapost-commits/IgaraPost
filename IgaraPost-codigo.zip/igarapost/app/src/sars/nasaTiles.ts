import L from "leaflet";
import { SARS } from "./config";
import { layerDate, wmtsUrl } from "./layers";

/**
 * Fundos e camadas da NASA GIBS com reserva automática.
 *
 * O Suomi NPP deixou de enviar dados em 2 nov 2026, por isso o fundo "do dia" tenta, nesta ordem:
 * VIIRS NOAA-20, VIIRS NOAA-21, MODIS Aqua e MODIS Terra (ontem e anteontem). Se nenhum carregar, usa a
 * Blue Marble da GIBS; sem internet, a Blue Marble guardada no app. Tudo em silêncio, sem aviso na tela.
 */
export const DAILY_BASES = [
  { layer: "VIIRS_NOAA20_CorrectedReflectance_TrueColor", label: "VIIRS NOAA-20" },
  { layer: "VIIRS_NOAA21_CorrectedReflectance_TrueColor", label: "VIIRS NOAA-21" },
  { layer: "MODIS_Aqua_CorrectedReflectance_TrueColor", label: "MODIS Aqua" },
  { layer: "MODIS_Terra_CorrectedReflectance_TrueColor", label: "MODIS Terra" },
];
const BLUE_MARBLE = { layer: "BlueMarble_NextGeneration", tms: "GoogleMapsCompatible_Level8", ext: "jpeg", maxNative: 8 };

/**
 * Blocos pequenos: cada bloco de 256 px da fonte aparece como 128 px na tela (um nível de zoom acima). O mapa
 * vai se completando em quadradinhos, em vez de esperar blocos gigantes, e a imagem fica mais nítida.
 */
export function smallTiles(maxNative: number) {
  return { tileSize: 128, zoomOffset: 1, maxNativeZoom: Math.max(0, maxNative - 1), minNativeZoom: 0, updateWhenZooming: false, keepBuffer: 2 };
}

export type BaseUsed = { kind: "google"; label: string } | { kind: "dia"; label: string; date: string } | { kind: "bluemarble" } | { kind: "offline" };

/**
 * Coloca o fundo no grupo e devolve uma função que o remove.
 *
 * Nada é trocado nem apagado depois de aparecer (a versão anterior trocava a camada inteira quando alguns
 * blocos falhavam, e o mapa ficava preto). Agora:
 *  - por baixo, sempre, a Blue Marble da NASA (e, sem internet, a imagem guardada no app);
 *  - por cima, o satélite do dia; se UM bloco falhar, só esse bloco tenta a próxima fonte
 *    (NOAA-20 → NOAA-21 → MODIS Aqua → MODIS Terra, ontem e anteontem). Se todas falharem, o bloco some e a
 *    Blue Marble de baixo aparece no lugar, em vez de preto.
 */
export function addNasaBase(g: L.LayerGroup, daily: boolean, onUsed: (u: BaseUsed) => void, offlineImage?: { url: string; bounds: [[number, number], [number, number]] }, onReady?: () => void) {
  let readySent = false;
  const ready = () => {
    if (!readySent) {
      readySent = true;
      onReady?.();
    }
  };
  const added: L.Layer[] = [];
  if (offlineImage) added.push(L.imageOverlay(offlineImage.url, offlineImage.bounds, { interactive: false, zIndex: 0, attribution: "NASA Blue Marble (GIBS)" } as object).addTo(g));
  const bm = L.tileLayer(wmtsUrl(BLUE_MARBLE.layer, BLUE_MARBLE.tms, BLUE_MARBLE.ext), { ...smallTiles(BLUE_MARBLE.maxNative), maxZoom: 18, zIndex: 1, attribution: SARS.attribution, crossOrigin: true });
  let bmOk = 0,
    bmErr = 0;
  bm.on("tileload", () => {
    if (!bmOk++ && !daily) onUsed({ kind: "bluemarble" });
  });
  bm.on("tileerror", () => {
    if (++bmErr >= 6 && !bmOk && !daily) {
      onUsed({ kind: "offline" });
      ready();
    }
  });
  bm.on("load", ready);
  added.push(bm.addTo(g));

  if (daily) {
    const chain: { url: string; label: string; date: string }[] = [];
    for (const lag of [1, 2])
      for (const b of DAILY_BASES) {
        // 6 h de folga: o dia "de ontem" em UTC só fica completo algumas horas depois da meia-noite UTC
        const date = new Date(Date.now() - (lag * 24 + 6) * 3600_000).toISOString().slice(0, 10);
        chain.push({ url: wmtsUrl(b.layer, "GoogleMapsCompatible_Level9", "jpg", date), label: b.label, date });
      }
    const top = L.tileLayer(chain[0].url, { ...smallTiles(9), maxZoom: 18, zIndex: 2, attribution: SARS.attribution, crossOrigin: true });
    let ok = 0,
      fails = 0;
    top.on("tileload", (e: { tile: HTMLImageElement }) => {
      const k = Number(e.tile.dataset.k || 0);
      if (!ok++) onUsed({ kind: "dia", label: chain[k].label, date: chain[k].date });
    });
    top.on("tileerror", (e: { tile: HTMLImageElement; coords: { x: number; y: number; z: number } }) => {
      const t = e.tile;
      const k = Number(t.dataset.k || 0) + 1;
      if (k < chain.length) {
        // só este bloco tenta a próxima fonte (coordenadas no nível do pedido: z + 1, por causa dos blocos pequenos)
        const z = e.coords.z + 1,
          n = 2 ** z;
        const x = ((e.coords.x % n) + n) % n;
        t.dataset.k = String(k);
        t.src = L.Util.template(chain[k].url, { z, x, y: e.coords.y });
      } else {
        t.style.visibility = "hidden"; // deixa ver a Blue Marble de baixo
        if (++fails > 20 && !ok) onUsed(bmOk ? { kind: "bluemarble" } : { kind: "offline" });
      }
    });
    top.on("load", ready);
    added.push(top.addTo(g));
  }
  return () => added.forEach((l) => g.removeLayer(l));
}

/* ---------------- detalhe ao aproximar: NASA HLS (Landsat 8/9 e Sentinel-2, 30 m) ---------------- */
/**
 * O satélite do dia (VIIRS) tem ~375 m por pixel: de perto, fica borrado. A partir do zoom HLS_MIN_ZOOM o app põe por
 * cima as imagens em cor natural do HLS (Harmonized Landsat Sentinel-2) da NASA GIBS, com 30 m por pixel.
 * Cada passagem cobre só uma faixa; por isso juntamos os últimos dias, a mais recente por cima. Onde nenhuma passagem
 * cobre (ou o bloco falha), o bloco some e aparece o satélite do dia por baixo.
 */
export const HLS_LAYERS = [
  { layer: "HLS_L30_Nadir_BRDF_Adjusted_Reflectance", label: "Landsat 8/9" },
  { layer: "HLS_S30_Nadir_BRDF_Adjusted_Reflectance", label: "Sentinel-2" },
];
export const HLS_MIN_ZOOM = 10;
export const HLS_ATTR = "Detalhe: NASA HLS (Landsat, Copernicus Sentinel-2)";
/** Datas usadas, da mais antiga para a mais recente (o HLS chega à GIBS 2 a 4 dias depois da passagem). */
export function hlsDates(days = 6, now = Date.now()) {
  const out: string[] = [];
  for (let lag = days + 1; lag >= 2; lag--) out.push(new Date(now - lag * 864e5).toISOString().slice(0, 10));
  return out;
}
export function addHlsDetail(g: L.LayerGroup, opts: { days?: number; onTile?: () => void } = {}) {
  const added: L.Layer[] = [];
  for (const date of hlsDates(opts.days))
    for (const h of HLS_LAYERS) {
      const t = L.tileLayer(wmtsUrl(h.layer, "GoogleMapsCompatible_Level12", "png", date), {
        minZoom: HLS_MIN_ZOOM,
        maxNativeZoom: 12,
        maxZoom: 18,
        zIndex: 3, // acima do satélite do dia (2) e abaixo de todas as camadas de dados (10+)
        crossOrigin: true,
        updateWhenZooming: false,
        keepBuffer: 1,
        attribution: HLS_ATTR,
        className: "hls-tiles",
      });
      t.on("tileerror", (e: { tile: HTMLImageElement }) => void (e.tile.style.visibility = "hidden"));
      if (opts.onTile) t.on("tileload", opts.onTile);
      added.push(t.addTo(g));
    }
  return () => added.forEach((l) => g.removeLayer(l));
}

/* ---------------- NISAR (NASA/ISRO) na NASA GIBS ---------------- */
export const NISAR_LAYER = "NISAR_L2_Geocoded_Polarimetric_Covariance";
const TMS_CANDIDATES = ["GoogleMapsCompatible_Level12", "GoogleMapsCompatible_Level13", "GoogleMapsCompatible_Level11", "GoogleMapsCompatible_Level10", "GoogleMapsCompatible_Level9"];
let nisarTms: Promise<{ tms: string; maxNative: number }> | undefined;
const TMS_KEY = "igarapost:nisar-tms";

/** Testa um bloco com <img>: funciona mesmo quando a resposta de erro não traz cabeçalho CORS. */
function imgOk(url: string, ms = 8000) {
  return new Promise<boolean>((res) => {
    const im = new Image();
    const t = window.setTimeout(() => res(false), ms);
    im.onload = () => {
      window.clearTimeout(t);
      res(im.naturalWidth > 0);
    };
    im.onerror = () => {
      window.clearTimeout(t);
      res(false);
    };
    im.src = url;
  });
}

/**
 * Conjunto de níveis da camada NISAR. Descobre testando blocos sobre a Amazônia em datas recentes e guarda a
 * resposta no aparelho. Nunca bloqueia o mapa: sem resposta, usa o nível 12 (o mesmo das camadas OPERA).
 */
export function nisarTileMatrix(): Promise<{ tms: string; maxNative: number }> {
  if (!nisarTms)
    nisarTms = (async () => {
      const toM = (tms: string) => ({ tms, maxNative: Number(tms.replace(/\D+/g, "")) });
      try {
        const saved = localStorage.getItem(TMS_KEY);
        if (saved) return toM(saved);
      } catch {
        /* sem armazenamento */
      }
      const dates = [3, 8, 14, 20].map((d) => layerDate(d));
      for (const tms of TMS_CANDIDATES) {
        // bloco do nível 3 que cobre a Amazônia central
        const tries = dates.map((d) => imgOk(`${SARS.wmtsUrl}/${NISAR_LAYER}/default/${d}/${tms}/3/4/2.png`));
        if ((await Promise.all(tries)).some(Boolean)) {
          try {
            localStorage.setItem(TMS_KEY, tms);
          } catch {
            /* ok */
          }
          return toM(tms);
        }
      }
      return toM(TMS_CANDIDATES[0]);
    })();
  return nisarTms;
}

/** Início dos dados do NISAR (lançamento em 30 jul 2025). Antes disso não há imagem. */
export const NISAR_START = "2025-07-30";

/** Dias (AAAA-MM-DD) de uma janela que termina em `end`: o NISAR repete a mesma órbita a cada 12 dias. */
export function windowDays(end: string, days = 12) {
  const t = Date.parse(end + "T12:00:00Z");
  return Array.from({ length: days }, (_, k) => new Date(t - (days - 1 - k) * 864e5).toISOString().slice(0, 10)).filter((d) => Date.parse(d) <= Date.now() && d >= NISAR_START);
}

/** Camadas de uma janela de 12 dias (a passagem mais recente fica por cima), como o mosaico do Worldview. */
export function nisarWindowLayers(end: string, m: { tms: string; maxNative: number }, opts: { pane?: string; opacity?: number } = {}) {
  return windowDays(end).map((d, k) =>
    L.tileLayer(wmtsUrl(NISAR_LAYER, m.tms, "png", d), {
      ...smallTiles(m.maxNative),
      maxZoom: 18,
      opacity: opts.opacity ?? 1,
      pane: opts.pane ?? "overlayPane",
      zIndex: 20 + k,
      crossOrigin: true,
      attribution: "Radar: NASA/ISRO NISAR (GCOV provisório), NASA GIBS",
    }),
  );
}

/* ---------------- camada de mudança calculada no aparelho ---------------- */
const CHANGE = { escureceu: [40, 200, 230], clareou: [230, 120, 20], agua: [30, 90, 160] } as const;

async function compositeTile(url: (d: string) => string, days: string[]): Promise<ImageData | null> {
  const c = document.createElement("canvas");
  c.width = c.height = 256;
  const g = c.getContext("2d", { willReadFrequently: true })!;
  let any = false;
  // a passagem mais recente fica por cima, como no mosaico do Worldview
  const imgs = await Promise.all(
    days.map(async (d) => {
      try {
        const r = await fetch(url(d));
        if (!r.ok) return null;
        const b = await r.blob();
        return b.type.startsWith("image/") ? await createImageBitmap(b) : null;
      } catch {
        return null;
      }
    }),
  );
  for (const im of imgs)
    if (im) {
      g.drawImage(im, 0, 0, 256, 256);
      any = true;
    }
  return any ? g.getImageData(0, 0, 256, 256) : null;
}

/**
 * Camada de mudança entre duas janelas de 12 dias do NISAR, calculada no próprio aparelho bloco a bloco:
 * escuro no radar (água parada ou superfície lisa) que surgiu, sumiu ou ficou. É uma leitura visual da imagem
 * em cor falsa, sem valores calibrados.
 */
export function nisarChangeLayer(endA: string, endB: string, m: { tms: string; maxNative: number }, opts: { pane?: string; bounds?: [[number, number], [number, number]]; onProgress?: (done: number, total: number) => void } = {}) {
  const daysA = windowDays(endA),
    daysB = windowDays(endB);
  let total = 0,
    done = 0;
  const Grid = (L.GridLayer as unknown as { extend: (o: object) => new (o: object) => L.Layer }).extend({
    createTile(coords: { x: number; y: number; z: number }, cb: (e: Error | null, t: HTMLElement) => void) {
      const tile = document.createElement("canvas");
      tile.width = tile.height = 256;
      total++;
      opts.onProgress?.(done, total);
      const url = (d: string) => `${SARS.wmtsUrl}/${NISAR_LAYER}/default/${d}/${m.tms}/${coords.z}/${coords.y}/${coords.x}.png`;
      void Promise.all([compositeTile(url, daysA), compositeTile(url, daysB)]).then(([a, b]) => {
        if (a && b) {
          const out = tile.getContext("2d")!.createImageData(256, 256);
          const dark = (d: Uint8ClampedArray, i: number) => 0.3 * d[i] + 0.59 * d[i + 1] + 0.11 * d[i + 2] < 45;
          for (let i = 0; i < out.data.length; i += 4) {
            if (a.data[i + 3] < 40 || b.data[i + 3] < 40) continue;
            const da = dark(a.data, i),
              db = dark(b.data, i);
            const col = !da && db ? CHANGE.escureceu : da && !db ? CHANGE.clareou : da && db ? CHANGE.agua : null;
            if (!col) continue;
            out.data[i] = col[0];
            out.data[i + 1] = col[1];
            out.data[i + 2] = col[2];
            out.data[i + 3] = 220;
          }
          tile.getContext("2d")!.putImageData(out, 0, 0);
        }
        done++;
        opts.onProgress?.(done, total);
        cb(null, tile);
      });
      return tile;
    },
  });
  return new Grid({ maxNativeZoom: m.maxNative, minZoom: 5, maxZoom: 18, pane: opts.pane ?? "overlayPane", bounds: opts.bounds, attribution: "Mudança calculada no aparelho a partir do NISAR (NASA/ISRO), NASA GIBS" });
}
