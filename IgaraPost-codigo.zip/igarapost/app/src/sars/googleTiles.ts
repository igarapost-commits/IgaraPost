import { LOCALE } from "../i18n/lang";
import L from "leaflet";
import { getState } from "../store";
import { addNasaBase, type BaseUsed } from "./nasaTiles";

/**
 * Fundo do Google Maps pela Map Tiles API oficial (2D tiles), com as camadas da NASA por cima.
 *
 * - Precisa de uma chave da Google Maps Platform com a "Map Tiles API" ativada: VITE_GOOGLE_MAPS_KEY no build
 *   ou Perfil › Configurações › Mapa do Google (fica só no aparelho).
 * - Cada tipo de mapa usa uma sessão (createSession), guardada no aparelho até expirar.
 * - As regras do Google exigem mostrar "Google Maps" e o copyright dos dados da área visível; isso é feito na
 *   atribuição do mapa e atualizado a cada movimento (rota viewport).
 */
export type GoogleType = "satellite" | "roadmap";
const API = "https://tile.googleapis.com";
const env = (import.meta.env ?? {}) as ImportMetaEnv;

export function googleKey(): string {
  return (getState().prefs.googleKey || (env.VITE_GOOGLE_MAPS_KEY as string | undefined) || "").trim();
}

type Session = { session: string; expiry: number };
const cacheKey = (key: string, t: GoogleType) => `igarapost:gmaps:${t}:${key.slice(-6)}`;

/** Cria (ou reaproveita) a sessão do tipo de mapa. Lança erro com mensagem legível se a chave não servir. */
export async function googleSession(key: string, type: GoogleType): Promise<Session> {
  try {
    const c = JSON.parse(localStorage.getItem(cacheKey(key, type)) || "null") as Session | null;
    if (c && c.expiry * 1000 > Date.now() + 3600_000) return c;
  } catch {
    /* sem armazenamento */
  }
  const body: Record<string, unknown> = { mapType: type, language: LOCALE, region: "BR" };
  if (type === "satellite") body.layerTypes = ["layerRoadmap"]; // satélite com nomes e ruas, como o "híbrido" do Google Maps
  const r = await fetch(`${API}/v1/createSession?key=${encodeURIComponent(key)}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const j = (await r.json().catch(() => ({}))) as { session?: string; expiry?: string | number; error?: { message?: string } };
  if (!r.ok || !j.session) throw new Error(j.error?.message || `HTTP ${r.status}`);
  const s = { session: j.session, expiry: Number(j.expiry) || Date.now() / 1000 + 86400 };
  try {
    localStorage.setItem(cacheKey(key, type), JSON.stringify(s));
  } catch {
    /* ok */
  }
  return s;
}

/**
 * Coloca o fundo do Google no grupo. Chama `onFail` se a chave ou a sessão não funcionarem (o chamador usa
 * então o fundo da NASA). Devolve uma função que remove o fundo e a atribuição.
 */
export function addGoogleBase(map: L.Map, g: L.LayerGroup, type: GoogleType, cb: { onUsed: () => void; onReady: () => void; onFail: (msg: string) => void }) {
  const key = googleKey();
  let dead = false;
  let layer: L.Layer | undefined;
  let copyright = "";
  let timer: number | undefined;
  const attr = map.attributionControl;
  const setAttr = (txt: string) => {
    if (copyright) attr.removeAttribution(copyright);
    copyright = txt;
    if (copyright) attr.addAttribution(copyright);
  };
  if (!key) {
    cb.onFail("sem chave");
    return () => void 0;
  }
  void googleSession(key, type)
    .then((s) => {
      if (dead) return;
      const q = `session=${encodeURIComponent(s.session)}&key=${encodeURIComponent(key)}`;
      const t = L.tileLayer(`${API}/v1/2dtiles/{z}/{x}/{y}?${q}`, { maxZoom: 18, maxNativeZoom: type === "satellite" ? 18 : 18, zIndex: 1, updateWhenZooming: false, keepBuffer: 2 });
      let ok = 0,
        err = 0;
      t.on("tileload", () => {
        if (!ok++) cb.onUsed();
      });
      t.on("tileerror", () => {
        if (++err >= 4 && !ok && !dead) {
          g.removeLayer(t);
          try {
            localStorage.removeItem(cacheKey(key, type));
          } catch {
            /* ok */
          }
          cb.onFail("os blocos do Google não carregaram");
        }
      });
      t.on("load", cb.onReady);
      layer = t.addTo(g);
      // "Google Maps" + copyright dos dados da área visível (exigência da Map Tiles API)
      attr.setPrefix('<span class="gmaps-logo" role="img" aria-label="Google Maps">Google Maps</span>');
      const upd = () => {
        window.clearTimeout(timer);
        timer = window.setTimeout(async () => {
          const b = map.getBounds();
          const u = `${API}/tile/v1/viewport?${q}&zoom=${Math.round(map.getZoom())}&north=${b.getNorth().toFixed(4)}&south=${b.getSouth().toFixed(4)}&east=${Math.min(180, b.getEast()).toFixed(4)}&west=${Math.max(-180, b.getWest()).toFixed(4)}`;
          try {
            const r = await fetch(u);
            const j = (await r.json()) as { copyright?: string };
            if (!dead && j.copyright) setAttr(j.copyright);
          } catch {
            if (!dead) setAttr(type === "satellite" ? "Imagens e dados do mapa: Google" : "Dados do mapa: Google");
          }
        }, 400);
      };
      map.on("moveend", upd);
      upd();
      cleanupFns.push(() => map.off("moveend", upd));
    })
    .catch((e: Error) => !dead && cb.onFail(e.message));
  const cleanupFns: (() => void)[] = [];
  return () => {
    dead = true;
    window.clearTimeout(timer);
    cleanupFns.forEach((f) => f());
    if (layer) g.removeLayer(layer);
    setAttr("");
    attr.setPrefix(false);
  };
}

/** Testa uma chave (Perfil › Configurações). */
export async function testGoogleKey(key: string) {
  await googleSession(key.trim(), "satellite");
}

/** Fundos do app: Google (padrão, com chave) e os da NASA (reserva, ou escolha da pessoa). */
export type AppBase = "google" | "google-mapa" | "mundo" | "bluemarble";
export const APP_BASES: Record<AppBase, { label: string; note: string }> = {
  google: { label: "Google Satélite", note: "Imagem de satélite do Google Maps com nomes de ruas e lugares (Map Tiles API)." },
  "google-mapa": { label: "Google Mapa", note: "Mapa de ruas do Google Maps (Map Tiles API)." },
  bluemarble: { label: "NASA · Blue Marble", note: "Composição sem nuvens da NASA (padrão do app); não muda com o tempo." },
  mundo: { label: "NASA · satélite do dia", note: "Cor natural do dia anterior (VIIRS NOAA-20, com reservas), como no NASA Worldview." },
};

/**
 * Põe o fundo escolhido. Com o Google sem chave ou com erro, cai em silêncio para o fundo da NASA e avisa
 * `onGoogleFail` (o motivo aparece em Camadas e em Configurações, não sobre o mapa).
 */
export function addAppBase(map: L.Map, g: L.LayerGroup, kind: AppBase, onUsed: (u: BaseUsed) => void, onReady: () => void, onGoogleFail?: (msg: string) => void) {
  let gClean: (() => void) | undefined, nClean: (() => void) | undefined;
  const nasa = () => {
    gClean?.();
    nClean = addNasaBase(g, kind !== "bluemarble", onUsed, undefined, onReady);
  };
  if (kind === "google" || kind === "google-mapa") {
    gClean = addGoogleBase(map, g, kind === "google" ? "satellite" : "roadmap", {
      onUsed: () => onUsed({ kind: "google", label: APP_BASES[kind].label }),
      onReady,
      onFail: (m) => {
        onGoogleFail?.(m);
        nasa();
      },
    });
  } else nasa();
  return () => {
    gClean?.();
    nClean?.();
  };
}
