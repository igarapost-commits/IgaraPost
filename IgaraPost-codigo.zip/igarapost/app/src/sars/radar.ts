import type { Category, RadarCheck, RadarStatus } from "../types";
import { distKm, fmtDate, type CemadenFile } from "../data";
import { SARS } from "./config";
import { categoryEvent, layerDate, SARS_LAYERS, tileOf, type SampleRule, type SarsLayer } from "./layers";
import type { LiveFire } from "./inpeCsv";

/**
 * Confere se um evento relatado já aparece nos dados do SARS perto do ponto e da data da observação.
 *
 *  no_radar        = o SARS já mostra algo compatível (o relato confirma o que os satélites viram)
 *  fora_do_radar   = o SARS foi consultado e não mostra nada ali: o relato preenche uma lacuna
 *  nao_verificado  = não foi possível conferir (sem conexão, fonte sem dado pontual, fora da cobertura)
 *  confirmado      = estava fora do radar e, numa nova conferência, o SARS passou a mostrar o evento
 *
 * Nenhum desses estados verifica o relato: "fora do radar" não quer dizer que o relato esteja errado,
 * e "no radar" não quer dizer que a pessoa viu exatamente o que o satélite detectou.
 */
export interface RadarInput {
  category: Category;
  lat: number;
  lon: number;
  observedAt: string;
}
export interface RadarContext {
  fires: LiveFire[];
  liveOk: boolean;
  cemaden?: CemadenFile;
  cemadenFailed?: boolean;
}

/** Área coberta pelos arquivos da NASA FIRMS usados no app (América do Sul). */
const FIRMS_BOX = { s: -57, n: 14, w: -83, e: -33 };
const inFirms = (lat: number, lon: number) => lat >= FIRMS_BOX.s && lat <= FIRMS_BOX.n && lon >= FIRMS_BOX.w && lon <= FIRMS_BOX.e;

export const RADAR_LABEL: Record<RadarStatus, string> = {
  no_radar: `Já aparece no ${SARS.name}`,
  fora_do_radar: `Fora do radar do ${SARS.name}`,
  nao_verificado: "Conferência indisponível",
  confirmado: `Confirmado depois pelo ${SARS.name}`,
};

/** Lê os pixels de uma camada WMTS da NASA GIBS num raio ao redor do ponto (no nível nativo da camada). */
export async function sampleLayer(l: SarsLayer, time: string, lat: number, lon: number, radiusM: number, rule: SampleRule): Promise<boolean> {
  const z = l.maxNative;
  const { px, py, metersPerPx } = tileOf(lat, lon, z);
  const rPx = Math.max(1, Math.min(256, radiusM / metersPerPx));
  const tx0 = Math.floor((px - rPx) / 256),
    tx1 = Math.floor((px + rPx) / 256),
    ty0 = Math.floor((py - rPx) / 256),
    ty1 = Math.floor((py + rPx) / 256);
  const base = `${SARS.wmtsUrl}/${l.layer}/default/${time}/${l.tms}`;
  for (let ty = ty0; ty <= ty1; ty++)
    for (let tx = tx0; tx <= tx1; tx++) {
      const ctl = new AbortController();
      const timer = window.setTimeout(() => ctl.abort(), 12_000);
      try {
        const r = await fetch(`${base}/${z}/${ty}/${tx}.${l.ext}`, { signal: ctl.signal });
        if (r.status === 404) continue; // sem imagem nesse bloco/data
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const blob = await r.blob();
        if (!blob.type.startsWith("image/")) throw new Error("a fonte não devolveu imagem");
        const bmp = await createImageBitmap(blob);
        const c = document.createElement("canvas");
        c.width = bmp.width;
        c.height = bmp.height;
        const g = c.getContext("2d")!;
        g.drawImage(bmp, 0, 0);
        const d = g.getImageData(0, 0, c.width, c.height).data;
        const k = c.width / 256;
        for (let y = 0; y < c.height; y++)
          for (let x = 0; x < c.width; x++) {
            const gx = tx * 256 + x / k,
              gy = ty * 256 + y / k;
            if ((gx - px) ** 2 + (gy - py) ** 2 > rPx * rPx) continue;
            const i = (y * c.width + x) * 4;
            const [R, G, B, A] = [d[i], d[i + 1], d[i + 2], d[i + 3]];
            if (A < 60) continue;
            if (rule === "qualquer") return true;
            if (rule === "vermelho" && R > 170 && G < 110 && B < 110) return true;
          }
      } finally {
        window.clearTimeout(timer);
      }
    }
  return false;
}

const layerOf = (id: string) => SARS_LAYERS.find((l) => l.id === id)!;
const iso = (t: number) => new Date(t).toISOString();

export async function radarCheck(inp: RadarInput, ctx: RadarContext): Promise<RadarCheck> {
  const now = Date.now();
  const at = iso(now);
  const ev = categoryEvent(inp.category);
  const obs = Date.parse(inp.observedAt);
  const out = (status: RadarStatus, detail: string, evidence?: RadarCheck["evidence"]): RadarCheck => ({ status, detail, checkedAt: at, evidence });
  if (!ev) return out("nao_verificado", `O ${SARS.name} não tem uma camada para esse tipo de ocorrência. O relato fica registrado para a equipe.`);

  /* ---- fogo e fumaça: focos de fogo ativo da NASA FIRMS (VIIRS, últimas 48 h) ---- */
  if (ev === "queimada" || ev === "fumaca") {
    const radius = ev === "queimada" ? 5 : 30;
    const [a, b] = [obs - 24 * 3600_000, obs + 24 * 3600_000];
    if (!inFirms(inp.lat, inp.lon)) return out("nao_verificado", "O ponto fica fora da área dos focos da NASA FIRMS usados no app (América do Sul).");
    if (b < now - SARS.liveWindowMs) return out("nao_verificado", "Os focos da NASA FIRMS no app cobrem só as últimas 48 h; essa observação é mais antiga.");
    if (!ctx.liveOk) return out("nao_verificado", "Sem conexão com a NASA FIRMS agora. O relato pode ser enviado; a conferência é refeita em Perfil › Meus relatos.");
    const near = ctx.fires.filter((f) => f.t >= a && f.t <= b).map((f) => distKm(inp.lat, inp.lon, f.lat, f.lon)).filter((d) => d <= radius);
    if (near.length)
      return out("no_radar", `${near.length} foco(s) de fogo ativo (NASA FIRMS, VIIRS) a até ${radius} km, entre ${fmtDate(a, true)} e ${fmtDate(Math.min(b, now), true)} (o mais perto a ${Math.min(...near).toFixed(1)} km).`, {
        kind: "focos",
        n: near.length,
        nearestKm: Math.round(Math.min(...near) * 10) / 10,
      });
    return out(
      "fora_do_radar",
      ev === "queimada"
        ? `Nenhum foco de fogo ativo da NASA a até ${radius} km nas 24 h antes e depois da observação. Fogo pequeno, rasteiro ou sob nuvens costuma escapar dos satélites: seu relato é a única fonte aqui.`
        : `Nenhum foco de fogo ativo da NASA a até ${radius} km perto da data. A fumaça pode vir de longe ou de fogo não detectado: seu relato ajuda a entender de onde ela vem.`,
      { kind: "focos", n: 0 },
    );
  }

  /* ---- enchente: produto de inundação ---- */
  {
    const fl = layerOf("inundacao");
    try {
      const dates = [...new Set([layerDate(0, obs), layerDate(-1, obs)].filter((d) => Date.parse(d) <= now))];
      for (const d of dates) {
        if (await sampleLayer(fl, d, inp.lat, inp.lon, 3000, "vermelho"))
          return out("no_radar", `O produto de inundação (MODIS, 2 dias) marca água fora do normal a até 3 km em ${fmtDate(d + "T12:00:00")}.`, { kind: "imagem", layer: fl.layer, date: d });
      }
      return out(
        "fora_do_radar",
        `O produto de inundação não marca água fora do normal a até 3 km nessa data. Nuvens, mata fechada e áreas pequenas escondem enchentes dos satélites ópticos: seu relato registra o que eles não viram.`,
      );
    } catch {
      return out("nao_verificado", "Não foi possível consultar a camada de inundação agora. O relato pode ser enviado; a conferência é refeita em Perfil › Meus relatos.");
    }
  }

}

/** Estado depois de conferir de novo: "fora do radar" que passou a aparecer vira "confirmado". */
export function recheckStatus(prev: RadarCheck | undefined, now: RadarCheck): RadarCheck {
  if (!prev) return now;
  if ((prev.status === "fora_do_radar" || prev.status === "confirmado") && now.status === "no_radar") return { ...now, status: "confirmado", firstCheck: prev.firstCheck ?? prev };
  if (prev.status === "confirmado") return prev; // uma confirmação não volta atrás por falta de dado novo
  if (now.status === "nao_verificado" && prev.status !== "nao_verificado") return { ...prev, recheckedAt: now.checkedAt };
  return { ...now, firstCheck: prev.firstCheck ?? prev };
}
