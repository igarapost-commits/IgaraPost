/**
 * Regiões geográficas da floresta amazônica (Brasil) usadas no "Estudo de Região" do Explorador NISAR.
 * Retângulos aproximados (oeste, sul, leste, norte), traçados pelos grandes rios e eixos de ocupação.
 */
export interface AmazonRegion {
  id: string;
  name: string;
  /** [oeste, sul, leste, norte] em graus */
  bbox: [number, number, number, number];
  note: string;
}

export const AMAZON_REGIONS: AmazonRegion[] = [
  { id: "manaus", name: "Manaus e Baixo Rio Negro (AM)", bbox: [-61.2, -4.2, -58.4, -2.4], note: "Encontro dos rios Negro e Solimões, várzeas do Careiro e de Autazes." },
  { id: "alto-negro", name: "Alto Rio Negro (AM)", bbox: [-68.5, -1.5, -63.0, 2.0], note: "Rio Negro acima de Barcelos, São Gabriel da Cachoeira." },
  { id: "alto-solimoes", name: "Alto Solimões (AM)", bbox: [-70.5, -5.0, -64.0, -2.0], note: "Tabatinga, Fonte Boa e Tefé." },
  { id: "purus", name: "Médio Solimões e Purus (AM)", bbox: [-66.5, -8.0, -61.0, -3.5], note: "Coari, Lábrea e o baixo Purus." },
  { id: "madeira", name: "Rio Madeira (AM/RO)", bbox: [-65.5, -10.5, -60.0, -5.5], note: "Humaitá, Manicoré e Porto Velho." },
  { id: "baixo-amazonas", name: "Baixo Amazonas (AM/PA)", bbox: [-58.5, -3.5, -53.5, -1.0], note: "Parintins, Óbidos e Santarém." },
  { id: "tapajos", name: "Tapajós (PA)", bbox: [-58.0, -8.5, -54.0, -3.5], note: "Itaituba e o vale do Tapajós." },
  { id: "xingu", name: "Xingu (PA)", bbox: [-55.0, -8.5, -51.0, -3.0], note: "Altamira e São Félix do Xingu." },
  { id: "sul-para", name: "Sul e Sudeste do Pará", bbox: [-52.5, -9.5, -48.0, -4.5], note: "Marabá, Parauapebas e Redenção." },
  { id: "marajo", name: "Marajó e Belém (PA)", bbox: [-51.5, -2.5, -47.5, 1.0], note: "Foz do Amazonas e estuário." },
  { id: "amapa", name: "Amapá", bbox: [-55.0, -1.0, -50.0, 4.5], note: "Macapá e o norte do estuário." },
  { id: "roraima", name: "Roraima", bbox: [-64.5, 0.0, -59.5, 5.0], note: "Boa Vista e o rio Branco." },
  { id: "acre", name: "Acre", bbox: [-74.0, -11.2, -66.5, -7.0], note: "Rio Branco, Cruzeiro do Sul e o Juruá." },
  { id: "rondonia", name: "Rondônia", bbox: [-66.0, -13.7, -60.0, -8.0], note: "Arco do desmatamento, BR-364." },
  { id: "norte-mt", name: "Norte de Mato Grosso", bbox: [-61.0, -13.0, -50.5, -8.5], note: "Sinop, Alta Floresta e o Xingu mato-grossense." },
];

export const regionBounds = (r: AmazonRegion): [[number, number], [number, number]] => [
  [r.bbox[1], r.bbox[0]],
  [r.bbox[3], r.bbox[2]],
];
export const inRegion = (r: AmazonRegion, lat: number, lon: number) => lon >= r.bbox[0] && lon <= r.bbox[2] && lat >= r.bbox[1] && lat <= r.bbox[3];
