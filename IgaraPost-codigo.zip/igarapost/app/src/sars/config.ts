/**
 * Provedor "SARS": um único lugar para dizer de onde vêm o mapa-múndi e os dados ambientais em tempo real.
 * Desde a 0.3.3 o mapa usa SOMENTE dados da NASA:
 *  - NASA GIBS (WMTS, EPSG:3857, o mesmo serviço do NASA Worldview): fundo em cor natural do dia (VIIRS),
 *    Blue Marble, litoral, fronteiras e nomes, e as camadas de fumaça (aerossol MODIS) e enchentes (MODIS Flood e
 *    água por radar OPERA DSWx-S1);
 *  - NASA FIRMS: focos de fogo ativo do VIIRS (NOAA-20 e NOAA-21) das últimas 48 h, quase em tempo real.
 * Para apontar para outro provedor, defina as variáveis VITE_SARS_* no build.
 */
const env = (import.meta.env ?? {}) as ImportMetaEnv;

export const SARS = {
  /** nome mostrado na interface */
  name: (env.VITE_SARS_NAME as string | undefined) || "SARS",
  /** descrição curta, usada no "Sobre" e na legenda */
  description: "Sistema de Acompanhamento por Radar e Satélite: imagens e camadas da NASA (GIBS, as mesmas do NASA Worldview) e focos de fogo ativo da NASA FIRMS.",
  /** WMTS (REST) das camadas globais */
  wmtsUrl: (env.VITE_SARS_WMTS_URL as string | undefined) || "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best",
  /** atribuição exigida pelas fontes */
  attribution: 'Imagens: <a href="https://earthdata.nasa.gov/gibs" target="_blank" rel="noreferrer">NASA GIBS</a> · Focos: <a href="https://firms.modaps.eosdis.nasa.gov" target="_blank" rel="noreferrer">NASA FIRMS</a>',
  /**
   * Endereço de um serviço de tempo real próprio (rotas /api/live/*, como o de server/). Vazio = o app lê os
   * arquivos da NASA FIRMS diretamente (padrão da IgaraPost 10).
   */
  liveUrl: (env.VITE_SARS_LIVE_URL as string | undefined) || "",
  /** arquivos CSV da NASA FIRMS (sem chave), América do Sul, últimas 48 h */
  firmsCsv: ((env.VITE_SARS_FIRMS_CSV as string | undefined) || "https://firms.modaps.eosdis.nasa.gov/data/active_fire/noaa-20-viirs-c2/csv/J1_VIIRS_C2_South_America_48h.csv,https://firms.modaps.eosdis.nasa.gov/data/active_fire/noaa-21-viirs-c2/csv/J2_VIIRS_C2_South_America_48h.csv").split(","),
  /** intervalo de consulta quando não há SSE */
  pollMs: 10 * 60_000,
  /** de quanto em quanto tempo as camadas de imagem são recarregadas (as fontes atualizam ao longo do dia) */
  tileRefreshMs: 30 * 60_000,
  /** janela de tempo dos focos ao vivo */
  liveWindowMs: 48 * 3600_000,
  /** dados mais antigos que isso aparecem como "atrasados" */
  staleMs: 30 * 60_000,
} as const;
