import React from "react";
import { Capacitor, CapacitorHttp } from "@capacitor/core";
import { normalizeUrl } from "../api";
import { SARS } from "./config";
import { mergeFires, parseInpeCsv, type LiveFire } from "./inpeCsv";

/**
 * Dados em tempo real do SARS (focos de calor). Um único canal para o app inteiro:
 *
 *  1. com servidor de tempo real (SARS.liveUrl): SSE em /api/live/stream;
 *     se o SSE falhar três vezes seguidas, troca para polling de /api/live/fires e tenta o SSE de novo
 *     depois de alguns minutos;
 *  2. sem servidor: leitura direta dos CSV da NASA FIRMS a cada SARS.pollMs (funciona no APK, onde o
 *     HTTP nativo não sofre bloqueio de CORS; no navegador a NASA pode recusar).
 *
 * O canal só fica ligado enquanto alguma tela usa os dados (useLive) e pausa com o app em segundo plano.
 */
export type LiveMode = "desligado" | "conectando" | "ao_vivo" | "polling" | "direto" | "falha";

export interface LiveState {
  mode: LiveMode;
  fires: LiveFire[];
  /** última vez que o app recebeu dados com sucesso */
  receivedAt?: number;
  /** última vez que a fonte (NASA FIRMS) foi lida pelo servidor */
  sourceAt?: number;
  /** foco mais recente nos dados */
  lastFireAt?: number;
  /** focos que chegaram na última atualização (para destacar no mapa) */
  freshIds: string[];
  error?: string;
  source: string;
}

type ServerFires = { fires: LiveFire[]; sourceAt?: string; source?: string; error?: string };

let st: LiveState = { mode: "desligado", fires: [], freshIds: [], source: "NASA FIRMS (VIIRS NOAA-20 e NOAA-21)" };
const subs = new Set<() => void>();
const emit = () => subs.forEach((f) => f());
const patch = (p: Partial<LiveState>) => {
  st = { ...st, ...p };
  emit();
};

let users = 0;
let es: EventSource | undefined;
let pollTimer: number | undefined;
let sseRetryTimer: number | undefined;
let stopTimer: number | undefined;
let sseFails = 0;

// a rede compartilhada (Supabase) não tem as rotas /api/live: sem VITE_SARS_LIVE_URL, lê a NASA FIRMS direto
const base = () => normalizeUrl(SARS.liveUrl || "");

function apply(incoming: LiveFire[], meta: { sourceAt?: string; source?: string; replace?: boolean }) {
  const before = new Set(st.fires.map((f) => f.id));
  const fires = mergeFires(meta.replace ? [] : st.fires, incoming, SARS.liveWindowMs);
  const freshIds = st.fires.length ? fires.filter((f) => !before.has(f.id)).map((f) => f.id) : [];
  patch({
    fires,
    freshIds,
    receivedAt: Date.now(),
    sourceAt: meta.sourceAt ? Date.parse(meta.sourceAt) : st.sourceAt,
    lastFireAt: fires[0]?.t,
    source: meta.source || st.source,
    error: undefined,
  });
}

/* ---------------- 1. servidor: SSE ---------------- */
function openSse(b: string) {
  closeSse();
  if (typeof EventSource === "undefined") return startPolling(b);
  patch({ mode: st.fires.length ? st.mode : "conectando" });
  es = new EventSource(`${b}/api/live/stream`);
  es.addEventListener("snapshot", (e) => {
    sseFails = 0;
    const d = JSON.parse((e as MessageEvent).data) as ServerFires;
    apply(d.fires, { sourceAt: d.sourceAt, source: d.source, replace: true });
    patch({ mode: "ao_vivo", error: d.error });
  });
  es.addEventListener("fires", (e) => {
    const d = JSON.parse((e as MessageEvent).data) as ServerFires;
    apply(d.fires, { sourceAt: d.sourceAt, source: d.source });
    patch({ mode: "ao_vivo" });
  });
  es.addEventListener("status", (e) => {
    const d = JSON.parse((e as MessageEvent).data) as { sourceAt?: string; error?: string };
    patch({ sourceAt: d.sourceAt ? Date.parse(d.sourceAt) : st.sourceAt, error: d.error, receivedAt: Date.now() });
  });
  es.onerror = () => {
    sseFails++;
    if (sseFails >= 3) {
      closeSse();
      startPolling(b);
      window.clearTimeout(sseRetryTimer);
      sseRetryTimer = window.setTimeout(() => users > 0 && openSse(b), 5 * 60_000);
    }
  };
}
function closeSse() {
  es?.close();
  es = undefined;
}

/* ---------------- 1b. servidor: polling ---------------- */
async function pollServer(b: string) {
  try {
    const since = st.fires.length ? `?since=${new Date(st.fires[0].t - 6 * 3600_000).toISOString()}` : "";
    const r = await fetch(`${b}/api/live/fires${since}`, { cache: "no-store" });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const d = (await r.json()) as ServerFires;
    apply(d.fires, { sourceAt: d.sourceAt, source: d.source, replace: !since });
    patch({ mode: "polling", error: d.error });
  } catch (e) {
    patch({ mode: st.fires.length ? "polling" : "falha", error: `Servidor de tempo real indisponível (${(e as Error).message}).` });
  }
}
function startPolling(b: string) {
  window.clearInterval(pollTimer);
  void pollServer(b);
  pollTimer = window.setInterval(() => void pollServer(b), SARS.pollMs);
}

/* ---------------- 2. sem servidor: NASA FIRMS direto ---------------- */
/** No APK usa o HTTP nativo (sem bloqueio de CORS); no navegador, fetch comum. */
async function getText(url: string): Promise<string> {
  if (Capacitor.isNativePlatform()) {
    const r = await CapacitorHttp.get({ url, responseType: "text", connectTimeout: 15000, readTimeout: 60000 });
    if (r.status < 200 || r.status >= 300) throw new Error(`HTTP ${r.status}`);
    return typeof r.data === "string" ? r.data : String(r.data);
  }
  const r = await fetch(url, { cache: "no-store" });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.text();
}
async function pollDirect() {
  const results = await Promise.allSettled(SARS.firmsCsv.map(async (u) => parseInpeCsv(await getText(u))));
  const ok = results.filter((r): r is PromiseFulfilledResult<LiveFire[]> => r.status === "fulfilled");
  if (!ok.length) {
    const reason = (results[0] as PromiseRejectedResult).reason as Error;
    return patch({
      mode: "falha",
      error:
        reason instanceof TypeError
          ? "A NASA FIRMS não permite a leitura direta por este navegador. No APK ela funciona."
          : `Não foi possível ler os focos da NASA FIRMS (${reason.message}).`,
    });
  }
  apply(
    ok.flatMap((r) => r.value),
    { sourceAt: new Date().toISOString(), source: "NASA FIRMS (VIIRS NOAA-20 e NOAA-21)" },
  );
  patch({ mode: "direto" });
}

/* ---------------- ciclo de vida ---------------- */
function connect() {
  const b = base();
  window.clearInterval(pollTimer);
  closeSse();
  sseFails = 0;
  if (b) openSse(b);
  else {
    patch({ mode: st.fires.length ? st.mode : "conectando" });
    void pollDirect();
    pollTimer = window.setInterval(() => void pollDirect(), SARS.pollMs);
  }
}
function disconnect() {
  closeSse();
  window.clearInterval(pollTimer);
  window.clearTimeout(sseRetryTimer);
  patch({ mode: "desligado" });
}

let lifecycleBound = false;
function bindLifecycle() {
  if (lifecycleBound) return;
  lifecycleBound = true;
  document.addEventListener("visibilitychange", () => {
    if (!users) return;
    if (document.visibilityState === "hidden") disconnect();
    else connect();
  });
  window.addEventListener("online", () => users && connect());
}

/** Atualiza agora (botão "Atualizar" do mapa). */
export function refreshLive() {
  if (users) connect();
}

export function getLive() {
  return st;
}

/** Liga o canal enquanto o componente estiver montado e devolve o estado atual. */
export function useLive(enabled = true): LiveState {
  React.useEffect(() => {
    if (!enabled) return;
    bindLifecycle();
    window.clearTimeout(stopTimer);
    if (users++ === 0 && st.mode === "desligado") connect();
    return () => {
      if (--users === 0) stopTimer = window.setTimeout(disconnect, 60_000);
    };
  }, [enabled]);
  return React.useSyncExternalStore(
    (cb) => {
      subs.add(cb);
      return () => subs.delete(cb);
    },
    () => st,
  );
}

/** Reconecta quando o endereço do servidor muda (Perfil › Conta). */
let lastBase = base();
window.setInterval(() => {
  const b = base();
  if (b !== lastBase) {
    lastBase = b;
    if (users) connect();
  }
}, 5000);

export const LIVE_LABEL: Record<LiveMode, string> = {
  desligado: "Tempo real desligado",
  conectando: "Conectando…",
  ao_vivo: "Ao vivo",
  polling: "Atualização periódica",
  direto: "Focos da NASA FIRMS",
  falha: "Tempo real indisponível",
};
