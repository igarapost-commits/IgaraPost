/** Foco de calor recebido em tempo real. `t` em ms (UTC). */
export interface LiveFire {
  id: string;
  lat: number;
  lon: number;
  t: number;
  sat: string;
  mun?: string;
  uf?: string;
  frp?: number | null;
}

const COLS = {
  id: ["id", "foco_id", "id_foco"],
  lat: ["lat", "latitude"],
  lon: ["lon", "longitude"],
  t: ["data_hora_gmt", "datahora", "data_hora", "data_pas"],
  date: ["acq_date"],
  time: ["acq_time"],
  sat: ["satelite", "satellite"],
  mun: ["municipio"],
  uf: ["estado", "uf"],
  frp: ["frp"],
} as const;

function splitCsvLine(line: string): string[] {
  const out: string[] = [];
  let cur = "",
    q = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (q) {
      if (c === '"' && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else if (c === '"') q = false;
      else cur += c;
    } else if (c === '"') q = true;
    else if (c === ",") {
      out.push(cur);
      cur = "";
    } else cur += c;
  }
  out.push(cur);
  return out;
}

/** Satélites como aparecem nos arquivos da NASA FIRMS. */
export const FIRMS_SAT: Record<string, string> = { N: "VIIRS Suomi NPP", N20: "VIIRS NOAA-20", N21: "VIIRS NOAA-21", "1": "VIIRS NOAA-20", Terra: "MODIS Terra", Aqua: "MODIS Aqua" };
/** acq_date "2026-11-14" + acq_time "1630" ou "16:30" (UTC) → ms */
export function firmsTime(date: string, time: string): number {
  const t = String(time).replace(":", "").trim().padStart(4, "0");
  return Date.parse(`${date.trim()}T${t.slice(0, 2)}:${t.slice(2, 4)}:00Z`);
}

/** "2026-11-14 16:10:00" (GMT) ou ISO → ms */
export function parseGmt(s: string): number {
  const v = s.trim();
  if (!v) return NaN;
  return Date.parse(/[zZ]|[+-]\d\d:?\d\d$/.test(v) ? v : v.replace(" ", "T") + "Z");
}

/**
 * Lê um CSV de focos (NASA FIRMS ou INPE). A leitura é feita pelo nome das colunas, para continuar funcionando
 * se a ordem mudar. Linhas sem coordenada ou data válidas são ignoradas.
 */
export function parseInpeCsv(text: string): LiveFire[] {
  const lines = text.replace(/^﻿/, "").split(/\r?\n/).filter((l) => l.trim());
  if (lines.length < 2) return [];
  const head = splitCsvLine(lines[0]).map((h) => h.trim().toLowerCase());
  const col = (k: keyof typeof COLS) => head.findIndex((h) => (COLS[k] as readonly string[]).includes(h));
  const ix = { id: col("id"), lat: col("lat"), lon: col("lon"), t: col("t"), date: col("date"), time: col("time"), sat: col("sat"), mun: col("mun"), uf: col("uf"), frp: col("frp") };
  if (ix.lat < 0 || ix.lon < 0 || (ix.t < 0 && ix.date < 0)) throw new Error("CSV de focos sem as colunas esperadas (latitude, longitude e data).");
  const out: LiveFire[] = [];
  for (let i = 1; i < lines.length; i++) {
    const r = splitCsvLine(lines[i]);
    const lat = Number(r[ix.lat]),
      lon = Number(r[ix.lon]),
      t = ix.t >= 0 ? parseGmt(r[ix.t] ?? "") : firmsTime(r[ix.date] ?? "", ix.time >= 0 ? r[ix.time] : "0000");
    if (!isFinite(lat) || !isFinite(lon) || !isFinite(t) || Math.abs(lat) > 90 || Math.abs(lon) > 180) continue;
    const satRaw = (ix.sat >= 0 ? r[ix.sat] : "")?.trim() || "?";
    const sat = FIRMS_SAT[satRaw] ?? satRaw;
    const frpRaw = ix.frp >= 0 ? Number(r[ix.frp]) : NaN;
    out.push({
      id: (ix.id >= 0 && r[ix.id]?.trim()) || `${sat}:${lat.toFixed(4)}:${lon.toFixed(4)}:${t}`,
      lat,
      lon,
      t,
      sat,
      mun: ix.mun >= 0 ? r[ix.mun]?.trim() || undefined : undefined,
      uf: ix.uf >= 0 ? r[ix.uf]?.trim() || undefined : undefined,
      frp: isFinite(frpRaw) && frpRaw > -900 ? frpRaw : null,
    });
  }
  return out;
}

/** Junta listas de focos sem repetir e descarta os mais antigos que a janela. */
export function mergeFires(a: LiveFire[], b: LiveFire[], windowMs: number, now = Date.now()): LiveFire[] {
  const m = new Map<string, LiveFire>();
  for (const f of a) m.set(f.id, f);
  for (const f of b) m.set(f.id, f);
  const min = now - windowMs;
  return [...m.values()].filter((f) => f.t >= min && f.t <= now + 3600_000).sort((x, y) => y.t - x.t);
}
