import React from "react";
import { Icon } from "./Icon";
import { useApp } from "./ctx";
import { commit, StorageError, useStore } from "./store";
import type { ApiError } from "./api";
import * as sb from "./sb";
import { Avatar } from "./PostCard";

/** Recorta a foto em quadrado e reduz para 192 px: fica leve para guardar no aparelho. */
function squarePhoto(file: File): Promise<string> {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const side = Math.min(img.width, img.height);
      const c = document.createElement("canvas");
      c.width = c.height = 192;
      c.getContext("2d")!.drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, 192, 192);
      URL.revokeObjectURL(url);
      res(c.toDataURL("image/jpeg", 0.8));
    };
    img.onerror = () => rej(new Error("Não foi possível ler essa imagem."));
    img.src = url;
  });
}

/** Janela "Editar perfil": foto, nome, frase sobre você e cidade ou comunidade. */
export function EditProfile({ onClose }: { onClose: () => void }) {
  const st = useStore();
  const { toast } = useApp();
  const [name, setName] = React.useState(st.server.user?.displayName ?? st.me.name);
  const [bio, setBio] = React.useState(st.me.bio ?? "");
  const [place, setPlace] = React.useState(st.me.place ?? "");
  const [photo, setPhoto] = React.useState<string | undefined>(st.me.photo ?? st.server.user?.photo);
  const [handle, setHandle] = React.useState(st.server.user?.handle ?? "");
  const [msg, setMsg] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const fileRef = React.useRef<HTMLInputElement>(null);

  const pick = async (f?: File) => {
    if (!f) return;
    try {
      setPhoto(await squarePhoto(f));
      setMsg("");
    } catch (e) {
      setMsg((e as Error).message);
    }
  };

  const save = async () => {
    const n = name.trim();
    if (n.length < 1 || n.length > 40) return setMsg("O nome precisa ter de 1 a 40 caracteres.");
    setBusy(true);
    setMsg("");
    try {
      // conectado à rede: nome, @ e foto também mudam lá, para os outros verem
      const u = st.server.user;
      let user = u;
      if (st.server.token && u) {
        const h = sb.cleanHandle(handle);
        const oldPhoto = st.me.photo ?? u.photo;
        const change = {
          ...(n !== u.displayName ? { name: n } : {}),
          ...(h !== u.handle ? { handle: h } : {}),
          ...(photo !== oldPhoto ? { avatar: photo ?? null } : {}),
        };
        if (Object.keys(change).length) user = await sb.updateProfile(change);
      } else if (u && sb.cleanHandle(handle) !== u.handle) {
        throw new Error("Sem conexão: o nome de usuário só muda com internet.");
      }
      commit((s) => ({
        ...s,
        me: { ...s.me, name: n, bio: bio.trim() || undefined, place: place.trim() || undefined, photo },
        server: user ? { ...s.server, user: { ...user, displayName: n } } : s.server,
      }));
      toast("Perfil atualizado");
      onClose();
    } catch (e) {
      setMsg(e instanceof StorageError ? "Não há espaço no aparelho para guardar a foto. Tente outra imagem ou remova a foto." : (e as ApiError).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <div className="sheet modal edit-profile" role="dialog" aria-modal="true" aria-label="Editar perfil" onClick={(e) => e.stopPropagation()}>
        <div className="section-title">
          <h2>Editar perfil</h2>
          <button className="btn sm ghost" onClick={onClose} aria-label="Fechar">
            <Icon name="close" />
          </button>
        </div>
        <div className="edit-photo">
          <Avatar a={{ id: "me", name: name || "?", photo }} size={88} />
          <div className="stack" style={{ gap: 8 }}>
            <button className="btn sm" onClick={() => fileRef.current?.click()}>
              <Icon name="camera" /> {photo ? "Trocar foto" : "Escolher foto"}
            </button>
            {photo && (
              <button className="btn sm ghost" onClick={() => setPhoto(undefined)}>
                <Icon name="trash" /> Remover foto
              </button>
            )}
          </div>
          <input ref={fileRef} id="ep-photo" type="file" accept="image/*" hidden onChange={(e) => void pick(e.target.files?.[0])} />
        </div>
        <label className="field">
          <span>Nome</span>
          <input id="ep-name" className="input" value={name} maxLength={40} onChange={(e) => setName(e.target.value)} autoComplete="name" />
        </label>
        {st.server.user && (
          <label className="field">
            <span>Nome de usuário</span>
            <div className="handle-input">
              <span aria-hidden>@</span>
              <input
                id="ep-handle"
                className="input"
                value={handle}
                maxLength={25}
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                translate="no"
                onChange={(e) => setHandle(e.target.value.toLowerCase().replace(/\s/g, ""))}
              />
            </div>
            <span className="small muted">Letras sem acento, números, ponto, hífen ou _ (3 a 24).</span>
          </label>
        )}
        <label className="field">
          <span>Cidade ou comunidade</span>
          <input id="ep-place" className="input" value={place} maxLength={60} onChange={(e) => setPlace(e.target.value)} placeholder="Ex.: Careiro da Várzea" />
        </label>
        <label className="field">
          <span>Sobre você</span>
          <textarea id="ep-bio" className="input" rows={3} value={bio} maxLength={160} onChange={(e) => setBio(e.target.value)} placeholder="Ex.: Professora, acompanho o rio e a fumaça na comunidade." />
          <span className="small muted" style={{ textAlign: "right" }}>{bio.length}/160</span>
        </label>
        {msg && (
          <p className="small" role="alert" style={{ color: "var(--danger, #c0392b)" }}>
            {msg}
          </p>
        )}
        <div className="row" style={{ justifyContent: "flex-end" }}>
          <button className="btn ghost" onClick={onClose}>
            Cancelar
          </button>
          <button id="ep-save" className="btn primary" onClick={save} disabled={busy}>
            {busy ? <span className="spin" aria-hidden /> : <Icon name="check" />} Salvar
          </button>
        </div>
      </div>
    </div>
  );
}
