import React from "react";
import { Icon } from "./Icon";
import { LANG } from "./i18n/lang";
import { needsTranslation, textLang, translateUser, TranslateError } from "./i18n/userText";

/**
 * Texto escrito por uma pessoa (relato ou comentário): aparece sempre no
 * idioma original. Se for de outro idioma que o do app, mostra o botão
 * "Ver tradução", que alterna com "Ver original".
 */
export function UserText(props: { text: string; lang?: string; className?: string; style?: React.CSSProperties }) {
  const { text, lang } = props;
  const [tr, setTr] = React.useState<{ text: string; via: "app" | "mymemory" } | null>(null);
  const [show, setShow] = React.useState(false);
  const [busy, setBusy] = React.useState(false);
  const [err, setErr] = React.useState<string | null>(null);
  React.useEffect(() => {
    setTr(null);
    setShow(false);
    setErr(null);
  }, [text]);
  const needs = needsTranslation(text, lang);
  const toggle = async () => {
    if (show) return setShow(false);
    if (tr) return setShow(true);
    setBusy(true);
    setErr(null);
    try {
      const r = await translateUser(text, textLang(text, lang)!, LANG);
      setTr(r);
      setShow(true);
    } catch (e) {
      const k = e instanceof TranslateError ? e.kind : "falha";
      setErr(k === "offline" ? "Sem internet: a tradução precisa de conexão." : k === "limite" ? "Limite diário de traduções atingido. Tente de novo amanhã." : "Não foi possível traduzir agora.");
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <p className={props.className} style={props.style} translate="no" lang={show ? undefined : textLang(text, lang) ?? undefined}>
        {show && tr ? tr.text : text}
      </p>
      {needs && (
        <div className="tr-row small">
          <button type="button" className="linkish tr-btn" onClick={toggle} disabled={busy} aria-pressed={show}>
            <Icon name="globe" size={14} /> {busy ? "Traduzindo…" : show ? "Ver original" : "Ver tradução"}
          </button>
          {show && tr && <span className="muted">Tradução automática</span>}
          {err && (
            <span className="warn-text" role="status">
              {err}
            </span>
          )}
        </div>
      )}
    </>
  );
}
