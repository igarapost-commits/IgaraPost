import type { Comment, Post, ServerUser } from "./types";

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public code?: string,
  ) {
    super(message);
  }
  /** sem resposta do servidor (sem internet, servidor desligado, tempo esgotado) */
  get network() {
    return this.status === 0;
  }
}

export function normalizeUrl(u: string) {
  return u.trim().replace(/\/+$/, "");
}

export async function api<T>(base: string, method: string, path: string, body?: unknown, token?: string, timeoutMs = 15000): Promise<T> {
  if (!base) throw new ApiError(0, "Nenhum servidor configurado.", "sem_servidor");
  const ctl = new AbortController();
  const t = window.setTimeout(() => ctl.abort(), timeoutMs);
  let r: Response;
  try {
    r = await fetch(normalizeUrl(base) + path, {
      method,
      headers: { ...(body ? { "Content-Type": "application/json" } : {}), ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: body ? JSON.stringify(body) : undefined,
      signal: ctl.signal,
    });
  } catch {
    throw new ApiError(0, "Sem conexão com o servidor.", "rede");
  } finally {
    window.clearTimeout(t);
  }
  let j: { error?: string; code?: string } & Record<string, unknown> = {};
  try {
    j = await r.json();
  } catch {
    /* resposta sem JSON */
  }
  if (!r.ok) throw new ApiError(r.status, j.error || `Erro ${r.status} no servidor.`, j.code);
  return j as T;
}

/* ---------- formatos do servidor -> formatos do app ---------- */
interface SPost {
  id: string;
  authorId: string;
  author: { id: string; handle: string; displayName: string };
  category: Post["category"];
  text: string;
  lat: number;
  lon: number;
  approx: boolean;
  municipio?: string;
  observedAt: string;
  publishedAt: string;
  editedAt?: string;
  communityIds: string[];
  photoUrl?: string;
  status: "visivel" | "oculto";
  commentCount: number;
  mine: boolean;
  radar?: Post["radar"];
}
interface SComment {
  id: string;
  postId: string;
  authorId: string;
  author: { id: string; handle: string; displayName: string };
  text: string;
  at: string;
  mine: boolean;
}
export const fromServerPost = (base: string, p: SPost): Post => ({
  id: p.id,
  kind: "community",
  authorId: p.authorId,
  author: { id: p.author.id, name: p.author.displayName, handle: p.author.handle },
  category: p.category,
  text: p.text,
  lat: p.lat,
  lon: p.lon,
  approx: p.approx,
  municipio: p.municipio,
  observedAt: p.observedAt,
  publishedAt: p.publishedAt,
  editedAt: p.editedAt,
  communityIds: p.communityIds,
  photo: p.photoUrl ? normalizeUrl(base) + p.photoUrl : undefined,
  sync: p.status === "oculto" ? "oculto" : "publicado",
  commentCount: p.commentCount,
  mine: p.mine,
  radar: p.radar,
});
export const fromServerComment = (c: SComment): Comment => ({
  id: c.id,
  postId: c.postId,
  authorId: c.authorId,
  author: { id: c.author.id, name: c.author.displayName, handle: c.author.handle },
  text: c.text,
  at: c.at,
  sync: "publicado",
  mine: c.mine,
});

export type { SPost, SComment };
export interface AuthResponse {
  token: string;
  user: ServerUser;
}
