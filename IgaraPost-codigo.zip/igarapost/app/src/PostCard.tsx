import React from "react";
import type { Author, Post, RadarCheck } from "./types";
import { RADAR_LABEL } from "./sars/radar";
import { useIsDark } from "./theme";
import { Icon } from "./Icon";
import { UserText } from "./UserText";
import { go, useApp } from "./ctx";
import { commit, StorageError, toggleIn, useStore } from "./store";
import { cardBg, CATEGORIES, EXAMPLE_COMMENTS, SOURCE_SHORT } from "./seed";
import { fmtDate, relTime } from "./data";
import { processOutbox, SYNC_LABEL } from "./sync";

export function KindBadges({ p }: { p: Post }) {
  return (
    <div className="row" style={{ gap: 4 }}>
      {p.kind === "community" && (
        <span className={`badge community ${p.verified ? "verified" : ""}`}>
          <Icon name={p.verified ? "check" : "people"} size={13} /> {p.verified ? "Relato da comunidade · verificado" : "Relato da comunidade · não verificado"}
        </span>
      )}
      {p.kind === "official" && (
        <span className="badge official">
          <Icon name="check" size={13} /> Dados oficiais · {SOURCE_SHORT(p)}
        </span>
      )}
      {p.kind === "nisar" && (
        <span className="badge nisar">
          <Icon name="radar" size={13} /> Análise experimental NISAR
        </span>
      )}
      {p.kind === "explainer" && (
        <span className="badge explainer">
          <Icon name="info" size={13} /> Explicativo
        </span>
      )}
      {p.radar && <RadarChip r={p.radar} />}
      {p.example && <span className="badge example">Exemplo fictício</span>}
      {p.scopeLabel && <span className="badge scope">{p.scopeLabel}</span>}
    </div>
  );
}

/** Selo da conferência com o SARS ("Fora do radar do SARS", "Já aparece no SARS"…). */
export function RadarChip({ r, withDetail }: { r: RadarCheck; withDetail?: boolean }) {
  return (
    <span className={`badge radar ${r.status}`} title={r.detail}>
      <Icon name={r.status === "fora_do_radar" ? "radar" : r.status === "nao_verificado" ? "info" : "satellite"} size={13} /> {RADAR_LABEL[r.status]}
      {withDetail ? <span className="radar-detail"> · {r.detail}</span> : null}
    </span>
  );
}

export function SyncChip({ p }: { p: Post }) {
  if (!p.sync || p.sync === "publicado") return p.sync === "publicado" && p.mine ? <span className="sync ok">Enviado</span> : null;
  return (
    <span className={`sync ${p.sync}`} title={p.syncError}>
      {p.sync === "enviando" ? <span className="spin" aria-hidden /> : null}
      {SYNC_LABEL[p.sync]}
    </span>
  );
}

const TEAM_LOGO = "igarapost-logo.png";

/** Logo da equipe Vento Norte (UEA) no canto das publicações da equipe: branca no tema escuro, preta no claro. */
/** Logo branca da Vento Norte no canto, para os cartões de fundo escuro cuja imagem não traz a logo ("Outro"). */
export function CornerLogo() {
  return <img className="vn-corner" src="vento-norte-branca.png" alt="Vento Norte · UEA" width={40} height={46} />;
}

export function VentoNorteLogo() {
  const dark = useIsDark();
  return <img className="vn-logo" src={dark ? "vento-norte-branca.png" : "vento-norte-preta.png"} alt="Vento Norte · UEA" width={36} height={42} />;
}

/** Foto de perfil: logo do IgaraPost para a equipe, a foto escolhida pela pessoa ou as iniciais. */
export function Avatar({ a, size = 38, className = "" }: { a: Author; size?: number; className?: string }) {
  const src = a.id === "equipe" ? TEAM_LOGO : a.photo;
  const style = { width: size, height: size, fontSize: Math.round(size * 0.38) };
  if (src)
    return (
      <div className={`avatar has-img ${a.id === "equipe" ? "team" : ""} ${className}`} style={style} aria-hidden>
        <img src={src} alt="" width={size} height={size} />
      </div>
    );
  return (
    <div className={`avatar ${className}`} style={style} aria-hidden>
      {initials(a.name)}
    </div>
  );
}

export function initials(n: string) {
  return n
    .replace(/\(.*\)/, "")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0])
    .join("")
    .toUpperCase();
}

/** Cartão de publicação. No feed é compacto (expande no lugar); no detalhe mostra tudo. */
export function PostCard({ p, detail, pinned }: { p: Post; detail?: boolean; pinned?: boolean }) {
  const st = useStore();
  const { author, setMapContext, toast } = useApp();
  const a = author(p);
  const cat = CATEGORIES[p.category];
  // fumaça, enchente, queimada e "Outro": imagem de fundo (a logo da Vento Norte já vem nela)
  const bg = cardBg(p.category);
  const [open, setOpen] = React.useState(!!detail);
  const long = p.text.length > 220 || p.text.includes("\n");
  /** relatos (de pessoas e exemplos) ficam no idioma original, com "Ver tradução"; só o conteúdo da equipe é traduzido pelo app */
  const userText = p.authorId !== "equipe";
  const liked = st.likes.includes(p.id);
  const saved = st.saves.includes(p.id);
  // no feed, tocar em qualquer parte do cartão (fora dos botões e links) abre a publicação
  const openDetail = (e: { target: EventTarget | null }) => {
    if (detail) return;
    if ((e.target as HTMLElement).closest("a, button, input, textarea, select, label, video")) return;
    if (window.getSelection()?.toString()) return; // estava selecionando texto
    go(`#post-${p.id}`);
  };

  const toggle = (key: "likes" | "saves", msgOn: string, msgOff: string) => {
    try {
      const on = !st[key].includes(p.id);
      commit((s) => ({ ...s, [key]: toggleIn(s[key], p.id) }));
      if (key === "saves") toast(on ? msgOn : msgOff);
    } catch (e) {
      toast((e as StorageError).message);
    }
  };
  const showOnMap = () => {
    if (p.lat == null || p.lon == null) return;
    setMapContext({ postId: p.id, lat: p.lat, lon: p.lon, observedAt: p.observedAt, label: `${cat.short} · ${p.municipio ?? "local do relato"}` });
    go("#mapa");
  };
  const nComments =
    p.commentCount ?? EXAMPLE_COMMENTS.filter((c) => c.postId === p.id).length + st.comments.filter((c) => c.postId === p.id).length + (st.server.comments[p.id]?.list.length ?? 0);

  return (
    <article
      className={`post ${detail ? "detail" : ""} ${pinned ? "pinned" : ""} ${bg?.className ?? ""}`}
      style={bg?.style}
      aria-label={p.title || `Publicação de ${a.name}`}
      onClick={openDetail}
    >
      {bg?.cornerLogo && <CornerLogo />}
      {pinned && (
        <div className="pinned-label">
          <Icon name="pin" size={13} /> Fixado no topo
        </div>
      )}
      <div className="post-head">
        <Avatar a={a} className={`${p.kind === "official" ? "official" : p.kind === "nisar" || p.kind === "explainer" ? "nisar" : ""} ${a.example ? "example" : ""}`} />
        <div className="grow stack" style={{ gap: 2 }}>
          <div className="row" style={{ justifyContent: "space-between", gap: 6, flexWrap: "nowrap" }}>
            <div className="grow" style={{ minWidth: 0 }}>
              <b className="author-name">{a.name}</b>
              {a.handle && <span className="small muted"> @{a.handle}</span>}
              {a.role && <div className="small muted">{a.role}</div>}
            </div>
            <SyncChip p={p} />
            {a.id === "equipe" && !bg && <VentoNorteLogo />}
          </div>
          <KindBadges p={p} />
        </div>
      </div>
      <div className="post-body">
        {p.title && (detail ? <h2 translate={userText ? "no" : undefined}>{p.title}</h2> : <h3 translate={userText ? "no" : undefined}>{p.title}</h3>)}
        {userText ? (
          <UserText className={`text ${!open && long ? "clamp" : ""}`} text={p.text} lang={p.lang} />
        ) : (
          <p className={`text ${!open && long ? "clamp" : ""}`}>{p.text}</p>
        )}
        {long && !detail && (
          <button className="linkish more-toggle" onClick={() => setOpen(!open)} aria-expanded={open}>
            {open ? "Ver menos" : "Ver mais"}
          </button>
        )}
        {p.photo && <img className="post-photo" src={p.photo} alt={`Foto enviada com o relato: ${cat.label}`} loading="lazy" decoding="async" />}
        <div className="post-meta">
          {p.municipio && (
            <span>
              <Icon name="pin" /> {p.municipio}
              {p.approx ? " · aproximado" : ""}
            </span>
          )}
          {p.kind === "community" && (
            <span title="Momento em que a pessoa observou">
              <Icon name="clock" /> Observado em {fmtDate(p.observedAt, true)}
            </span>
          )}
          {(p.kind === "community" || p.category !== "outro") && (
            <span className="badge cat" style={{ color: cat.color }}>
              <Icon name={cat.icon} size={13} /> {cat.short}
            </span>
          )}
        </div>
        {p.source && (
          <p className="source-line small muted">
            {p.kind === "explainer" ? `Fonte: ${p.source.name.split(" (")[0]}` : `Fonte: ${p.source.name.split(" (")[0]} · período: ${p.source.period}`}
          </p>
        )}
        <p className="small muted">
          {p.kind === "community" ? `Relatado ${relTime(p.publishedAt)}` : `Publicado em ${fmtDate(p.publishedAt)}`}
          {p.editedAt ? " · editado" : ""}
        </p>
        {p.sync === "falhou" && (
          <div className="callout warn small" role="alert">
            <b>Falha no envio:</b> {p.syncError} <a href={`#editar-${p.id}`}>Corrigir</a> ·{" "}
            <button className="linkish" onClick={() => processOutbox(true)}>
              Tentar de novo
            </button>
          </div>
        )}
        {p.sync === "pendente" && p.syncError && <p className="small muted">{p.syncError}</p>}
        {!detail && p.cta && (
          <a className="btn sm" href={p.cta.hash} style={{ alignSelf: "flex-start" }}>
            {p.cta.label}
          </a>
        )}
      </div>
      <div className="post-actions">
        <button aria-pressed={liked} className={liked ? "liked" : ""} onClick={() => toggle("likes", "", "")} title="O apoio fica salvo só neste aparelho">
          <Icon name="heart" filled={liked} /> {liked ? "Apoiado" : "Apoiar"}
        </button>
        <a
          href={`#post-${p.id}#comentarios`}
          aria-label="Abrir comentários"
          onClick={(e) => {
            // já na publicação: só desce até a conversa
            if (location.hash.startsWith(`#post-${p.id}`)) {
              e.preventDefault();
              document.getElementById("comentarios")?.scrollIntoView({ block: "start", behavior: "smooth" });
            }
          }}
        >
          <Icon name="comment" /> {nComments ? nComments : ""} Comentar
        </a>
        {p.lat != null ? (
          <button onClick={showOnMap}>
            <Icon name="map" /> Mapa
          </button>
        ) : p.cta ? (
          <a href={p.cta.hash}>
            <Icon name="map" /> Mapa
          </a>
        ) : null}
        <button aria-pressed={saved} className={saved ? "saved" : ""} onClick={() => toggle("saves", "Salvo neste aparelho", "Removido dos salvos")}>
          <Icon name="bookmark" filled={saved} /> {saved ? "Salvo" : "Salvar"}
        </button>
      </div>
    </article>
  );
}
