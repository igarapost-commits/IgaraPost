import React from "react";
import { Icon } from "./Icon";

export type PickOption<K extends string> = { key: K; label: string; icon?: string; color?: string };

/**
 * Botão que mostra só a opção escolhida e, ao tocar, expande embaixo
 * todas as opções numa grade de duas colunas (nada rola para o lado).
 * Devolve um fragmento: quem usa decide o contêiner (grade da barra do
 * Feed ou bloco de uma coluna dentro de folhas e páginas).
 */
export function ExpandPicker<K extends string>(props: {
  id: string;
  label: string;
  options: PickOption<K>[];
  value: K;
  onChange: (k: K) => void;
  className?: string;
}) {
  const { id, label, options, value, onChange } = props;
  const [open, setOpen] = React.useState(false);
  const cur = options.find((o) => o.key === value) ?? options[0];
  const ico = (o: PickOption<K>, active: boolean) =>
    o.icon ? (
      <span style={{ color: active ? undefined : o.color, display: "inline-flex" }}>
        <Icon name={o.icon} size={15} />
      </span>
    ) : null;
  return (
    <>
      <button
        type="button"
        id={id}
        className={`btn sm theme-toggle ${props.className ?? ""}`}
        aria-expanded={open}
        aria-controls={`${id}-opcoes`}
        aria-label={`${label}: ${cur.label}. Toque para ver as opções`}
        onClick={() => setOpen((v) => !v)}
      >
        {ico(cur, false)}
        <span className="grow">{cur.label}</span>
        <span className="theme-chevron" aria-hidden>
          <Icon name="chevron" size={16} />
        </span>
      </button>
      {open && (
        <div id={`${id}-opcoes`} className="theme-options" role="group" aria-label={label}>
          {options.map((o) => (
            <button
              type="button"
              key={o.key}
              className="chip"
              aria-pressed={o.key === value}
              onClick={() => {
                onChange(o.key);
                setOpen(false);
              }}
            >
              {ico(o, o.key === value)}
              {o.label}
            </button>
          ))}
        </div>
      )}
    </>
  );
}
