import React from "react";
import type { Comment, Post } from "./types";
import { Icon } from "./Icon";
import { UserText } from "./UserText";
import { detectLang } from "./i18n/userText";
import { LANG } from "./i18n/lang";
import { go, useApp } from "./ctx";
import { commit, StorageError, uid, useStore } from "./store";
import { AUTHORS, EXAMPLE_COMMENTS } from "./seed";
import { fmtDate, relTime } from "./data";
import { enqueue, fetchComments, refreshFeed, SYNC_LABEL, useComments, type FetchState } from "./sync";
import * as sb from "./sb";
import type { ApiError } from "./api";
import { Avatar, PostCard } from "./PostCard";

function Comments({ p }: { p: Post }) {
  const st = useStore();
  const { author, toast } = useApp();
  const shared = !!st.server.url && !p.example && p.sync !== "local";
  const list = useComments(p.id, !shared);
  const all = p.example ? [...EXAMPLE_COMMENTS.filter((c) => c.postId === p.id), ...list] : list;
  const [txt, setTxt] = React.useState("");
  const [err, setErr] = React.useState("");
  const [fs, setFs] = React.useState<FetchState>();
  React.useEffect(() => {
    if (shared) fetchComments(p.id).then(setFs);
  }, [shared, p.id]);
  const send = (e: React.FormEvent) => {
    e.preventDefault();
    const text = txt.trim();
    if (!text) return;
    setErr("");
    const c: Comment = { id: uid("c"), postId: p.id, authorId: shared ? (st.server.user?.id ?? "me") : "me", text, lang: detectLang(text) ?? LANG, at: new Date().toISOString() };
    try {
      if (shared) enqueue({ op: "createComment", comment: c });
      else commit((s) => ({ ...s, comments: [...s.comments, c] }));
      setTxt("");
    } catch (x) {
      setErr((x as StorageError).message); // o texto continua no campo
    }
  };
  const del = (c: Comment) => {
    try {
      if (c.sync === "local" || !shared) commit((s) => ({ ...s, comments: s.comments.filter((x) => x.id !== c.id) }));
      else enqueue({ op: "deleteComment", id: c.id, postId: p.id });
      toast("Comentário apagado");
    } catch (x) {
      toast((x as StorageError).message);
    }
  };
  return (
    <section className="stack" aria-labelledby="com-h" id="comentarios">
      <h2 id="com-h">Conversa ({all.length})</h2>
      {shared && fs?.state === "sem_conexao" && <p className="small muted">Sem conexão: mostrando os comentários obtidos {fs.at ? `em ${fmtDate(fs.at, true)}` : "anteriormente (nenhum)"}.</p>}
      {shared && fs?.state === "erro" && <p className="small muted">Não foi possível carregar os comentários: {fs.message}</p>}
      {all.map((c) => {
        const mine = c.mine || c.authorId === "me" || (st.server.user && c.authorId === st.server.user.id);
        const canDelete = mine || (shared && st.server.user?.role === "moderador");
        const a = mine ? author({ authorId: "me" }) : c.author ?? AUTHORS[c.authorId] ?? author({ authorId: c.authorId });
        return (
          <div key={c.id} className="row" style={{ alignItems: "flex-start", flexWrap: "nowrap" }}>
            <Avatar a={a} size={32} className={a.example ? "example" : ""} />
            <div className="panel grow" style={{ padding: "8px 12px", minWidth: 0 }}>
              <div className="row small" style={{ justifyContent: "space-between" }}>
                <b>{a.name}</b>
                <span className="muted">
                  {relTime(c.at)}
                  {c.sync && c.sync !== "publicado" ? ` · ${SYNC_LABEL[c.sync]}` : ""}
                </span>
              </div>
              {c.example && <span className="badge example">Comentário fictício</span>}
              <UserText style={{ whiteSpace: "pre-line", overflowWrap: "anywhere" }} text={c.text} lang={c.lang} />
              {canDelete && !c.example && (
                <button className="btn sm ghost danger" onClick={() => del(c)}>
                  Apagar
                </button>
              )}
            </div>
          </div>
        );
      })}
      <form className="stack" onSubmit={send}>
          <textarea id="comment-text" className="input" aria-label="Escreva um comentário" style={{ minHeight: 70 }} maxLength={600} value={txt} onChange={(e) => setTxt(e.target.value)} placeholder="Você viu algo parecido? Tem uma informação que ajuda?" />
          {err && (
            <div className="callout warn small" role="alert">
              {err}
            </div>
          )}
          <button className="btn primary" type="submit" disabled={!txt.trim()} style={{ alignSelf: "flex-start" }}>
            <Icon name="send" /> Comentar
          </button>
        </form>
    </section>
  );
}

const REASONS = ["Informação falsa ou enganosa", "Local ou data errados", "Expõe dados pessoais ou de terceiros", "Ofensivo, discriminatório ou assédio", "Propaganda ou spam"];

function AuthorActions({ p }: { p: Post }) {
  const st = useStore();
  const { toast } = useApp();
  const [menu, setMenu] = React.useState<"" | "report" | "delete">("");
  const [reason, setReason] = React.useState(REASONS[0]);
  const mine = p.mine || p.authorId === "me" || (!!st.server.user && p.authorId === st.server.user.id);
  const sharedTarget = !!st.server.url && !p.example && p.sync !== "local";
  const admin = sharedTarget && p.kind === "community" && st.server.user?.role === "moderador";
  const [busy, setBusy] = React.useState(false);
  const adminDo = async (f: () => Promise<void>, done: string) => {
    setBusy(true);
    try {
      await f();
      await refreshFeed();
      toast(done);
    } catch (e) {
      toast((e as ApiError).message);
    } finally {
      setBusy(false);
    }
  };
  const reported = st.reports.some((r) => r.postId === p.id) || st.outbox.some((x) => x.op === "report" && x.postId === p.id);
  const doDelete = () => {
    try {
      if (p.sync === "local") commit((s) => ({ ...s, posts: s.posts.filter((x) => x.id !== p.id), comments: s.comments.filter((c) => c.postId !== p.id) }));
      else enqueue({ op: "deletePost", id: p.id });
      toast("Relato excluído");
      go(mine ? "#perfil" : "#feed");
    } catch (e) {
      toast((e as StorageError).message);
    }
  };
  const doReport = () => {
    try {
      if (sharedTarget) enqueue({ op: "report", postId: p.id, reason });
      else commit((s) => ({ ...s, reports: [...s.reports, { id: uid("r"), postId: p.id, reason, at: new Date().toISOString(), status: "pendente" }] }));
      setMenu("");
      toast("Denúncia enviada");
    } catch (e) {
      toast((e as StorageError).message);
    }
  };
  if (p.kind !== "community" && !sharedTarget) return null;
  return (
    <div className="stack" style={{ gap: 8 }}>
      <div className="row">
        {mine && p.kind === "community" && (
          <a className="btn sm" href={`#editar-${p.id}`}>
            <Icon name="edit" /> Editar
          </a>
        )}
        {admin && !p.verified && p.sync !== "oculto" && (
          <button className="btn sm primary" disabled={busy} onClick={() => adminDo(() => sb.verifyPost(p.id), "Relato verificado")}>
            <Icon name="check" /> Verificar
          </button>
        )}
        {admin && !mine && (
          <button className="btn sm" disabled={busy} onClick={() => adminDo(() => sb.setPostStatus(p.id, p.sync === "oculto" ? "visivel" : "oculto"), p.sync === "oculto" ? "Publicação visível de novo" : "Publicação ocultada")}>
            <Icon name="flag" /> {p.sync === "oculto" ? "Mostrar de novo" : "Ocultar"}
          </button>
        )}
        {((mine && p.kind === "community") || admin) && (
          <button className="btn sm danger" onClick={() => setMenu(menu === "delete" ? "" : "delete")}>
            <Icon name="trash" /> Excluir
          </button>
        )}
        {!mine && !admin &&
          (reported ? (
            <span className="small muted">Denunciada. O resultado fica em Configurações › Meu registro.</span>
          ) : (
            <button className="btn sm" onClick={() => setMenu(menu === "report" ? "" : "report")}>
              <Icon name="flag" /> Denunciar
            </button>
          ))}
      </div>
      {menu === "delete" && (
        <div className="confirm">
          <b>Excluir este relato?</b>
          <span className="small">Some para todos, com os comentários. Não dá para desfazer.</span>
          <div className="row">
            <button className="btn danger" onClick={doDelete}>
              Excluir
            </button>
            <button className="btn" onClick={() => setMenu("")}>
              Cancelar
            </button>
          </div>
        </div>
      )}
      {menu === "report" && (
        <div className="confirm neutral">
          <label className="field">
            <span>Motivo da denúncia</span>
            <select id="report-reason" className="input" value={reason} onChange={(e) => setReason(e.target.value)}>
              {REASONS.map((r) => (
                <option key={r}>{r}</option>
              ))}
            </select>
          </label>
          <div className="row">
            <button className="btn primary" onClick={doReport}>
              Enviar denúncia
            </button>
            <button className="btn" onClick={() => setMenu("")}>
              Cancelar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export function scrollToComments() {
  document.getElementById("comentarios")?.scrollIntoView({ block: "start", behavior: "smooth" });
}

export function PostDetail({ id }: { id: string }) {
  const { findPost } = useApp();
  const p = findPost(id);
  React.useEffect(() => {
    // "Comentar" abre a publicação já na conversa (depois que a troca de tela volta ao topo)
    if (location.hash.endsWith("#comentarios")) window.setTimeout(scrollToComments, 60);
  }, []);
  if (!p)
    return (
      <div className="empty panel">
        Publicação não encontrada. Ela pode ter sido excluída, ocultada após revisão ou ainda não ter sido baixada. <a href="#feed">Voltar ao feed</a>
      </div>
    );
  return (
    <div className="stack" style={{ gap: 18 }}>
      <a className="btn sm ghost" href="#feed" style={{ alignSelf: "flex-start" }}>
        <Icon name="back" /> Feed
      </a>
      <PostCard p={p} detail />
      <AuthorActions p={p} />
      <Comments p={p} />
    </div>
  );
}
