/**
 * Aviso opcional (Configurações › Avisos): "seu relato foi verificado pela administração".
 *
 * O app confere ao abrir e enquanto está aberto. O aviso aparece:
 *  - como notificação do celular, se o app tiver o plugin nativo @capacitor/local-notifications (ver README) ou, no
 *    navegador, se a pessoa permitir notificações;
 *  - sempre dentro do app (mensagem na tela e na aba Atividade).
 */
import { tr3 } from "./i18n/lang";
import { getState } from "./store";
import { navigate } from "./nav";
import type { Post } from "./types";

const SEEN = "igarapost:verificados-vistos";
const LIST = "igarapost:avisos";

export interface Notice {
  id: string;
  postId: string;
  postText: string;
  at: string;
}

type LocalNotifications = {
  requestPermissions(): Promise<{ display: string }>;
  checkPermissions(): Promise<{ display: string }>;
  schedule(o: { notifications: { id: number; title: string; body: string; extra?: unknown }[] }): Promise<unknown>;
  addListener?(ev: string, f: (e: { notification: { extra?: { postId?: string } } }) => void): unknown;
};
function nativeLN(): LocalNotifications | undefined {
  const c = (window as unknown as { Capacitor?: { isPluginAvailable?: (n: string) => boolean; Plugins?: Record<string, unknown> } }).Capacitor;
  return c?.isPluginAvailable?.("LocalNotifications") ? (c.Plugins?.LocalNotifications as LocalNotifications) : undefined;
}

const read = <T,>(k: string, d: T): T => {
  try {
    return (JSON.parse(localStorage.getItem(k) || "null") as T) ?? d;
  } catch {
    return d;
  }
};
const write = (k: string, v: unknown) => {
  try {
    localStorage.setItem(k, JSON.stringify(v));
  } catch {
    /* sem espaço: o aviso só não fica guardado */
  }
};

export const notices = (): Notice[] => read<Notice[]>(LIST, []);

/** Este aparelho consegue mostrar notificação do sistema? */
export function systemNotifications(): boolean {
  return !!nativeLN() || typeof Notification !== "undefined";
}

/** Ao ligar o aviso: pede a permissão do sistema, quando houver. Devolve se a notificação do celular vai funcionar. */
export async function askPermission(): Promise<boolean> {
  const ln = nativeLN();
  try {
    if (ln) return (await ln.requestPermissions()).display === "granted";
    if (typeof Notification !== "undefined") return (await Notification.requestPermission()) === "granted";
  } catch {
    /* recusado ou indisponível */
  }
  return false;
}

let tapListener = false;
async function systemNotify(n: Notice, title: string, body: string) {
  const ln = nativeLN();
  try {
    if (ln) {
      if ((await ln.checkPermissions()).display !== "granted") return;
      if (!tapListener && ln.addListener) {
        tapListener = true;
        ln.addListener("localNotificationActionPerformed", (e) => {
          const id = e.notification.extra?.postId;
          if (id) navigate(`#post-${id}`);
        });
      }
      await ln.schedule({ notifications: [{ id: Math.floor(Date.now() % 2_000_000_000), title, body, extra: { postId: n.postId } }] });
    } else if (typeof Notification !== "undefined" && Notification.permission === "granted") {
      const w = new Notification(title, { body, icon: "icon-192.png", tag: n.id });
      w.onclick = () => {
        window.focus();
        navigate(`#post-${n.postId}`);
      };
    }
  } catch {
    /* o aviso dentro do app continua valendo */
  }
}

/**
 * Chamado a cada atualização do feed: compara quais relatos da pessoa estão verificados com os que ela já sabia.
 * Na primeira vez só memoriza (não avisa de verificações antigas).
 */
export function checkVerified(posts: Post[]) {
  const st = getState();
  const me = st.server.user?.id;
  if (!me) return;
  const verified = posts.filter((p) => p.authorId === me && p.verified).map((p) => p.id);
  const seen = read<string[] | null>(SEEN, null);
  write(SEEN, [...new Set([...(seen ?? []), ...verified])].slice(-500));
  if (!seen || !st.prefs.notifyVerified) return;
  const fresh = verified.filter((id) => !seen.includes(id));
  if (!fresh.length) return;
  const list = notices();
  for (const id of fresh) {
    const p = posts.find((x) => x.id === id)!;
    const n: Notice = { id: `v-${id}-${Date.now()}`, postId: id, postText: p.text.slice(0, 80), at: new Date().toISOString() };
    list.unshift(n);
    const title = tr3("Relato verificado", "Report verified", "Reporte verificado");
    const body = tr3("A administração do IgaraPost verificou o seu relato: ", "The IgaraPost administration verified your report: ", "La administración de IgaraPost verificó tu reporte: ") + `“${n.postText}”`;
    void systemNotify(n, title, body);
    window.dispatchEvent(new CustomEvent("igarapost:aviso", { detail: { text: "Seu relato foi verificado pela administração", postId: id } }));
  }
  write(LIST, list.slice(0, 50));
}
