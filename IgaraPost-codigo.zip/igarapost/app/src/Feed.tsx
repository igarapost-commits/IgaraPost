import { LOCALE } from "./i18n/lang";
import React from "react";
import { createPortal } from "react-dom";
import type { Category, Filters, Post, PostKind } from "./types";
import { Icon } from "./Icon";
import { ExpandPicker, type PickOption } from "./ExpandPicker";
import { useApp } from "./ctx";
import { useStore } from "./store";
import { CATEGORIES, COMMUNITIES, EXPLAINERS, MUNICIPIOS, sameKind, scopeInfo } from "./seed";
import { PERIOD_OPTIONS, periodLabel, periodRange, reloadData } from "./data";
import { PostCard } from "./PostCard";
import { processOutbox, refreshFeed } from "./sync";
import { PullToRefresh } from "./pullToRefresh";

/** Aplica recorte, tema, período e origem. Relatos locais respeitam o município escolhido. */
export function applyFilters(posts: Post[], f: Filters, follows: string[]) {
  const [a, b] = periodRange(f.period);
  const si = scopeInfo(f.scope, follows);
  const followedThemes = COMMUNITIES.filter((c) => follows.includes(c.id) && c.kind === "tema");
  return posts
    .filter((p) => {
      const t = Date.parse(p.observedAt);
      // as publicações explicativas valem para qualquer período: ficam sempre fixadas no topo
      if (p.kind !== "explainer" && (t < a || t > b)) return false;
      if (f.category !== "all" && !sameKind(p.category, f.category)) return false;
      if (f.kinds.length && !f.kinds.includes(p.kind)) return false;
      if (si.categories && p.kind !== "explainer" && !si.categories.includes(p.category) && !(si.communityId && p.communityIds.includes(si.communityId))) return false;
      if (p.kind !== "community") return true; // publicações de dados já são geradas para o recorte
      if (f.scope === "following") {
        const inMun = !!(p.municipio && si.municipios?.includes(p.municipio));
        const inCom = p.communityIds.some((c) => follows.includes(c));
        const inTheme = followedThemes.some((c) => c.categories?.includes(p.category));
        return inMun || inCom || inTheme;
      }
      if (si.municipios) return !!p.municipio && si.municipios.includes(p.municipio);
      if (si.communityId && !si.categories) return p.communityIds.includes(si.communityId); // tema sem categorias (ex.: radar)
      return true;
    })
    .sort((x, y) => pinRank(x) - pinRank(y) || Date.parse(y.publishedAt) - Date.parse(x.publishedAt));
}

/** Explicativos primeiro, na ordem da equipe; o resto por data. */
const PIN_ORDER = EXPLAINERS.map((e) => e.id);
const pinRank = (p: Post) => (p.kind === "explainer" ? (PIN_ORDER.indexOf(p.id) + 1 || PIN_ORDER.length + 1) - 100 : 0);

export function ScopeSelect({ id = "f-scope" }: { id?: string }) {
  const { filters: f, setFilters } = useApp();
  const st = useStore();
  const followed = COMMUNITIES.filter((c) => st.follows.includes(c.id));
  return (
    <select id={id} className="input scope-select" value={f.scope} onChange={(e) => setFilters({ ...f, scope: e.target.value })} aria-label="Região ou tema">
      {followed.length > 0 && (
        <optgroup label="Que eu acompanho">
          {followed.map((c) => (
            <option key={c.id} value={`com:${c.id}`}>
              {c.name}
            </option>
          ))}
          <option value="following">Tudo o que eu acompanho</option>
        </optgroup>
      )}
      <optgroup label="Área">
        <option value="all">Toda a área do app</option>
      </optgroup>
      <optgroup label="Município">
        {MUNICIPIOS.map((m) => (
          <option key={m} value={`mun:${m}`}>
            {m}
          </option>
        ))}
      </optgroup>
      <optgroup label="Territórios e temas">
        {COMMUNITIES.filter((c) => !st.follows.includes(c.id)).map((c) => (
          <option key={c.id} value={`com:${c.id}`}>
            {c.name}
          </option>
        ))}
      </optgroup>
    </select>
  );
}

const THEMES: [Category | "all", string, string][] = [
  ["all", "Tudo", "feed"],
  ["fumaca", "Fumaça", "smoke"],
  ["queimada", "Queimadas", "flame"],
  ["enchente", "Enchentes", "flood"],
];
const themeOptions = (): PickOption<Category | "all">[] =>
  THEMES.map(([k, l, ic]) => ({ key: k, label: l, icon: ic, color: k === "all" ? undefined : CATEGORIES[k as Category].color }));
/** Temas dentro da folha de Filtros (Feed e Mapa): mesmo botão que expande. */
export function ThemeChips() {
  const { filters: f, setFilters } = useApp();
  return (
    <div className="xpick-block">
      <ExpandPicker id="tema-filtro" label="Temas" options={themeOptions()} value={f.category} onChange={(k) => setFilters({ ...f, category: k })} />
    </div>
  );
}
/** Barra do Feed: só o tema escolhido aparece, ao lado de Filtros. */
export function ThemeMenu() {
  const { filters: f, setFilters } = useApp();
  return <ExpandPicker id="tema-btn" label="Temas" options={themeOptions()} value={f.category} onChange={(k) => setFilters({ ...f, category: k })} />;
}

export function FilterSheet({ onClose, showKinds = true }: { onClose: () => void; showKinds?: boolean }) {
  const { filters: f, setFilters } = useApp();
  const set = (patch: Partial<Filters>) => setFilters({ ...f, ...patch });
  const kinds: [PostKind, string][] = [
    ["community", "Relatos da comunidade"],
    ["explainer", "Explicativos"],
  ];
  // fora de qualquer contêiner (no Mapa a folha ficava dentro do mapa, por baixo da barra de navegação)
  return createPortal(
    <div className="sheet-backdrop" onClick={onClose}>
      <div className="sheet modal" role="dialog" aria-modal="true" aria-label="Filtros" onClick={(e) => e.stopPropagation()}>
        <div className="section-title">
          <h2>Filtros</h2>
          <button className="btn sm ghost" onClick={onClose} aria-label="Fechar filtros">
            <Icon name="close" />
          </button>
        </div>
        <label className="field">
          <span>Região ou tema</span>
          <ScopeSelect id="fs-scope" />
        </label>
        <label className="field">
          <span>Período da observação</span>
          <select id="f-period" className="input" value={f.period} onChange={(e) => set({ period: e.target.value })}>
            {!PERIOD_OPTIONS.some((o) => o.value === f.period) && <option value={f.period}>{periodLabel(f.period)}</option>}
            {PERIOD_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
        </label>
        <div className="field">
          <span>Tema</span>
          <ThemeChips />
        </div>
        {showKinds && (
          <div className="field">
            <span>Origem da informação</span>
            <div className="row">
              {kinds.map(([k, l]) => (
                <button key={k} className="chip" aria-pressed={f.kinds.includes(k)} onClick={() => set({ kinds: f.kinds.includes(k) ? f.kinds.filter((x) => x !== k) : [...f.kinds, k] })}>
                  {l}
                </button>
              ))}
            </div>
          </div>
        )}
        <div className="row">
          <button className="btn" onClick={() => setFilters({ ...f, category: "all", period: "all", kinds: [], examples: true })}>
            Limpar
          </button>
          <button className="btn primary" onClick={onClose}>
            Ver resultados
          </button>
        </div>
      </div>
    </div>
  ,
    document.body,
  );
}

export function Feed() {
  const { posts, filters, setFilters, dataErrors, toast } = useApp();
  const st = useStore();
  const [sheet, setSheet] = React.useState(false);
  // feed compartilhado: atualiza ao abrir, ao voltar para o app e a cada minuto (sem barra de estado na tela)
  React.useEffect(() => {
    if (!st.server.url) return;
    const refresh = () => {
      if (document.visibilityState !== "visible") return;
      void processOutbox(true);
      void refreshFeed();
    };
    refresh();
    const t = window.setInterval(refresh, 60_000);
    document.addEventListener("visibilitychange", refresh);
    return () => {
      window.clearInterval(t);
      document.removeEventListener("visibilitychange", refresh);
    };
  }, [st.server.url, st.server.token]);
  // arrastar para baixo: envia o que estiver na fila, baixa o feed compartilhado e recarrega os dados do app
  const [, setTick] = React.useState(0);
  const pullRefresh = React.useCallback(async () => {
    const t0 = Date.now();
    void processOutbox(true);
    const r = st.server.url ? await refreshFeed() : { state: "ok" as const };
    await reloadData();
    await new Promise((res) => window.setTimeout(res, Math.max(0, 600 - (Date.now() - t0)))); // o giro fica visível
    setTick((x) => x + 1);
    toast(r.state === "sem_conexao" ? "Sem conexão: mostrando o que já está no aparelho" : r.state === "erro" ? `Não foi possível atualizar: ${r.message}` : `Feed atualizado às ${new Date().toLocaleTimeString(LOCALE, { hour: "2-digit", minute: "2-digit" })}`);
  }, [st.server.url, toast]);
  const list = applyFilters(posts, filters, st.follows);
  const si = scopeInfo(filters.scope, st.follows);
  const nActive = (filters.period !== "all" ? 1 : 0) + filters.kinds.length;
  return (
    <div className="feed">
      <PullToRefresh onRefresh={pullRefresh} />
      <div className="feed-bar">
        <ThemeMenu />
        <button className="btn sm" onClick={() => setSheet(true)} aria-haspopup="dialog">
          <Icon name="filter" /> Filtros{nActive ? ` (${nActive})` : ""}
        </button>
      </div>
      {dataErrors.length > 0 && <div className="callout warn small">Falha ao carregar alguns dados: {dataErrors.join("; ")}. Os relatos continuam disponíveis.</div>}
      <p className="small muted">
        {list.length === 1 ? "1 publicação" : `${list.length} publicações`} · {periodLabel(filters.period).toLowerCase()}
        {nActive > 0 && (
          <>
            {" · "}
            <button className="linkish" onClick={() => setFilters({ ...filters, period: "all", kinds: [], examples: true })}>
              limpar filtros
            </button>
          </>
        )}
      </p>
      {list.map((p) => (
        <PostCard key={p.id} p={p} pinned={p.kind === "explainer"} />
      ))}
      {list.length === 0 && (
        <div className="empty panel">
          Nada encontrado para {si.label.toLowerCase()} com esses filtros. Experimente “Todo o período” ou outra região.
          <br />
          <a href="#relatar">Ou relate o que você viu.</a>
        </div>
      )}
      {sheet && <FilterSheet onClose={() => setSheet(false)} />}
    </div>
  );
}
