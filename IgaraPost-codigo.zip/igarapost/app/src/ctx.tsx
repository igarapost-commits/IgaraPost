import { navigate } from "./nav";
import React from "react";
import type { Author, Filters, Post } from "./types";
import { getState, setSoft, useStore } from "./store";
import { AUTHORS, COMMUNITIES, EXPLAINERS, isRemoved, REMOVED_CATEGORIES, TEAM } from "./seed";
import { useData, type CemadenFile, type FiresSummary, type Manifest, type NisarSummary } from "./data";
import { usePeoplePosts } from "./sync";

/** Contexto do mapa quando ele é aberto a partir de uma publicação: local e datas dessa publicação. */
export interface MapContext {
  postId?: string;
  lat: number;
  lon: number;
  observedAt?: string;
  label: string;
}

interface Ctx {
  posts: Post[]; // publicações do recorte atual (pessoas + dados + explicativos + exemplos)
  findPost: (id: string) => Post | undefined;
  author: (p: { authorId: string; author?: Author }) => Author;
  cemaden?: CemadenFile;
  cemadenFailed: boolean;
  nisar?: NisarSummary;
  fires?: FiresSummary;
  manifest?: Manifest;
  filters: Filters;
  setFilters: (f: Filters) => void;
  mapContext?: MapContext;
  setMapContext: (c?: MapContext) => void;
  toast: (msg: string) => void;
  dataErrors: string[];
}

const C = React.createContext<Ctx>(null as unknown as Ctx);
export const useApp = () => React.useContext(C);

export function go(hash: string) {
  navigate(hash);
  window.scrollTo(0, 0);
}

function defaultFilters(): Filters {
  const f = getState().follows.find((id) => COMMUNITIES.find((c) => c.id === id)?.kind === "territorio");
  return { scope: f ? `com:${f}` : "all", category: "all", period: "all", kinds: [], examples: true };
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const st = useStore();
  const cem = useData<CemadenFile>("cemaden_iis.json");
  const nis = useData<NisarSummary>("nisar/nisar_summary.json");
  const fs = useData<FiresSummary>("fires_summary.json");
  const man = useData<Manifest>("manifest.json");
  const people = usePeoplePosts();
  const filters = React.useMemo(() => {
    const f = { ...defaultFilters(), ...st.prefs.filters };
    // filtro salvo de Secas ou Cheias (removidos na 0.5.0) volta para "Tudo"
    if (f.category !== "all" && REMOVED_CATEGORIES.has(f.category)) f.category = "all";
    if (f.scope === "com:rios-seca") f.scope = "com:rios-enchente";
    // tipos que não existem mais no Feed (dados oficiais e análise NISAR saíram)
    f.kinds = f.kinds.filter((k) => k === "community" || k === "explainer");
    return f;
  }, [st.prefs.filters]);
  const setFilters = React.useCallback((f: Filters) => setSoft((s) => ({ ...s, prefs: { ...s.prefs, filters: f } })), []);
  const [mapContext, setMapContext] = React.useState<MapContext>();
  const [toastMsg, setToast] = React.useState<string>();
  const timer = React.useRef<number>();
  const toast = React.useCallback((m: string) => {
    setToast(m);
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setToast(undefined), 3600);
  }, []);
  // avisos que chegam fora das telas (ex.: "seu relato foi verificado")
  React.useEffect(() => {
    const f = (e: Event) => toast((e as CustomEvent<{ text: string }>).detail.text);
    window.addEventListener("igarapost:aviso", f);
    return () => window.removeEventListener("igarapost:aviso", f);
  }, [toast]);

  const hidden = st.hidden;
  const posts = React.useMemo(
    // no Feed: relatos das pessoas e os explicativos (tutoriais) da equipe
    () => [...people, ...EXPLAINERS].filter((p) => !hidden.includes(p.id) && !isRemoved(p)),
    [people, hidden],
  );
  const findPost = React.useCallback((id: string) => [...people, ...EXPLAINERS].find((p) => p.id === id), [people]);
  const author = React.useCallback(
    (p: { authorId: string; author?: Author }) => {
      if (p.author && p.authorId !== "me" && !(st.server.user && p.author.id === st.server.user.id)) return p.author;
      // a própria pessoa: nome da rede (se conectada) com a foto, frase e lugar do perfil deste aparelho
      const meServer = st.server.user ? { ...st.me, id: st.server.user.id, name: st.server.user.displayName, handle: st.server.user.handle, photo: st.me.photo ?? st.server.user.photo } : st.me;
      if (p.authorId === "me") return meServer;
      if (st.server.user && p.authorId === st.server.user.id) return meServer;
      return AUTHORS[p.authorId] || (p.authorId === "equipe" ? TEAM : { id: p.authorId, name: "Perfil desconhecido" });
    },
    [st.me, st.server.user],
  );
  const dataErrors = [cem.error, nis.error, fs.error].filter(Boolean) as string[];

  return (
    <C.Provider
      value={{ posts, findPost, author, cemaden: cem.data, cemadenFailed: !!cem.error, nisar: nis.data, fires: fs.data, manifest: man.data, filters, setFilters, mapContext, setMapContext, toast, dataErrors }}
    >
      {children}
      {toastMsg && (
        <div className="toast" role="status" aria-live="polite">
          {toastMsg}
        </div>
      )}
    </C.Provider>
  );
}
