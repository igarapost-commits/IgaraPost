from PIL import Image, ImageDraw
import numpy as np, os
BLUE = (201, 223, 236, 255)          # #C9DFEC, azul-bebê padrão do ícone
RES = '/home/claude/work/igarapost/app/android/app/src/main/res'
PUB = '/home/claude/work/igarapost/app/public'
art = Image.open('arte.png'); rmax = float(open('rmax.txt').read())
os.makedirs('saida', exist_ok=True)

def place(canvas, frac_radius, bg=None, dy=0.0):
    """Arte centrada num quadrado de lado `canvas`, cabendo num círculo de raio frac_radius*canvas."""
    s = frac_radius * canvas / rmax
    a = art.resize((max(1, round(art.width * s)), max(1, round(art.height * s))), Image.LANCZOS)
    img = Image.new('RGBA', (canvas, canvas), bg or (0, 0, 0, 0))
    img.alpha_composite(a, ((canvas - a.width) // 2, round((canvas - a.height) / 2 + dy * canvas)))
    return img

def mask(img, shape):
    n = img.width; big = 4 * n
    m = Image.new('L', (big, big), 0); d = ImageDraw.Draw(m)
    if shape == 'circle': d.ellipse((0, 0, big - 1, big - 1), fill=255)
    else: d.rounded_rectangle((0, 0, big - 1, big - 1), radius=round(big * 0.22), fill=255)
    out = img.copy(); out.putalpha(m.resize((n, n), Image.LANCZOS)); return out

# 1) ícone adaptável (Android 8+): camada da frente em 108 dp; a arte cabe no círculo seguro de 66 dp (raio 33 dp)
DENS = {'mdpi': 1, 'hdpi': 1.5, 'xhdpi': 2, 'xxhdpi': 3, 'xxxhdpi': 4}
SAFE = 31.5 / 108                  # raio da arte em relação ao lado (um pouco dentro dos 33 dp)
for d, k in DENS.items():
    n = round(108 * k)
    place(n, SAFE).save(f'{RES}/mipmap-{d}/ic_launcher_foreground.png', optimize=True)
    # 2) ícones antigos (até Android 7): quadrado arredondado e redondo, 48 dp, mesmo enquadramento (centro de 72 dp de 108)
    m = round(48 * k)
    full = place(1296, SAFE, BLUE)              # 1296 = 108*12 → corta o centro de 72 dp
    c = (1296 - 864) // 2
    vis = full.crop((c, c, c + 864, c + 864)).resize((m, m), Image.LANCZOS)
    mask(vis, 'rounded').save(f'{RES}/mipmap-{d}/ic_launcher.png', optimize=True)
    mask(vis, 'circle').save(f'{RES}/mipmap-{d}/ic_launcher_round.png', optimize=True)

# 3) tela de abertura nativa: azul-escuro liso (#041543), igual ao fundo da abertura animada do index.html
for f in sorted(os.listdir(RES)):
    p = f'{RES}/{f}/splash.png'
    if not (f.startswith('drawable') and os.path.exists(p)): continue
    w, h = Image.open(p).size
    Image.new('RGB', (w, h), (4, 21, 67)).save(p, optimize=True)

# 4) web e dentro do app
big = place(1296, SAFE, BLUE); c = (1296 - 864) // 2; vis = big.crop((c, c, c + 864, c + 864))
vis.resize((512, 512), Image.LANCZOS).convert('RGB').save('saida/icone-512-quadrado.png')            # loja/apresentação
mask(vis.resize((512, 512), Image.LANCZOS), 'rounded').save('saida/icone-512-arredondado.png')
mask(vis.resize((512, 512), Image.LANCZOS), 'circle').save('saida/icone-512-redondo.png')
place(1024, SAFE).save('saida/camada-frente-adaptavel-1024.png')
vis.resize((192, 192), Image.LANCZOS).convert('RGB').save(f'{PUB}/icon-192.png', optimize=True)
mask(vis.resize((64, 64), Image.LANCZOS), 'rounded').save(f'{PUB}/favicon.png', optimize=True)
# logo usado dentro do app (cabeçalho, avatar da equipe, Sobre nós): círculo azul-bebê sem o anel preto
cur = Image.open(f'{PUB}/igarapost-logo.png'); n = max(cur.size)
logo = place(n, 0.40, BLUE)
mask(logo, 'circle').save(f'{PUB}/igarapost-logo.png', optimize=True)
print('ok', n)
