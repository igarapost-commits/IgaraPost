# Separa a arte (árvores, nome, barco e reflexo) do fundo em degradê do logo redondo.
from PIL import Image, ImageFilter
import numpy as np
src = Image.open('/mnt/user-data/uploads/27610cb2-image.jpg').convert('RGB')
im = np.asarray(src).astype(np.float64); H, W, _ = im.shape
cx, cy, R = 539.5, 532.5, 523.5
yy, xx = np.mgrid[0:H, 0:W]; r = np.hypot(xx - cx, yy - cy)
inside = r < R - 14                       # dentro do círculo, sem o anel preto
# modelo do fundo: quadrático em x,y, ajustado só nos pixels de fundo (iterativo)
X = np.stack([np.ones_like(xx), xx, yy, xx*xx, yy*yy, xx*yy], -1).reshape(-1, 6) / np.array([1, W, H, W*W, H*H, W*H])
P = im.reshape(-1, 3)
Rc, Gc, Bc = P[:, 0], P[:, 1], P[:, 2]
m = inside.reshape(-1) & (Rc > 125) & (Rc < 215) & (Bc > 185) & (Bc - Rc > 28) & (Bc - Rc < 62) & (Gc - Rc > 18) & (Gc - Rc < 36)
print("amostras iniciais de fundo:", m.sum())
m0 = m.copy()
for it in range(6):
    coef, *_ = np.linalg.lstsq(X[m], P[m], rcond=None)
    B = X @ coef
    res = np.linalg.norm(P - B, axis=1)
    m = m0 & (res < [24, 16, 12, 10, 9, 9][it])
B = B.reshape(H, W, 3)
print("pixels de fundo usados:", m.sum(), "resíduo médio:", round(float(np.linalg.norm(P[m]-B.reshape(-1,3)[m],axis=1).mean()),2))
d = np.linalg.norm(im - B, axis=2)
a = np.clip((d - 9) / (34 - 9), 0, 1)
a[~inside] = 0
# suaviza a borda do recorte circular (a arte não encosta no anel, mas por garantia)
a *= np.clip((R - 14 - r) / 6, 0, 1)
# cor da arte "sem o fundo": F = (pix - B*(1-a)) / a
with np.errstate(divide='ignore', invalid='ignore'):
    F = (im - B * (1 - a[..., None])) / np.maximum(a[..., None], 1e-3)
F = np.clip(np.where(a[..., None] > 0.02, F, im), 0, 255)
rgba = np.dstack([F, a * 255]).astype(np.uint8)
art = Image.fromarray(rgba, 'RGBA')
ys, xs = np.nonzero(a > 0.15)
box = (xs.min(), ys.min(), xs.max() + 1, ys.max() + 1); print("caixa da arte:", box)
art = art.crop(box); art.save('arte.png')
# raio que contém toda a arte, a partir do centro da caixa (para a zona segura do ícone adaptável)
aa = np.asarray(art)[..., 3] > 38
ys, xs = np.nonzero(aa); h, w = aa.shape
rmax = np.hypot(xs - w / 2, ys - h / 2).max(); print("raio máximo da arte:", round(float(rmax), 1), "tamanho:", art.size)
open('rmax.txt', 'w').write(str(float(rmax)))
