// Monta a página única publicada no claude.ai a partir do build "artifact":
// React, ReactDOM e Leaflet vêm do cdnjs (versões fixas); CSS e JS do app ficam embutidos;
// os dados (public/data) são publicados como arquivos ao lado da página.
import { readFileSync, writeFileSync } from "node:fs";
const d = "dist-artifact/";
const css = readFileSync(d + "app.css", "utf8");
const js = readFileSync(d + "app.js", "utf8").replace(/<\/script/gi, "<\\/script");
const html = `<title>IgaraPost</title>
<meta name="claude:viewport-fit-sides" content="cover">
<meta name="description" content="Rede social de monitoramento colaborativo de queimadas e secas na Amazônia, com dados INPE, Cemaden e NISAR (protótipo).">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,800&family=Inter:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap">
<style>${css}</style>
<div id="root"></div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react/18.3.1/umd/react.production.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.3.1/umd/react-dom.production.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.js"></script>
<script>${js}</script>
`;
writeFileSync(d + "igarapost.html", html);
console.log("ok", (html.length / 1024).toFixed(0), "KB");
