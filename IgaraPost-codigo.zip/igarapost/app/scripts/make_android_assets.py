"""Gera ícones, telas de abertura e imagens web do IgaraPost a partir do logotipo oficial
(assets-src/igarapost-logo-original.png: barco no igarapé, círculo azul).
Uso: python3 scripts/make_android_assets.py   (a partir de app/)"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter

APP = Path(__file__).resolve().parent.parent
RES = APP / "android/app/src/main/res"
PUB = APP / "public"
NAVY = (10, 24, 69)          # contorno do letreiro
SKY = (201, 223, 236)        # azul-claro da borda do círculo
SPLASH_BG = (234, 243, 249)  # fundo claro da abertura

def load_logo():
    im = Image.open(APP / "assets-src/igarapost-logo-original.png").convert("RGBA")
    bbox = im.getchannel("A").point(lambda a: 255 if a > 20 else 0).getbbox()
    im = im.crop(bbox)
    s = max(im.size); sq = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    sq.paste(im, ((s - im.size[0]) // 2, (s - im.size[1]) // 2))
    return sq

LOGO = load_logo()
def logo(px): return LOGO.resize((px, px), Image.LANCZOS)

def on_canvas(size, logo_frac, bg):
    c = Image.new("RGBA", (size, size), bg)
    l = logo(int(size * logo_frac)); o = (size - l.size[0]) // 2
    c.alpha_composite(l, (o, o)); return c

def circle_mask(im):
    m = Image.new("L", im.size, 0); ImageDraw.Draw(m).ellipse([0, 0, im.size[0] - 1, im.size[1] - 1], fill=255)
    out = im.copy(); out.putalpha(m); return out

def run():
    # web
    logo(256).save(PUB / "igarapost-logo.png", optimize=True)
    logo(64).save(PUB / "favicon.png", optimize=True)
    logo(192).save(PUB / "icon-192.png", optimize=True)
    # Android: ícones legados, redondo e primeiro plano do adaptativo (108 dp, logo ~67% para caber no círculo)
    dens = {"mdpi": 1, "hdpi": 1.5, "xhdpi": 2, "xxhdpi": 3, "xxxhdpi": 4}
    for name, f in dens.items():
        m = RES / f"mipmap-{name}"
        n = int(48 * f)
        on_canvas(n, 1.0, (0, 0, 0, 0)).save(m / "ic_launcher.png")
        circle_mask(on_canvas(n, 1.0, SKY + (255,))).save(m / "ic_launcher_round.png")
        on_canvas(int(108 * f), 0.67, (0, 0, 0, 0)).save(m / "ic_launcher_foreground.png")
    (RES / "values/ic_launcher_background.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#C9DFEC</color>\n</resources>\n')
    # telas de abertura: fundo azul-claro com o logo no centro
    for p in RES.glob("drawable*/splash.png"):
        w, h = Image.open(p).size
        im = Image.new("RGBA", (w, h), SPLASH_BG + (255,))
        s = int(min(w, h) * 0.42); l = logo(s)
        sh = Image.new("RGBA", (s, s), (0, 0, 0, 0)); sh.putalpha(l.getchannel("A").point(lambda a: int(a * 0.25)))
        sh = sh.filter(ImageFilter.GaussianBlur(s * 0.03))
        im.alpha_composite(sh, ((w - s) // 2, (h - s) // 2 + int(s * 0.03)))
        im.alpha_composite(l, ((w - s) // 2, (h - s) // 2))
        im.convert("RGB").save(p)
    print("ok")

if __name__ == "__main__":
    run()
