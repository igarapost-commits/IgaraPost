import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";
const b = await chromium.launch(); const out = []; const ok = (c, n) => out.push((c ? "OK     " : "FALHOU ") + n);
const ctx = async (lang) => { const c = await b.newContext({ locale: "pt-BR", viewport: { width: 390, height: 844 } }); await c.addInitScript((l) => { sessionStorage.setItem("igarapost:semIntro", "1"); if (l) localStorage.setItem("igarapost:lang", l); }, lang); await c.route(/^https?:\/\/(?!localhost)/, (r) => r.abort()); const p = await c.newPage(); p.errs = []; p.on("pageerror", (e) => p.errs.push(e.message)); return [c, p]; };
const text = async (p, h, w = 1000) => { await p.goto("http://localhost:4175/" + h); await p.waitForTimeout(w); return (await p.textContent("main")).replace(/\s+/g, " "); };
let [c, p] = await ctx(null);
// Feed só com os tutoriais da equipe
await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(1200);
const arts = await p.$$eval("article", (as) => as.map((a) => [a.querySelector("h2,h3")?.textContent.trim(), a.querySelector(".author-name, .name, b")?.textContent.trim()]));
ok(arts.length === 2 && /Foco de calor/.test(arts[0][0]) && /radar do NISAR/.test(arts[1][0]), "Feed (sem relatos no aparelho): só os 2 tutoriais da equipe " + JSON.stringify(arts.map((a) => a[0])));
const feedTxt = await text(p, "#feed");
ok(!/exemplo|fictíci|Dados oficiais · INPE|Análise experimental NISAR|Focos de calor em/i.test(feedTxt), "Feed sem exemplos, relatos fictícios nem publicações de dados");
await p.click(".feed-bar .btn:has-text('Filtros')"); await p.waitForTimeout(300);
const orig = await p.$$eval(".sheet .row .chip", (cs) => cs.map((x) => x.textContent.trim()));
ok(JSON.stringify(orig) === '["Relatos da comunidade","Explicativos"]', "Origem da informação só com Relatos da comunidade e Explicativos " + JSON.stringify(orig));
await p.keyboard.press("Escape");
// Sobre nós, guia, Explorador NISAR: sem textos fictícios
for (const h of ["#sobre", "#como-funciona", "#nisar", "#perfil"]) { const t = await text(p, h, h === "#nisar" ? 2500 : 1000); ok(!/exemplo fictíci|perfis fictícios|Exemplos fictícios|\(exemplo\)|Perfil fictício/i.test(t), `${h}: sem textos fictícios`); }
// guia: 7 tópicos, sem o 8 e sem MyMemory
const g = await text(p, "#como-funciona");
const nTop = await p.$$eval(".howto-step", (x) => x.length);
ok(nTop === 7 && !/Sem internet e rede compartilhada|MyMemory/.test(g), `guia com ${nTop} tópicos, sem "Sem internet e rede compartilhada" e sem MyMemory`);
ok(!/Filtros: escolhe quais relatos aparecem no mapa/.test(g), "guia não fala mais do botão Filtros do mapa");
// emergência por idioma
const emPT = (await text(p, "#relatar")) + (await text(p, "#como-funciona")) + (await text(p, "#sobre"));
ok(/ligue 193 \(Bombeiros\) ou 199 \(Defesa Civil\)/.test(emPT) && !/911|112/.test(emPT), "português (Brasil): 193 Bombeiros e 199 Defesa Civil");
await c.close();
for (const [l, num, re] of [["en", "911", /call 911/], ["es", "112", /llama al 112/]]) {
  [c, p] = await ctx(l);
  const t = (await text(p, "#relatar")) + (await text(p, "#como-funciona")) + (await text(p, "#sobre"));
  const n = (t.match(new RegExp(re.source, "g")) || []).length;
  ok(n === 3 && !/193|199/.test(t), `${l === "en" ? "inglês (EUA)" : "espanhol (Espanha)"}: ${num} nos 3 avisos (Relatar, guia e Sobre nós), sem 193/199`);
  ok(p.errs.length === 0, `${l}: sem erros JS`);
  await c.close();
}
console.log(out.join("\n")); await b.close();
