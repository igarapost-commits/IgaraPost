// percorre o app num idioma e lista os textos que ficaram sem tradução
import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";
import fs from "fs";
const LANG = process.argv[2] || "en"; const OUT = process.argv[3] || `/home/claude/i18n/missing-${LANG}.json`;
const b = await chromium.launch();
const c = await b.newContext({ viewport: { width: 390, height: 860 }, geolocation: { latitude: -3.1, longitude: -60.02 }, permissions: ["geolocation"] });
await c.addInitScript((l) => { try { localStorage.setItem("igarapost:lang", l); } catch {} }, LANG);
await c.route(/^https?:\/\/(?!localhost)/, async (r) => { const u = r.request().url();
  if (u.includes("gibs")) { const png = u.endsWith(".png"); return r.fulfill({ status: 200, contentType: png ? "image/png" : "image/jpeg", headers: { "Access-Control-Allow-Origin": "*" }, body: fs.readFileSync(png ? (u.includes("NISAR") ? "/tmp/nA.png" : "/tmp/ref.png") : "/tmp/tile.jpg") }); }
  return r.abort(); });
const p = await c.newPage(); const errs = []; p.on("pageerror", (e) => errs.push(e.message)); p.on("dialog", (d) => d.dismiss());
const all = new Map(); const where = (tag) => p.evaluate(() => [...(window.__i18nMissing || [])]).then((xs) => { for (const x of xs) if (!all.has(x)) all.set(x, tag); });
const go = async (h, wait = 900) => { await p.evaluate((h) => (location.hash = h), h).catch(() => {}); await p.waitForTimeout(wait); await where(h); };
const tryClick = async (sel, wait = 350, tag = sel) => { const el = await p.$(sel); if (!el) return false; try { await el.click({ timeout: 2000 }); } catch { return false; } await p.waitForTimeout(wait); await where(tag); return true; };
await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(1500); await where("#feed");
// feed
await p.evaluate(() => scrollTo(0, 99999)); await p.waitForTimeout(500); await where("feed-fim");
await tryClick("#tema-btn"); await tryClick("#tema-btn-opcoes .chip >> nth=3", 500, "feed-enchente"); await tryClick("#tema-btn"); await tryClick("#tema-btn-opcoes .chip >> nth=0");
await tryClick(".feed-bar .btn:has-text('Filtros')"); await tryClick("#tema-filtro"); 
await p.evaluate(() => [...document.querySelectorAll(".sheet select")].forEach((s) => [...s.options].forEach(() => {}))); await where("sheet");
await p.keyboard.press("Escape"); await p.waitForTimeout(300);
// todos os posts (detalhe)
const posts = await p.evaluate(async () => { scrollTo(0, 0); return [...new Set([...document.querySelectorAll("a[href^='#post-']")].map((a) => a.getAttribute("href")))]; });
for (const h of posts) { await go(h, 700); await p.evaluate(() => scrollTo(0, 99999)); await p.waitForTimeout(250); await where(h); }
// mapa
await go("#mapa", 2500);
for (const ev of ["Fumaça", "Queimadas", "Enchentes", "Smoke", "Fires", "Floods", "Humo", "Incendios", "Inundaciones"]) await tryClick(`.event-bar .event-chip:has-text('${ev}')`, 700, "mapa-evento");
const ntools = (await p.$$(".map-tools .tool")).length;
for (let i = 0; i < ntools; i++) {
  await go("#feed", 200); await go("#mapa", 1500);
  const t = (await p.$$(".map-tools .tool"))[i]; if (!t || (await t.evaluate((e) => e.tagName === "A"))) continue;
  await t.click().catch(() => {}); await p.waitForTimeout(700); await where("mapa-tool-" + i);
  const inp = await p.$(".sheet input[type=search], .sheet input[type=text]"); if (inp) { await inp.fill("Man"); await p.waitForTimeout(600); await where("busca"); await inp.fill("zzzz"); await p.waitForTimeout(500); await where("busca-vazia"); }
  for (const cb of await p.$$(".sheet input[type=checkbox], .sheet [role=radio], .sheet .chip")) { await cb.click({ timeout: 800 }).catch(() => {}); await p.waitForTimeout(250); await where("mapa-sheet-" + i); }
}
await go("#feed", 200); await go("#mapa", 1800);
const box = await p.$(".leaflet-container"); if (box) { const bb = await box.boundingBox(); for (let k = 0; k < 6; k++) { await p.mouse.click(bb.x + bb.width * (0.3 + 0.08 * k), bb.y + bb.height * (0.45 + 0.03 * k)); await p.waitForTimeout(500); await where("mapa-clique"); } }
for (const m of await p.$$(".leaflet-marker-icon, .leaflet-interactive")) { await m.click({ timeout: 600, force: true }).catch(() => {}); await p.waitForTimeout(250); await where("mapa-marcador"); if ((all.size > 0) && Math.random() < 0) break; }
// nisar
await go("#nisar", 3500); await p.evaluate(() => scrollTo(0, 99999)); await where("#nisar");
for (const r of await p.$$("[role=radio], .segmented button, .chip, select")) { await r.click({ timeout: 800 }).catch(() => {}); await p.waitForTimeout(400); await where("nisar-controles"); }
for (const d of await p.$$("details summary")) { await d.click({ timeout: 600 }).catch(() => {}); } await where("nisar-detalhes");
// relatar (cada tipo)
for (const tipo of [0, 1, 2, 3]) {
  await go("#feed", 200); await go("#relatar", 900);
  const tiles = await p.$$(".type-tile"); if (!tiles[tipo]) continue; await tiles[tipo].click(); await p.waitForTimeout(400); await where("relatar-tipo");
  await tryClick(".compose-actions .btn.primary", 600, "relatar-passo1-vazio");
  await p.fill("textarea", "Teste automático de tradução, texto do relato.").catch(() => {});
  await tryClick(".compose-actions .btn.primary", 800, "relatar-passo2");
  for (const ch of ["Ontem", "Hoje cedo", "Personalizar", "Agora"]) await tryClick(`.time-chips .chip >> nth=${["Agora", "Hoje cedo", "Ontem", "Personalizar"].indexOf(ch)}`, 250, "relatar-hora");
  await tryClick(".compose-actions .btn.primary", 800, "relatar-sem-local");
  await tryClick("button:has-text('Usar minha localização'), button:has-text('Use my location'), button:has-text('Usar mi ubicación')", 900, "relatar-local");
  for (let k = 0; k < 4; k++) await tryClick(".compose-actions .btn.primary", 900, "relatar-passo" + (3 + k));
  await p.evaluate(() => scrollTo(0, 99999)); await where("relatar-fim");
}
// perfil
for (const h of ["#perfil", "#perfil-atividade", "#perfil-salvos", "#perfil-revisao", "#perfil-configuracoes", "#perfil-dados"]) { await go(h, 900); await p.evaluate(() => scrollTo(0, 99999)); await where(h); }
await go("#perfil", 900);
await tryClick("#meus-filtro"); for (let k = 0; k < 6; k++) { await tryClick(`#meus-filtro-opcoes .chip >> nth=${k}`, 300, "meus-filtro"); await tryClick("#meus-filtro"); }
for (const d of await p.$$("details summary")) await d.click({ timeout: 600 }).catch(() => {}); await where("meus-detalhes");
for (const btn of await p.$$("main button")) { const t = (await btn.textContent()).trim(); if (/Excluir|Delete|Eliminar|Apagar|Limpar/i.test(t)) continue; }
await tryClick("button:has-text('Editar perfil'), button:has-text('Edit profile'), button:has-text('Editar perfil')", 600, "editar-perfil"); await p.evaluate(() => scrollTo(0, 99999)); await where("editar-perfil");
await go("#perfil-configuracoes", 900);
await tryClick("button:has-text('Apagar'), button:has-text('Limpar'), button:has-text('Delete'), button:has-text('Clear'), button:has-text('Borrar')", 500, "config-apagar");
for (const h of ["#sobre", "#como-funciona", "#ajuda", "#post-naoexiste"]) { await go(h, 900); await p.evaluate(() => scrollTo(0, 99999)); await where(h); }
const title = await p.title(); all.set("__TITLE__ " + title, "title");
fs.writeFileSync(OUT, JSON.stringify([...all].map(([s, w]) => ({ s, w })), null, 1));
console.log(LANG, "faltando:", all.size, "erros JS:", errs.length, errs.slice(0, 3).join(" | "));
await b.close();
