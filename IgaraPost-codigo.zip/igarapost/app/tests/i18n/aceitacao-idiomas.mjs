import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";
import { seedReports } from "../relatos-de-teste.mjs";
const b = await chromium.launch(); const out = []; const ok = (c, n) => out.push((c ? "OK     " : "FALHOU ") + n);
const c = await b.newContext({ locale: "pt-BR", viewport: { width: 360, height: 800 }, geolocation: { latitude: -3.1, longitude: -60.02 }, permissions: ["geolocation"] });
await c.route(/^https?:\/\/(?!localhost)/, (r) => r.abort());
const p = await c.newPage(); const errs = []; p.on("pageerror", (e) => errs.push(e.message));
const nav = () => p.$$eval("nav[aria-label] a, .tabbar a", (as) => as.map((a) => a.textContent.trim()).filter(Boolean).join("|"));
// português (padrão)
await p.goto("http://localhost:4175/#perfil-configuracoes"); await p.waitForTimeout(1200);
const langs = await p.$$eval("[aria-labelledby=idioma-titulo] button", (bs) => bs.map((x) => [x.textContent.trim(), x.getAttribute("aria-checked")]));
ok(JSON.stringify(langs) === '[["Português","true"],["English","false"],["Español","false"]]' && (await p.textContent("#idioma-titulo")).trim() === "Idioma", "PT: Configurações tem Idioma com Português marcado " + JSON.stringify(langs));
ok(/Relatar/.test(await nav()) && (await p.evaluate(() => document.documentElement.lang)) === "pt-BR", "PT: app em português, lang=pt-BR " + (await nav()));
await p.screenshot({ path: "/tmp/cfg-pt.png" });
// troca para inglês tocando no botão
await Promise.all([p.waitForEvent("load"), p.click("[aria-labelledby=idioma-titulo] button:has-text('English')")]); await p.waitForTimeout(1200);
ok((await p.evaluate(() => location.hash)) === "#perfil-configuracoes" && (await p.textContent("#idioma-titulo")).trim() === "Language" && /Report/.test(await nav()) && (await p.evaluate(() => document.documentElement.lang)) === "en", "EN: tocar em English recarrega na mesma tela, já em inglês " + (await nav()));
ok((await p.$eval("[aria-labelledby=idioma-titulo] button[aria-checked=true]", (x) => x.textContent.trim())) === "English", "EN: English fica marcado");
// feed: interações depois da tradução
await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(1200);
const head0 = (await p.textContent(".feed-bar + p, .feed-count, main p.small")).trim();
await p.click("#tema-btn"); await p.waitForTimeout(150);
ok(JSON.stringify(await p.$$eval("#tema-btn-opcoes .chip", (cs) => cs.map((x) => x.textContent.trim()))) === '["All","Smoke","Fires","Floods"]', "EN: opções do tema traduzidas");
await p.click("#tema-btn-opcoes .chip:has-text('Fires')"); await p.waitForTimeout(400);
const btn = (await p.textContent("#tema-btn")).trim(); const head1 = (await p.textContent(".feed-bar + p, .feed-count, main p.small")).trim();
ok(btn === "Fires" && head1 !== head0 && /^\d+ posts? · all time$/.test(head1), `EN: depois de filtrar, o botão e a contagem continuam em inglês ("${btn}", "${head1}")`);
ok(/Published on [A-Z][a-z]{2} \d{1,2}, 2026/.test(await p.textContent("main")), "EN: datas no formato inglês (Published on Nov 14, 2026)");
await p.click("#tema-btn"); await p.click("#tema-btn-opcoes .chip:has-text('All')");
// relatar: mensagens de erro e textos do usuário
await p.goto("http://localhost:4175/#relatar"); await p.waitForTimeout(900);
await p.click(".compose-actions .btn.primary"); await p.waitForTimeout(300);
ok(/Choose the type of event\./.test(await p.textContent("main")), "EN: aviso de validação em inglês");
const userText = "Fumaça forte desde ontem à tarde, vindo do lado do ramal. Os olhos ardem e a visibilidade no rio está ruim de manhã cedo.";
await p.click(".type-tile >> nth=0"); await p.fill("textarea", userText); await p.click(".compose-actions .btn.primary"); await p.waitForTimeout(800);
ok(JSON.stringify(await p.$$eval(".time-chips .chip", (cs) => cs.map((x) => x.textContent.trim()))) === '["Now","Earlier today","Yesterday","Custom"]', "EN: atalhos de horário traduzidos");
await p.click("button:has-text('Use my location')").catch(() => {}); await p.waitForTimeout(900);
for (let i = 0; i < 5; i++) { if (!(await p.evaluate(() => location.hash)).startsWith("#relatar")) break; const bt = await p.$(".compose-actions .btn.primary"); if (!bt) break; await bt.click(); await p.waitForTimeout(900); }
await p.goto("http://localhost:4175/#perfil"); await p.waitForTimeout(1000);
const mine = await p.$$eval(".report-item .text", (ts) => ts.map((t) => t.textContent.trim()));
ok(mine.includes(userText), "EN: texto escrito pela pessoa continua em português em Meus relatos (não é traduzido)");
await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(1000);
const feedTexts = await p.$$eval("article .text", (ts) => ts.map((t) => t.textContent.trim()));
ok(feedTexts.includes(userText) && feedTexts.some((t) => /^Heat hotspot: a satellite/.test(t)), "EN: no Feed, o relato da pessoa fica original e o tutorial da equipe é traduzido");
// espanhol e volta para o português
await p.goto("http://localhost:4175/#perfil-configuracoes"); await p.waitForTimeout(800);
await Promise.all([p.waitForEvent("load"), p.click("[aria-labelledby=idioma-titulo] button:has-text('Español')")]); await p.waitForTimeout(1200);
ok((await p.textContent("#idioma-titulo")).trim() === "Idioma" && /Reportar/.test(await nav()) && (await p.evaluate(() => document.documentElement.lang)) === "es", "ES: tocar em Español deixa o app em espanhol " + (await nav()));
await p.screenshot({ path: "/tmp/cfg-es.png" });
await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(1000);
ok(/Publicado el \d{1,2} [a-z]{3,4} 2026/.test(await p.textContent("main")), "ES: datas em espanhol (Publicado el 14 nov 2026)");
await p.goto("http://localhost:4175/#perfil-configuracoes"); await p.waitForTimeout(800);
await Promise.all([p.waitForEvent("load"), p.click("[aria-labelledby=idioma-titulo] button:has-text('Português')")]); await p.waitForTimeout(1200);
ok((await p.textContent("#idioma-titulo")).trim() === "Idioma" && /Relatar/.test(await nav()) && (await p.evaluate(() => document.documentElement.lang)) === "pt-BR" && /Aparência/.test(await p.textContent("main")), "PT: voltar para Português restaura o app original");
ok(errs.length === 0, "sem erros JS " + errs.join(" | "));
console.log(out.join("\n")); await b.close();
