import { build } from "/opt/npm-tools/node_modules/esbuild/lib/main.js";
import fs from "fs";
await build({ entryPoints: ["/home/claude/work/igarapost/app/src/i18n/dom.ts"], bundle: true, format: "esm", outfile: "/tmp/i18n-dom.mjs", platform: "node", define: { "import.meta.env": "{}" }, logLevel: "error" });
const m = await import("/tmp/i18n-dom.mjs?" + Date.now());
const stat = JSON.parse(fs.readFileSync("strings-static.json"));
const pt = /[ãõçáéíóúâêôàÃÕÇÁÉÍÓÚ]|\b(de|da|do|das|dos|para|com|não|sem|um|uma|o|os|as|no|na|em|por|que|mais|até|ou|foco|focos|relato|relatos|dias|aqui|agora|ontem|hoje|toque|ver|abrir)\b/i;
for (const l of ["en", "es"]) {
  m.loadDict(l);
  const miss = [];
  for (const [s, v] of stat) {
    // valores de exemplo para os marcadores
    const sample = s.replace(/\{(\d)\}/g, (_, i) => ["12", "Manaus", "3", "4", "5", "6", "7"][i]);
    if (m.translate(sample) == null && m.translate(s) == null && pt.test(s)) miss.push([v.at, s]);
  }
  fs.writeFileSync(`static-miss-${l}.json`, JSON.stringify(miss, null, 0).replace(/\],\[/g, "],\n["));
  console.log(l, "estáticos sem tradução:", miss.length);
}
