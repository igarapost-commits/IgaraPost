import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";
const b = await chromium.launch(); const out = []; const ok = (c, n) => out.push((c ? "OK     " : "FALHOU ") + n);
const NAV = { pt: "Relatar", en: "Report", es: "Reportar" };
const open = async (locale, saved) => {
  const c = await b.newContext({ viewport: { width: 390, height: 844 }, locale });
  await c.addInitScript((s) => { if (s && !sessionStorage.getItem("x")) { localStorage.setItem("igarapost:lang", s); sessionStorage.setItem("x", "1"); } }, saved ?? null);
  await c.route(/^https?:\/\/(?!localhost)/, (r) => r.abort()); const p = await c.newPage(); p.errs = []; p.on("pageerror", (e) => p.errs.push(e.message));
  await p.goto("http://localhost:4175/#perfil-configuracoes"); await p.waitForTimeout(1400);
  return [c, p];
};
const state = (p) => p.evaluate(() => ({ html: document.documentElement.lang, nav: [...document.querySelectorAll("nav a")].map((a) => a.textContent.trim()).join("|"), marcado: document.querySelector("[aria-labelledby=idioma-titulo] [aria-checked=true]")?.textContent.trim(), credito: document.querySelector(".intro-by")?.textContent.trim() ?? null }));
const exp = { pt: ["pt-BR", "Português", "Uma realização"], en: ["en", "English", "A production by"], es: ["es", "Español", "Una realización de"] };
for (const [locale, want] of [["pt-BR", "pt"], ["pt-PT", "pt"], ["es-ES", "es"], ["es-MX", "es"], ["en-US", "en"], ["en-GB", "en"], ["fr-FR", "en"], ["de-DE", "en"], ["ja-JP", "en"], ["zh-CN", "en"]]) {
  const [c, p] = await open(locale);
  await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(150);
  await p.goto("about:blank"); await p.goto("http://localhost:4175/#perfil-configuracoes"); await p.waitForTimeout(1300);
  const s = await state(p);
  ok(s.html === exp[want][0] && s.nav.includes(NAV[want]) && s.marcado === exp[want][1] && (s.credito === null || s.credito === exp[want][2]), `celular em ${locale} → app em ${exp[want][1]} ${JSON.stringify(s)}`);
  ok(p.errs.length === 0, `${locale}: sem erros JS`);
  await c.close();
}
// a escolha em Configurações vale mais que o idioma do celular
{ const [c, p] = await open("es-ES", "pt"); const s = await state(p); ok(s.marcado === "Português" && s.nav.includes("Relatar"), "celular em espanhol com Português escolhido em Configurações → português " + JSON.stringify(s)); await c.close(); }
{ const [c, p] = await open("fr-FR");
  ok((await state(p)).marcado === "English", "celular em francês abre em inglês");
  await Promise.all([p.waitForEvent("load"), p.click("[aria-labelledby=idioma-titulo] button:has-text('Español')")]); await p.waitForTimeout(1300);
  await p.reload(); await p.waitForTimeout(1300);
  const s = await state(p); ok(s.marcado === "Español" && s.nav.includes("Reportar"), "depois de escolher Español, continua em espanhol ao abrir de novo " + JSON.stringify(s));
  await c.close(); }
console.log(out.join("\n")); await b.close();
