import ts from "/opt/node-tools/node_modules/typescript/lib/typescript.js";
import fs from "fs"; import path from "path";
const root = "/home/claude/work/igarapost/app/src";
const files = []; (function walk(d) { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) { if (f !== "i18n") walk(p); } else if (/\.(tsx?|mts)$/.test(f) && !f.endsWith(".d.ts")) files.push(p); } })(root);
// regra do React/Babel para texto JSX
function clean(str) { const lines = str.split(/\r\n|\n|\r/); let last = 0; lines.forEach((l, i) => { if (/[^ \t]/.test(l)) last = i; }); let out = "";
  lines.forEach((l0, i) => { let l = l0.replace(/\t/g, " "); if (i !== 0) l = l.replace(/^[ ]+/, ""); if (i !== lines.length - 1) l = l.replace(/[ ]+$/, ""); if (l) { if (i !== last) l += " "; out += l; } }); return out; }
const norm = (s) => s.replace(/\s+/g, " ").trim();
const out = new Map();
const add = (s, kind, f, node, sf) => { s = norm(s); if (!s || !/[A-Za-zÀ-ú]{2}/.test(s)) return;
  if (/^[\w.:/#-]+$/.test(s) && !/[À-ú]/.test(s) && !/^[A-Z][a-z]+$/.test(s)) return;
  if (/^https?:|^[a-z-]+:[a-z]|^\.|^#|^var\(|px\b|^M\d|^\{\d\}$/.test(s)) return;
  if (!out.has(s)) out.set(s, { kind, at: path.basename(f) + ":" + (sf.getLineAndCharacterOfPosition(node.getStart()).line + 1) }); };
const hasJsx = (n) => { let r = false; const v = (x) => { if (r) return; if (ts.isJsxElement(x) || ts.isJsxSelfClosingElement(x) || ts.isJsxFragment(x)) r = true; else ts.forEachChild(x, v); }; v(n); return r; };
const ATTR_SKIP = /^(className|id|href|src|role|type|name|key|htmlFor|aria-controls|aria-labelledby|aria-describedby|d|viewBox|inputMode|autoComplete|rel|target|method|accept|capture|lang|translate|style)$/;
for (const f of files) { const sf = ts.createSourceFile(f, fs.readFileSync(f, "utf8"), ts.ScriptTarget.Latest, true);
  const visit = (n) => {
    if (ts.isJsxElement(n) || ts.isJsxFragment(n)) {
      let run = "", k = 0, texts = 0;
      const flush = () => { if (texts > 1 || (texts && k)) add(run, "run", f, n, sf); else if (texts) add(run, "jsx", f, n, sf); run = ""; k = 0; texts = 0; };
      for (const ch of n.children) {
        if (ts.isJsxText(ch)) { const t = clean(ch.text); if (t) { run += t; texts++; } }
        else if (ts.isJsxExpression(ch)) { const e = ch.expression; if (!e) continue;
          if (ts.isStringLiteral(e) || ts.isNoSubstitutionTemplateLiteral(e)) { run += e.text; if (/[A-Za-zÀ-ú]/.test(e.text)) texts++; }
          else if (hasJsx(e)) flush(); else run += "{" + k++ + "}"; }
        else flush();
      }
      flush();
    } else if (ts.isStringLiteral(n) || ts.isNoSubstitutionTemplateLiteral(n)) { const p = n.parent; if (!(ts.isImportDeclaration(p) || ts.isExportDeclaration(p)) && !(ts.isJsxAttribute(p) && ATTR_SKIP.test(p.name.getText())) && !ts.isElementAccessExpression(p) && !(ts.isJsxExpression(p) && p.parent && (ts.isJsxElement(p.parent) || ts.isJsxFragment(p.parent)))) add(n.text, "str", f, n, sf); }
    else if (ts.isTemplateExpression(n)) { let s = n.head.text; n.templateSpans.forEach((sp, i) => { s += "{" + i + "}" + sp.literal.text; }); add(s, "tpl", f, n, sf); }
    ts.forEachChild(n, visit); };
  visit(sf); }
const pt = /[ãõçáéíóúâêôà]|\b(de|da|do|das|dos|para|com|não|sem|um|uma|e|o|a|os|as|no|na|em|por|que|mais|ver|abrir|fechar|salvar|todos|tudo|até|ou)\b/i;
const keep = [...out].filter(([s]) => pt.test(s) || /^[A-ZÁÉÍÓÚ][a-zà-ú]+( [a-zà-ú]+)*$/.test(s));
fs.writeFileSync("strings-static.json", JSON.stringify(keep, null, 1));
console.log("total", out.size, "keep", keep.length, "runs", keep.filter(([, v]) => v.kind === "run").length, "chars", keep.reduce((a, [s]) => a + s.length, 0));
const by = {}; keep.forEach(([s, v]) => { const f = v.at.split(":")[0]; (by[f] = by[f] || []).push((v.kind === "run" ? "R " : v.kind === "tpl" ? "T " : "") + s); }); fs.writeFileSync("byfile.json", JSON.stringify(by));
console.log(Object.fromEntries(Object.entries(by).map(([k, v]) => [k, v.length])));
