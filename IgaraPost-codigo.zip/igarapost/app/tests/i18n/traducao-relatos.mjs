import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";
import { seedReports } from "../relatos-de-teste.mjs";
const b = await chromium.launch(); const out = []; const ok = (c, n) => out.push((c ? "OK     " : "FALHOU ") + n);
const reqs = []; let mode = "ok";
async function ctx(lang) {
  const c = await b.newContext({ locale: "pt-BR", viewport: { width: 360, height: 800 }, geolocation: { latitude: -3.1, longitude: -60.02 }, permissions: ["geolocation"] });
  if (lang) await c.addInitScript((l) => { try { localStorage.setItem("igarapost:lang", l); } catch {} }, lang);
  await c.route(/^https?:\/\/(?!localhost)/, async (r) => { const u = new URL(r.request().url());
    if (u.hostname === "api.mymemory.translated.net") { reqs.push({ q: u.searchParams.get("q"), lp: u.searchParams.get("langpair") });
      if (mode === "offline") return r.abort();
      if (mode === "limit") return r.fulfill({ status: 200, contentType: "application/json", headers: { "Access-Control-Allow-Origin": "*" }, body: JSON.stringify({ responseStatus: 429, responseData: { translatedText: "MYMEMORY WARNING: YOU USED ALL AVAILABLE FREE TRANSLATIONS FOR TODAY" } }) });
      return r.fulfill({ status: 200, contentType: "application/json", headers: { "Access-Control-Allow-Origin": "*" }, body: JSON.stringify({ responseStatus: 200, responseData: { translatedText: "[" + u.searchParams.get("langpair") + "] " + u.searchParams.get("q").replace(/'/g, "&#39;") } }) }); }
    return r.abort(); });
  const p = await c.newPage(); p.errs = []; p.on("pageerror", (e) => p.errs.push(e.message)); return [c, p];
}
// ---------- português ----------
let [c, p] = await ctx(null);
await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(1200);
await p.click(".feed-bar .btn:has-text('Filtros')"); await p.waitForTimeout(300);
ok(!(await p.$("#f-examples")) && !/Mostrar exemplos/.test(await p.textContent(".sheet")), "PT: Filtros sem a opção 'Mostrar exemplos fictícios'");
await p.keyboard.press("Escape"); await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(800);
ok((await p.$$("article .badge.example")).length === 0 && !/Exemplo fictício|\(exemplo\)/.test(await p.textContent("main")), "PT: nenhum exemplo fictício no Feed");
ok((await p.$$(".tr-btn")).length === 0, "PT: relatos em português não mostram 'Ver tradução'");
await p.goto("http://localhost:4175/#perfil-configuracoes"); await p.waitForTimeout(800);
const idiomaSec = await p.$eval("section[aria-labelledby=idioma-titulo]", (s) => s.textContent.replace(/\s+/g, " ").trim());
ok(idiomaSec.replace(/ /g, "") === "IdiomaPortuguêsEnglishEspañol", "PT: seção Idioma sem o texto explicativo (" + idiomaSec + ")");
// cria um relato em português e um comentário em espanhol (feitos pela pessoa)
await p.goto("http://localhost:4175/#relatar"); await p.waitForTimeout(800);
const ptReport = "Fumaça muito forte perto da escola desde cedo, as crianças estão tossindo. Não dá para ver o outro lado do rio.";
await p.click(".type-tile >> nth=0"); await p.fill("textarea", ptReport); await p.click(".compose-actions .btn.primary"); await p.waitForTimeout(700);
await p.click("button:has-text('Usar minha localização')").catch(() => {}); await p.waitForTimeout(900);
for (let i = 0; i < 5; i++) { if (!(await p.evaluate(() => location.hash)).startsWith("#relatar")) break; const bt = await p.$(".compose-actions .btn.primary"); if (!bt) break; await bt.click(); await p.waitForTimeout(900); }
const myPost = await p.evaluate(() => { const x = (() => { const s = JSON.parse(localStorage.getItem("igarapost:v2")); const all = [...s.posts, ...s.outbox.filter((o) => o.op === "createPost").map((o) => o.post), ...s.server.posts.filter((q) => q.mine)]; return all.sort((a, b) => Date.parse(b.publishedAt) - Date.parse(a.publishedAt))[0]; })(); return x && { id: x.id, lang: x.lang }; });
ok(myPost && myPost.lang === "pt", "relato novo guarda o idioma em que foi escrito: " + JSON.stringify(myPost));
await p.goto("http://localhost:4175/#post-" + myPost.id); await p.waitForTimeout(900);
const esComment = "Aquí también hay mucho humo desde ayer, cerca del río. Los niños tienen tos.";
await p.fill(".comments textarea, textarea", esComment); await p.click("button:has-text('Comentar')"); await p.waitForTimeout(800);
const enComment = "Same here, the smoke is very strong near the river.";
await p.fill(".comments textarea, textarea", enComment); await p.click("button:has-text('Comentar')"); await p.waitForTimeout(800);
const stored = await p.evaluate(() => { const s = JSON.parse(localStorage.getItem("igarapost:v2")); return [...s.comments, ...s.outbox.filter((o) => o.op === "createComment").map((o) => o.comment), ...Object.values(s.server.comments).flatMap((c) => c.list)].map((c) => [c.lang, c.text.slice(0, 12)]); });
ok(JSON.stringify(stored.map((x) => x[0]).sort()) === '["en","es"]', "comentários guardam o idioma: " + JSON.stringify(stored));
const ptBtns = await p.$$eval(".tr-btn", (bs) => bs.map((x) => x.closest(".panel, article")?.textContent.slice(0, 40)));
ok(ptBtns.length === 2, "PT: só os comentários em espanhol e inglês têm 'Ver tradução' (" + ptBtns.length + ")");
reqs.length = 0;
await p.click(".tr-btn >> nth=0"); await p.waitForTimeout(500);
const shownPt = await p.$$eval("[translate=no]", (ps) => ps.map((x) => x.textContent.trim()).filter((t) => t.startsWith("[")));
ok(reqs.length === 1 && reqs[0].lp === "es-ES|pt-BR" && shownPt.some((t) => t.startsWith("[es-ES|pt-BR] Aquí también")) && /Ver original/.test(await p.textContent(".tr-btn >> nth=0")), "PT: 'Ver tradução' traduz o comentário em espanhol (es→pt) e vira 'Ver original' " + JSON.stringify(reqs));
await p.click(".tr-btn >> nth=0"); await p.waitForTimeout(200);
ok((await p.$$eval("[translate=no]", (ps) => ps.map((x) => x.textContent.trim()))).includes(esComment), "PT: 'Ver original' volta ao texto escrito");
await p.click(".tr-btn >> nth=0"); await p.waitForTimeout(300);
ok(reqs.length === 1, "segunda vez usa a tradução guardada (sem nova consulta)");
await c.close();
// ---------- inglês ----------
[c, p] = await ctx("en");
await seedReports(p); await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(1200);
const exampleOrig = "Céu cinza e cheiro de queimado na Zona Leste logo cedo. Quem tem asma em casa, atenção.";
const texts = await p.$$eval("article .text", (ts) => ts.map((t) => t.textContent.trim()));
ok(texts.includes(exampleOrig) && texts.some((t) => t.startsWith("Heat hotspot: a satellite")), "EN: relato em português fica original; tutorial da equipe é traduzido pelo app");
const art0 = p.locator("article", { hasText: "Céu cinza e cheiro de queimado" }).first();
await art0.evaluate((a) => a.setAttribute("data-t", "ex"));
const art = p.locator("article[data-t=ex]");
ok((await art.locator(".tr-btn").count()) === 1 && (await p.locator("article", { hasText: "Heat hotspot: a satellite" }).first().locator(".tr-btn").count()) === 0, "EN: botão 'See translation' só no relato, não no tutorial da equipe");
reqs.length = 0;
await art.locator(".tr-btn").click(); await p.waitForTimeout(500);
const exTr = (await art.locator(".text").textContent()).trim();
const note = await art.locator(".tr-row").textContent();
ok(exTr.startsWith("[pt-BR|en-US] Céu cinza") && reqs.length === 1 && /Automatic translation/.test(note) && !/MyMemory/.test(note), "EN: tradução automática, sem o nome do serviço na tela (" + note.trim() + ")");
await p.screenshot({ path: "/tmp/tr-en-feed.png", clip: { x: 0, y: 0, width: 360, height: 800 } });
ok((await art.locator(".tr-btn").textContent()).includes("See original"), "EN: botão vira 'See original'");
// relato da pessoa em português (cria) → MyMemory pt→en
await p.goto("http://localhost:4175/#relatar"); await p.waitForTimeout(800);
const longPt = ("Fumaça forte desde ontem perto do porto e da escola da comunidade, com cheiro de queimado muito forte. ").repeat(9).trim();
await p.click(".type-tile >> nth=0"); await p.fill("textarea", longPt.slice(0, 990)); await p.click(".compose-actions .btn.primary"); await p.waitForTimeout(700);
await p.click("button:has-text('Use my location')").catch(() => {}); await p.waitForTimeout(900);
for (let i = 0; i < 5; i++) { if (!(await p.evaluate(() => location.hash)).startsWith("#relatar")) break; const bt = await p.$(".compose-actions .btn.primary"); if (!bt) break; await bt.click(); await p.waitForTimeout(900); }
const id2 = await p.evaluate(() => (() => { const s = JSON.parse(localStorage.getItem("igarapost:v2")); const all = [...s.posts, ...s.outbox.filter((o) => o.op === "createPost").map((o) => o.post), ...s.server.posts.filter((q) => q.mine)]; return all.sort((a, b) => Date.parse(b.publishedAt) - Date.parse(a.publishedAt))[0]; })().id);
await p.goto("http://localhost:4175/#post-" + id2); await p.waitForTimeout(900);
reqs.length = 0; mode = "ok";
await p.click("article .tr-btn"); await p.waitForTimeout(800);
const maxBytes = Math.max(...reqs.map((r) => Buffer.byteLength(r.q)));
ok(reqs.length >= 2 && reqs.every((r) => r.lp === "pt-BR|en-US") && maxBytes <= 500 && /Automatic translation/.test(await p.textContent("article")) && !/MyMemory/.test(await p.textContent("article")), `EN: texto longo traduzido em ${reqs.length} partes de até ${maxBytes} bytes (limite do serviço: 500)`);
// erros
await p.click("article .tr-btn"); await p.evaluate(() => localStorage.removeItem("igarapost:traducoes"));
await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(300); await p.goto("http://localhost:4175/#post-" + id2); await p.waitForTimeout(800);
await p.reload(); await p.waitForTimeout(1200);
mode = "limit"; await p.click("article .tr-btn"); await p.waitForTimeout(600);
ok(/Daily translation limit reached/.test(await p.textContent("article")), "EN: limite diário do serviço mostra aviso claro");
mode = "offline"; await p.click("article .tr-btn"); await p.waitForTimeout(600);
ok(/No internet: translation needs a connection/.test(await p.textContent("article")), "EN: sem internet mostra aviso claro");
mode = "ok";
ok(p.errs.length === 0, "EN: sem erros JS " + p.errs.join("|"));
await c.close();
// ---------- espanhol: relato em português ----------
[c, p] = await ctx("es");
await seedReports(p); await p.goto("http://localhost:4175/#post-t-ramal"); await p.waitForTimeout(1200);
const cm = p.locator("article").first();
ok((await cm.locator(".tr-btn").count()) === 1 && /Ver traducción/.test(await cm.locator(".tr-btn").textContent()), "ES: relato em português fica original, com 'Ver traducción'");
reqs.length = 0; await cm.locator(".tr-btn").click(); await p.waitForTimeout(500);
ok(reqs.length === 1 && reqs[0].lp === "pt-BR|es-ES" && /Traducción automática/.test(await cm.textContent()) && !/MyMemory/.test(await cm.textContent()), "ES: tradução pt→es " + JSON.stringify(reqs));
await p.screenshot({ path: "/tmp/tr-es-comment.png", fullPage: false });
ok(p.errs.length === 0, "ES: sem erros JS " + p.errs.join("|"));
await c.close();
console.log(out.join("\n")); await b.close();
