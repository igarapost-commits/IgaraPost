// Supabase simulado para testes: Auth (anônimo), PostgREST (subconjunto) e Storage, executando tudo num
// PostgreSQL de verdade com o script supabase/igarapost-v10.sql (RLS, gatilhos e funções reais).
import http from "node:http";
import { execFile } from "node:child_process";
import crypto from "node:crypto";

const PORT = Number(process.env.PORT || 54321);
const KEY = process.env.SB_KEY || "sb_publishable_teste";
const DB = process.env.DB || "sbmock";
const TTL = Number(process.env.TTL || 3600); // validade do token (s)
const ANON = process.env.ANON !== "0";
const log = [];

const psql = (sql) =>
  new Promise((res) => {
    execFile("psql", ["-h", "/tmp/pg", "-p", "5433", "-U", "postgres", "-d", DB, "-X", "-q", "-At", "-v", "ON_ERROR_STOP=1", "-v", "VERBOSITY=verbose", "-c", sql], { maxBuffer: 64 << 20 }, (err, out, errout) => {
      if (err) {
        const m = /ERROR:\s+([0-9A-Z]{5}):\s+(.*)/.exec(errout || "") || [];
        return res({ error: { code: m[1] || "XX000", message: (m[2] || errout || String(err)).trim() } });
      }
      res({ out: out.trim() });
    });
  });
const lit = (v) => {
  const tag = "q" + crypto.randomBytes(4).toString("hex");
  return `$${tag}$${v}$${tag}$`;
};
const ident = (s) => {
  if (!/^[a-z_][a-z0-9_]*$/.test(s)) throw Object.assign(new Error("bad ident " + s), { http: 400 });
  return `"${s}"`;
};

/* ---------- tokens ---------- */
const b64 = (o) => Buffer.from(JSON.stringify(o)).toString("base64url");
const refresh = new Map(); // refresh_token -> user id
const tokens = new Map(); // access_token -> {sub, exp}
function issue(sub) {
  const exp = Math.floor(Date.now() / 1000) + TTL;
  const access = `${b64({ alg: "HS256", typ: "JWT" })}.${b64({ sub, exp, role: "authenticated", is_anonymous: true })}.${crypto.randomBytes(16).toString("base64url")}`;
  const rt = crypto.randomBytes(12).toString("hex");
  tokens.set(access, { sub, exp });
  refresh.set(rt, sub);
  return { access_token: access, token_type: "bearer", expires_in: TTL, expires_at: exp, refresh_token: rt, user: { id: sub, role: "authenticated", is_anonymous: true } };
}

const files = new Map(); // "bucket/path" -> {type, data}

function send(r, status, body, headers = {}) {
  const h = { "Access-Control-Allow-Origin": "*", ...headers };
  if (body === undefined) {
    r.writeHead(status, h);
    return r.end();
  }
  if (Buffer.isBuffer(body)) {
    r.writeHead(status, h);
    return r.end(body);
  }
  r.writeHead(status, { "Content-Type": "application/json", ...h });
  r.end(JSON.stringify(body));
}
const pgStatus = (code, authed) =>
  ({ "23505": 409, "42501": authed ? 403 : 401, "23514": 400, "22P02": 400, "23502": 400, P0001: 400, P0002: 400, "22023": 400, "42P01": 404, "23503": 409 })[code] ?? 400;

function where(params) {
  const cl = [];
  for (const [k, v] of params) {
    if (["select", "order", "limit", "offset"].includes(k)) continue;
    const m = /^(eq|neq|gt|lt|gte|lte)\.(.*)$/s.exec(v);
    if (!m) throw Object.assign(new Error("filtro não suportado " + v), { http: 400 });
    const op = { eq: "=", neq: "<>", gt: ">", lt: "<", gte: ">=", lte: "<=" }[m[1]];
    cl.push(`${ident(k)}::text ${op} ${lit(m[2])}`);
  }
  return cl.length ? " where " + cl.join(" and ") : "";
}
const orderBy = (p) => {
  const o = p.get("order");
  if (!o) return "";
  return " order by " + o.split(",").map((x) => {
    const [c, d] = x.split(".");
    return `${ident(c)} ${d === "desc" ? "desc" : "asc"}`;
  }).join(", ");
};
const cols = (p) => {
  const s = p.get("select") || "*";
  return s === "*" ? "*" : s.split(",").map(ident).join(", ");
};

async function run(sub, stmt) {
  const pre = sub
    ? `begin; set local role authenticated; set local request.jwt.claim.sub = '${sub.replace(/[^0-9a-f-]/g, "")}';\n`
    : `begin; set local role anon;\n`;
  return psql(`${pre}${stmt}; commit;`);
}

http
  .createServer(async (q, r) => {
    const chunks = [];
    for await (const c of q) chunks.push(c);
    const raw = Buffer.concat(chunks);
    const url = new URL(q.url, "http://x");
    if (q.method === "OPTIONS")
      return send(r, 204, undefined, {
        "Access-Control-Allow-Methods": "GET,POST,PATCH,PUT,DELETE,OPTIONS",
        "Access-Control-Allow-Headers": "apikey,authorization,content-type,prefer,x-upsert,cache-control,x-client-info",
        "Access-Control-Max-Age": "600",
      });
    log.push(`${q.method} ${url.pathname}`);
    if (url.pathname === "/__log") return send(r, 200, log.splice(0));
    if (url.pathname === "/__files") return send(r, 200, [...files.keys()]);
    // arquivos públicos não exigem chave
    const pub = /^\/storage\/v1\/object\/public\/([^/]+)\/(.+)$/.exec(url.pathname);
    if (pub && q.method === "GET") {
      const f = files.get(pub[1] + "/" + decodeURIComponent(pub[2]));
      return f ? send(r, 200, f.data, { "Content-Type": f.type }) : send(r, 400, { statusCode: "404", error: "not_found", message: "Object not found" });
    }
    if (q.headers.apikey !== KEY) return send(r, 401, { message: "Invalid API key", hint: "Double check your Supabase `anon` or `service_role` API key." });
    const auth = q.headers.authorization || "";
    if (/^Bearer sb_/.test(auth)) return send(r, 401, { message: "Invalid JWT" });
    let sub;
    if (auth.startsWith("Bearer ")) {
      const t = tokens.get(auth.slice(7));
      if (!t) return send(r, 401, { code: "PGRST301", message: "JWT could not be decoded" });
      if (t.exp < Date.now() / 1000) return send(r, 401, { code: "PGRST303", message: "JWT expired" });
      sub = t.sub;
    }
    let body;
    try {
      body = raw.length && (q.headers["content-type"] || "").includes("json") ? JSON.parse(raw.toString()) : undefined;
    } catch {
      return send(r, 400, { message: "bad json" });
    }
    try {
      /* ---------------- auth ---------------- */
      if (url.pathname === "/auth/v1/signup" && q.method === "POST") {
        if (body?.email || body?.phone) return send(r, 400, { msg: "só anônimo no simulador" });
        if (!ANON) return send(r, 422, { code: 422, error_code: "anonymous_provider_disabled", msg: "Anonymous sign-ins are disabled" });
        const x = await psql(`insert into auth.users default values returning id`);
        if (x.error) return send(r, 500, x.error);
        return send(r, 200, issue(x.out));
      }
      if (url.pathname === "/auth/v1/token" && url.searchParams.get("grant_type") === "refresh_token") {
        const u = refresh.get(body?.refresh_token);
        if (!u) return send(r, 400, { code: 400, error_code: "refresh_token_not_found", msg: "Invalid Refresh Token: Refresh Token Not Found" });
        refresh.delete(body.refresh_token);
        return send(r, 200, issue(u));
      }
      /* ---------------- storage ---------------- */
      const so = /^\/storage\/v1\/object\/([^/]+)\/(.+)$/.exec(url.pathname);
      if (so) {
        const bucket = so[1], name = decodeURIComponent(so[2]);
        if (!sub) return send(r, 400, { statusCode: "403", error: "Unauthorized", message: "new row violates row-level security policy" });
        if (q.method === "POST") {
          const b = await psql(`select coalesce(file_size_limit,0) || '|' || array_to_string(allowed_mime_types, ',') from storage.buckets where id = ${lit(bucket)}`);
          if (!b.out) return send(r, 400, { statusCode: "404", error: "Bucket not found", message: "Bucket not found" });
          const [lim, mimes] = b.out.split("|");
          const type = (q.headers["content-type"] || "").split(";")[0];
          if (Number(lim) && raw.length > Number(lim)) return send(r, 400, { statusCode: "413", error: "Payload too large", message: "The object exceeded the maximum allowed size" });
          if (mimes && !mimes.split(",").includes(type)) return send(r, 400, { statusCode: "415", error: "invalid_mime_type", message: `mime type ${type} is not supported` });
          if (files.has(bucket + "/" + name)) return send(r, 400, { statusCode: "409", error: "Duplicate", message: "The resource already exists" });
          const x = await run(sub, `insert into storage.objects (bucket_id, name) values (${lit(bucket)}, ${lit(name)})`);
          if (x.error) return send(r, 400, { statusCode: "403", error: "Unauthorized", message: x.error.message });
          files.set(bucket + "/" + name, { type, data: raw });
          return send(r, 200, { Key: `${bucket}/${name}`, Id: crypto.randomUUID() });
        }
        if (q.method === "DELETE") {
          const x = await run(sub, `with d as (delete from storage.objects where bucket_id = ${lit(bucket)} and name = ${lit(name)} returning 1) select count(*) from d`);
          if (x.error) return send(r, 400, { statusCode: "403", error: "Unauthorized", message: x.error.message });
          if (x.out === "1") files.delete(bucket + "/" + name);
          return send(r, x.out === "1" ? 200 : 400, x.out === "1" ? { message: "Successfully deleted" } : { statusCode: "404", error: "not_found", message: "Object not found" });
        }
      }
      /* ---------------- rest ---------------- */
      const rpc = /^\/rest\/v1\/rpc\/([a-z_]+)$/.exec(url.pathname);
      if (rpc && q.method === "POST") {
        const args = Object.entries(body || {}).map(([k, v]) => `${ident(k)} => ${lit(String(v))}`).join(", ");
        const rs = await psql(`select proretset from pg_proc where proname = ${lit(rpc[1])} and pronamespace = 'public'::regnamespace`);
        const x = await run(sub, rs.out === "t" ? `select coalesce(json_agg(x), '[]') from ${ident(rpc[1])}(${args}) x` : `select coalesce(to_json(${ident(rpc[1])}(${args})), 'null')`);
        if (x.error) return send(r, pgStatus(x.error.code, !!sub), x.error);
        return send(r, 200, JSON.parse(x.out || "null"));
      }
      const rel = /^\/rest\/v1\/([a-z_]+)$/.exec(url.pathname);
      if (!rel) return send(r, 404, { message: "rota não simulada" });
      const t = ident(rel[1]);
      const p = url.searchParams;
      const rep = /return=representation/.test(q.headers.prefer || "");
      let stmt;
      if (q.method === "GET") {
        const lim = p.get("limit") ? ` limit ${Number(p.get("limit"))}` : "";
        stmt = `select coalesce(json_agg(x), '[]') from (select ${cols(p)} from public.${t}${where(p)}${orderBy(p)}${lim}) x`;
      } else if (q.method === "POST") {
        const keys = Object.keys(body || {}).map(ident);
        stmt = `with x as (insert into public.${t} (${keys.join(",")}) select ${keys.join(",")} from json_populate_record(null::public.${t}, ${lit(JSON.stringify(body))}) returning *) select coalesce(json_agg(x), '[]') from x`;
      } else if (q.method === "PATCH") {
        const sets = Object.keys(body || {}).map((k) => `${ident(k)} = j.${ident(k)}`).join(", ");
        stmt = `with j as (select * from json_populate_record(null::public.${t}, ${lit(JSON.stringify(body))})), x as (update public.${t} set ${sets} from j${where(p).replace(" where ", " where ").replace(/"([a-z_]+)"::text/g, `public.${t}."$1"::text`)} returning public.${t}.*) select coalesce(json_agg(x), '[]') from x`;
      } else if (q.method === "DELETE") {
        stmt = `with x as (delete from public.${t}${where(p)} returning *) select coalesce(json_agg(x), '[]') from x`;
      } else return send(r, 405, { message: "método" });
      const x = await run(sub, stmt);
      if (x.error) return send(r, pgStatus(x.error.code, !!sub), { code: x.error.code, message: x.error.message, details: null, hint: null });
      if (q.method === "GET") return send(r, 200, JSON.parse(x.out));
      if (rep) return send(r, q.method === "POST" ? 201 : 200, JSON.parse(x.out));
      return send(r, q.method === "POST" ? 201 : 204, undefined);
    } catch (e) {
      return send(r, e.http || 500, { message: String(e.message || e) });
    }
  })
  .listen(PORT, () => console.log("supabase simulado em", PORT));
