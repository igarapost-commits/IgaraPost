#!/bin/sh
# recria o banco do simulador: imitação de auth/storage + script real do IgaraPost
P="psql -h /tmp/pg -p 5433 -U postgres -q -X"
$P -c "drop database if exists ${DB:-sbmock}" -c "create database ${DB:-sbmock}" >/dev/null
sed '/create role/d' "$(dirname "$0")/imitacao-auth-storage.sql" | $P -d ${DB:-sbmock} -v ON_ERROR_STOP=1 >/dev/null
$P -d ${DB:-sbmock} -c "alter table storage.objects add unique (bucket_id, name)" >/dev/null
$P -d ${DB:-sbmock} -v ON_ERROR_STOP=1 -f "$(dirname "$0")/../../../supabase/igarapost-v10.sql" 2>&1 | grep -v NOTICE
