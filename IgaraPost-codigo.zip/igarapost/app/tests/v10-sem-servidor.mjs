// IgaraPost 10 · primeira abertura sem acesso ao servidor; depois o servidor aparece.
import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";
import { execFileSync } from "node:child_process";
const b = await chromium.launch(); const out = []; const ok = (c, n) => { out.push((c ? "OK     " : "FALHOU ") + n); console.log((c ? "OK     " : "FALHOU ") + n); };
const sql = (q) => execFileSync("psql", ["-h", "/tmp/pg", "-p", "5433", "-U", "postgres", "-d", "sbmock", "-At", "-c", q]).toString().trim();
const waitFor = async (fn, ms = 9000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return true; await new Promise((r) => setTimeout(r, 250)); } return false; };
const mode = process.argv[2] || "sem-servidor";
const c = await b.newContext({ viewport: { width: 390, height: 844 }, locale: "pt-BR" });
await c.route(/^https?:\/\/(?!localhost)/, (r) => r.abort());
const block = (r) => r.abort();
if (mode === "sem-servidor") await c.route("http://localhost:54321/**", block);
const p = await c.newPage(); p.errs = []; p.on("pageerror", (e) => p.errs.push(e.message));
await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(1800);
ok(!(await p.evaluate(() => localStorage.getItem("igarapost:sessao"))), `${mode}: sem conta ainda`);
await p.goto("http://localhost:4175/#perfil-configuracoes"); await p.waitForTimeout(400);
ok((await p.textContent("section[aria-labelledby=rede-titulo]")).includes("Conectando…"), `${mode}: Configurações mostra “Conectando…”`);
await p.goto("http://localhost:4175/#relatar"); await p.waitForTimeout(600);
await p.click(".type-tile:has-text('Fumaça')"); await p.fill("#c-text", "Fumaça na estrada, visibilidade baixa no km 20.");
await p.click("button:has-text('Continuar')"); await p.waitForTimeout(250);
await p.click("text=Digitar coordenadas").catch(() => {}); await p.getByLabel("Latitude").fill("-3.2"); await p.getByLabel("Longitude").fill("-60.1");
await p.click("button:has-text('Continuar')"); await p.waitForTimeout(250);
ok((await p.textContent(".compose-actions .btn.primary")).trim() === "Relatar", `${mode}: mesmo sem conta, o relato vai para a rede`);
await p.click(".compose-actions .btn.primary"); await p.waitForTimeout(800);
const q = await p.evaluate(() => JSON.parse(localStorage.getItem("igarapost:v2")).outbox);
ok(q.length === 1 && q[0].op === "createPost", `${mode}: relato na fila de envio`);
ok((await p.textContent("main")).includes("Fumaça na estrada"), `${mode}: o relato já aparece no aparelho`);
const pid = q[0].post.id;
await p.fill("#comment-text", "Complemento: piorou às 9h."); await p.click("button:has-text('Comentar') >> nth=-1"); await p.waitForTimeout(300);
ok((await p.evaluate(() => JSON.parse(localStorage.getItem("igarapost:v2")).outbox.length)) === 2, `${mode}: comentário também vai para a fila`);
if (mode === "sem-servidor") {
  await c.unroute("http://localhost:54321/**", block);
  await p.evaluate(() => window.dispatchEvent(new Event("online")));
  ok(await waitFor(() => sql(`select count(*) from posts where id='${pid}'`) === "1" && sql(`select count(*) from comments where post_id='${pid}'`) === "1"), "servidor alcançável: a conta é criada e a fila sai sozinha, na ordem");
  ok(await waitFor(async () => (await p.evaluate(() => JSON.parse(localStorage.getItem("igarapost:v2")).outbox.length)) === 0), "fila vazia");
} else {
  await p.waitForTimeout(1500);
  ok(sql(`select count(*) from posts`) === "0", "anônimo desligado: nada é enviado, nada se perde (fica na fila)");
}
ok(p.errs.length === 0, `${mode}: sem erros de JavaScript ${p.errs.join(" | ")}`);
console.log("\n" + out.filter((x) => x.startsWith("FALHOU")).length + " falha(s) de " + out.length);
await b.close();
