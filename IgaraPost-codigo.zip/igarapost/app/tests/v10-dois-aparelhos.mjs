// IgaraPost 10 · dois aparelhos + moderação, contra o Supabase simulado (Postgres real com o script).
import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";
import { execFileSync } from "node:child_process";
const b = await chromium.launch(); const out = []; const ok = (c, n) => { out.push((c ? "OK     " : "FALHOU ") + n); console.log((c ? "OK     " : "FALHOU ") + n); };
const SB = "http://localhost:54321";
const sql = (q) => execFileSync("psql", ["-h", "/tmp/pg", "-p", "5433", "-U", "postgres", "-d", "sbmock", "-At", "-c", q]).toString().trim();
async function device(name, locale = "pt-BR") {
  const c = await b.newContext({ viewport: { width: 390, height: 844 }, locale });
  await c.route(/^https?:\/\/(?!localhost)/, (r) => r.abort());
  const p = await c.newPage(); p.errs = []; p.on("pageerror", (e) => p.errs.push(e.message));
  p.on("console", (m) => m.type() === "error" && !/Failed to load resource|ERR_FAILED/.test(m.text()) && p.errs.push("console: " + m.text()));
  await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(1800);
  p.label = name; return [c, p];
}
const sess = (p) => p.evaluate(() => JSON.parse(localStorage.getItem("igarapost:sessao") || "null"));
const st = (p) => p.evaluate(() => JSON.parse(localStorage.getItem("igarapost:v2") || "null"));
const waitFor = async (fn, ms = 8000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return true; await new Promise((r) => setTimeout(r, 250)); } return false; };

/* ---------- A: entra sozinho e publica com foto ---------- */
const [ca, A] = await device("A");
const sa = await sess(A);
ok(!!sa?.user_id && sa.url === SB, "A: entrou sozinho na rede (conta anônima), sem tela de login");
ok(sql(`select count(*) from profiles where id='${sa?.user_id}'`) === "1", "A: perfil criado no banco");
await A.goto("http://localhost:4175/#perfil-configuracoes"); await A.waitForTimeout(500);
ok((await A.textContent("section[aria-labelledby=rede-titulo]")).includes("Conectado"), "A: Configurações mostra “Conectado”");
await A.goto("http://localhost:4175/#relatar"); await A.waitForTimeout(600);
await A.click(".type-tile:has-text('Fumaça')");
await A.fill("#c-text", "Fumaça forte no bairro desde cedo, cheiro de queimado.");
await A.click("button:has-text('Continuar')"); await A.waitForTimeout(300);
await A.click("text=Digitar coordenadas").catch(() => {}); await A.getByLabel("Latitude").fill("-3.10"); await A.getByLabel("Longitude").fill("-60.02"); await A.waitForTimeout(300);
await A.click("button:has-text('Continuar')"); await A.waitForTimeout(300);
await A.setInputFiles("#c-photo", "/tmp/foto-teste.jpg"); await A.waitForTimeout(800);
const relBtn = await A.textContent(".compose-actions .btn.primary");
ok(/Relatar$/.test(relBtn.trim()), "A: botão final é “Relatar” (vai para a rede) — " + relBtn.trim());
await A.click(".compose-actions .btn.primary"); await A.waitForTimeout(500);
ok(await waitFor(() => sql(`select count(*) from posts where author_id='${sa.user_id}'`) === "1"), "A: relato gravado no Supabase");
const pid = sql(`select id from posts where author_id='${sa.user_id}' limit 1`);
const photo = sql(`select photo_path from posts where id='${pid}'`);
ok(photo.startsWith(sa.user_id + "/"), "A: foto enviada para a pasta da própria conta: " + photo);
ok(await waitFor(async () => (await st(A)).outbox.length === 0), "A: fila de envio vazia depois de publicar");

/* ---------- B: vê, comenta, denuncia ---------- */
const [cb, B] = await device("B");
const sbb = await sess(B);
ok(sbb?.user_id && sbb.user_id !== sa.user_id, "B: outra conta, criada sozinha");
ok(await waitFor(async () => (await B.locator(`#post-${pid}, [data-id='${pid}'], a[href='#post-${pid}']`).count()) > 0 || (await B.textContent("main")).includes("Fumaça forte no bairro")), "B: vê o relato de A no feed");
await B.goto(`http://localhost:4175/#post-${pid}`); await B.waitForTimeout(1200);
const img = await B.evaluate(() => [...document.images].map((i) => [i.src, i.naturalWidth]).find(([s]) => s.includes("/storage/v1/object/public/fotos/")));
ok(img && img[1] > 0, "B: a foto de A carrega pelo link público " + JSON.stringify(img));
await B.fill("#comment-text", "Aqui também, perto da escola.");
await B.click("button:has-text('Comentar') >> nth=-1"); await B.waitForTimeout(400);
ok(await waitFor(() => sql(`select count(*) from comments where post_id='${pid}'`) === "1"), "B: comentário gravado no Supabase");
await B.click("button:has-text('Denunciar')"); await B.waitForTimeout(300);
await B.click("button:has-text('Enviar denúncia')"); await B.waitForTimeout(400);
ok(await waitFor(() => sql(`select count(*) from reports where post_id='${pid}' and status='pendente'`) === "1"), "B: denúncia na fila de moderação");
// B tenta editar o relato de A direto na API (com a sessão dele): o banco recusa
const hack = await B.evaluate(async ([sb, id, tok]) => { const r = await fetch(`${sb}/rest/v1/posts?id=eq.${id}`, { method: "PATCH", headers: { apikey: "sb_publishable_teste", Authorization: "Bearer " + tok, "Content-Type": "application/json", Prefer: "return=representation" }, body: JSON.stringify({ text: "texto trocado por outra pessoa" }) }); return [r.status, await r.json()]; }, [SB, pid, sbb.access_token]);
ok(hack[1].length === 0 && sql(`select text from posts where id='${pid}'`).startsWith("Fumaça forte"), "B não consegue alterar o relato de A, mesmo chamando a API direto");

/* ---------- A: vê atividade e o comentário ---------- */
await A.goto("http://localhost:4175/#perfil-atividade"); await A.waitForTimeout(1500);
ok((await A.textContent("main")).includes("Aqui também, perto da escola."), "A: Atividade mostra o comentário de B");
await A.goto(`http://localhost:4175/#post-${pid}`); await A.waitForTimeout(1500);
ok((await A.textContent("main")).includes("Aqui também, perto da escola."), "A: vê o comentário de B na publicação");

/* ---------- moderador: código da conta + insert, como no guia ---------- */
const [cm, M] = await device("M");
const sm = await sess(M);
await M.goto("http://localhost:4175/#perfil-configuracoes"); await M.waitForTimeout(500);
sql(`insert into public.moderators (user_id) values ('${sm.user_id}')`); // administração cadastrada direto no banco também funciona
await M.goto("http://localhost:4175/#perfil-revisao"); await M.waitForTimeout(1800);
ok((await M.textContent("main")).includes("Fila de moderação"), "M: depois do insert, a Revisão mostra a fila (sem reinstalar)");
ok((await M.textContent("main")).includes("Informação falsa ou enganosa"), "M: vê a denúncia de B");
await M.click("button:has-text('Ocultar') >> nth=0"); await M.waitForTimeout(1000);
ok(sql(`select status from posts where id='${pid}'`) === "oculto" && sql(`select status from reports where post_id='${pid}'`) === "ocultado", "M: ocultar muda o relato e a denúncia no banco");

/* ---------- efeito da moderação ---------- */
await B.goto("http://localhost:4175/#feed"); await B.waitForTimeout(400); await B.reload(); await B.waitForTimeout(2200);
ok(!(await B.textContent("main")).includes("Fumaça forte no bairro"), "B: o relato ocultado some do feed");
await B.goto("http://localhost:4175/#perfil-configuracoes"); await B.waitForTimeout(800); await B.click("#gerar-registro"); await B.waitForTimeout(1500);
ok(/resultado: publicação ocultada/.test(await B.textContent(".log-box")), "B: vê o resultado da denúncia (ocultada) em Meu registro");
await A.goto("http://localhost:4175/#perfil"); await A.waitForTimeout(400); await A.reload(); await A.waitForTimeout(2200);
ok((await A.textContent("main")).includes("Fumaça forte no bairro"), "A: o autor ainda vê o próprio relato (marcado como ocultado)");
ok((await A.textContent("main")).includes("Ocultado após revisão"), "A: com o aviso “Ocultado após revisão”");

/* ---------- A edita e apaga ---------- */
/* ---------- B fica offline, relata, volta ---------- */
await cb.setOffline(true);
await B.goto("http://localhost:4175/#relatar"); await B.waitForTimeout(600);
await B.click(".type-tile:has-text('Enchente')");
await B.fill("#c-text", "Água subindo na rua de baixo, já entrou em duas casas.");
await B.click("button:has-text('Continuar')"); await B.waitForTimeout(300);
await B.click("text=Digitar coordenadas").catch(() => {}); await B.getByLabel("Latitude").fill("-3.28"); await B.getByLabel("Longitude").fill("-60.19"); await B.waitForTimeout(300);
await B.click("button:has-text('Continuar')"); await B.waitForTimeout(300);
await B.click(".compose-actions .btn.primary"); await B.waitForTimeout(800);
const qb = (await st(B)).outbox;
ok(qb.length === 1 && qb[0].op === "createPost" && sql(`select count(*) from posts where author_id='${sbb.user_id}'`) === "0", "B offline: o relato fica na fila do aparelho");
await cb.setOffline(false); await B.evaluate(() => window.dispatchEvent(new Event("online")));
ok(await waitFor(() => sql(`select count(*) from posts where author_id='${sbb.user_id}'`) === "1"), "B: ao voltar a conexão, o relato é enviado sozinho");
await A.goto("http://localhost:4175/#feed"); await A.waitForTimeout(300); await A.reload(); await A.waitForTimeout(2200);
ok((await A.textContent("main")).includes("Água subindo na rua de baixo"), "A: vê o relato que B fez offline");

/* ---------- sessão sobrevive a “Apagar os dados” ---------- */
await A.goto("http://localhost:4175/#perfil-configuracoes"); await A.waitForTimeout(500);
await A.click("button:has-text('Apagar os dados deste aparelho')"); await A.click(".confirm button.btn.danger:has-text('Apagar')"); await A.waitForTimeout(400);
await A.reload(); await A.waitForTimeout(2200);
ok((await sess(A)).user_id === sa.user_id, "A: depois de “Apagar os dados”, continua a mesma conta (relatos continuam seus)");

for (const [n, p] of [["A", A], ["B", B], ["M", M]]) ok(p.errs.length === 0, `${n}: sem erros de JavaScript ${p.errs.slice(0, 3).join(" | ")}`);
console.log("\n" + out.filter((x) => x.startsWith("FALHOU")).length + " falha(s) de " + out.length);
await b.close();
