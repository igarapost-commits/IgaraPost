// Relatos de teste (como se tivessem sido feitos neste aparelho), já que o app não traz mais exemplos.
export const TEST_POSTS = [
  { id: "t-autazes", category: "fumaca", municipio: "Autazes", lat: -3.58, lon: -59.13, approx: true, observedAt: "2026-09-12T11:30:00.000Z", text: "Fumaça forte desde ontem à tarde, vindo do lado do ramal. Os olhos ardem e a visibilidade no rio está ruim de manhã cedo." },
  { id: "t-ramal", category: "queimada", municipio: "Careiro da Várzea", lat: -3.2, lon: -59.8, approx: false, observedAt: "2026-09-20T18:00:00.000Z", text: "Vi fogo numa área de pasto perto do ramal, à tarde. Não sei se foi controlado." },
  { id: "t-manaus", category: "fumaca", municipio: "Manaus", lat: -3.05, lon: -59.94, approx: true, observedAt: "2026-10-14T10:40:00.000Z", text: "Céu cinza e cheiro de queimado na Zona Leste logo cedo. Quem tem asma em casa, atenção." },
  { id: "t-manaquiri", category: "queimada", municipio: "Manaquiri", lat: -3.42, lon: -60.46, approx: false, observedAt: "2026-10-02T15:00:00.000Z", text: "Fumaça e fogo em capoeira na estrada de Manaquiri." },
];
export async function seedReports(p, base = "http://localhost:4175/") {
  await p.goto(base + "#feed"); await p.waitForTimeout(600);
  await p.evaluate((posts) => {
    const s = JSON.parse(localStorage.getItem("igarapost:v2")) ?? { v: 2, posts: [] };
    s.posts = s.posts ?? [];
    const have = new Set(s.posts.map((x) => x.id));
    for (const t of posts) if (!have.has(t.id)) s.posts.push({ kind: "community", authorId: "me", lang: "pt", communityIds: [], publishedAt: t.observedAt, ...t });
    localStorage.setItem("igarapost:v2", JSON.stringify(s));
  }, TEST_POSTS);
  await p.reload(); await p.waitForTimeout(800);
}
