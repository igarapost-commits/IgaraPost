// Teste de ponta a ponta do IgaraPost 0.2 (Playwright + Chromium) com dois "aparelhos" (contextos de
// navegador independentes, cada um com seu próprio armazenamento) e o servidor real.
//
//   1) servidor:  DB=/tmp/teste.db MODERATORS=mod_teste node ../server/index.mjs   (porta 8787)
//   2) app:       npx vite preview --port 4173
//   3) teste:     NODE_PATH=$(npm root -g) node tests/e2e.mjs http://localhost:4173/ http://localhost:8787 [pasta-screenshots]
import { createRequire } from "node:module";
const require_ = createRequire(import.meta.url);
const { chromium } = require_("playwright");
const APP = process.argv[2] || "http://localhost:4173/";
const SRV = process.argv[3] || "http://localhost:8787";
const SHOTS = process.argv[4] || "";
const results = [];
const ok = (name, cond, extra = "") => results.push([cond ? "OK " : "FALHOU", name, extra]);
const errors = [];
const b = await chromium.launch();
const mkDevice = async (label) => {
  // ANDROID=1 usa o perfil de um celular Android (Pixel 7: tela, toque, user agent)
  const ctx = await b.newContext(process.env.ANDROID ? { ...require_("playwright").devices["Pixel 7"] } : { viewport: { width: 400, height: 860 }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  page.on("pageerror", (e) => errors.push(`${label}: ${e}`));
  page.on("console", (m) => m.type() === "error" && !/tile\.openstreetmap|gibs\.earthdata|firms\.modaps|dataserver-coids|ERR_FAILED|net::|status of 403|EventSource/.test(m.text()) && errors.push(`${label}: ${m.text()}`));
  // mapas e camadas online (OSM, NASA GIBS) e o INPE são bloqueados no teste para verificar os modos
  // offline e "conferência indisponível" de forma determinística
  await ctx.route(/tile\.openstreetmap\.org|gibs\.earthdata\.nasa\.gov|firms\.modaps\.eosdis\.nasa\.gov|dataserver-coids\.inpe\.br/, (r) => r.abort());
  return { ctx, page };
};
const shot = async (page, n) => SHOTS && page.screenshot({ path: `${SHOTS}/${n}.png` });
const step = async (name, fn) => {
  try {
    await fn();
  } catch (e) {
    results.push(["FALHOU", name, String(e.message || e).split("\n")[0]]);
  }
};
// 0.3.5: a escolha da região fica só na folha de filtros do feed
async function pickScope(page, value) {
  await page.click("button:has-text('Filtros')");
  await page.selectOption("#fs-scope", value);
  await page.click("button:has-text('Ver resultados')");
}
async function compose(page, { cat, text, lat, lon }) {
  await page.goto(APP + "#relatar");
  await page.click(`.type-tile:has-text("${cat}")`);
  await page.fill("#c-text", text);
  await page.click("button:has-text('Continuar')");
  await page.click("summary:has-text('Digitar coordenadas')");
  await page.fill("#c-lat", String(lat));
  await page.fill("#c-lon", String(lon));
  await page.click("button:has-text('Continuar')");
}

/* =============================== APARELHO A, sem servidor =============================== */
const A = await mkDevice("A");
const pa = A.page;
await pa.goto(APP + "#feed");
await pa.waitForSelector("article", { timeout: 15000 });

await step("feed", async () => {
  await pickScope(pa, "all");
  await pa.waitForSelector("text=Focos de calor em setembro/2026");
  const card = pa.locator("article", { hasText: "Focos de calor em setembro/2026" });
  const txt = await card.innerText();
  ok("Resumo regional identificado como tal", /Resumo regional/.test(txt) && /Na área do app/.test(txt));
  ok("Publicação da equipe com dados do INPE (não do INPE)", /Equipe IgaraPost/.test(txt) && /Dados oficiais · INPE/.test(txt));
  ok("Fonte e período visíveis no cartão", /Fonte: INPE.*período: setembro\/2026/s.test(txt));
  ok("Exemplos fictícios identificados", (await pa.locator(".badge.example").count()) > 0);
  await shot(pa, "01-feed");
});

await step("filtro municipal", async () => {
  await pickScope(pa, "mun:Autazes");
  const card = pa.locator("article", { hasText: "Focos de calor em setembro/2026" });
  const txt = await card.innerText();
  ok("Município recalcula contagem (Autazes, set: 239 AQUA_M-T)", /Contagem municipal · Autazes/.test(txt) && /239 focos/.test(txt), txt.match(/\d+ focos/)?.[0]);
  ok("Nenhum resumo regional com aparência municipal", (await pa.locator("article", { hasText: "Resumo regional" }).count()) === 0);
  const muns = await pa.locator("article .post-meta").allInnerTexts();
  ok("Relatos locais só de Autazes", muns.filter((m) => /\b(Manaus|Iranduba|Careiro)\b/.test(m)).length === 0, `${muns.length} cartões`);
  await pickScope(pa, "mun:Itacoatiara");
  ok("Município sem relatos não mostra relatos de outros", (await pa.locator("article .badge.community").count()) === 0);
  await pickScope(pa, "com:manaus-entorno");
});

await step("detalhes de dados perto do relato", async () => {
  await pa.goto(APP + "#post-ex-fumaca-autazes");
  await pa.waitForSelector("text=AQUA_M-T");
  await pa.waitForFunction(() => !document.querySelector(".nearby")?.textContent?.includes("carregando"));
  const t2 = await pa.locator(".nearby").innerText();
  ok("Relato de setembro: IIS com mês exato", /IIS-3 em Autazes, referência setembro\/2026/.test(t2));
});

await step("falha de gravação", async () => {
  await compose(pa, { cat: "Fumaça", text: "Teste de falha de gravação: fumaça perto do porto.", lat: -3.2, lon: -59.83 });
  await pa.evaluate(() => {
    window.__set = Storage.prototype.setItem;
    Storage.prototype.setItem = function () {
      throw new DOMException("cheio", "QuotaExceededError");
    };
  });
  try {
    await pa.click("button:has-text('Relatar neste aparelho')");
    await pa.waitForSelector("[role=alert]:has-text('Não há espaço')");
  } catch (e) {
    await pa.evaluate(() => (Storage.prototype.setItem = window.__set));
    throw e;
  }
  const alert = await pa.locator("[role=alert]:has-text('Não há espaço')").innerText();
  const toastTxt = (await pa.locator(".toast").count()) ? await pa.locator(".toast").innerText() : "";
  ok("Falha de gravação não gera falso sucesso", /Não há espaço/.test(alert) && (await pa.evaluate(() => location.hash)) === "#relatar" && !/salvo|publicado/i.test(toastTxt), toastTxt);
  ok("Formulário preserva o conteúdo após a falha", /Teste de falha de gravação/.test(await pa.locator(".review").innerText()));
  await shot(pa, "02-falha-gravacao");
  await pa.evaluate(() => (Storage.prototype.setItem = window.__set));
  await pa.click("button:has-text('Relatar neste aparelho')");
  await pa.waitForSelector("text=Dados próximos a este relato");
  ok("Nova tentativa salva e mostra 'Salvo só neste aparelho'", /Salvo só neste aparelho/.test(await pa.locator("article").first().innerText()));
});

await step("rascunho e persistência", async () => {
  await pa.goto(APP + "#relatar");
  await pa.click('.type-tile:has-text("Seca")');
  await pa.fill("#c-text", "Rascunho que deve sobreviver à atualização da página.");
  await pa.waitForSelector("text=Rascunho salvo no aparelho");
  await pa.reload();
  await pa.waitForSelector("#c-text");
  ok("Rascunho recuperado após atualizar", (await pa.inputValue("#c-text")).startsWith("Rascunho que deve"));
  await pa.click("button:has-text('Descartar rascunho')");
  await pa.goto(APP + "#perfil");
  ok("Relato local persiste após atualizar", /Teste de falha de gravação/.test(await pa.locator(".feed").innerText()));
});

await step("mapa com contexto do relato", async () => {
  await pa.goto(APP + "#post-ex-fumaca-autazes");
  await pa.click("article button:has-text('Mapa')");
  await pa.waitForSelector(".map-context");
  const c = await pa.locator(".map-context").innerText();
  ok("Mapa mantém local e data do relato", /Contexto do relato/.test(c) && /12 set 2026/.test(c) && /dia da observação/.test(c));
  const strip = await pa.locator(".date-strip").innerText();
  ok("Datas das camadas mostradas separadamente", /Focos AQUA_M-T: 9 set 2026 a 15 set 2026/.test(strip), strip);
  await pa.waitForSelector(".map-notice", { timeout: 15000 });
  ok("Sem as imagens da NASA, usa a Blue Marble guardada e avisa", /não carregaram/.test(await pa.locator(".map-notice").innerText()));
  await pa.waitForTimeout(600);
  await shot(pa, "03-mapa-contexto");
  await pa.click(".map-ctrl button:has-text('Buscar')");
  await pa.fill("#map-search", "lago");
  const hits = await pa.locator(".hits li").count();
  ok("Busca encontra comunidades (OSM)", hits >= 3, `${hits} resultados`);
  await pa.fill("#map-search", "Iranduba");
  await pa.click(".hits button >> nth=0");
  await pa.waitForSelector(".leaflet-popup-content");
  const pop = await pa.locator(".leaflet-popup-content").innerText();
  ok("Consulta do ponto mostra dados da NASA e avisa sobre ausência", /NASA FIRMS/.test(pop) && /não garante/.test(pop) && /Relatar/.test(pop), pop.replace(/\n/g, " | ").slice(0, 160));
  await pa.click(".map-ctrl button:has-text('Camadas')");
  await pa.check("#ly-ev-enchente");
  const leg = await pa.locator(".sheet").innerText();
  ok("Legenda só com fontes da NASA, com cobertura e data", /Cobertura: global/.test(leg) && /NASA GIBS/.test(leg) && !/Cemaden|INPE|OpenStreetMap/.test(leg));
  await shot(pa, "04-mapa-legenda");
});

await step("explorador NISAR", async () => {
  await pa.goto(APP + "#nisar");
  await pa.waitForSelector("text=Comparabilidade e qualidade do par");
  const t = await pa.locator("main").innerText();
  ok("NISAR identificado como exploração visual e segmentação", /Exploração visual experimental/.test(t) && /segmentação das prévias/.test(t));
  ok("Pendência do processamento calibrado declarada", /testado apenas com um arquivo sintético/.test(t) && /Valores calibrados \(gamma0\)\s*não/.test(t));
  ok("Relatos posicionados em relação às datas do radar", /entre as duas imagens|depois das duas imagens/.test(t));
});

/* =============================== rede compartilhada: A e B =============================== */
// 0.3.3: a aba Conta saiu do app. O teste cria a conta pela API e grava a sessão no aparelho simulado,
// como faria um build com VITE_API_URL e uma tela de login própria.
async function connect(page, handle, name) {
  const r = await fetch(SRV + "/api/auth/register", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ handle, displayName: name, password: "senha-de-teste-123" }) }).then((x) => x.json());
  await page.goto(APP + "#feed");
  await page.evaluate(({ url, token, user }) => {
    const k = "igarapost:v2";
    const s = JSON.parse(localStorage.getItem(k) || "{}");
    localStorage.setItem(k, JSON.stringify({ ...s, v: 2, server: { url, token, user, posts: [], comments: {} } }));
  }, { url: SRV, token: r.token, user: r.user });
  await page.reload();
}
const B_ = await mkDevice("B");
const pb = B_.page;
const TXT_A = `Fumaça densa no ramal do Lago do Limão (teste ${Date.now()})`;
const TXT_OFF = `Relato feito sem internet no barco (${Date.now() % 1000000}).`;
await step("percurso social entre aparelhos", async () => {
  await connect(pa, `ana${Date.now() % 100000}`, "Ana Teste");
  await connect(pb, `bia${Date.now() % 100000}`, "Bia Teste");
  await compose(pa, { cat: "Fumaça", text: TXT_A, lat: -3.25, lon: -59.9 });
  await pa.click(".compose-actions button:has-text('Relatar')");
  await pa.waitForSelector("article .sync.ok:has-text('Enviado')", { timeout: 15000 });
  ok("A relata e só vê 'Enviado' após confirmação do servidor", true);
  await pb.goto(APP + "#feed");
  await pickScope(pb, "all");
  await pb.reload(); // o feed se atualiza sozinho ao abrir
  await pb.waitForSelector(`text=${TXT_A}`, { timeout: 15000 });
  ok("B vê o relato de A em outro aparelho", true);
  await pb.locator("article", { hasText: TXT_A }).locator("a:has-text('Comentar')").click();
  await pb.waitForSelector("text=Dados próximos a este relato");
  ok("B não vê editar/excluir no relato de A", (await pb.locator("a:has-text('Editar'), button:has-text('Excluir')").count()) === 0);
  await pb.fill("#comment-text", "Aqui no Careiro também, desde ontem.");
  await pb.click("button:has-text('Comentar')");
  await pb.waitForFunction(() => /Aqui no Careiro também/.test(document.body.innerText) && !/Aguardando conexão|Enviando/.test(document.querySelector("#comentarios")?.textContent || ""));
  ok("B comenta e o comentário é enviado", true);
  await pa.goto(APP + "#perfil-atividade");
  await pa.waitForSelector("text=Aqui no Careiro também", { timeout: 15000 });
  ok("A consulta o comentário de B (Atividade)", /Bia Teste comentou/.test(await pa.locator(".activity").first().innerText()));
  await shot(pa, "05-atividade");
});

await step("autoria e permissões", async () => {
  const id = await pa.evaluate((t) => JSON.parse(localStorage.getItem("igarapost:v2")).server.posts.find((p) => p.text === t)?.id, TXT_A);
  const tokB = await pb.evaluate(() => JSON.parse(localStorage.getItem("igarapost:v2")).server.token);
  const r = await pb.evaluate(
    async ([srv, id, tok]) => (await fetch(`${srv}/api/posts/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json", Authorization: `Bearer ${tok}` }, body: JSON.stringify({ text: "alteração indevida de outra pessoa" }) })).status,
    [SRV, id, tokB],
  );
  ok("Servidor recusa edição por outra pessoa (403)", r === 403, `status ${r}`);
  await pa.goto(APP + `#editar-${id}`);
  await pa.fill("#c-text", TXT_A + " — editado pela autora");
  await pa.click("button:has-text('Continuar')");
  await pa.click("button:has-text('Continuar')");
  await pa.click("button:has-text('Salvar alterações')");
  await pa.waitForSelector("article .sync.ok:has-text('Enviado')", { timeout: 15000 });
  await pb.goto(APP + "#feed");
  await pb.reload(); // o feed se atualiza sozinho ao abrir
  await pb.waitForSelector("text=editado pela autora", { timeout: 15000 });
  ok("Edição da autora aparece no outro aparelho", true);
});

await step("sem conexão", async () => {
  await pa.goto(APP + "#feed");
  await A.ctx.setOffline(true);
  try {
  await compose(pa, { cat: "Cheia", text: TXT_OFF, lat: -3.18, lon: -59.95 });
  await pa.click(".compose-actions button:has-text('Relatar')");
  await pa.waitForSelector("article .sync.pendente", { timeout: 15000 });
  ok("Sem conexão: 'Aguardando conexão', nunca 'Enviado'", /Aguardando conexão/.test(await pa.locator("article").first().innerText()));
  await shot(pa, "06-offline");
  } finally {
    await A.ctx.setOffline(false);
  }
  await pa.evaluate(() => window.dispatchEvent(new Event("online")));
  await pa.waitForSelector("article .sync.ok:has-text('Enviado')", { timeout: 20000 });
  ok("Volta a conexão: envio automático e 'Enviado'", true);
  await pb.goto(APP + "#feed");
  await pb.reload(); // o feed se atualiza sozinho ao abrir
  await pb.waitForSelector(`text=${TXT_OFF}`, { timeout: 15000 });
  ok("Relato feito offline aparece no outro aparelho", true);
});

await step("denúncia com destino real", async () => {
  await pb.locator("article", { hasText: TXT_OFF }).locator("a:has-text('Comentar')").click();
  await pb.click("button:has-text('Denunciar')");
  await pb.click("button:has-text('Enviar denúncia')");
  await pb.goto(APP + "#perfil-revisao");
  await pb.waitForSelector("text=resultado: ", { timeout: 15000 });
  ok("Denúncia chega à fila do servidor (Perfil › Revisão mostra 'pendente')", /resultado: pendente/.test(await pb.locator("main").innerText()));
  const posts = await (await fetch(`${SRV}/api/posts`)).json();
  ok("Exemplos fictícios nunca vão ao servidor", !posts.posts.some((p) => p.id.startsWith("ex-")));
});

await step("persistência ao reabrir (rede)", async () => {
  await pa.reload();
  await pa.goto(APP + "#perfil");
  await pa.waitForSelector(`text=${TXT_OFF}`);
  ok("Sessão e relatos continuam após reabrir", /Ana Teste/.test(await pa.locator("h1").innerText()));
});

await step("tema e largura", async () => {
  await pa.emulateMedia({ colorScheme: "dark" });
  await pa.goto(APP + "#feed");
  await pa.waitForSelector("article");
  ok("Tema escuro", (await pa.evaluate(() => getComputedStyle(document.body).backgroundColor)) === "rgb(8, 18, 31)");
  await pa.goto(APP + "#perfil-configuracoes");
  await pa.click(".segmented button:has-text('Claro')");
  ok("Tema escolhido (Claro) vale mesmo com o aparelho no escuro", (await pa.evaluate(() => getComputedStyle(document.body).backgroundColor)) === "rgb(241, 246, 250)");
  await pa.reload();
  ok("Tema escolhido fica salvo", (await pa.evaluate(() => document.documentElement.dataset.theme)) === "light");
  await pa.click(".segmented button:has-text('Automático')");
  for (const h of ["#feed", "#relatar", "#perfil", "#nisar", "#sobre", "#como-funciona", "#mapa"]) {
    await pa.goto(APP + h);
    await pa.waitForTimeout(300);
    const over = await pa.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
    if (over) ok(`Sem rolagem horizontal em ${h}`, false);
  }
  ok(`Sem rolagem horizontal a ${pa.viewportSize().width} px (6 telas)`, true);
  await shot(pa, "07-escuro");
});

ok("Sem erros de JavaScript", errors.length === 0, errors.slice(0, 3).join(" | "));
await b.close();
for (const r of results) console.log(r.join("  "));
console.log(`${results.filter((r) => r[0] === "OK ").length}/${results.length} verificações OK`);
process.exit(results.some((r) => r[0] !== "OK ") ? 1 : 0);
