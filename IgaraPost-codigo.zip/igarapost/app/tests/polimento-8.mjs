import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";
import { seedReports } from "./relatos-de-teste.mjs";
const b = await chromium.launch(); const out = []; const ok = (c, n) => out.push((c ? "OK     " : "FALHOU ") + n);
const c = await b.newContext({ locale: "pt-BR", viewport: { width: 390, height: 844 } }); await c.addInitScript(() => sessionStorage.setItem("igarapost:semIntro", "1"));
await c.route(/^https?:\/\/(?!localhost)/, (r) => r.abort()); const p = await c.newPage(); const errs = []; p.on("pageerror", (e) => errs.push(e.message));
await seedReports(p); await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(1200);
// Comentar no Feed (num relato lá embaixo)
const art = p.locator("article", { hasText: "Céu cinza e cheiro de queimado" }).first(); await art.scrollIntoViewIfNeeded();
await art.locator(".post-actions a[aria-label='Abrir comentários']").click(); await p.waitForTimeout(900);
const vis = () => p.evaluate(() => { const c = document.getElementById("comentarios").getBoundingClientRect(), t = document.getElementById("comment-text").getBoundingClientRect(), nav = document.querySelector("nav.tabbar, .tabbar, nav[aria-label='Navegação principal']"); const nb = nav ? nav.getBoundingClientRect().top : innerHeight; return { hash: location.hash, top: Math.round(c.top), caixaVisivel: t.top >= 56 && t.bottom <= nb, y: Math.round(scrollY), noFim: Math.abs(scrollY - (document.documentElement.scrollHeight - innerHeight)) < 4 }; });
const r1 = await vis();
ok(r1.hash.endsWith("#comentarios") && r1.caixaVisivel && r1.top >= 56, "Comentar no Feed abre a publicação com a conversa e a caixa de comentário na tela " + JSON.stringify(r1));
// publicação longa (explicativo): precisa rolar até a conversa
await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(800);
const longa = p.locator("article", { hasText: "Foco de calor, incêndio e área queimada" }).first();
await longa.locator(".post-actions a[aria-label='Abrir comentários']").click(); await p.waitForTimeout(1100);
const r3 = await vis();
ok(r3.y > 0 && r3.caixaVisivel && (r3.top <= 140 || r3.noFim), "em publicação longa, a tela desce até a conversa " + JSON.stringify(r3));
// dentro do detalhe: volta ao topo e toca Comentar de novo
await p.evaluate(() => scrollTo(0, 0)); await p.waitForTimeout(300);
await p.click(".post-actions a[aria-label='Abrir comentários']"); await p.waitForTimeout(900);
const r2 = await vis();
ok(r2.y > 0 && r2.caixaVisivel && (r2.top <= 140 || r2.noFim), "dentro da publicação, Comentar desce até a conversa " + JSON.stringify(r2));
const txt = await p.textContent("main");
ok(!/Dados próximos a este relato|Fonte, período e método|Comentar como|Comentários em exemplos fictícios/.test(txt), "detalhe só com a publicação e a conversa");
await p.goto("http://localhost:4175/#relatar"); await p.waitForTimeout(900);
const rel = await p.textContent("main");
ok(!/Outra ocorrência ambiental|Viu fumaça, fogo ou enchente que ainda não aparece no mapa\? Conte|Fora do radar do SARS/.test(rel) && /Em perigo, ligue 193/.test(rel), "Relatar sem textos descritivos (fica só o aviso de emergência)");
await p.click(".type-tile >> nth=0"); await p.fill("textarea", "Teste de polimento do texto."); await p.click(".compose-actions .btn.primary"); await p.waitForTimeout(700);
const gps = (await p.textContent(".gps-btn")).trim();
ok(gps === "Usar minha localização", "botão de localização sem o '(GPS)': " + gps);
ok(errs.length === 0, "sem erros JS " + errs.join("|"));
console.log(out.join("\n")); await b.close();
