// IgaraPost 10 (ajustes 3): voltar com memória de uma tela, aviso de relato verificado e foto da equipe.
import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";
import { execFileSync } from "node:child_process";
const b = await chromium.launch(); const out = []; const ok = (c, n) => { out.push((c ? "OK     " : "FALHOU ") + n); console.log((c ? "OK     " : "FALHOU ") + n); };
const sql = (q) => execFileSync("psql", ["-h", "/tmp/pg", "-p", "5433", "-U", "postgres", "-d", "sbmock", "-At", "-c", q]).toString().trim();
const waitFor = async (fn, ms = 9000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return true; await new Promise((r) => setTimeout(r, 250)); } return false; };
async function device(locale = "pt-BR", grant = false) {
  const c = await b.newContext({ viewport: { width: 390, height: 844 }, locale, permissions: [] });
  await c.route(/^https?:\/\/(?!localhost)/, (r) => r.abort());
  await c.addInitScript(() => {
    if (location.protocol === "about:") return;
    sessionStorage.setItem("igarapost:semIntro", "1");
    // celular que permitiu notificações (o Chromium sem tela sempre responde "denied"): conta as que o app cria
    window.__notifs = [];
    window.Notification = class { constructor(t, o) { window.__notifs.push([t, o?.body]); } static get permission() { return window.__perm || "default"; } static async requestPermission() { window.__perm = "granted"; return "granted"; } };
  });
  const p = await c.newPage(); p.errs = []; p.on("pageerror", (e) => p.errs.push(e.message));
  await p.goto("about:blank"); await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(1800);
  return [c, p];
}
const hash = (p) => p.evaluate(() => location.hash);
const back = async (p) => { await p.goBack().catch(() => {}); await p.waitForTimeout(500); };
const tab = (p, name) => p.click(`nav.bottomnav a:has-text('${name}')`).then(() => p.waitForTimeout(500));

/* ---------- voltar ---------- */
const [ca, A] = await device();
await tab(A, "Mapa"); await tab(A, "Perfil"); await A.click(".profile-menu a:has-text('Configurações')"); await A.waitForTimeout(500);
ok((await hash(A)) === "#perfil-configuracoes", "abre Mapa › Perfil › Configurações");
ok(await A.evaluate(() => history.length) <= 3, "o histórico não cresce (about:blank + 2 telas): " + (await A.evaluate(() => history.length)));
await back(A);
ok((await hash(A)) === "#perfil", "voltar leva à última tela (Perfil)");
ok(!(await A.locator(".topbar .back-btn").count()), "na tela de chegada não há mais para onde voltar (botão Voltar some)");
await back(A);
ok(A.url() === "about:blank", "voltar de novo sai do app");
await A.goto("http://localhost:4175/#feed"); await A.waitForTimeout(1200);
ok(!(await A.locator(".topbar .back-btn").count()), "primeira tela: sem botão Voltar");
await A.click("article.post >> nth=0"); await A.waitForTimeout(600);
const postHash = await hash(A);
ok(postHash.startsWith("#post-") && (await A.locator(".topbar .back-btn").count()) === 1, "abrindo uma publicação aparece o botão Voltar");
await A.click("a:has-text('Comentar') >> nth=0").catch(() => {}); await A.waitForTimeout(400);
await A.click(".topbar .back-btn"); await A.waitForTimeout(600);
ok((await hash(A)) === "#feed", "botão Voltar do app leva ao Feed (Comentar dentro da publicação não conta como outra tela)");
await A.goto("http://localhost:4175/#sobre"); await A.waitForTimeout(800);
/* ---------- foto da equipe ---------- */
const img = await A.evaluate(() => { const i = document.querySelector(".team-photo img"); return i && [i.naturalWidth, i.complete]; });
ok(img && img[0] === 1200, "Sobre nós mostra a foto da equipe " + JSON.stringify(img));
/* ---------- aviso de verificação ---------- */
const [cb, B] = await device("pt-BR", true); const sB = await B.evaluate(() => JSON.parse(localStorage.getItem("igarapost:sessao")));
await B.goto("http://localhost:4175/#relatar"); await B.waitForTimeout(500);
await B.click(".type-tile:has-text('Fumaça')"); await B.fill("#c-text", "Fumaça na beira do rio desde cedo.");
await B.click("button:has-text('Continuar')"); await B.waitForTimeout(250);
await B.click("text=Digitar coordenadas").catch(() => {}); await B.getByLabel("Latitude").fill("-3.12"); await B.getByLabel("Longitude").fill("-60.03");
await B.click("button:has-text('Continuar')"); await B.waitForTimeout(250); await B.click(".compose-actions .btn.primary"); await B.waitForTimeout(800);
ok(await waitFor(() => sql(`select count(*) from posts where author_id='${sB.user_id}'`) === "1"), "B publica");
const pid = sql(`select id from posts where author_id='${sB.user_id}'`);
await B.goto("http://localhost:4175/#perfil-configuracoes"); await B.waitForTimeout(500);
ok(!(await B.isChecked("#aviso-verificado")), "o aviso vem desligado (opcional)");
await B.click("#aviso-verificado"); await B.waitForTimeout(800);
ok(await B.isChecked("#aviso-verificado") && (await B.evaluate(() => JSON.parse(localStorage.getItem("igarapost:v2")).prefs.notifyVerified)) === true, "B liga o aviso");
await B.evaluate(() => window.dispatchEvent(new Event("online"))); await B.waitForTimeout(1200); // memoriza o estado atual
const [cm, M] = await device();
sql(`insert into moderators (user_id) select id from profiles where id <> '${sB.user_id}' and id not in (select user_id from moderators)`);
await M.goto(`http://localhost:4175/#post-${pid}`); await M.waitForTimeout(400); await M.reload(); await M.waitForTimeout(1500);
await M.click("button:has-text('Verificar')"); await M.waitForTimeout(800);
ok(sql(`select verified from posts where id='${pid}'`) === "t", "administração verifica");
await B.goto("http://localhost:4175/#mapa"); await B.waitForTimeout(500);
await B.evaluate(() => window.dispatchEvent(new Event("online")));
ok(await waitFor(async () => ((await B.locator(".toast").textContent().catch(() => "")) || "").includes("verificado pela administração")), "B recebe o aviso na tela (em outra tela do app)");
ok(await waitFor(async () => (await B.evaluate(() => window.__notifs?.length || 0)) === 1), "e uma notificação do sistema: " + JSON.stringify(await B.evaluate(() => window.__notifs)));
await B.goto("http://localhost:4175/#perfil-atividade"); await B.waitForTimeout(1200);
ok((await B.textContent("main")).includes("Relato verificado pela administração"), "o aviso fica na aba Atividade");
await B.evaluate(() => window.dispatchEvent(new Event("online"))); await B.waitForTimeout(1500);
ok((await B.evaluate(() => window.__notifs.length)) === 1, "não repete o aviso");
/* ---------- desligado: não avisa ---------- */
const [cc, C] = await device("pt-BR", true); const sC = await C.evaluate(() => JSON.parse(localStorage.getItem("igarapost:sessao")));
await C.goto("http://localhost:4175/#relatar"); await C.waitForTimeout(500);
await C.click(".type-tile:has-text('Fumaça')"); await C.fill("#c-text", "Outra fumaça, perto da estrada.");
await C.click("button:has-text('Continuar')"); await C.waitForTimeout(250);
await C.click("text=Digitar coordenadas").catch(() => {}); await C.getByLabel("Latitude").fill("-3.2"); await C.getByLabel("Longitude").fill("-60.2");
await C.click("button:has-text('Continuar')"); await C.waitForTimeout(250); await C.click(".compose-actions .btn.primary"); await C.waitForTimeout(800);
await waitFor(() => sql(`select count(*) from posts where author_id='${sC.user_id}'`) === "1");
await C.evaluate(() => window.dispatchEvent(new Event("online"))); await C.waitForTimeout(1200);
sql(`update posts set verified = true where author_id='${sC.user_id}'`);
await C.evaluate(() => window.dispatchEvent(new Event("online"))); await C.waitForTimeout(2000);
ok((await C.evaluate(() => window.__notifs.length)) === 0, "com o aviso desligado, nada é mostrado");
/* ---------- inglês ---------- */
const [ce, E] = await device("en-US");
await E.goto("http://localhost:4175/#perfil-configuracoes"); await E.waitForTimeout(600);
ok((await E.textContent("section[aria-labelledby=avisos-titulo]")).includes("Notify me when one of my reports is verified"), "seção de avisos traduzida");
await E.goto("http://localhost:4175/#sobre"); await E.waitForTimeout(600);
ok((await E.textContent(".team-photo")).includes("Development team"), "legenda da foto traduzida");
for (const [n, p] of [["A", A], ["B", B], ["M", M], ["C", C], ["E", E]]) ok(p.errs.length === 0, `${n}: sem erros de JavaScript ${p.errs.slice(0, 3).join(" | ")}`);
console.log("\n" + out.filter((x) => x.startsWith("FALHOU")).length + " falha(s) de " + out.length);
await b.close();
