import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";
import { seedReports } from "./relatos-de-teste.mjs";
const b = await chromium.launch(); const out = []; const ok = (c, n) => out.push((c ? "OK     " : "FALHOU ") + n);
const c = await b.newContext({ locale: "pt-BR", viewport: { width: 390, height: 844 }, geolocation: { latitude: -3.1, longitude: -60.02 }, permissions: ["geolocation"] }); await c.addInitScript(() => sessionStorage.setItem("igarapost:semIntro", "1"));
await c.route(/^https?:\/\/(?!localhost)/, (r) => r.abort()); const p = await c.newPage(); const errs = []; p.on("pageerror", (e) => errs.push(e.message));
await seedReports(p);
const state = () => p.evaluate(() => ({ pins: document.querySelectorAll(".leaflet-marker-pane .pin").length, clusters: [...document.querySelectorAll(".leaflet-marker-pane .cluster")].map((x) => +x.textContent), popup: document.querySelector(".leaflet-popup-content")?.textContent.replace(/\s+/g, " ").trim() ?? "" }));
// 1) botão Mapa em relatos de lugares diferentes (dentro e fora do filtro "Manaus e entorno")
for (const [id, mun, trecho] of [["t-autazes", "Autazes", "Fumaça forte desde ontem"], ["t-manaquiri", "Manaquiri", "Fumaça e fogo em capoeira"], ["t-manaus", "Manaus", "Céu cinza e cheiro"]]) {
  await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(300); await p.goto("http://localhost:4175/#post-" + id); await p.waitForTimeout(800);
  await p.click(".post-actions button:has-text('Mapa')"); await p.waitForTimeout(2200);
  const s = await state();
  const inView = await p.evaluate(() => { const pop = document.querySelector(".leaflet-popup"); const m = document.querySelector(".leaflet-container").getBoundingClientRect(); if (!pop) return false; const r = pop.getBoundingClientRect(); return r.bottom > m.top && r.top < m.bottom; });
  ok(s.popup.includes(mun) && s.popup.includes(trecho) && inView, `Mapa no relato de ${mun}: abre a marcação dele, com o popup na tela (${s.popup.slice(0, 70)}…)`);
}
// 2) mapa sem botão de filtros: mostra todos os relatos; os botões de evento escolhem os tipos
await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(300);
await p.click(".feed-bar .btn:has-text('Filtros')"); await p.waitForTimeout(300);
await p.click("#tema-filtro"); await p.click("#tema-filtro-opcoes .chip:has-text('Enchentes')"); await p.click("button:has-text('Ver resultados')"); await p.waitForTimeout(300);
await p.goto("http://localhost:4175/#mapa"); await p.waitForTimeout(2200);
const total = (s) => s.pins + s.clusters.reduce((a, x) => a + x, 0);
ok(!(await p.$(".map-tools .tool:has-text('Filtros')")) && (await p.$$(".map-tools .tool")).length === 5, "Mapa sem o botão Filtros (5 ferramentas)");
await p.click(".map-tools .tool:has-text('Mundo')"); await p.waitForTimeout(900);
const sAll = await state();
ok(total(sAll) === 4, `o mapa mostra todos os relatos, mesmo com o Feed filtrado em Enchentes (${total(sAll)})`);
await p.click(".event-bar .event-chip:has-text('Queimadas')"); await p.waitForTimeout(900);
const sQ = await state();
ok(total(sQ) === 2, `botão de evento Queimadas mostra só os relatos de queimada (${total(sQ)})`);
const lay = await p.evaluate(() => { const ts = [...document.querySelectorAll(".map-tools .tool")].map((t) => t.getBoundingClientRect()); const ws = ts.map((r) => Math.round(r.width)); const tops = ts.map((r) => Math.round(r.top)); const at = document.querySelector(".leaflet-control-attribution").getBoundingClientRect(); const z = document.querySelector(".leaflet-control-zoom").getBoundingClientRect(); const row = document.querySelector(".map-tools").getBoundingClientRect(); return { ws, umaFileira: new Set(tops).size === 1, iguais: new Set(ws).size === 1, creditoAcima: at.bottom <= row.top + 1, zoomAcima: z.bottom <= row.top + 1, cabe: ts[4].right <= innerWidth }; });
ok(lay.umaFileira && lay.iguais && lay.creditoAcima && lay.zoomAcima && lay.cabe, "ferramentas numa fileira só, do mesmo tamanho, sem nada por cima " + JSON.stringify(lay));
await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(300);
await p.click(".feed-bar .btn:has-text('Filtros')"); await p.waitForTimeout(300); await p.click("button:has-text('Limpar')"); await p.click("button:has-text('Ver resultados')").catch(() => {}); await p.waitForTimeout(300);
// 3) no Feed a folha de filtros continua funcionando
await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(800);
await p.click(".feed-bar .btn:has-text('Filtros')"); await p.waitForTimeout(300);
await p.click("#tema-filtro"); await p.click("#tema-filtro-opcoes .chip:has-text('Queimadas')"); await p.click("button:has-text('Ver resultados')"); await p.waitForTimeout(500);
const cats = await p.$$eval("article .badge.cat", (bs) => [...new Set(bs.map((x) => x.textContent.trim()))]);
ok(!(await p.$(".sheet.modal")) && cats.every((x) => x === "Queimada") && (await p.textContent("#tema-btn")).trim() === "Queimadas", "Feed: filtros continuam funcionando " + JSON.stringify(cats));
ok(errs.length === 0, "sem erros JS " + errs.join("|"));
console.log(out.join("\n")); await b.close();
