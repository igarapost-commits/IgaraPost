// IgaraPost 10 · casos difíceis: edição/exclusão com foto, token vencido, conta perdida, anônimo desligado, atualização da 8.
import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";
import { execFileSync } from "node:child_process";
const b = await chromium.launch(); const out = []; const ok = (c, n) => { out.push((c ? "OK     " : "FALHOU ") + n); console.log((c ? "OK     " : "FALHOU ") + n); };
const SB = "http://localhost:54321", K = "sb_publishable_teste";
const sql = (q) => execFileSync("psql", ["-h", "/tmp/pg", "-p", "5433", "-U", "postgres", "-d", "sbmock", "-At", "-c", q]).toString().trim();
const files = async () => (await fetch(SB + "/__files")).json();
const waitFor = async (fn, ms = 9000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return true; await new Promise((r) => setTimeout(r, 250)); } return false; };
async function device(init) {
  const c = await b.newContext({ viewport: { width: 390, height: 844 }, locale: "pt-BR" });
  await c.route(/^https?:\/\/(?!localhost)/, (r) => r.abort());
  if (init) await c.addInitScript(init.fn, init.arg);
  const p = await c.newPage(); p.errs = []; p.on("pageerror", (e) => p.errs.push(e.message));
  await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(1800);
  return [c, p];
}
const sess = (p) => p.evaluate(() => JSON.parse(localStorage.getItem("igarapost:sessao") || "null"));
const st = (p) => p.evaluate(() => JSON.parse(localStorage.getItem("igarapost:v2") || "null"));
async function compose(p, text, photo) {
  await p.goto("http://localhost:4175/#relatar"); await p.waitForTimeout(600);
  await p.click(".type-tile:has-text('Queimada')"); await p.fill("#c-text", text);
  await p.click("button:has-text('Continuar')"); await p.waitForTimeout(250);
  await p.click("text=Digitar coordenadas").catch(() => {}); await p.getByLabel("Latitude").fill("-3.12345"); await p.getByLabel("Longitude").fill("-60.0211");
  await p.click("#c-approx"); // local aproximado
  await p.click("button:has-text('Continuar')"); await p.waitForTimeout(250);
  if (photo) { await p.setInputFiles("#c-photo", photo); await p.waitForTimeout(700); }
  await p.click(".compose-actions .btn.primary"); await p.waitForTimeout(600);
}

/* ---------- token vence (TTL curto do simulador) e é renovado sozinho ---------- */
const [ca, A] = await device();
const s0 = await sess(A);
await compose(A, "Fogo em área de capoeira, fumaça escura subindo.", "/tmp/foto-teste.jpg");
ok(await waitFor(() => sql(`select count(*) from posts where author_id='${s0.user_id}'`) === "1"), "A publica com foto");
const pid = sql(`select id from posts where author_id='${s0.user_id}'`);
ok(sql(`select lat||','||lon from posts where id='${pid}'`) === "-3.12,-60.02", "local aproximado: o banco guarda só o ponto arredondado (" + sql(`select lat||','||lon from posts where id='${pid}'`) + ")");
await A.waitForTimeout(6000); // TTL=5 s
await A.goto(`http://localhost:4175/#post-${pid}`); await A.waitForTimeout(800);
await A.fill("#comment-text", "Atualizando: o fogo já diminuiu."); await A.click("button:has-text('Comentar') >> nth=-1");
ok(await waitFor(() => sql(`select count(*) from comments where post_id='${pid}'`) === "1"), "com o token vencido, o app renova a sessão sozinho e comenta");
ok((await sess(A)).user_id === s0.user_id && (await sess(A)).access_token !== s0.access_token, "mesma conta, token novo");

/* ---------- editar: troca a foto, depois remove ---------- */
const photo1 = sql(`select photo_path from posts where id='${pid}'`);
await A.goto(`http://localhost:4175/#post-${pid}`); await A.waitForTimeout(800);
await A.click("a:has-text('Editar')"); await A.waitForTimeout(600);
await A.fill("#c-text", "Fogo em área de capoeira, fumaça escura subindo. Corrigindo: começou às 14h.");
await A.click("button:has-text('Continuar')"); await A.waitForTimeout(250); await A.click("button:has-text('Continuar')"); await A.waitForTimeout(250);
const png = "/tmp/foto2.png"; execFileSync("python3", ["-c", `from PIL import Image; Image.new('RGB',(500,400),(200,90,40)).save('${png}')`]);
await A.setInputFiles("#c-photo", png); await A.waitForTimeout(700);
await A.click(".compose-actions .btn.primary"); await A.waitForTimeout(500);
ok(await waitFor(() => sql(`select photo_path from posts where id='${pid}'`) !== photo1), "editar com outra foto: a foto nova vai para o relato");
ok(sql(`select edited_at is not null from posts where id='${pid}'`) === "t" && sql(`select text from posts where id='${pid}'`).includes("14h"), "texto editado e marcado como editado");
ok(await waitFor(async () => !(await files()).includes("fotos/" + photo1)), "a foto antiga é apagada do Storage");
await A.goto(`http://localhost:4175/#post-${pid}`); await A.waitForTimeout(800);
await A.click("a:has-text('Editar')"); await A.waitForTimeout(600);
await A.click("button:has-text('Continuar')"); await A.waitForTimeout(250); await A.click("button:has-text('Continuar')"); await A.waitForTimeout(250);
await A.click(".photo-chosen button.danger"); await A.click(".compose-actions .btn.primary"); await A.waitForTimeout(500);
ok(await waitFor(() => sql(`select coalesce(photo_path,'-') from posts where id='${pid}'`) === "-"), "remover a foto na edição");
ok(await waitFor(async () => !(await files()).some((f) => f.startsWith("fotos/" + s0.user_id))), "e o arquivo sai do Storage");

/* ---------- nome do perfil aparece para os outros ---------- */
await A.goto("http://localhost:4175/#perfil"); await A.waitForTimeout(500);
await A.click("#edit-profile"); await A.waitForTimeout(300);
await A.fill(".edit-profile input:not([type=file]) >> nth=0", "Joana do Tarumã"); await A.click(".edit-profile button.primary"); await A.waitForTimeout(800);
ok(sql(`select display_name from profiles where id='${s0.user_id}'`) === "Joana do Tarumã", "nome do perfil gravado na rede");
const [cb, B] = await device();
ok(await waitFor(async () => (await B.textContent("main")).includes("Joana do Tarumã")), "outro aparelho vê o nome novo no relato");

/* ---------- apagar comentário e relato ---------- */
await A.goto(`http://localhost:4175/#post-${pid}`); await A.waitForTimeout(1000);
await A.click("button.ghost.danger:has-text('Apagar')");
ok(await waitFor(() => sql(`select count(*) from comments where post_id='${pid}'`) === "0"), "apagar o próprio comentário");
await A.goto(`http://localhost:4175/#post-${pid}`); await A.waitForTimeout(800);
await A.click("button:has-text('Excluir')"); await A.waitForTimeout(200); await A.click(".confirm button.danger:has-text('Excluir')");
ok(await waitFor(() => sql(`select count(*) from posts where id='${pid}'`) === "0"), "apagar o próprio relato");

/* ---------- servidor perde as contas (refresh recusado) → cria outra e segue ---------- */
const [cc, C] = await device();
const sc = await sess(C);
await C.evaluate(() => { const s = JSON.parse(localStorage.getItem("igarapost:sessao")); s.refresh_token = "invalido"; s.expires_at = 1; localStorage.setItem("igarapost:sessao", JSON.stringify(s)); });
await C.reload(); await C.waitForTimeout(2500);
const sc2 = await sess(C);
ok(sc2 && sc2.user_id !== sc.user_id, "sessão recusada pelo servidor: o aparelho cria outra conta sozinho e continua");

/* ---------- atualização da 8: relatos locais e servidor vazio ---------- */
const v8 = { fn: () => { if (sessionStorage.getItem("seeded")) return; sessionStorage.setItem("seeded", "1"); localStorage.setItem("igarapost:v2", JSON.stringify({ v: 2, me: { id: "me", name: "Você" }, posts: [{ id: "p-antigo1", kind: "community", authorId: "me", category: "enchente", text: "Relato feito na versão 8, só no aparelho.", lat: -3.1, lon: -60, observedAt: "2026-11-10T12:00:00.000Z", publishedAt: "2026-11-10T12:00:00.000Z", communityIds: [] }], comments: [], likes: [], saves: [], follows: ["manaus-entorno"], reports: [], hidden: [], outbox: [], server: { url: "", posts: [], comments: {} }, prefs: {} })); } };
const [cd, D] = await device(v8);
const sd = await st(D);
ok(sd.server.url === SB, "vindo da 8: passa para a rede");
ok(await waitFor(() => sql(`select count(*) from posts where id='p-antigo1'`) === "1"), "o relato antigo vai para a rede sozinho");

for (const [n, p] of [["A", A], ["B", B], ["C", C], ["D", D]]) ok(p.errs.length === 0, `${n}: sem erros de JavaScript ${p.errs.slice(0, 3).join(" | ")}`);
console.log("\n" + out.filter((x) => x.startsWith("FALHOU")).length + " falha(s) de " + out.length);
await b.close();
