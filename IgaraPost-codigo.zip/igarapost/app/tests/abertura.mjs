import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";
const b = await chromium.launch(); const out = []; const ok = (c, n) => out.push((c ? "OK     " : "FALHOU ") + n);
const mk = async (opts = {}, lang) => { const c = await b.newContext({ locale: "pt-BR", viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, ...opts }); if (lang) await c.addInitScript((l) => { try { localStorage.setItem("igarapost:lang", l); } catch {} }, lang); await c.route(/^https?:\/\/(?!localhost)/, (r) => r.abort()); const p = await c.newPage(); p.errs = []; p.on("pageerror", (e) => p.errs.push(e.message)); return [c, p]; };
// 1) quadros da animação
let [c, p] = await mk();
const t0 = Date.now(); await p.goto("http://localhost:4175/#feed", { waitUntil: "commit" });
const frames = [];
for (const t of [150, 450, 800, 1250, 1700, 2350, 2800, 3300]) { const w = t - (Date.now() - t0); if (w > 0) await p.waitForTimeout(w); const f = `/tmp/intro-${t}.png`; await p.screenshot({ path: f }); frames.push(f);
  const st = await p.evaluate(() => { const el = document.getElementById("intro"); if (!el) return null; const cs = getComputedStyle(el); const cr = document.querySelector(".intro-credit"); return { op: +cs.opacity, credit: cr ? +getComputedStyle(cr).opacity : null }; });
  out.push(`        t=${t}ms abertura=${JSON.stringify(st)}`); }
ok(!(await p.$("#intro")) && !(await p.evaluate(() => document.documentElement.classList.contains("intro-on"))), "abertura sai sozinha em ~3 s e é removida");
ok(/Tudo|publicações/.test(await p.textContent("main")), "depois dela, o Feed está pronto");
const pos = await (async () => { await p.goto("about:blank"); await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(1300); return p.evaluate(() => { const r = document.querySelector(".intro-credit").getBoundingClientRect(); const s = document.querySelector(".intro-stage").getBoundingClientRect(); return { credR: Math.round(innerWidth - r.right), credB: Math.round(innerHeight - r.bottom), text: document.querySelector(".intro-credit").textContent.replace(/\s+/g, " ").trim(), stageCx: Math.round(s.left + s.width / 2), vw: innerWidth }; }); })();
ok(pos.credR >= 16 && pos.credR < 40 && pos.credB > 15 && pos.credB < 60 && /Uma realização ?Vento Norte/.test(pos.text) && Math.abs(pos.stageCx - pos.vw / 2) <= 2, "logo no centro e crédito no canto inferior direito: " + JSON.stringify(pos));
ok(p.errs.length === 0, "sem erros JS " + p.errs.join("|"));
await c.close();
// 2) tocar pula
[c, p] = await mk(); await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(700);
const tt = Date.now(); await p.mouse.click(200, 400); await p.waitForFunction(() => !document.getElementById("intro"), null, { timeout: 3000 });
const dt = Date.now() - tt; ok(dt > 200 && dt < 900, `tocar na tela pula a abertura com um esmaecer rápido (${Date.now() - tt} ms)`);
// 3) troca de idioma não repete a abertura
await p.goto("http://localhost:4175/#perfil-configuracoes"); await p.waitForTimeout(400);
await Promise.all([p.waitForEvent("load"), p.click("[aria-labelledby=idioma-titulo] button:has-text('English')")]);
await p.waitForTimeout(150);
ok(!(await p.$("#intro")) || (await p.evaluate(() => getComputedStyle(document.getElementById("intro")).display)) === "none", "trocar o idioma recarrega sem repetir a abertura");
await p.reload(); await p.waitForTimeout(1300);
ok(/A production by ?Vento Norte/.test(await p.textContent(".intro-credit")), "abrir de novo (em inglês) mostra a abertura traduzida: " + (await p.textContent(".intro-credit")).replace(/\s+/g, " ").trim());
await p.screenshot({ path: "/tmp/intro-en.png" });
await c.close();
// 4) movimento reduzido
[c, p] = await mk({ reducedMotion: "reduce" }); await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(500);
const rm = await p.evaluate(() => ({ shine: getComputedStyle(document.querySelector(".intro-shine")).display, ripple: getComputedStyle(document.querySelector(".intro-ripple")).display }));
await p.waitForFunction(() => !document.getElementById("intro"), null, { timeout: 4000 });
ok(rm.shine === "none" && rm.ripple === "none", "com 'reduzir movimento': só aparece e some, sem brilho nem ondas");
await c.close();
// 5) vídeo
const cv = await b.newContext({ locale: "pt-BR", viewport: { width: 390, height: 844 }, recordVideo: { dir: "/tmp/video-intro", size: { width: 390, height: 844 } } });
await cv.route(/^https?:\/\/(?!localhost)/, (r) => r.abort()); const pv = await cv.newPage(); await pv.goto("http://localhost:4175/#feed"); await pv.waitForTimeout(4200); await cv.close();
console.log(out.join("\n"));
import fs from "fs"; fs.writeFileSync("/tmp/intro-frames.json", JSON.stringify(frames));
await b.close();
