// Testes da lógica do SARS (sem navegador). Uso: cd app && npx tsx tests/sars-logic.test.mts
import assert from "node:assert/strict";
(globalThis as any).window = globalThis;
const S = new URL("../src", import.meta.url).pathname;
const { parseInpeCsv, mergeFires } = await import(S + "/sars/inpeCsv.ts");
const { radarCheck, recheckStatus } = await import(S + "/sars/radar.ts");
const { categoryEvent, layerDate, tileOf, SARS_LAYERS, EVENT_ORDER } = await import(S + "/sars/layers.ts");
const results: string[] = [];
async function check(name: string, fn: () => unknown) { try { await fn(); results.push("OK   " + name); } catch (e) { results.push("FALHOU " + name + " :: " + (e as Error).message); } }

await check("parseInpeCsv: colunas por nome, aspas, BOM, linhas ruins", () => {
  const f = parseInpeCsv('﻿latitude,longitude,satelite,data_hora_gmt,frp\n-3.1,-60,NPP-375,2026-11-14 16:10:00,3.2\n"x",-60,NPP,2026-11-14 16:10:00,1\n');
  assert.equal(f.length, 1); assert.equal(f[0].t, Date.parse("2026-11-14T16:10:00Z")); assert.equal(f[0].frp, 3.2);
});
await check("parseInpeCsv lê arquivos da NASA FIRMS", () => {
  const f = parseInpeCsv("latitude,longitude,acq_date,acq_time,satellite,frp\n-3.1,-60,2026-11-14,0418,N20,2.5\n");
  assert.equal(f[0].t, Date.parse("2026-11-14T04:18:00Z")); assert.equal(f[0].sat, "VIIRS NOAA-20");
});
await check("mergeFires: sem duplicar e descartando fora da janela", () => {
  const now = Date.now();
  const a = [{ id: "1", lat: 0, lon: 0, t: now - 1000, sat: "x" }, { id: "old", lat: 0, lon: 0, t: now - 50 * 3600e3, sat: "x" }];
  const m = mergeFires(a, [{ id: "1", lat: 0, lon: 0, t: now - 1000, sat: "x" }, { id: "2", lat: 0, lon: 0, t: now, sat: "x" }], 48 * 3600e3, now);
  assert.deepEqual(m.map((x: any) => x.id), ["2", "1"]);
});
await check("categoryEvent: secas e cheias saíram (sem evento)", () => {
  for (const c of ["falta_chuva", "reducao_agua", "cheia", "impacto"]) assert.equal(categoryEvent(c as any), null, c);
  assert.deepEqual(EVENT_ORDER, ["fumaca", "queimada", "enchente"]);
  assert.ok(!SARS_LAYERS.some((l: any) => /SMAP/.test(l.layer)), "sem camada de umidade do solo"); assert.ok(EVENT_ORDER.filter((e: string) => e !== "queimada").every((e: string) => SARS_LAYERS.some((l: any) => l.event === e)), "cada evento de imagem tem camada");
});
await check("tileOf: bloco e pixel WMTS do ponto", () => {
  const t = tileOf(0, 0, 1); assert.equal(t.px, 256); assert.equal(Math.round(t.py), 256);
  assert.equal(layerDate(1, Date.parse("2026-11-14T02:00:00Z")), "2026-11-13");
});
const obs = new Date(Date.now() - 2 * 3600e3).toISOString();
await check("radarCheck queimada: foco ao vivo a 2 km → no_radar", async () => {
  const r = await radarCheck({ category: "queimada", lat: -3.1, lon: -60, observedAt: obs }, { fires: [{ id: "a", lat: -3.115, lon: -60.01, t: Date.now() - 3600e3, sat: "NPP-375" }], liveOk: true });
  assert.equal(r.status, "no_radar"); assert.equal(r.evidence?.n, 1);
});
await check("radarCheck queimada: sem foco FIRMS perto → fora_do_radar", async () => {
  (globalThis as any).fetch = async () => { throw new TypeError("offline"); };
  const r = await radarCheck({ category: "queimada", lat: -3.1, lon: -60, observedAt: obs }, { fires: [{ id: "a", lat: -3.5, lon: -60.5, t: Date.now() - 3600e3, sat: "x" }], liveOk: true });
  assert.equal(r.status, "fora_do_radar");
});
await check("radarCheck queimada sem tempo real e sem imagem → nao_verificado", async () => {
  const r = await radarCheck({ category: "queimada", lat: -3.1, lon: -60, observedAt: obs }, { fires: [], liveOk: false });
  assert.equal(r.status, "nao_verificado");
});
await check("radarCheck enchente sem conexão → nao_verificado; 'outro' → nao_verificado", async () => {
  assert.equal((await radarCheck({ category: "enchente", lat: -3.1, lon: -60, observedAt: obs }, { fires: [], liveOk: true })).status, "nao_verificado");
  assert.equal((await radarCheck({ category: "outro", lat: -3.1, lon: -60, observedAt: obs }, { fires: [], liveOk: true })).status, "nao_verificado");
});
await check("radarCheck de relato antigo de seca → nao_verificado", async () => {
  assert.equal((await radarCheck({ category: "falta_chuva", lat: -3, lon: -60, observedAt: obs }, { fires: [], liveOk: true })).status, "nao_verificado");
});
await check("recheckStatus: fora → no_radar vira confirmado; confirmado não volta; falha mantém anterior", () => {
  const fora = { status: "fora_do_radar", detail: "", checkedAt: "2026-11-14T10:00:00Z" } as any;
  const c = recheckStatus(fora, { status: "no_radar", detail: "d", checkedAt: "2026-11-14T12:00:00Z" } as any);
  assert.equal(c.status, "confirmado"); assert.equal(c.firstCheck.status, "fora_do_radar");
  assert.equal(recheckStatus(c, { status: "fora_do_radar", detail: "", checkedAt: "x" } as any).status, "confirmado");
  const k = recheckStatus(fora, { status: "nao_verificado", detail: "", checkedAt: "2026-11-14T13:00:00Z" } as any);
  assert.equal(k.status, "fora_do_radar"); assert.equal(k.recheckedAt, "2026-11-14T13:00:00Z");
});
console.log(results.join("\n"));
process.exit(results.some((r) => !r.startsWith("OK")) ? 1 : 0);
