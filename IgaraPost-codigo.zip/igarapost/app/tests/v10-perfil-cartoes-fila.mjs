// IgaraPost 10 (ajustes 2): foto de perfil para todos, cartão inteiro abre a publicação, @ editável e único,
// fila de moderação com relatos não verificados e Revisão só para a administração.
import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";
import { execFileSync } from "node:child_process";
const b = await chromium.launch(); const out = []; const ok = (c, n) => { out.push((c ? "OK     " : "FALHOU ") + n); console.log((c ? "OK     " : "FALHOU ") + n); };
const sql = (q) => execFileSync("psql", ["-h", "/tmp/pg", "-p", "5433", "-U", "postgres", "-d", "sbmock", "-At", "-c", q]).toString().trim();
const waitFor = async (fn, ms = 9000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return true; await new Promise((r) => setTimeout(r, 250)); } return false; };
async function device(locale = "pt-BR") {
  const c = await b.newContext({ viewport: { width: 390, height: 844 }, locale });
  await c.route(/^https?:\/\/(?!localhost)/, (r) => r.abort());
  await c.addInitScript(() => sessionStorage.setItem("igarapost:semIntro", "1"));
  const p = await c.newPage(); p.errs = []; p.on("pageerror", (e) => p.errs.push(e.message));
  await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(1800);
  return [c, p];
}
const sess = (p) => p.evaluate(() => JSON.parse(localStorage.getItem("igarapost:sessao") || "null"));
async function editProfile(p, { name, handle, photo }) {
  await p.goto("http://localhost:4175/#perfil"); await p.waitForTimeout(500);
  await p.click("#edit-profile"); await p.waitForTimeout(300);
  if (photo) { await p.setInputFiles("#ep-photo", photo); await p.waitForTimeout(500); }
  if (name) await p.fill("#ep-name", name);
  if (handle != null) await p.fill("#ep-handle", handle);
  await p.click("#ep-save"); await p.waitForTimeout(1200);
  return (await p.locator(".edit-profile [role=alert]").count()) ? await p.textContent(".edit-profile [role=alert]") : "";
}
async function compose(p, text) {
  await p.goto("http://localhost:4175/#relatar"); await p.waitForTimeout(600);
  await p.click(".type-tile:has-text('Enchente')"); await p.fill("#c-text", text);
  await p.click("button:has-text('Continuar')"); await p.waitForTimeout(250);
  await p.click("text=Digitar coordenadas").catch(() => {}); await p.getByLabel("Latitude").fill("-3.13"); await p.getByLabel("Longitude").fill("-60.01");
  await p.click("button:has-text('Continuar')"); await p.waitForTimeout(250);
  await p.click(".compose-actions .btn.primary"); await p.waitForTimeout(600);
}

/* ---------- A: foto, nome e @ ---------- */
const [ca, A] = await device(); const sA = await sess(A);
const e1 = await editProfile(A, { name: "Maria do Rio", handle: "@Maria_Rio", photo: "/tmp/foto-teste.jpg" });
ok(!e1 && sql(`select handle from profiles where id='${sA.user_id}'`) === "maria_rio", "A troca o @ para maria_rio (o @ e as maiúsculas são ajustados)");
const av = sql(`select coalesce(avatar_path,'-') from profiles where id='${sA.user_id}'`);
ok(av.startsWith(sA.user_id + "/avatar-"), "A foto do perfil vai para a rede: " + av);
await compose(A, "A água do igarapé subiu e cobriu a rua.");
ok(await waitFor(() => sql(`select count(*) from posts where author_id='${sA.user_id}'`) === "1"), "A publica");
const pid = sql(`select id from posts where author_id='${sA.user_id}'`);
await A.goto("http://localhost:4175/#feed"); await A.waitForTimeout(400); await A.reload(); await A.waitForTimeout(1800);
const ownImg = await A.evaluate((id) => document.querySelector(`article .post-head .avatar img`)?.getAttribute("src")?.slice(0, 30), pid);
ok(!!ownImg, "A vê a própria foto no cartão do Feed");
/* ---------- B vê a foto e o @ de A ---------- */
const [cb, B] = await device(); const sB = await sess(B);
ok(await waitFor(async () => (await B.textContent("main")).includes("A água do igarapé")), "B vê o relato de A");
const card = B.locator("article.post", { hasText: "A água do igarapé" }).first();
const src = await card.locator(".post-head .avatar img").getAttribute("src").catch(() => null);
ok(src && src.includes("/storage/v1/object/public/fotos/" + sA.user_id + "/avatar-"), "B vê a foto de perfil de A no Feed");
ok((await card.textContent()).includes("@maria_rio") && (await card.textContent()).includes("Maria do Rio"), "B vê o nome e o @ novos de A");
ok((await card.textContent()).includes("não verificado"), "relato novo aparece como “não verificado”");
/* ---------- cartão inteiro abre a publicação ---------- */
await card.locator(".post-body .text").click(); await B.waitForTimeout(600);
ok((await B.evaluate(() => location.hash)) === `#post-${pid}`, "tocar no texto do cartão abre a publicação");
await B.goto("http://localhost:4175/#feed"); await B.waitForTimeout(800);
await B.locator("article.post", { hasText: "A água do igarapé" }).first().locator(".post-meta").click(); await B.waitForTimeout(600);
ok((await B.evaluate(() => location.hash)) === `#post-${pid}`, "tocar na data/local do cartão também abre");
await B.goto("http://localhost:4175/#feed"); await B.waitForTimeout(800);
await B.locator("article.post", { hasText: "A água do igarapé" }).first().locator("button:has-text('Apoiar')").click(); await B.waitForTimeout(400);
ok((await B.evaluate(() => location.hash)) === "#feed", "tocar em Apoiar não abre a publicação");
/* ---------- comentário com a foto ---------- */
await B.goto(`http://localhost:4175/#post-${pid}`); await B.waitForTimeout(800);
await A.goto(`http://localhost:4175/#post-${pid}`); await A.waitForTimeout(800);
await A.fill("#comment-text", "Atualização: a água baixou um pouco."); await A.click("button:has-text('Comentar') >> nth=-1");
ok(await waitFor(() => sql(`select count(*) from comments where post_id='${pid}'`) === "1"), "A comenta");
await B.reload(); await B.waitForTimeout(1500);
const csrc = await B.evaluate(() => [...document.querySelectorAll("#comentarios .avatar img")].map((i) => i.getAttribute("src")).find((s) => s.includes("avatar-")));
ok(!!csrc, "B vê a foto de A no comentário");
/* ---------- @ único ---------- */
const e2 = await editProfile(B, { handle: "maria_rio" });
ok(/já está em uso/.test(e2) && sql(`select handle from profiles where id='${sB.user_id}'`) !== "maria_rio", "B não consegue usar um @ que já existe: " + e2);
await B.click(".edit-profile button:has-text('Cancelar')").catch(() => {});
const e3 = await editProfile(B, { handle: "jo" });
ok(/3 a 24/.test(e3), "@ curto demais é recusado: " + e3);
await B.click(".edit-profile button:has-text('Cancelar')").catch(() => {});
const e4 = await editProfile(B, { handle: "joao.do-lago_2" });
ok(!e4 && sql(`select handle from profiles where id='${sB.user_id}'`) === "joao.do-lago_2", "B troca para outro @ livre");
/* ---------- Revisão só para a administração ---------- */
await B.goto("http://localhost:4175/#perfil"); await B.waitForTimeout(500);
ok(!(await B.locator(".profile-menu a:has-text('Revisão')").count()), "quem não administra não vê a aba Revisão");
await B.goto("http://localhost:4175/#perfil-revisao"); await B.waitForTimeout(500);
ok(!(await B.textContent("main")).includes("Fila de moderação"), "nem abrindo o endereço da Revisão");
const [cm, M] = await device();
await editProfile(M, { name: "IgaraPost" });
await M.goto("http://localhost:4175/#perfil"); await M.waitForTimeout(600);
ok((await M.locator(".profile-menu a:has-text('Revisão')").count()) === 1, "administração vê a aba Revisão");
await M.click(".profile-menu a:has-text('Revisão')"); await M.waitForTimeout(1500);
const rv = await M.textContent("main");
ok(/Fila de moderação/.test(rv) && /Relatos não verificados \(1\)/.test(rv) && rv.includes("A água do igarapé"), "fila de moderação lista o relato não verificado");
await M.click(".queue-post button:has-text('Verificar')"); await M.waitForTimeout(1200);
ok(sql(`select verified from posts where id='${pid}'`) === "t", "administração verifica o relato");
ok(/Relatos não verificados \(0\)/.test(await M.textContent("main")), "e ele sai da fila");
await B.goto("http://localhost:4175/#feed"); await B.waitForTimeout(300); await B.reload(); await B.waitForTimeout(1800);
ok((await B.locator("article.post", { hasText: "A água do igarapé" }).first().textContent()).includes("Relato da comunidade · verificado"), "B vê o selo “verificado”");
/* ---------- autor edita: volta para a fila ---------- */
await A.goto(`http://localhost:4175/#editar-${pid}`); await A.waitForTimeout(600);
await A.fill("#c-text", "A água do igarapé subiu e cobriu a rua. Corrigindo: foi às 5h.");
await A.click("button:has-text('Continuar')"); await A.waitForTimeout(250); await A.click("button:has-text('Continuar')"); await A.waitForTimeout(250);
await A.click(".compose-actions .btn.primary"); await A.waitForTimeout(800);
ok(await waitFor(() => sql(`select verified from posts where id='${pid}'`) === "f"), "editado pelo autor, volta a “não verificado”");
/* ---------- inglês ---------- */
const [ce, E] = await device("en-US");
ok(await waitFor(async () => (await E.textContent("main")).includes("Community report · unverified") || (await E.textContent("main")).includes("Community report · not verified")), "selo traduzido em inglês");
for (const [n, p] of [["A", A], ["B", B], ["M", M], ["E", E]]) ok(p.errs.length === 0, `${n}: sem erros de JavaScript ${p.errs.slice(0, 3).join(" | ")}`);
console.log("\n" + out.filter((x) => x.startsWith("FALHOU")).length + " falha(s) de " + out.length);
await b.close();
