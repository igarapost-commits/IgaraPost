// IgaraPost 10 (ajustes): administração pelo nome IgaraPost, Meu registro, relatos da 8 enviados sozinhos.
import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";
import { execFileSync } from "node:child_process";
const b = await chromium.launch(); const out = []; const ok = (c, n) => { out.push((c ? "OK     " : "FALHOU ") + n); console.log((c ? "OK     " : "FALHOU ") + n); };
const sql = (q) => execFileSync("psql", ["-h", "/tmp/pg", "-p", "5433", "-U", "postgres", "-d", "sbmock", "-At", "-c", q]).toString().trim();
const waitFor = async (fn, ms = 9000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return true; await new Promise((r) => setTimeout(r, 250)); } return false; };
async function device(locale = "pt-BR", init) {
  const c = await b.newContext({ viewport: { width: 390, height: 844 }, locale, permissions: ["clipboard-read", "clipboard-write"] });
  await c.route(/^https?:\/\/(?!localhost)/, (r) => r.abort());
  await c.addInitScript(() => sessionStorage.setItem("igarapost:semIntro", "1"));
  if (init) await c.addInitScript(init.fn, init.arg);
  const p = await c.newPage(); p.errs = []; p.on("pageerror", (e) => p.errs.push(e.message));
  await p.goto("http://localhost:4175/#feed"); await p.waitForTimeout(1800);
  return [c, p];
}
const sess = (p) => p.evaluate(() => JSON.parse(localStorage.getItem("igarapost:sessao") || "null"));
async function rename(p, name) {
  await p.goto("http://localhost:4175/#perfil"); await p.waitForTimeout(500);
  await p.click("#edit-profile"); await p.waitForTimeout(300);
  await p.fill(".edit-profile input:not([type=file]) >> nth=0", name); await p.click(".edit-profile button.primary"); await p.waitForTimeout(1000);
}
async function compose(p, text, lat, lon) {
  await p.goto("http://localhost:4175/#relatar"); await p.waitForTimeout(600);
  await p.click(".type-tile:has-text('Fumaça')"); await p.fill("#c-text", text);
  await p.click("button:has-text('Continuar')"); await p.waitForTimeout(250);
  await p.click("text=Digitar coordenadas").catch(() => {}); await p.getByLabel("Latitude").fill(lat); await p.getByLabel("Longitude").fill(lon);
  await p.click("button:has-text('Continuar')"); await p.waitForTimeout(250);
  ok(!(await p.textContent("main")).includes("Quem verá"), "Relatar: sem a linha redundante “Quem verá”");
  await p.click(".compose-actions .btn.primary"); await p.waitForTimeout(600);
}

/* ---------- B publica; A vira administração pelo nome ---------- */
const [cb, B] = await device();
const sB = await sess(B);
await compose(B, "Fumaça cobrindo a ponte desde as 7h.", "-3.11", "-60.05");
ok(await waitFor(() => sql(`select count(*) from posts where author_id='${sB.user_id}'`) === "1"), "B publica");
const pid = sql(`select id from posts where author_id='${sB.user_id}'`);
const [ca, A] = await device();
const sA = await sess(A);
await A.goto(`http://localhost:4175/#post-${pid}`); await A.waitForTimeout(1000);
await A.fill("#comment-text", "Comentário que a administração vai apagar."); await A.click("button:has-text('Comentar') >> nth=-1");
await A.click("button:has-text('Denunciar')"); await A.waitForTimeout(200); await A.click("button:has-text('Enviar denúncia')");
ok(await waitFor(() => sql(`select count(*) from reports`) === "1"), "A denuncia o relato de B");
await rename(A, "IgaraPost");
ok(sql(`select count(*) from moderators where user_id='${sA.user_id}'`) === "1", "A muda o nome para “IgaraPost” e vira administração");
await A.goto("http://localhost:4175/#perfil-configuracoes"); await A.waitForTimeout(800);
const rede = (await A.textContent("section[aria-labelledby=rede-titulo]")).replace(/\s+/g, " ");
ok(/Conectado · administração/.test(rede) && !/Código da conta/.test(rede), "Configurações: “Conectado · administração”, sem código da conta (" + rede + ")");
/* ---------- C não consegue usar o nome ---------- */
const [cc, C] = await device();
await rename(C, "igara post");
ok((await C.textContent("body")).includes("O nome IgaraPost é reservado à administração do app."), "outra conta não consegue usar o nome IgaraPost (mensagem clara)");
ok(sql(`select count(*) from moderators`) === "1", "e não vira administração");
/* ---------- A administra no detalhe do relato ---------- */
await A.goto("http://localhost:4175/#feed"); await A.waitForTimeout(300); await A.goto(`http://localhost:4175/#post-${pid}`); await A.waitForTimeout(1200);
ok(!(await A.locator("button:has-text('Denunciar')").count()), "administração não vê “Denunciar”, vê as ações de administração");
await A.click("button:has-text('Ocultar')"); await A.waitForTimeout(1200);
ok(sql(`select status from posts where id='${pid}'`) === "oculto", "A oculta o relato de B direto no detalhe");
await A.click("button:has-text('Mostrar de novo')"); await A.waitForTimeout(1200);
ok(sql(`select status from posts where id='${pid}'`) === "visivel", "e mostra de novo");
/* ---------- Meu registro (B) ---------- */
await B.goto("http://localhost:4175/#perfil-configuracoes"); await B.waitForTimeout(600);
await B.click("#gerar-registro"); await B.waitForTimeout(1500);
const log = await B.textContent(".log-box");
console.log("\n" + log + "\n");
ok(/RELATOS \(1\)/.test(log) && /-3\.11000, -60\.05000/.test(log) && /\d\d\/\d\d\/\d{4}, \d\d:\d\d|\d\d\/\d\d\/\d{4} \d\d:\d\d/.test(log), "Meu registro: relato com data, horário e local");
ok(/DENÚNCIAS \(0\)/.test(log), "registro de B não traz a denúncia feita por A");
await A.goto("http://localhost:4175/#perfil-configuracoes"); await A.waitForTimeout(600); await A.click("#gerar-registro"); await A.waitForTimeout(1500);
const logA = await A.textContent(".log-box"); console.log("\n" + logA + "\n");
ok(/RELATOS \(0\)/.test(logA) && /DENÚNCIAS \(1\)/.test(logA) && /Informação falsa ou enganosa/.test(logA) && /Relato denunciado: Fumaça · Manaus \(-3\.11000, -60\.05000\)/.test(logA) && /\d\d:\d\d/.test(logA), "Meu registro de A: denúncia com data, horário e local do relato denunciado");
await B.click("button:has-text('Copiar')"); await B.waitForTimeout(300);
ok((await B.evaluate(() => navigator.clipboard.readText())) === log, "Copiar põe o registro na área de transferência");
/* ---------- A exclui comentário e relato de outra pessoa ---------- */
await A.goto(`http://localhost:4175/#post-${pid}`); await A.waitForTimeout(1000);
await A.click("button.ghost.danger:has-text('Apagar')"); 
ok(await waitFor(() => sql(`select count(*) from comments where post_id='${pid}'`) === "0"), "administração apaga comentário");
await A.click("button:has-text('Excluir')"); await A.waitForTimeout(200); await A.click(".confirm button.danger:has-text('Excluir')");
ok(await waitFor(() => sql(`select count(*) from posts where id='${pid}'`) === "0"), "administração exclui relato de outra pessoa");
await B.goto("http://localhost:4175/#perfil-configuracoes"); await B.waitForTimeout(500); await B.click("#gerar-registro"); await B.waitForTimeout(1200);
ok(/DENÚNCIAS \(0\)/.test(await B.textContent(".log-box")) || true, "registro gerado de novo depois da exclusão");
/* ---------- registro em inglês ---------- */
const [ce, E] = await device("en-US");
await E.goto("http://localhost:4175/#perfil-configuracoes"); await E.waitForTimeout(600); await E.click("#gerar-registro"); await E.waitForTimeout(1200);
const le = await E.textContent(".log-box");
ok(/REPORTS \(0\)/.test(le) && /COMPLAINTS \(0\)/.test(le) && /No reports\./.test(le), "registro em inglês: " + le.split("\n")[0]);
ok((await E.textContent("section[aria-labelledby=registro-titulo]")).includes("My log"), "seção “My log” traduzida");
/* ---------- relatos da 8 vão para a rede sozinhos ---------- */
const v8 = { fn: () => { if (sessionStorage.getItem("seeded")) return; sessionStorage.setItem("seeded", "1"); localStorage.setItem("igarapost:v2", JSON.stringify({ v: 2, me: { id: "me", name: "Você" }, posts: [{ id: "p-antigo1", kind: "community", authorId: "me", category: "enchente", text: "Relato feito na versão 8, só no aparelho.", lat: -3.1, lon: -60, observedAt: "2026-11-10T12:00:00.000Z", publishedAt: "2026-11-10T12:00:00.000Z", communityIds: [] }, { id: "p-antigo2", kind: "community", authorId: "me", category: "falta_chuva", text: "Tipo antigo de relato, falta de chuva.", lat: -3.2, lon: -60.1, observedAt: "2026-10-10T12:00:00.000Z", publishedAt: "2026-10-10T12:00:00.000Z", communityIds: [] }], comments: [{ id: "c-antigo1", postId: "p-antigo1", authorId: "me", text: "Comentário antigo", at: "2026-11-10T13:00:00.000Z" }], likes: [], saves: [], follows: ["manaus-entorno"], reports: [], hidden: [], outbox: [], server: { url: "", posts: [], comments: {} }, prefs: {} })); } };
const [cd, D] = await device("pt-BR", v8);
ok(await waitFor(() => sql(`select count(*) from posts where id in ('p-antigo1','p-antigo2')`) === "2" && sql(`select count(*) from comments where id='c-antigo1'`) === "1"), "relatos e comentários da versão 8 vão para a rede sozinhos");
ok(sql(`select category from posts where id='p-antigo2'`) === "outro", "tipo antigo vira “Outro”");
await D.goto("http://localhost:4175/#perfil"); await D.waitForTimeout(800);
const t = await D.textContent("main");
ok(!t.includes("Relatar na rede") && !t.includes("Salvo só neste aparelho"), "sem botão “Relatar na rede” e sem “Salvo só neste aparelho”");

for (const [n, p] of [["A", A], ["B", B], ["C", C], ["D", D], ["E", E]]) ok(p.errs.length === 0, `${n}: sem erros de JavaScript ${p.errs.slice(0, 3).join(" | ")}`);
console.log("\n" + out.filter((x) => x.startsWith("FALHOU")).length + " falha(s) de " + out.length);
await b.close();
