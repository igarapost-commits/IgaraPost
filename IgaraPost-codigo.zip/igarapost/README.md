# IgaraPost

Rede de monitoramento colaborativo de fumaça, queimadas e enchentes. Um mapa-múndi (SARS) junta camadas
globais de satélite e radar, focos do INPE em tempo real e os relatos da população, principalmente do que ainda está
**fora do radar** dos sensores oficiais. Inclui publicações da equipe com dados oficiais (INPE) e uma
exploração experimental do radar NISAR no entorno de Manaus. Equipe
Vento Norte (UEA), NASA Space Apps Challenge, desafio *Dancing with the SARs*.

**Versão atual: IgaraPost 10** (versionName 10.0.0, versionCode 37; rede social funcional com Supabase) (15/11/2026). As mudanças de cada versão estão no fim deste arquivo.

## Estrutura

```
igarapost/
├── app/              React + TypeScript + Vite + Leaflet; Android com Capacitor 6
│   ├── src/          telas: Feed, Mapa, Relatar, Perfil (com Meus relatos), Explorador NISAR, Sobre
│   │   ├── sars/       provedor SARS: config, camadas globais, tempo real e conferência "fora do radar"
│   │   ├── store.ts    armazenamento no aparelho com gravação conferida
│   │   ├── sync.ts     fila de envio, sincronização e estados reais de cada relato
│   │   ├── sb.ts       conexão com o Supabase (conta anônima, relatos, comentários, fotos, denúncias, moderação)
│   │   └── api.ts      erros de rede e cliente do servidor antigo
│   ├── public/data/  camadas pequenas preparadas pelo pipeline (~1,8 MB)
│   ├── tests/e2e.mjs teste de ponta a ponta com dois aparelhos simulados e o servidor real
│   └── android/      projeto Android (a chave de assinatura não vai para o repositório)
├── supabase/         igarapost-v10.sql: banco da rede (tabelas, regras RLS, fotos, moderação) + teste das regras
├── server/           servidor próprio das versões até a 8 (não é mais usado pelo app)
├── data-pipeline/    Python: baixa, recorta e prepara os dados; scripts NISAR
└── docs/             NISAR_METODO.md, NISAR_INVENTARIO.md
```

## Como executar

### App no navegador (desenvolvimento)
```bash
cd app && npm install && npm run dev
```
Sem servidor configurado, tudo fica salvo só no navegador e o app avisa isso no topo.

### Rede compartilhada (Supabase)
A partir da IgaraPost 10, a rede é o projeto Supabase `igarapost` (`https://bwkdeulgxnozixlqpsud.supabase.co`).
O app usa só o endereço e a **chave publicável** (`sb_publishable_…`), gravados em `app/src/sb.ts`; a senha do banco e a
chave secreta nunca vão no app. A segurança está nas regras do banco.

1. No painel do Supabase: **SQL Editor › New query**, cole `supabase/igarapost-v10.sql` inteiro e clique **Run**. Pode rodar de novo
   sem perder dados (é assim que se aplica uma versão nova do script).
2. **Authentication › Sign In / Providers › Allow anonymous sign-ins**: ligado. Cada aparelho entra sozinho, sem e-mail nem senha.
3. **Administração:** no celular de quem administra, Perfil › Editar perfil › nome **IgaraPost**. A primeira conta que
   adota esse nome vira a administradora; depois disso o nome fica reservado e o banco recusa para as outras contas.
   Só a administração vê a aba Perfil › Revisão (fila de moderação: denúncias pendentes e relatos não verificados) e pode
   verificar, ocultar, mostrar de novo ou excluir qualquer relato ou comentário (no detalhe do relato). Para tirar alguém: `delete from public.moderators where user_id = '…';`.

Para apontar o app para outro projeto: `VITE_SUPABASE_URL` e `VITE_SUPABASE_KEY` no build.

### Testes
Rede (IgaraPost 10), com um Supabase simulado que roda as consultas num PostgreSQL de verdade com o script do banco
(mesmas regras RLS, gatilhos e funções):
```bash
app/tests/supabase-simulado/preparar-banco.sh          # recria o banco de teste
node app/tests/supabase-simulado/servidor.mjs          # Auth + REST + Storage em http://localhost:54321
# build de teste: VITE_SUPABASE_URL=http://localhost:54321 VITE_SUPABASE_KEY=sb_publishable_teste
node app/tests/v10-dois-aparelhos.mjs                  # A publica com foto; B vê, comenta, denuncia; moderador oculta; offline
TTL=5 node app/tests/supabase-simulado/servidor.mjs    # (token vence em 5 s) para:
node app/tests/v10-casos-dificeis.mjs                  # editar/apagar com foto, token vencido, conta perdida, atualização da 8
node app/tests/v10-sem-servidor.mjs                    # primeira abertura sem servidor; também com ANON=0 no simulador
node app/tests/v10-administracao-registro.mjs          # nome IgaraPost = administração, Meu registro, relatos da 8
```
`supabase/teste-regras.sql` confere as regras direto no banco (duas pessoas e um moderador).

```bash
node server/test.mjs
```
```bash
cd app && npm run build && npx vite preview --port 4173
```
Em outro terminal, com o servidor rodando:
```bash
cd app && NODE_PATH=$(npm root -g) node tests/e2e.mjs http://localhost:4173/ http://localhost:8787
```
```bash
cd data-pipeline && python3 tests/test_gcov_pipeline.py /tmp/gcovtest
```
```bash
cd app && npx tsx tests/sars-logic.test.mts
```
O teste de ponta a ponta precisa do Playwright com o Chromium instalado globalmente. Use `ANDROID=1` para o perfil de um celular Android.

### APK Android
```bash
cd app && npm run android:apk
```
Requer JDK 17 ou mais novo, Android SDK 34 (`sdk.dir` em `android/local.properties`), `android/igarapost-release.jks` e `android/keystore.properties`. Para o app já vir com o servidor configurado, defina `VITE_API_URL=https://...` antes do comando.

### Botão voltar do celular e notificações do sistema (build nativo)
O APK gerado neste repositório reaproveita o código nativo da versão 0.2.0, que não tem os plugins `@capacitor/app` e
`@capacitor/local-notifications`. Sem eles, no Android:
- o botão/gesto **voltar do celular** fecha o app direto (o botão **Voltar** no topo do app funciona);
- o aviso de **relato verificado** aparece dentro do app (mensagem e aba Atividade), não na barra de notificações.

O código já está pronto para os dois plugins (estão em `package.json`). Para ativá-los, gere o APK no computador da equipe:
```bash
cd app && npm install && npm run build && npx cap sync android
# depois abra app/android no Android Studio (Build › Build APK) ou: cd android && ./gradlew assembleDebug
```
Com o `@capacitor/app` (sem ouvintes no JS), o voltar do celular volta no histórico do WebView e, quando não há mais
para onde voltar, fecha o app. Como o app guarda só a última tela (`src/nav.ts`), o resultado é: voltar leva à última
tela; na primeira tela, fecha o app. Com o `@capacitor/local-notifications`, ligar o aviso em Configurações pede a
permissão do Android 13+ e o aviso passa a aparecer na barra de notificações (tocar abre o relato). Notificação com o
app fechado exigiria notificação push (Firebase), que não está no projeto: o app confere ao abrir e a cada 90 s aberto.

### Dados
```bash
cd data-pipeline && pip install -r requirements.txt && ./run_all.sh
```
A atualização é **manual**: rode o pipeline e gere um novo build. O app mostra a data de obtenção de cada fonte em Sobre e no indicador do topo.

## SARS: mapa-múndi e tempo real (0.3.0)

"SARS" é o nome, na interface, da camada de dados ambientais do app. Ela é um **provedor configurável**
(`app/src/sars/config.ts`). Por padrão usa fontes públicas:

| Evento | Camada global (NASA GIBS, WMS) | Sensor | Atualização |
|---|---|---|---|
| Fumaça | `MODIS_Terra_Aerosol_Optical_Depth_3km` | óptico | diária |
| Queimadas | focos de fogo ativo da **NASA FIRMS** (VIIRS NOAA-20 e Suomi NPP) | infravermelho termal | quase em tempo real |
| Enchentes | `MODIS_Combined_Flood_2-Day` | óptico | diária |
| Enchentes (água por radar) | `OPERA_L3_Dynamic_Surface_Water_Extent-Sentinel-1` (+ NISAR experimental) | **radar SAR** | 6–12 dias |

Mapa-múndi de fundo: `VIIRS_SNPP_CorrectedReflectance_TrueColor` (dia anterior completo) ou Blue Marble; OSM e o mapa
offline continuam disponíveis.

**Tempo real.** O servidor lê o CSV diário de focos do INPE a cada 5 min e envia os focos novos ao app por
**Server-Sent Events** (`/api/live/stream`). Se o SSE falhar, o app troca para polling (`/api/live/fires`). Sem
servidor, o app consulta o INPE diretamente: no APK isso usa o HTTP nativo; no navegador o INPE pode recusar por CORS,
e o app avisa. As imagens do GIBS são recarregadas a cada 30 min com o mapa aberto.

**Fora do radar.** Ao relatar, o app confere se o evento já aparece no SARS perto do ponto e da data:
- fogo e fumaça: focos ao vivo (5 km / 30 km) e pixels de anomalia térmica;
- enchente: pixels de inundação do MODIS.

O resultado (`no_radar`, `fora_do_radar`, `nao_verificado`) vai junto com o relato. Em Perfil › Meus relatos, a
conferência é refeita, automaticamente para relatos recentes ou pelo botão. Se o evento passar a aparecer, o relato
vira **"Confirmado depois pelo SARS"**. Nenhum desses estados verifica o relato.

Para usar outro provedor, defina no build:

| Variável | Para quê |
|---|---|
| `VITE_SARS_NAME` | nome mostrado na interface (padrão `SARS`) |
| `VITE_SARS_WMS_URL` | WMS das camadas globais (EPSG:3857, com `TIME`) |
| `VITE_SARS_LIVE_URL` | serviço de tempo real com as rotas `/api/live/*` (padrão: o servidor do app) |
| `VITE_SARS_INPE_CSV` | CSV de focos para a consulta direta, com `{AAAAMMDD}` |

Os identificadores das camadas ficam em `app/src/sars/layers.ts`. Os de queimadas, enchentes e OPERA DSWx-S1 foram
conferidos no GetCapabilities do GIBS em 14/11/2026. Os de aerossol e cor natural seguem a nomenclatura do GIBS
e não foram conferidos um a um. Uma camada que não carregar aparece como "Não carregou" na legenda, sem quebrar o
mapa.

## O que funciona (verificado em 14/11/2026, versão 0.2.0)

| Verificação | Como foi verificada | Resultado |
|---|---|---|
| Falha de gravação não gera falso sucesso; o formulário preserva o conteúdo e permite tentar de novo | e2e com `localStorage` forçado a falhar (cota cheia) | OK |
| Rascunho salvo no aparelho e recuperado ao reabrir | e2e com recarga da página | OK |
| Filtro municipal recalcula os números (Autazes, setembro: 239 focos AQUA_M-T no município inteiro) e não mostra resumo regional como municipal | e2e | OK |
| Relatos locais respeitam o município escolhido | e2e | OK |
| Mapa aberto de um relato mantém local e período; datas de cada camada mostradas separadamente | e2e | OK |
| Mapa offline quando o mapa online falha; busca por comunidade; consulta de ponto com estados distintos | e2e com o OpenStreetMap bloqueado | OK |
| Publicar → outro aparelho vê → comenta → o autor consulta o comentário | e2e, dois contextos de navegador + servidor real | OK |
| Edição e exclusão só pelo autor (403 para outras pessoas) | testes da API e e2e | OK |
| Sem conexão: "Aguardando conexão"; envio automático ao voltar | e2e com rede desligada | OK |
| Denúncia vai para a fila de moderação do servidor; exemplos fictícios nunca são enviados | e2e e testes da API | OK |
| Tema claro/escuro, sem rolagem horizontal no celular | e2e (400 px e Pixel 7) | OK |
| Análise calibrada NISAR: alinhamento, máscaras e parâmetros | só com dados sintéticos | 9/9 OK |

Totais:
- e2e: 44/44 na versão web e 44/44 no pacote do APK com perfil Pixel 7;
- API do servidor: 15/15;
- script NISAR calibrado: 9/9 com dados sintéticos.

**Limite da verificação:** o APK foi gerado, assinado e conferido (`apksigner`, `aapt`), e o conteúdo web empacotado foi testado no Chromium com perfil Android. **O app não foi aberto num celular ou emulador Android**, porque o ambiente de build não tem aceleração para emulador. Teste num aparelho, principalmente a localização, a câmera/galeria e a conexão com o servidor.

## Estados de um relato (os que existem de fato)

| Estado | Significado |
|---|---|
| Rascunho salvo no aparelho | formulário em andamento, gravado e conferido |
| Salvo só neste aparelho | modo sem servidor; outras pessoas não veem |
| Aguardando conexão | gravado na fila do aparelho; será enviado quando houver conexão |
| Enviando… | envio em andamento |
| Falha no envio | o servidor recusou; o motivo aparece com as opções corrigir ou tentar de novo |
| Publicado | confirmado pelo servidor, visível para outras pessoas |
| Ocultado após revisão | moderação ocultou depois de uma denúncia |

## Limitações e dependências

- **Servidor publicado na internet:** falta um host com HTTPS. O servidor roda em qualquer máquina com Node 22. O APK aceita HTTP só para teste em rede local, e isso deve ser desligado em produção.
- **Contas:** não há recuperação de senha nem verificação de e-mail. Moderadores são definidos por variável de ambiente.
- **NISAR calibrado:** não executado com dados reais, porque o login Earthdata foi recusado. A análise do app usa as prévias (browse) e é uma exploração visual experimental. Os detalhes estão em `docs/NISAR_METODO.md`.
- **Dados ambientais:** são uma fotografia de 14/11/2026, com atualização manual. Os focos vão até 13/11/2026 20:04 UTC.
- **Geometrias municipais:** o arquivo `cemaden_iis.json` (serviço público do Cemaden) é usado só para achar o município de um ponto; os índices de seca dele não aparecem mais no app.
- **Mapa online:** o OpenStreetMap tem política de uso justo. Para muitos usuários, use um provedor de mapas próprio.
- **Apoios e salvos:** continuam só no aparelho.
- **Validação com usuários:** não houve teste com usuários reais.

## Fontes e créditos
- INPE, Programa Queimadas (dados abertos).
- Cemaden/MCTI, Alerta Secas.
- NASA/JPL e ISRO, missão NISAR, via ASF DAAC.
- NASA GIBS (Blue Marble).
- © colaboradores do OpenStreetMap (ODbL).
- Software livre: React, Vite, Leaflet, Capacitor, Node.js e SQLite.

As publicações com números são **elaboradas pela equipe** a partir desses dados, não pelas instituições.

## Mudanças da 0.5.7 para a 0.5.8
Feita a partir da 0.5.7 ("IgaraPost 7.7"), a pedido da equipe; as mudanças da 0.6.0 não estão nesta versão.
- Feed: no lugar da fileira de temas (Enchentes ficava cortado na tela), há um só botão com o tema escolhido ("Tudo"
  no começo), ao lado de Filtros. Tocar nele abre todas as opções (Tudo, Fumaça, Queimadas, Enchentes); escolher uma
  fecha a lista.
- Sobre nós: logo redonda da Vento Norte (UEA) ao lado da logo do IgaraPost (`app/public/vento-norte-redonda.png`,
  recortada no círculo, sem o fundo cinza; original em `app/assets-src/vento-norte-redonda-original.png`).

## Mudanças da 0.5.6 para a 0.5.7
- **Correção do Explorador NISAR:** desde a 0.5.3 o mapa ficava preto, porque uma regra de estilo do minimapa
  (`position: relative`) também valia para `.nisar-map` e deixava o mapa com altura zero. O mapa volta a ocupar a
  moldura inteira, como na 0.5.2.
- A **Camada de mudança** saiu de novo do Estudo de Região (fica só "Deslizar A × B").
- Apoiar e Salvar: o coração e o marcador ficam **preenchidos** quando marcados e vazios ao desmarcar (Icon `filled`).
- Logo da Vento Norte **padronizada** nos cartões com fundo:
  - os cartões usam versões das imagens sem a logo embutida (`bg/<tipo>-post.jpg`);
  - a logo entra à parte, sempre branca, com 44 px de altura e no mesmo canto. Antes ela ficava tingida pela cor e pelo
    véu de cada foto.

## Mudanças da 0.5.5 para a 0.5.6
- Explorador NISAR: a **Camada de mudança** voltou ao Estudo de Região (botões "Deslizar A × B" e "Camada de mudança").
- Relatar:
  - botões de baixo simétricos: a ação principal (Continuar ou Relatar) na linha toda e, embaixo, Voltar e Cancelar do
    mesmo tamanho (na etapa 1, Cancelar na linha toda);
  - bordas dos tipos de ocorrência com 2 px na cor de cada tipo, iguais às dos posts; o escolhido ganha um anel na mesma
    cor.
- **Meus relatos** com o mesmo fundo e borda dos posts do feed, conforme a tag. O selo de envio fica abaixo do título e
  os botões do cartão viraram uma grade 2 × 2.
- Posts "Outro" com a arte IgaraPost **centralizada** (`bg/outro-post.jpg`, a mesma imagem sem a logo embutida) e a
  logo branca da Vento Norte no canto superior direito.

## Mudanças da 0.5.4 para a 0.5.5
- Publicações com a tag **Outro** também ganham imagem de fundo (logo do IgaraPost, sem a borda branca).
- Fundo dos posts **sem degradê**: um véu liso por tipo, só o necessário para ler o texto (`POST_VEIL` em `seed.ts`:
  fumaça 0,5; queimada 0,32; enchente 0,18; Outro 0,12).
- Bordas dos posts na cor de cada tipo, no lugar das bordas azuis (`POST_BORDER`): queimada laranja `#e8641a`, fumaça
  cinza `#9aa1a6`, enchente azul-marinho do fundo `#2f4278` e Outro verde-escuro `#2b5a5f`. Vale também para os
  explicativos fixados no topo.

## Mudanças da 0.5.3 para a 0.5.4
- **Imagens de fundo por tipo** (pasta `app/public/bg`, sem a borda branca; originais em `app/assets-src/bg`):
  - publicações e relatos de **fumaça** (Teatro Amazonas na fumaça), **enchente** (rua alagada) e **queimada**
    (brigadista) no feed, com véu escuro e texto claro nos dois temas. A logo da Vento Norte já vem na imagem, então a
    logo separada não aparece nesses posts;
  - os botões Fumaça, Queimada, Enchente e **Outro** (logo do IgaraPost) na tela Relatar.

## Mudanças da 0.5.2 para a 0.5.3
- **Logo da Vento Norte (UEA)** no canto superior direito das publicações da equipe: branca no tema escuro, preta no
  claro. Os arquivos são `app/public/vento-norte-branca.png` e `vento-norte-preta.png`, gerados da logo preta
  original (`app/assets-src/vento-norte-original.png`).
- Relatar:
  - o campo de data e hora fica travado; para editá-lo, toque no novo atalho **Personalizar** (ao lado de Ontem);
  - os quatro atalhos ficam numa linha só;
  - os botões + e − do minimapa não passam mais por cima do topo ao rolar.
- Mapa:
  - **NASA Blue Marble** é o fundo padrão;
  - saíram as opções "Litoral, fronteiras e nomes de lugares" e "Imagem detalhada ao aproximar" (o detalhe HLS
    continua ligado);
  - o cabeçalho das janelas de baixo (com o X) fica fixo ao rolar;
  - ao buscar um município ou uma cidade, o mapa desenha o **limite do município** (linha tracejada) e enquadra o
    território. A etiqueta "Limite de …" tira a linha.
- Explorador NISAR:
  - Data A e Data B lado a lado, centralizadas;
  - saiu a "Camada de mudança" (fica só a comparação deslizando A × B);
  - o gráfico de superfície escura foi refeito: ocupa a largura da tela sem cortar pontos, tem curva suave
    (interpolação monotônica, sem picos inventados), área em degradê, meses no eixo, as datas A e B marcadas e o
    valor de cada passagem ao tocar.

## Mudanças da 0.5.1 para a 0.5.2
- **Relatos entre aparelhos sem login.** Com um servidor configurado (`VITE_API_URL` no build), cada aparelho cria
  sozinho uma conta (`aparelho_xxxxxxxxxx`, senha aleatória guardada em `igarapost:device-account`) na primeira vez que
  abre com internet.
  - Os relatos vão para a rede compartilhada e aparecem no Feed e no Mapa de todos os aparelhos.
  - O nome escolhido em Editar perfil é o nome mostrado na rede; sem nome, aparece "Pessoa da comunidade".
  - Relatos antigos feitos "neste aparelho" não são enviados sozinhos (há o botão "Relatar na rede" em Meus relatos).
  - Sem servidor ou sem internet, tudo continua funcionando só no aparelho.
- Servidor: `TRUST_PROXY=1` usa o IP do `X-Forwarded-For` nos limites de tentativas (necessário atrás de hospedagens).
- **Publicação do servidor:** `Dockerfile`, `.dockerignore` e `render.yaml` na raiz (ver "Publicar o servidor" abaixo).
- Relatar:
  - saíram os avisos "Rascunho salvo no aparelho às…" (o rascunho continua sendo salvo; só uma falha aparece);
  - os atalhos Agora, Hoje cedo e Ontem ficam marcados quando escolhidos;
  - "Tirar foto" e "Escolher da galeria" viraram dois botões grandes iguais, sem sobreposição com os textos.
- Editar perfil: saiu o texto "Tudo fica guardado só neste aparelho".
- Feed: "Ver mais" à direita, logo abaixo do texto.

### Publicar o servidor (para os relatos aparecerem entre aparelhos)
1. Suba este projeto para um repositório no GitHub.
2. No Render (render.com), "New +" > "Blueprint", escolha o repositório: o `render.yaml` cria o serviço
   `igarapost-servidor` com o `Dockerfile`. Qualquer serviço que rode Docker (Fly.io, Railway) também serve.
3. Confira `https://SEU-ENDERECO/api/health` (deve responder `"ok": true`).
4. Gere o app com `VITE_API_URL=https://SEU-ENDERECO` (em `app/.env` antes do `npm run build`).
- No plano gratuito do Render, o serviço dorme sem uso (o primeiro acesso demora cerca de 1 min) e o disco é apagado ao
  reiniciar. Para guardar os relatos, use um plano com disco (o `render.yaml` traz o trecho comentado) ou um volume
  no Fly.io.

## Mudanças da 0.5.0 para a 0.5.1
- O mapa abre **sem nenhum evento ligado** (antes, Queimadas vinha ligado).
- **Mais nitidez de perto:**
  - o fundo da NASA ia só até o zoom 13 e sumia depois; agora vai até o zoom 18;
  - a partir do zoom 10 entra o detalhe de 30 m do **NASA HLS** (Harmonized Landsat Sentinel-2) na GIBS. São as
    camadas `HLS_L30_Nadir_BRDF_Adjusted_Reflectance` e `HLS_S30_Nadir_BRDF_Adjusted_Reflectance`, em
    `GoogleMapsCompatible_Level12`, PNG;
  - são usados os últimos 6 dias, a passagem mais recente por cima. Onde não há passagem ou o bloco falha, aparece o
    satélite do dia;
  - dá para desligar em Camadas ("Imagem detalhada ao aproximar").
- **Correção:** depois de abrir um relato no mapa, o mapa ficava preso no local dele, mesmo com o relato excluído. Agora
  o contexto do relato vale só para aquela visita ao mapa e some quando o relato deixa de existir.
- As ferramentas do mapa (Buscar, Região, Mundo, Camadas, Filtros e NISAR) foram para o **canto inferior esquerdo**, em
  grade 3 × 2, e a atribuição fica à direita delas.

## Mudanças da 0.4.2 para a 0.5.0
- **Secas e cheias saíram do app.** Ficam só fumaça, queimadas e enchentes:
  - mapa com 3 filtros (a camada de umidade do solo SMAP saiu; a água por radar OPERA e o NISAR passaram para Enchentes);
  - Relatar com os tipos Fumaça, Queimada, Enchente e Outro; Feed com os temas Tudo, Fumaça, Queimadas e Enchentes;
  - saíram as publicações do índice de seca do Cemaden, o explicativo do IIS, os exemplos fictícios de seca e o bloco
    de índice de seca nos detalhes de um relato; a comunidade "Rios, seca e cheia" virou "Rios e enchentes";
  - relatos antigos de seca, cheia ou água baixa guardados no aparelho deixam de aparecer, e um filtro salvo de Secas
    ou Cheias volta para "Tudo";
  - o servidor recusa essas categorias (400) e não as lista mais no feed;
  - o arquivo `cemaden_iis.json` continua no app só pelas geometrias dos municípios (para achar o município de um ponto).
- **Sobre nós** reescrito em texto corrido, sem tabelas. O botão "Sobre nós" fica fixo no centro, logo acima da barra
  de navegação, em todas as seções do Perfil.
- **Explorador NISAR**: as tabelas de comparabilidade, de produtos disponíveis e de identificação dos arquivos viraram
  parágrafos.
- **Logo do IgaraPost** como foto de perfil das publicações da equipe.
- **Editar perfil** (Perfil › Editar perfil): foto (recortada em quadrado, 192 px), nome, cidade ou comunidade e uma frase
  sobre a pessoa. Conectado à rede, o nome também muda lá (`PATCH /api/me`); foto, cidade e frase ficam no aparelho.
  A foto aparece nos seus relatos e comentários.
- Tipo **Outro** com ícone de reticências (…) no lugar do círculo.
- Textos e parágrafos longos **justificados**, com hifenização em português.

## Mudanças da 0.4.1 para a 0.4.2
- Saiu de Perfil › Configurações a seção "Mapa do Google" (campo da chave da API). Sem chave, o mapa usa o fundo da
  NASA e as opções do Google não aparecem em Camadas. Uma chave definida na compilação (`VITE_GOOGLE_MAPS_KEY`)
  continua funcionando.
- As publicações **Explicativas** (foco × incêndio × área queimada, como o radar do NISAR enxerga a Amazônia, como ler
  o índice de seca do Cemaden) ficam fixadas no topo do Feed, com o selo "Fixado no topo", em qualquer período.
  Com um tema escolhido, aparecem as explicativas daquele tema.

## Mudanças da 0.4.0 para a 0.4.1
- No canto superior direito, o botão "Sobre nós" deu lugar a **"Como o aplicativo funciona"** (`#como-funciona`,
  arquivo `app/src/HowTo.tsx`): um guia passo a passo de cada aba (Feed, Mapa, Explorador NISAR, Relatar e Perfil) e
  do significado da situação de cada relato.
- O botão **"Sobre nós"** agora fica centralizado no fim da aba Perfil, em todas as seções dela.

## Mudanças da 0.3.9 para a 0.4.0
- **Correção do mapa da aba Mapa (preto, com blocos parados).** O mapa desenhava todos os focos da NASA FIRMS de uma
  vez: na América do Sul, isso passa de 28 mil pontos, cada um com seu balão, e travava o celular enquanto o fundo
  carregava. O Explorador NISAR não desenha focos e por isso funcionava. Agora:
  - só os focos da área visível são desenhados, e de novo a cada movimento do mapa;
  - quando são muitos, os focos vizinhos na tela viram um único círculo, maior conforme a quantidade, e ao aproximar
    o mapa aparecem os focos individuais;
  - os balões só são montados quando o ponto é tocado, e o destaque de focos novos fica limitado a 30.
- As camadas de referência da NASA (nomes e litoral) ficam desligadas por padrão, para não disputar a conexão com o
  fundo. Elas podem ser ligadas em Camadas.

## Mudanças da 0.3.8 para a 0.3.9
- Explorador NISAR: saíram os atalhos de período ("Hoje × 3 meses atrás" etc.) e a barra deslizante abaixo do mapa.
  - O antes e depois agora se compara arrastando a **bolinha do meio** (ou a própria linha); o mapa não se mexe
    enquanto se arrasta.
  - Pelo teclado, a bolinha também responde às setas ← e →.

## Mudanças da 0.3.7 para a 0.3.8
- **Fundo do mapa do Google Maps**, com todos os dados da NASA por cima (focos FIRMS, fumaça, enchentes, secas, cheias
  e NISAR). Vale para o mapa principal e para o Explorador NISAR.
  - Usa a Map Tiles API oficial (2D tiles): `app/src/sars/googleTiles.ts`.
  - Há duas opções: "Google Satélite" (satélite com nomes, o padrão) e "Google Mapa" (ruas).
  - A chave vem de `VITE_GOOGLE_MAPS_KEY` no build ou de Perfil › Configurações › Mapa do Google (guardada só no
    aparelho, com teste antes de salvar).
  - Sem chave, ou se o Google recusar, o fundo da NASA aparece no lugar, sem aviso sobre o mapa.
  - A atribuição "Google Maps" e o copyright da área visível (rota `viewport`) são mostrados, como pedem as regras da
    Map Tiles API.
  - Zoom até 18. As camadas de referência da NASA (nomes, litoral) só aparecem sobre os fundos da NASA.
- O fundo "satélite do dia" da NASA usa 6 h de folga, para não pegar o dia ainda incompleto (blocos pretos).
- Correção: os cinco filtros de evento (Fumaça, Queimadas, Enchentes, Secas, Cheias) cabem na largura da tela, com
  ícone em cima e nome embaixo.

**Para ativar o Google Maps:**
1. No Google Cloud, crie uma chave da Google Maps Platform e ative a **Map Tiles API**.
2. Restrinja a chave só a essa API e defina uma cota diária.
3. Coloque a chave em `app/.env` como `VITE_GOOGLE_MAPS_KEY=...` antes do build (desde a 0.4.2, não há mais campo para colar a chave no app).

## Mudanças da 0.3.6 para a 0.3.7
- **Correção do mapa que ficava preto.** O fundo trocava a camada inteira quando alguns blocos falhavam, até chegar
  à reserva sem internet. Agora:
  - a Blue Marble da NASA fica sempre por baixo, e o satélite do dia por cima;
  - se um bloco falhar, só ele tenta a próxima fonte (NOAA-20 → NOAA-21 → MODIS Aqua → MODIS Terra) e, se nenhuma
    responder, deixa ver a Blue Marble;
  - o fundo só é refeito quando muda o tipo ou o dia.
- **Correção da conexão ao NISAR.** O teste da camada usava `fetch`, que falha quando a resposta de erro da GIBS vem
  sem cabeçalho CORS. Agora o teste é feito com imagens, sobre a Amazônia e em várias datas, e o resultado fica guardado
  no aparelho. A mensagem de erro sobre o mapa saiu.
- Saiu a opção "Prévias da equipe" do Explorador NISAR.
- Saiu o texto "(12 dias até)" das datas. O atalho de período agora se chama "Agora × passagem anterior".

## Mudanças da 0.3.5 para a 0.3.6
- **Estudo de Região** (antes "Estudo em Manaus") no Explorador NISAR:
  - 15 regiões da floresta amazônica (`app/src/sars/regions.ts`); a região escolhida é enquadrada e contornada;
  - comparação A × B e **camada de mudança calculada no aparelho**, bloco a bloco, a partir da camada NISAR da GIBS:
    áreas escuras que surgiram, sumiram ou ficaram;
  - número de focos da NASA FIRMS e de relatos na região;
  - em Manaus, continuam as prévias processadas pela equipe.
- Datas do NISAR liberadas desde o lançamento (30 jul 2025) até hoje, com atalhos de período (últimos 12 dias,
  3 meses, 1 ano, primeiras imagens).
- Correção: o balão dos relatos no mapa do NISAR agora abre por toque, quebra o texto e fica dentro do mapa.
- **Carregamento do mapa:**
  - o fundo de satélite carrega primeiro, e focos, camadas e relatos só entram depois que ele aparece (ou após 5 s);
  - os blocos ficaram menores (128 px na tela, um nível de zoom acima), então o mapa vai se completando em
    quadradinhos em vez de quadrados gigantes, e fica mais nítido.

## Mudanças da 0.3.4 para a 0.3.5
- **Fundo do mapa corrigido.** O Suomi NPP parou de enviar dados em 2 nov 2026, e por isso o fundo "do dia" não
  carregava. Agora o app tenta, em ordem, VIIRS NOAA-20, VIIRS NOAA-21, MODIS Aqua e MODIS Terra (ontem e anteontem),
  depois a Blue Marble da GIBS e, sem internet, a Blue Marble guardada no app. Tudo isso sem aviso na tela
  (`app/src/sars/nasaTiles.ts`).
- Os focos da NASA FIRMS passam a vir do VIIRS NOAA-20 e NOAA-21, no app e no servidor.
- **NISAR no próprio mapa.** O Explorador NISAR virou um mapa interativo que compara duas datas com uma divisória
  deslizante, em qualquer lugar. Usa a camada NISAR GCOV da NASA GIBS (mosaicos de 12 dias), a mesma do Worldview. O
  estudo da equipe em Manaus continua disponível no mesmo mapa. No mapa principal, "Cheias" › Radar NISAR mostra a
  camada global. Os botões +/− agora são os do mapa, no canto inferior direito.
- Correção: os botões +/− e a atribuição do mapa não ficam mais por cima das folhas (busca, camadas).
- Saiu o aviso "As imagens da NASA não carregaram…". A faixa de datas do mapa ficou fixa: não rola nem se mexe, e os
  textos longos são encurtados.
- Saiu do feed o quadro "Você está vendo" com o botão Relatar. A região continua em Filtros, e o Relatar continua na
  barra inferior.
- A camada OPERA DSWx-S1 só aparece a partir do zoom regional (7), para não desenhar blocos vazios do GIBS em
  escala continental.

## Mudanças da 0.3.3 para a 0.3.4
- **Arrastar para baixo atualiza o feed.** O app envia o que estiver na fila, baixa o feed compartilhado (se houver
  servidor) e recarrega os dados. Se a recarga falhar, o que já estava na tela continua.
- Saiu a faixa azul-clara abaixo da barra superior.
- Correção: a barra de seções do Perfil não volta mais sozinha para o começo ao tocar numa opção. Ela só rola o
  necessário para mostrar a seção escolhida.
- "Tema e dados" passou a se chamar **Configurações** (`#perfil-configuracoes`). Os endereços antigos continuam
  funcionando.
- Saiu o link "Sobre o IgaraPost, os dados e os créditos" do fim do Perfil. O "Sobre nós" continua no topo.

## Mudanças da 0.3.2 para a 0.3.3
- **Mapa somente com dados da NASA, no visual do NASA Worldview:**
  - fundo em cor natural do dia (VIIRS Suomi NPP) ou Blue Marble, pela NASA GIBS em WMTS;
  - litoral, fronteiras e nomes de lugares (camadas de referência da GIBS);
  - focos de fogo ativo da **NASA FIRMS** (VIIRS NOAA-20 e Suomi NPP, América do Sul, 48 h);
  - fumaça (MODIS), enchentes (MODIS Flood), secas (SMAP) e cheias (OPERA DSWx-S1);
  - NISAR (NASA/ISRO).

  Saíram do mapa o OpenStreetMap, o mapa offline, os focos do INPE, o índice de seca e os limites do Cemaden. Os dados
  do INPE e do Cemaden continuam nas publicações do feed. Sem internet, o mapa mostra a Blue Marble do entorno de
  Manaus guardada no app.
- A conferência "fora do radar" de fogo e fumaça usa os focos da NASA FIRMS. A de enchente e cheia lê os blocos WMTS
  do produto de inundação. O servidor (`live.mjs`) também passou a ler a NASA FIRMS.
- **A aba Conta saiu do Perfil.** Sem ela não há tela para conectar um servidor ou entrar numa conta, e o app funciona
  só no aparelho. Para a rede compartilhada, gere o app com `VITE_API_URL` e crie uma nova tela de login.
- O botão de informações do topo agora mostra o texto **"Sobre nós"**, e a página tem esse título.
- O minimapa da tela Relatar continua com ruas do OpenStreetMap, para ajudar a marcar o ponto exato.

## Mudanças da 0.3.1 para a 0.3.2
- Tema escolhido pela pessoa em Perfil › Configurações: **Automático** (segue o aparelho), **Claro** ou **Escuro**. A
  escolha fica salva no aparelho e também vale para o mapa (`app/src/theme.ts`).
- Saíram o indicador de armazenamento do topo ("Só neste aparelho") e a faixa "Seus relatos ficam só neste aparelho ·
  Conectar a um servidor" do feed. O feed compartilhado agora se atualiza sozinho ao abrir, ao voltar para o app e a
  cada minuto. O servidor continua sendo configurado em Perfil › Conta, e os envios pendentes aparecem em Meus relatos.

## Mudanças da 0.3.0 para a 0.3.1 · identidade visual azul
- Logo oficial do projeto (barco no igarapé) em `app/assets-src/`, na barra superior, no "Sobre", no favicon, no ícone
  do app e na tela de abertura.
- Paleta trocada de verde para azul, a partir das cores da logo:
  - azul principal `#1B6C97`;
  - azul-celeste `#2B8CB9`;
  - marinho `#0A1845`.

  O modo escuro também foi ajustado. As cores dos eventos (fogo, seca, água) continuam as mesmas.
- `scripts/make_android_assets.py` gera todos os ícones, as telas de abertura e as imagens web a partir da logo. O fundo
  do ícone adaptativo agora é `#C9DFEC`.

## Mudanças da 0.2.0 para a 0.3.0
1. **Mapa-múndi SARS:**
   - camadas globais da NASA GIBS e mapa sem trava de área;
   - filtros de evento (Fumaça, Queimadas, Enchentes, Secas, Cheias) que ligam as camadas e filtram os relatos;
   - focos do INPE em tempo real (SSE, com polling como alternativa) e indicador "Ao vivo";
   - recarga periódica das imagens.
2. **Navegação e textos:**
   - a aba e a rota Comunidades foram removidas (`#comunidades` leva ao feed);
   - "Publicar" virou **"Relatar"** (aba, botões e `#publicar` → `#relatar`);
   - o botão do mapa agora é "Relatar";
   - comentários usam "Comentar" e o estado de envio virou "Enviado".
3. **Tela Relatar · Fora do radar do SARS:**
   - tipos Fumaça, Queimada, Enchente, Seca, Cheia e Outro;
   - GPS de alta precisão, mostrando a precisão;
   - foto pela câmera ou pela galeria;
   - conferência automática com o SARS.

   Os tipos antigos ("Água baixa", "Impacto") continuam sendo exibidos em relatos já feitos.
4. **Perfil › Meus relatos:**
   - resumo (relatos, fora do radar, confirmados depois, não enviados) e filtros;
   - histórico de cada relato;
   - reconferência com o SARS.
5. **Servidor:**
   - categorias `enchente` e `cheia`;
   - área de relatos ampliada para o Brasil;
   - coluna `radar` (migração automática) e `PUT /api/posts/:id/radar`;
   - módulo `live.mjs` com `/api/live/status`, `/api/live/fires` e `/api/live/stream`.
6. **Testes:**
   - API do servidor: 20/20;
   - lógica do SARS (`app/tests/sars-logic.test.mts`): 10/10;
   - verificação da interface no Chromium: 26/26, feita fora do repositório.

   O `tests/e2e.mjs` foi atualizado para a nova interface, mas **não foi executado** nesta versão (veja abaixo).

**Limites da verificação da 0.3.0:**
- O ambiente de desenvolvimento não tinha acesso à internet nem às dependências do npm. A tipagem foi conferida com
  definições mínimas de React e Leaflet.
- A interface foi testada no Chromium com um Leaflet simulado: navegação, formulário, Meus relatos e controles do mapa.
- O desenho real das camadas do GIBS, o SSE com o INPE de verdade e o APK **ainda precisam ser testados** com
  `npm install`, `npm run build` e `tests/e2e.mjs`, e num aparelho.

## Mudanças da 0.1.0 para a 0.2.0
1. **Gravação confiável:** `commit()` grava e confere antes de mudar o estado. Em caso de falha, a mensagem aparece e o formulário é preservado. Só os estados que existem de fato são exibidos.
2. **Filtros e datas:**
   - recorte municipal com contagens completas do município;
   - "Resumo regional" identificado, com sua abrangência;
   - índice de seca sem substituição silenciosa de mês;
   - mapa com o contexto do relato.
3. **Feed e publicação:**
   - região acompanhada em destaque, atalhos de tema, filtros num painel e cartões compactos;
   - formulário em 3 partes com rascunho e revisão, e com data observada separada da publicada.
4. **Rede entre aparelhos:**
   - servidor com contas, perfis, publicações, comentários, comunidades seguidas, autoria e denúncias com moderação;
   - fila de envio para uso sem conexão.
5. **Mapa:**
   - OpenStreetMap online com mapa offline do app (rios, vias e 783 localidades);
   - busca, "Minha região", agrupamento de relatos;
   - legenda com origem, cobertura e período, e estados de dados distintos.
6. **NISAR:**
   - textos de exploração experimental;
   - tabela de comparabilidade, inventário dos GCOV e relação temporal relato × passagens;
   - script calibrado reforçado (alinhamento, máscaras, parâmetros, GeoTIFF), testado com dados sintéticos.

## Mudanças da 0.5.8 para a 0.5.9

- Fileiras de botões que rolavam para o lado agora usam o mesmo botão que expande do Feed: os temas dentro de **Filtros** (no Feed e no Mapa) e o filtro de **Meus relatos** (Todos, Fora do radar, Confirmados, Enviados, Não enviados, Com falha). O botão mostra só a opção escolhida; ao tocar, abre embaixo todas as opções em duas colunas e fecha depois da escolha. Componente novo: `app/src/ExpandPicker.tsx`.
- Continuam como estavam, a pedido: as abas do Perfil (Meus relatos, Atividade, Salvos, Revisão, Configurações) e os atalhos de horário do Relatar (Agora, Hoje cedo, Ontem, Personalizar).
- Corrigida a tela "solta" para o lado no Explorador NISAR: o nome das imagens (`NISAR_L2_PR_GCOV_…`) é uma palavra só, sem espaços, e alargava a página para quase o dobro da tela. Agora ele quebra a linha, e a página nunca rola na horizontal.

## Mudanças da 0.5.9 para a IgaraPost 7.9.1

A partir desta versão, o número segue o nome usado pela equipe: **IgaraPost 7.9.1** (versionCode 27, instala por cima de todas as anteriores).

### Seleção de idioma (português, inglês e espanhol)

- Em **Perfil › Configurações** há a seção **Idioma** com Português, English e Español. Ao tocar em outro idioma, a tela recarrega e o app inteiro passa a esse idioma: menus, Feed, Mapa (inclusive popups e legendas das camadas), Explorador NISAR, Relatar (avisos, validações e conferência com o SARS), Perfil, Sobre nós, Como o aplicativo funciona, publicações da equipe e exemplos fictícios. A escolha fica salva no aparelho (`localStorage`, chave `igarapost:lang`); o padrão é português.
- Datas e números seguem o idioma (ex.: "Nov 14, 2026" e "6,237.4" em inglês; "14 nov 2026" em espanhol).
- **Não são traduzidos** os textos escritos pelas pessoas: relatos, títulos e comentários de usuários ficam no idioma original (elementos com `translate="no"`). Nomes de lugares também não.

### Como a tradução funciona (para quem for mexer no código)

- O app continua escrito em português. `app/src/i18n/dom.ts` observa a tela (MutationObserver) e troca cada texto e os atributos `aria-label`, `placeholder`, `title` e `alt` pela entrada do dicionário. Também traduz `alert`/`confirm`.
- O React escreve uma frase com valores no meio como vários nós de texto vizinhos; o tradutor junta esses nós e traduz a frase inteira, com `{0}`, `{1}`… no lugar dos valores (os valores também são traduzidos quando têm entrada). Se não houver entrada para a frase, tenta pedaço por pedaço.
- Os dicionários ficam em `app/src/i18n/s_*.ts`, uma linha por texto: `["português", "English", "Español"]`. São cerca de 950 entradas.
- `app/src/i18n/lang.ts` guarda o idioma, o `LOCALE` usado em `toLocaleString` e `tr3()` para trechos montados no código (datas relativas, por exemplo).
- **Texto novo no app?** Acrescente a linha no `s_*.ts` da área. Para conferir, há scripts em `app/tests/i18n/`: `extrair-textos.mjs` lista todos os textos do código (com as frases JSX inteiras), `conferir-dicionario.mjs` aponta os que não têm tradução, `percorrer-telas.mjs` abre o app em inglês ou espanhol, percorre as telas e lista o que ficou sem tradução, e `aceitacao-idiomas.mjs` testa a troca de idioma (os caminhos no topo dos scripts são do ambiente de build da equipe).
- Nesta versão: 0 textos com cara de português nas telas percorridas em inglês e em espanhol, e 15/15 verificações da troca de idioma.

### Outros ajustes

- A página "Como o aplicativo funciona" menciona a escolha de idioma em Configurações.
- O cabeçalho do Perfil foi reescrito como uma frase só ("Perfil deste aparelho · Manaus · 2 relato(s)"), para poder ser traduzido inteiro.

## Mudanças da 7.9.1 para a IgaraPost 7.9.2

- **Relatos e comentários ficam sempre no idioma original**, inclusive os exemplos fictícios que vêm com o app. Quando o texto está num idioma diferente do escolhido em Configurações, aparece o botão **Ver tradução** (que vira **Ver original**). As publicações da equipe (explicativos, dados oficiais e NISAR) continuam sendo traduzidas pelo app.
- O idioma de cada relato e comentário é detectado pelo próprio aparelho, sem internet (português, inglês ou espanhol, por palavras e acentos típicos); relatos e comentários novos também guardam o idioma em que foram escritos (`lang`). Textos curtos demais para saber o idioma (um nome, "ok") não mostram o botão.
- De onde vem a tradução: os exemplos do app usam o dicionário do próprio app (funciona sem internet). Os textos escritos pelas pessoas são traduzidos pelo serviço gratuito **MyMemory** (`api.mymemory.translated.net`), só quando alguém toca em "Ver tradução". Ao tocar, o texto é enviado a esse serviço. O texto é dividido em partes de até 450 bytes (o serviço aceita 500 por pedido) e as traduções ficam guardadas no aparelho (`igarapost:traducoes`, últimas 150) para não consultar de novo. Uso anônimo do MyMemory: cerca de 5.000 caracteres por dia por rede; ao passar disso, ou sem internet, o app mostra um aviso claro e o texto original continua lá. Código em `app/src/i18n/userText.ts` e `app/src/UserText.tsx`; para trocar de serviço, basta mudar `translateUser`.
- Removida dos Filtros a opção "Mostrar exemplos fictícios de demonstração": os exemplos aparecem sempre (com o selo "Exemplo fictício").
- Removido o texto explicativo abaixo da escolha de Idioma em Configurações.
- Teste novo: `app/tests/i18n/traducao-relatos.mjs` (21 verificações, com o serviço de tradução simulado, inclusive limite diário e falta de internet).

## Mudanças da 7.9.2 para a IgaraPost 7.9.3

- **Novo ícone do app, para qualquer formato.** A arte do logo (árvores, nome IGARAPOST, barco e reflexo) foi separada do fundo em degradê e do anel preto do logo redondo, e agora fica sobre um azul-bebê único (#C9DFEC) que preenche o ícone inteiro.
  - Android 8 ou mais novo (ícone adaptável): a arte é a camada da frente (`mipmap-*/ic_launcher_foreground.png`) e o fundo é a cor `ic_launcher_background`. A arte cabe no círculo seguro de 66 dp, então aparece inteira em círculo, quadrado, quadrado arredondado, squircle ou gota, conforme o celular.
  - Android 7 ou mais antigo: `ic_launcher.png` (quadrado arredondado) e `ic_launcher_round.png` (redondo), sem anel preto.
  - Tela de abertura (`drawable-*/splash.png`): fundo azul-bebê inteiro com a arte no centro.
  - Web e dentro do app: `public/icon-192.png`, `public/favicon.png` e `public/igarapost-logo.png` (cabeçalho, avatar da equipe e Sobre nós), com o mesmo azul-bebê e sem anel preto.
  - Fontes e script em `app/assets-src/icone/`: `extrair.py` separa a arte do logo original (`logo-redondo-original.jpg`) modelando o degradê do fundo; `gerar.py` gera todos os tamanhos. Também estão lá versões de 512 px (quadrada, arredondada e redonda) e a camada da frente em 1024 px, para loja, apresentação ou redes.
- Removido de Configurações o quadro "Onde ficam seus dados?".

## Mudanças da 7.9.3 para a IgaraPost 8 (primeira versão oficial)

- **Abertura animada** toda vez que o app é aberto, no estilo das aberturas de jogos: fundo azul-escuro (#041543), o logo do IgaraPost (sem fundo) entra crescendo com um leve "pulo", uma faixa de luz passa pelo logo e duas ondas se abrem na água embaixo do barco; no canto inferior direito aparece "Uma realização Vento Norte" com o logo da Vento Norte. Depois de ~2,5 s tudo esmaece e o app aparece. Tocar na tela pula a abertura.
  - A abertura está no `index.html` (HTML + CSS) para aparecer já no primeiro quadro, antes do app carregar; `app/src/intro.ts` só a retira quando termina. Imagens em `public/intro/` (`igarapost.webp`, a arte sem fundo; `vento-norte.png`, o logo da Vento Norte em linhas brancas com fundo transparente).
  - Com "reduzir movimento" ligado no celular, a abertura só aparece e some (sem brilho, ondas ou zoom), em ~2 s.
  - Trocar o idioma em Configurações recarrega o app sem repetir a abertura. O texto "Uma realização" segue o idioma ("A production by", "Una realización de").
  - Para combinar com a abertura, a tela nativa de abertura do Android (`splash.png`) e a cor de fundo do WebView (`capacitor.config.json`, `backgroundColor`) passaram a ser o mesmo azul-escuro, sem piscar outra cor (antes o APK usava um verde antigo).
- As fontes do Google passaram a carregar sem bloquear a primeira tela (sem internet, o app não fica esperando por elas).
- Descrição do app (`index.html`) atualizada: fumaça, queimadas e enchentes.
- Teste novo: `app/tests/abertura.mjs` (tempo, posição do crédito, toque para pular, troca de idioma, inglês e "reduzir movimento").

### Ajustes na IgaraPost 8 (mesmo nome de versão, versionCode 36)

- O logo da Vento Norte na abertura é o arquivo enviado pela equipe (logo branco com fundo transparente, `public/intro/vento-norte.png`), usado sem nenhum tratamento.
- **"Como o aplicativo funciona" virou um guia completo**, com tudo o que o app faz, área por área: abertura; Feed (fixados no topo, botão de tema, filtros, atualizar, ações e selos de cada publicação, dados oficiais); detalhe da publicação (dados próximos, fonte e método, comentários, denúncia, exclusão); Mapa (eventos, focos e "Ao vivo", Buscar com limite do município, Região, Mundo, Camadas, Filtros, NISAR, imagem detalhada, toque no mapa, relatos no mapa, sem internet); Explorador NISAR (Mundo, Estudo de Região, cores, análise do entorno de Manaus); Relatar (as 3 etapas, conferência com o SARS, rascunho, sem internet); Perfil (editar perfil, Meus relatos e filtros, histórico e Conferir de novo, Atividade, Salvos, Revisão, Configurações, Sobre nós); idiomas e "Ver tradução"; sem internet e rede compartilhada; e o significado de cada situação de relato. Tudo traduzido para inglês e espanhol (`app/src/i18n/s_howto.ts`).
- Títulos do guia alinhados à esquerda (não justificados).
- **Comentar leva direto à conversa:** o botão Comentar abre a publicação já na seção de comentários (`#post-ID#comentarios`); dentro da publicação, ele só desce até a conversa.
- **Detalhe da publicação só com a conversa:** saíram "Dados próximos a este relato" (focos do INPE e pixel do NISAR perto do relato) e o quadro "Fonte, período e método". A fonte e o período continuam na linha "Fonte" do próprio cartão.
- **Vistoria de textos redundantes** (saíram ou foram encurtados):
  - Relatar: o selo "Fora do radar do SARS" acima do título, o parágrafo de apresentação, "Relatos aparecem como não verificados" (fica só o aviso de emergência), a descrição do tipo "Outro", o "(GPS)" e o "exata" do botão de localização, "Toque no mapa para marcar…", "Para escolher outro dia… Personalizar", "Com o tipo e o local marcados, o app confere…", "A foto é reduzida no aparelho…" e a linha "Status" da revisão; o aviso de dados pessoais e a opção de local aproximado ficaram curtos.
  - Feed e cartões: "explicativos fixados no topo, depois os mais recentes", "Sem nenhuma marcada, todas aparecem.", "com dados do INPE/da missão NISAR" (repetia o selo), "período: texto explicativo", "obtido em…" (repetia "Publicado em"), o selo "Outro" nas publicações da equipe e as frases que repetiam o selo de envio ("Este relato está só neste aparelho…", "Ocultado para outras pessoas…").
  - Conversa: "Comentar como Você" e os avisos "Comentários em exemplos fictícios…"/"Este relato está só neste aparelho; os comentários também.". O comentário fictício que citava os "dados próximos" foi reescrito.
  - Mapa: a dica da busca, o parágrafo de abertura das Camadas e as descrições longas de cada camada (fica a legenda e uma linha "fonte · data"), o texto longo do fundo do mapa e do radar NISAR, e as frases explicativas dos popups de focos e do ponto no mapa.
  - Perfil: "Perfil deste aparelho" no cabeçalho, "Focos ao vivo indisponíveis agora…", o texto da conferência indisponível em cada relato, as explicações de Atividade e Salvos vazios, a explicação do tema e a linha de uso de armazenamento em Configurações.
- O guia "Como o aplicativo funciona" foi atualizado (sem os trechos removidos e com o Comentar indo direto à conversa). Teste novo: `app/tests/polimento-8.mjs`.
- **Botão Mapa da publicação:** agora abre o mapa já na marcação do relato, com o popup aberto e o zoom mais próximo. Antes, o relato só aparecia se passasse pelos filtros atuais (com o padrão "Manaus e entorno", relatos de Autazes ou Manaquiri não apareciam) e o popup tentava abrir antes de os marcadores existirem. O relato que abriu o mapa aparece mesmo fora dos filtros.
- **Filtros do Mapa corrigidos:** a folha de filtros abria dentro do mapa e ficava por baixo da barra de navegação, cobrindo "Limpar" e "Ver resultados". Agora ela abre por cima do app inteiro, como no Feed, e os filtros de região, período e tema mudam os relatos no mapa. Teste novo: `app/tests/mapa-8.mjs`.
- **Sem conteúdo fictício:** saíram os 4 perfis, os 4 relatos e os 2 comentários de exemplo (e os selos e textos "Exemplo fictício"/"Perfil fictício"). Também saíram do Feed as publicações de dados (contagens do INPE e resumo do NISAR): o Feed mostra os relatos das pessoas e os 2 tutoriais da equipe IgaraPost, fixados no topo. Os dados continuam no Mapa e no Explorador NISAR. Em Filtros › Origem da informação ficaram "Relatos da comunidade" e "Explicativos". "Sobre nós" e o guia foram ajustados.
- **Tradução:** o nome do serviço (MyMemory) não aparece mais na tela; o rótulo é só "Tradução automática". Como não há mais exemplos, todo relato e comentário de outro idioma usa a tradução automática.
- **Guia:** saiu o tópico 8 ("Sem internet e rede compartilhada"); o guia tem 7 tópicos.
- **Mapa sem o botão Filtros:** o mapa mostra todos os relatos, e os botões de evento do topo (Fumaça, Queimadas, Enchentes) escolhem os tipos. As 5 ferramentas (Buscar, Região, Mundo, Camadas, NISAR) ficam numa fileira só, do mesmo tamanho, e o zoom e os créditos do mapa passaram para cima delas.
- **Emergência por idioma:** português (Brasil) 193 (Bombeiros) e 199 (Defesa Civil); inglês (EUA) 911; espanhol (Espanha) 112. Vale para o aviso do Relatar, do guia e de "Sobre nós".
- Testes: `app/tests/conteudo-8.mjs` (novo) e os anteriores adaptados; `app/tests/relatos-de-teste.mjs` cria relatos de teste no aparelho, já que o app não traz mais exemplos.
- **Idioma do celular:** sem uma escolha em Configurações, o app abre no idioma do sistema do celular: português (qualquer país, ex.: pt-BR, pt-PT), espanhol (es-ES, es-MX…) ou inglês (en-US, en-GB…). Qualquer outro idioma (francês, alemão, japonês, chinês…) abre em inglês. Vale o primeiro idioma da lista de preferências do Android que o app tem. Quando a pessoa escolhe um idioma em Perfil › Configurações, essa escolha fica salva e vale mais que a do celular. Código em `app/src/i18n/lang.ts` (`deviceLang`). Datas e números em espanhol seguem o padrão da Espanha (es-ES). Teste novo: `app/tests/i18n/idioma-do-celular.mjs` (10 idiomas de celular e a escolha manual).
- Os testes que esperam o app em português agora simulam um celular em português do Brasil (`locale: "pt-BR"`).

## Mudanças da IgaraPost 8 para a IgaraPost 10 (rede social funcional)

- **Rede compartilhada de verdade, no Supabase.** Relatos, fotos, comentários, denúncias e moderação agora ficam no projeto
  Supabase `igarapost`: o que uma pessoa relata aparece para todas as outras. Antes, sem servidor publicado, tudo ficava só no aparelho.
- **Sem cadastro:** cada aparelho entra sozinho com uma conta anônima do Supabase na primeira vez que abre com internet. A sessão
  é renovada sozinha e continua a mesma depois de "Apagar os dados deste aparelho" (os relatos continuam sendo da pessoa).
- **Banco com regras próprias (`supabase/igarapost-v10.sql`):** ninguém publica em nome de outra pessoa nem edita, apaga ou oculta
  relato de outra pessoa (mesmo chamando a API direto); só a moderação muda o status; relato ocultado some para os outros, continua
  visível para o autor ("Ocultado após revisão") e não aceita comentários; "local aproximado" é arredondado no próprio banco
  (~2 km); fotos só na pasta da própria conta, até 2 MB, JPG/PNG/WebP; limite de 20 relatos e 60 comentários por hora por conta;
  sem sessão não se lê nada.
- **Fotos no Supabase Storage** (espaço `fotos`, link público). Trocar ou remover a foto na edição apaga o arquivo antigo; apagar
  o relato apaga a foto.
- **Administração pelo nome "IgaraPost":** a primeira conta que muda o nome do perfil para IgaraPost vira a administradora
  (nome reservado no banco; as outras contas recebem "O nome IgaraPost é reservado à administração do app."). Ela vê em
  Perfil › Revisão a fila de denúncias pendentes (a decisão vale para todas as denúncias do mesmo relato) e, no detalhe de
  qualquer relato, pode ocultar, mostrar de novo ou excluir; também apaga qualquer comentário (e a foto do relato excluído).
- **Configurações › Rede IgaraPost:** "Conectado" (com "· administração" quando for o caso), "Conectando…" ou sem internet.
- **Configurações › Meu registro:** gera um texto só com os dados da própria pessoa: os relatos (data e horário da
  ocorrência, tipo, município e coordenadas, data de envio, estado) e as denúncias (data e horário, motivo, resultado e o
  local do relato denunciado, mesmo se ele foi ocultado depois). Horários no fuso do aparelho; botão Copiar. No banco, a
  função `my_report_log()` devolve só as denúncias de quem chama.
- **Fila offline mantida e ampliada:** sem internet (ou antes de a conta existir), relatos, edições, comentários e denúncias ficam
  na fila e saem sozinhos, na ordem, quando a conexão volta. Reenvios não duplicam nada.
- **Quem vem da 8:** os relatos que estavam só no aparelho (e os comentários feitos neles) entram na fila e vão para a rede
  sozinhos na primeira abertura; tipos antigos viram "Outro".
- **Textos enxutos:** saíram o código da conta, a linha "Quem verá" do Relatar, a explicação do Meus relatos vazio,
  "· visível para outras pessoas", o parágrafo de armazenamento em "Sobre nós", a revisão local de denúncias e os avisos de
  envio longos (agora "Enviando relato…" / "Sem internet: o relato sai quando a conexão voltar").
- Atividade mostra os comentários que outras pessoas fizeram nos seus relatos; o nome do perfil vale para todos.
- Textos novos em português, inglês e espanhol; guia "Como o aplicativo funciona" atualizado (Quem vê, Revisão, Configurações).
- O APK passou a aceitar nomes de versão de qualquer tamanho (`axml.patch_any` reconstrói a tabela de textos do manifesto).

### Ajustes na IgaraPost 10 (perfil, cartões e fila de moderação)

- **Foto de perfil para todos:** a foto escolhida em Editar perfil vai para a rede (Storage, `fotos/<conta>/avatar-…`) e
  aparece no Feed, no detalhe, nos comentários e no Perfil, para todas as pessoas. A foto anterior é apagada; quem já tinha
  foto só no aparelho tem ela enviada sozinha.
- **Cartão inteiro abre a publicação:** no Feed, tocar em qualquer parte do cartão (texto, foto, local, data) abre o detalhe;
  botões e links (Apoiar, Salvar, Mapa, Ver tradução, Ver mais) continuam fazendo só a sua ação.
- **Nome de usuário (@) editável e único:** em Editar perfil, campo "Nome de usuário" (3 a 24 caracteres: letras minúsculas
  sem acento, números, ponto, hífen ou _; o "@" e as maiúsculas são ajustados sozinhos). O banco recusa @ repetido (sem
  diferenciar maiúsculas) com "Esse nome de usuário já está em uso. Escolha outro."; o @igarapost é da administração.
- **Relatos verificados:** todo relato nasce "Relato da comunidade · não verificado". A administração verifica e o selo vira
  "verificado". Se o autor muda o texto, a foto, o local ou a data, volta a "não verificado". Manter após denúncia também
  verifica; o que a administração publica já nasce verificado. Colunas novas: `posts.verified`, `posts.verified_at`,
  `profiles.avatar_path`.
- **Revisão só para a administração:** a aba some para as outras contas. Ela tem a fila de moderação: denúncias pendentes
  (Manter/Ocultar) e relatos não verificados, do mais antigo para o mais novo (Verificar/Ocultar). Quem denunciou vê o
  resultado em Configurações › Meu registro.
- Teste novo: `app/tests/v10-perfil-cartoes-fila.mjs`. O script do banco pode ser rodado de novo sobre o anterior (testado).

### Ajustes na IgaraPost 10 (voltar, avisos e foto da equipe)

- **Foto da equipe** em "Sobre nós" (`public/equipe-vento-norte.jpg`, 1200 × 797), com legenda.
- **Voltar com memória de uma tela** (`src/nav.ts`): o app guarda só a última tela; o histórico nunca passa de duas
  entradas. O botão **Voltar** (seta no topo) aparece quando há uma tela anterior e leva até ela; depois some. Abrir os
  comentários dentro da mesma publicação não conta como outra tela. O voltar do celular depende do build nativo (acima).
- **Aviso de relato verificado (opcional):** Configurações › Avisos › "Avisar quando um relato meu for verificado pela
  administração" (vem desligado). Ligado, o app confere ao abrir e a cada 90 s enquanto está aberto, em qualquer tela; o
  aviso aparece como mensagem, fica na aba Atividade e, onde houver, vira notificação do sistema. Não avisa de
  verificações antigas nem repete.
- Teste novo: `app/tests/v10-voltar-avisos-equipe.mjs`.

