-- =====================================================================
--  IgaraPost 10 · banco de dados no Supabase
--  Como usar: Supabase › SQL Editor › New query › cole este arquivo
--  inteiro › Run. Pode rodar de novo sem problema: nada é apagado.
--
--  O que este script cria:
--   1. perfis (um por conta; a conta anônima do aparelho já ganha um)
--   2. administração: o perfil chamado "IgaraPost" (nome reservado; a primeira
--      conta que adota o nome vira a administradora)
--   3. relatos, comentários e denúncias
--   4. regras de segurança (RLS): cada pessoa só altera o que é seu;
--      todos leem o que está publicado; relato ocultado some para os outros
--   5. limites contra abuso (relatos e comentários por hora)
--   6. consultas prontas que o app usa (feed, atividade, fila de moderação)
--      + nome de usuário (@) editável e único, foto de perfil e relatos verificados
--   7. espaço "fotos" para as fotos dos relatos (até 2 MB, só imagens)
--
--  A senha do banco e a chave secreta NÃO vão no app. O app usa só a
--  chave pública (sb_publishable_...) e a sessão de cada pessoa.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Perfis
-- ---------------------------------------------------------------------
create table if not exists public.profiles (
  id           uuid primary key references auth.users (id) on delete cascade,
  handle       text unique not null,
  display_name text not null default 'Pessoa da comunidade' check (char_length(display_name) between 1 and 40),
  place        text check (char_length(place) <= 60),
  bio          text check (char_length(bio) <= 160),
  created_at   timestamptz not null default now()
);

-- foto de perfil (Storage) e nome de usuário (@) único, sem diferenciar maiúsculas
alter table public.profiles add column if not exists avatar_path text check (char_length(avatar_path) <= 200);
alter table public.profiles drop constraint if exists profiles_handle_format;
alter table public.profiles add constraint profiles_handle_format check (handle ~ '^[a-z0-9_.-]{3,24}$');
create unique index if not exists profiles_handle_lower on public.profiles (lower(handle));

-- toda conta nova (inclusive a anônima criada pelo app) ganha um perfil
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, handle)
  values (new.id, 'pessoa-' || substr(replace(new.id::text, '-', ''), 1, 8))
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- contas que já existiam antes deste script
insert into public.profiles (id, handle)
select id, 'pessoa-' || substr(replace(id::text, '-', ''), 1, 8) from auth.users
on conflict (id) do nothing;

-- ---------------------------------------------------------------------
-- 2. Moderadores
-- ---------------------------------------------------------------------
create table if not exists public.moderators (
  user_id  uuid primary key references auth.users (id) on delete cascade,
  added_at timestamptz not null default now()
);

create or replace function public.is_moderator()
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.moderators m where m.user_id = auth.uid());
$$;

-- nome "IgaraPost" = administração. O nome é reservado: só quem já administra pode usá-lo.
-- Enquanto não houver ninguém na administração, a primeira conta que adotar o nome vira a administradora.
create or replace function public.profiles_guard()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  new.display_name := btrim(new.display_name);
  if lower(regexp_replace(new.display_name, '\s', '', 'g')) = 'igarapost'
     and lower(regexp_replace(old.display_name, '\s', '', 'g')) <> 'igarapost' then
    if not public.is_moderator() then
      if exists (select 1 from public.moderators) then
        raise exception 'O nome IgaraPost é reservado à administração do app.' using errcode = 'P0001';
      end if;
      insert into public.moderators (user_id) values (new.id);
    end if;
    new.display_name := 'IgaraPost';
    -- a administração ganha também o @igarapost, se estiver livre
    if new.handle = old.handle and not exists (select 1 from public.profiles where lower(handle) = 'igarapost' and id <> new.id) then
      new.handle := 'igarapost';
    end if;
  end if;
  new.handle := lower(btrim(regexp_replace(new.handle, '^@+', '')));
  if new.handle = 'igarapost' and new.handle is distinct from old.handle and not public.is_moderator() then
    raise exception 'O nome de usuário @igarapost é reservado à administração do app.' using errcode = 'P0001';
  end if;
  if new.handle is distinct from old.handle
     and exists (select 1 from public.profiles where lower(handle) = new.handle and id <> new.id) then
    raise exception 'Esse nome de usuário já está em uso. Escolha outro.' using errcode = 'P0001';
  end if;
  return new;
end $$;

drop trigger if exists profiles_guard on public.profiles;
create trigger profiles_guard before update on public.profiles
  for each row execute function public.profiles_guard();

-- ---------------------------------------------------------------------
-- 3. Relatos, comentários e denúncias
-- ---------------------------------------------------------------------
create table if not exists public.posts (
  id            text primary key check (char_length(id) between 3 and 64),
  author_id     uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  category      text not null check (category in ('fumaca', 'queimada', 'enchente', 'outro')),
  text          text not null check (char_length(text) between 10 and 1000),
  lang          text check (lang in ('pt', 'en', 'es')),
  lat           double precision not null check (lat between -90 and 90),
  lon           double precision not null check (lon between -180 and 180),
  approx        boolean not null default false,
  municipio     text check (char_length(municipio) <= 80),
  observed_at   timestamptz not null,
  published_at  timestamptz not null default now(),
  edited_at     timestamptz,
  community_ids text[] not null default '{}',
  photo_path    text check (char_length(photo_path) <= 200),
  status        text not null default 'visivel' check (status in ('visivel', 'oculto')),
  radar         jsonb
);
-- verificado pela administração (os relatos nascem "não verificados")
alter table public.posts add column if not exists verified boolean not null default false;
alter table public.posts add column if not exists verified_at timestamptz;
create index if not exists posts_published_idx on public.posts (published_at desc);
create index if not exists posts_author_idx on public.posts (author_id);

create table if not exists public.comments (
  id         text primary key check (char_length(id) between 3 and 64),
  post_id    text not null references public.posts (id) on delete cascade,
  author_id  uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  text       text not null check (char_length(text) between 1 and 600),
  lang       text check (lang in ('pt', 'en', 'es')),
  created_at timestamptz not null default now()
);
create index if not exists comments_post_idx on public.comments (post_id, created_at);
create index if not exists comments_author_idx on public.comments (author_id);

create table if not exists public.reports (
  id          text primary key default gen_random_uuid()::text,
  post_id     text not null references public.posts (id) on delete cascade,
  reporter_id uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  reason      text not null check (char_length(reason) between 2 and 120),
  created_at  timestamptz not null default now(),
  status      text not null default 'pendente' check (status in ('pendente', 'mantido', 'ocultado')),
  reviewed_at timestamptz,
  reviewed_by uuid references auth.users (id) on delete set null,
  unique (post_id, reporter_id)
);
create index if not exists reports_status_idx on public.reports (status, created_at);

-- ---------------------------------------------------------------------
-- 4. Proteções que valem mesmo se alguém tentar burlar o app
-- ---------------------------------------------------------------------
create or replace function public.posts_guard()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then
    new.author_id    := auth.uid();
    new.status       := 'visivel';
    new.published_at := now();
    new.edited_at    := null;
    new.verified     := public.is_moderator(); -- o que a administração publica já nasce verificado
    new.verified_at  := case when new.verified then now() end;
    if (select count(*) from public.posts
        where author_id = auth.uid() and published_at > now() - interval '1 hour') >= 20 then
      raise exception 'Limite de 20 relatos por hora atingido. Tente mais tarde.' using errcode = 'P0001';
    end if;
  else
    -- autor, data de publicação e id não mudam; só a moderação muda o status
    new.id           := old.id;
    new.author_id    := old.author_id;
    new.published_at := old.published_at;
    if not public.is_moderator() then
      new.status      := old.status;
      new.verified    := old.verified;
      new.verified_at := old.verified_at;
    elsif new.verified and not old.verified then
      new.verified_at := now();
    elsif not new.verified then
      new.verified_at := null;
    end if;
    if (new.text, new.category, new.lat, new.lon, new.approx, new.observed_at, new.photo_path, new.municipio)
       is distinct from
       (old.text, old.category, old.lat, old.lon, old.approx, old.observed_at, old.photo_path, old.municipio) then
      new.edited_at := now();
      -- relato mudado pelo autor volta a "não verificado"
      if not public.is_moderator() then
        new.verified := false;
        new.verified_at := null;
      end if;
    end if;
  end if;
  -- "local aproximado": guarda só um ponto da grade de ~2 km
  if new.approx then
    new.lat := round((new.lat / 0.02)::numeric) * 0.02;
    new.lon := round((new.lon / 0.02)::numeric) * 0.02;
  end if;
  return new;
end $$;

drop trigger if exists posts_guard on public.posts;
create trigger posts_guard before insert or update on public.posts
  for each row execute function public.posts_guard();

create or replace function public.comments_guard()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  new.author_id  := auth.uid();
  new.created_at := now();
  if (select count(*) from public.comments
      where author_id = auth.uid() and created_at > now() - interval '1 hour') >= 60 then
    raise exception 'Limite de 60 comentários por hora atingido. Tente mais tarde.' using errcode = 'P0001';
  end if;
  return new;
end $$;

drop trigger if exists comments_guard on public.comments;
create trigger comments_guard before insert on public.comments
  for each row execute function public.comments_guard();

create or replace function public.reports_guard()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  new.reporter_id := auth.uid();
  new.status      := 'pendente';
  new.created_at  := now();
  new.reviewed_at := null;
  new.reviewed_by := null;
  return new;
end $$;

drop trigger if exists reports_guard on public.reports;
create trigger reports_guard before insert on public.reports
  for each row execute function public.reports_guard();

-- ---------------------------------------------------------------------
-- 5. Regras de acesso (Row Level Security)
-- ---------------------------------------------------------------------
alter table public.profiles   enable row level security;
alter table public.moderators enable row level security;
alter table public.posts      enable row level security;
alter table public.comments   enable row level security;
alter table public.reports    enable row level security;

-- quem não entrou (sem sessão) não acessa nada; o app sempre entra com a conta do aparelho
revoke all on public.profiles, public.moderators, public.posts, public.comments, public.reports from anon;
revoke all on public.profiles, public.moderators, public.posts, public.comments, public.reports from authenticated;

grant select on public.profiles to authenticated;
grant update (display_name, handle, avatar_path, place, bio) on public.profiles to authenticated;
grant select on public.moderators to authenticated;
grant select, insert, update, delete on public.posts to authenticated;
grant select, insert, delete on public.comments to authenticated;
grant select, insert on public.reports to authenticated;

drop policy if exists "perfis: todos leem" on public.profiles;
create policy "perfis: todos leem" on public.profiles
  for select to authenticated using (true);
drop policy if exists "perfis: cada um edita o seu" on public.profiles;
create policy "perfis: cada um edita o seu" on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists "moderadores: cada um ve se e moderador" on public.moderators;
create policy "moderadores: cada um ve se e moderador" on public.moderators
  for select to authenticated using (user_id = auth.uid());

drop policy if exists "relatos: ler" on public.posts;
create policy "relatos: ler" on public.posts
  for select to authenticated
  using (status = 'visivel' or author_id = auth.uid() or public.is_moderator());
drop policy if exists "relatos: publicar" on public.posts;
create policy "relatos: publicar" on public.posts
  for insert to authenticated with check (author_id = auth.uid());
drop policy if exists "relatos: editar os seus" on public.posts;
create policy "relatos: editar os seus" on public.posts
  for update to authenticated
  using (author_id = auth.uid() or public.is_moderator())
  with check (author_id = auth.uid() or public.is_moderator());
drop policy if exists "relatos: apagar os seus" on public.posts;
create policy "relatos: apagar os seus" on public.posts
  for delete to authenticated using (author_id = auth.uid() or public.is_moderator());

drop policy if exists "comentarios: ler" on public.comments;
create policy "comentarios: ler" on public.comments
  for select to authenticated
  using (exists (select 1 from public.posts p where p.id = post_id));
drop policy if exists "comentarios: comentar" on public.comments;
create policy "comentarios: comentar" on public.comments
  for insert to authenticated
  with check (author_id = auth.uid()
              and exists (select 1 from public.posts p where p.id = post_id and p.status = 'visivel'));
drop policy if exists "comentarios: apagar os seus" on public.comments;
create policy "comentarios: apagar os seus" on public.comments
  for delete to authenticated using (author_id = auth.uid() or public.is_moderator());

drop policy if exists "denuncias: ver as suas (ou moderacao)" on public.reports;
create policy "denuncias: ver as suas (ou moderacao)" on public.reports
  for select to authenticated using (reporter_id = auth.uid() or public.is_moderator());
drop policy if exists "denuncias: denunciar" on public.reports;
create policy "denuncias: denunciar" on public.reports
  for insert to authenticated
  with check (reporter_id = auth.uid() and exists (select 1 from public.posts p where p.id = post_id));

-- ---------------------------------------------------------------------
-- 6. Consultas prontas usadas pelo app (respeitam as regras acima)
-- ---------------------------------------------------------------------
create or replace view public.feed with (security_invoker = true) as
select p.id, p.author_id, pr.handle as author_handle, pr.display_name as author_name,
       p.category, p.text, p.lang, p.lat, p.lon, p.approx, p.municipio,
       p.observed_at, p.published_at, p.edited_at, p.community_ids, p.photo_path, p.status, p.radar,
       (select count(*) from public.comments c where c.post_id = p.id)::int as comment_count,
       p.verified, pr.avatar_path as author_avatar
from public.posts p
join public.profiles pr on pr.id = p.author_id;

create or replace view public.comment_feed with (security_invoker = true) as
select c.id, c.post_id, c.author_id, pr.handle as author_handle, pr.display_name as author_name,
       c.text, c.lang, c.created_at, pr.avatar_path as author_avatar
from public.comments c
join public.profiles pr on pr.id = c.author_id;

-- comentários de outras pessoas nos meus relatos (aba Atividade)
create or replace view public.activity with (security_invoker = true) as
select c.id, c.post_id, c.text, c.created_at, pr.handle as author_handle, pr.display_name as author_name,
       left(p.text, 80) as post_text
from public.comments c
join public.posts p on p.id = c.post_id
join public.profiles pr on pr.id = c.author_id
where p.author_id = auth.uid() and c.author_id <> auth.uid();

-- denúncias pendentes (só aparece para a moderação)
create or replace view public.moderation_queue with (security_invoker = true) as
select r.id, r.post_id, r.reason, r.created_at, r.status,
       pr.handle as reporter_handle, left(p.text, 160) as post_text, p.status as post_status
from public.reports r
join public.posts p on p.id = r.post_id
join public.profiles pr on pr.id = r.reporter_id
where r.status = 'pendente' and public.is_moderator();

revoke all on public.feed, public.comment_feed, public.activity, public.moderation_queue from anon;
grant select on public.feed, public.comment_feed, public.activity, public.moderation_queue to authenticated;

-- decisão da moderação: "mantido" (o relato continua) ou "ocultado" (some para os outros)
create or replace function public.moderate_report(report_id text, decision text)
returns void language plpgsql security definer set search_path = '' as $$
declare pid text;
begin
  if not public.is_moderator() then
    raise exception 'Somente a moderação pode revisar denúncias.' using errcode = '42501';
  end if;
  if decision not in ('mantido', 'ocultado') then
    raise exception 'Decisão inválida.' using errcode = '22023';
  end if;
  select r.post_id into pid from public.reports r where r.id = report_id;
  if pid is null then
    raise exception 'Denúncia não encontrada.' using errcode = 'P0002';
  end if;
  -- a decisão vale para todas as denúncias pendentes do mesmo relato
  update public.reports
     set status = decision, reviewed_at = now(), reviewed_by = auth.uid()
   where post_id = pid and (status = 'pendente' or id = report_id);
  update public.posts
     set status = case when decision = 'ocultado' then 'oculto' else 'visivel' end,
         verified = (decision = 'mantido')
   where id = pid;
end $$;

-- registro da própria pessoa (Configurações › Meu registro): as denúncias que ela fez, com data, hora e o local do
-- relato denunciado (mesmo se ele foi ocultado depois). Só devolve as denúncias de quem chama.
create or replace function public.my_report_log()
returns table (id text, created_at timestamptz, reason text, status text, reviewed_at timestamptz,
               post_id text, category text, municipio text, lat double precision, lon double precision, approx boolean)
language sql stable security definer set search_path = '' as $$
  select r.id, r.created_at, r.reason, r.status, r.reviewed_at,
         r.post_id, p.category, p.municipio, p.lat, p.lon, p.approx
  from public.reports r
  left join public.posts p on p.id = r.post_id
  where r.reporter_id = auth.uid()
  order by r.created_at desc;
$$;
revoke all on function public.my_report_log() from public, anon;
grant execute on function public.my_report_log() to authenticated;

revoke all on function public.moderate_report(text, text) from public, anon;
grant execute on function public.moderate_report(text, text) to authenticated;
revoke all on function public.is_moderator() from public, anon;
grant execute on function public.is_moderator() to authenticated;

-- ---------------------------------------------------------------------
-- 7. Fotos dos relatos (Storage)
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('fotos', 'fotos', true, 2097152, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update
  set public = excluded.public,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

-- cada pessoa só envia e apaga fotos dentro da própria pasta (fotos/<id da conta>/...)
drop policy if exists "fotos: enviar na propria pasta" on storage.objects;
create policy "fotos: enviar na propria pasta" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'fotos' and (storage.foldername(name))[1] = auth.uid()::text);
-- (apagar exige também poder ver o arquivo; a exibição das fotos usa o link público e não depende disto)
drop policy if exists "fotos: ver as proprias" on storage.objects;
create policy "fotos: ver as proprias" on storage.objects
  for select to authenticated
  using (bucket_id = 'fotos' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_moderator()));
drop policy if exists "fotos: apagar as proprias" on storage.objects;
create policy "fotos: apagar as proprias" on storage.objects
  for delete to authenticated
  using (bucket_id = 'fotos' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_moderator()));

-- ---------------------------------------------------------------------
-- 8. Administração
-- ---------------------------------------------------------------------
-- No app: Perfil › Editar perfil › nome "IgaraPost". A primeira conta que fizer isso vira a
-- administradora (fila de denúncias em Perfil › Revisão; ocultar ou excluir qualquer relato ou
-- comentário; verificar relatos na "fila de moderação"). Depois disso o nome (e o @igarapost)
-- fica bloqueado para as outras contas.
--
-- Para conferir quem administra:
--   select m.user_id, p.display_name from public.moderators m join public.profiles p on p.id = m.user_id;
-- Para tirar alguém da administração (o nome volta a ficar livre se não sobrar ninguém):
--   delete from public.moderators where user_id = 'CODIGO-DA-CONTA';
