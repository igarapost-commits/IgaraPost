\set ON_ERROR_STOP 0
insert into auth.users (id) values ('aaaaaaaa-0000-0000-0000-000000000001'),('bbbbbbbb-0000-0000-0000-000000000002'),('cccccccc-0000-0000-0000-000000000003');
insert into public.moderators values ('cccccccc-0000-0000-0000-000000000003');
select 'perfis criados', count(*) from public.profiles;
-- A publica
set role authenticated; set request.jwt.claim.sub = 'aaaaaaaa-0000-0000-0000-000000000001';
insert into public.posts (id, author_id, category, text, lat, lon, approx, observed_at, status) values ('post-1','bbbbbbbb-0000-0000-0000-000000000002','fumaca','Muita fumaça no bairro hoje cedo',-3.10123,-60.02567,true,now(),'oculto');
select 'A: autor forçado/status/aprox', author_id::text like 'aaaa%', status, lat, lon from public.posts;
update public.profiles set display_name='Ana' where id = auth.uid();
update public.profiles set display_name='HACK' where id <> auth.uid();
-- B
set request.jwt.claim.sub = 'bbbbbbbb-0000-0000-0000-000000000002';
select 'B vê feed', count(*), max(author_name), max(comment_count) from public.feed;
update public.posts set text='editado pelo B maliciosamente' where id='post-1'; select 'B editou? (0=nao)', count(*) from public.posts where text like 'editado%';
delete from public.posts where id='post-1'; select 'B apagou? (1=nao)', count(*) from public.posts;
insert into public.comments (id, post_id, text) values ('com-1','post-1','Confirmo, aqui também');
insert into public.reports (post_id, reason) values ('post-1','Informação falsa');
insert into public.reports (post_id, reason) values ('post-1','de novo');
select 'B vê fila mod (0)', count(*) from public.moderation_queue;
select public.moderate_report((select id from public.reports limit 1),'ocultado');
-- A vê atividade
set request.jwt.claim.sub = 'aaaaaaaa-0000-0000-0000-000000000001';
select 'A atividade', count(*), max(author_name) from public.activity;
select 'A vê denúncias de outros (0)', count(*) from public.reports;
update public.posts set status='oculto' where id='post-1'; select 'A tentou ocultar: ', status from public.posts;
-- moderador
set request.jwt.claim.sub = 'cccccccc-0000-0000-0000-000000000003';
select 'M fila', count(*), max(reason), max(post_text) from public.moderation_queue;
select public.moderate_report((select id from public.reports limit 1),'ocultado');
select 'M depois', status from public.posts;
-- B não vê mais, A (autor) vê
set request.jwt.claim.sub = 'bbbbbbbb-0000-0000-0000-000000000002';
select 'B vê oculto? (0)', count(*) from public.feed;
insert into public.comments (id, post_id, text) values ('com-2','post-1','comentar em oculto');
select 'B status denúncia', status from public.reports;
set request.jwt.claim.sub = 'aaaaaaaa-0000-0000-0000-000000000001';
select 'A vê o seu oculto', status from public.feed;
-- edição marca edited_at
update public.posts set text='Fumaça forte, corrigindo horário' where id='post-1';
select 'A editou', edited_at is not null, status from public.posts;
-- storage
insert into storage.objects (bucket_id, name) values ('fotos','aaaaaaaa-0000-0000-0000-000000000001/post-1.jpg');
insert into storage.objects (bucket_id, name) values ('fotos','bbbbbbbb-0000-0000-0000-000000000002/x.jpg');
select 'fotos', count(*) from storage.objects;
-- sem sessão
reset role; set role anon;
select 'anon feed' , count(*) from public.feed;
reset role;
-- limite
set role authenticated; set request.jwt.claim.sub = 'bbbbbbbb-0000-0000-0000-000000000002';
do $$ begin for i in 1..21 loop insert into public.posts (id, category, text, lat, lon, observed_at) values ('lim'||i,'outro','teste de limite por hora',0,0,now()); end loop; end $$;
select 'B posts após 21 tentativas (0 = tudo revertido)', count(*) from public.posts where author_id=auth.uid();
set role authenticated; set request.jwt.claim.sub = 'aaaaaaaa-0000-0000-0000-000000000001';
select 'A vê própria foto?', count(*) from storage.objects;
\set ON_ERROR_STOP 0
insert into auth.users (id) values ('aaaaaaaa-0000-0000-0000-000000000001'),('bbbbbbbb-0000-0000-0000-000000000002');
set role authenticated;
set request.jwt.claim.sub = 'aaaaaaaa-0000-0000-0000-000000000001';
update public.profiles set display_name = '  Igara Post ' where id = auth.uid();
select 'A admin?', public.is_moderator(), (select display_name from public.profiles where id = auth.uid());
set request.jwt.claim.sub = 'bbbbbbbb-0000-0000-0000-000000000002';
update public.profiles set display_name = 'igarapost' where id = auth.uid();
select 'B admin? (f)', public.is_moderator(), (select display_name from public.profiles where id = auth.uid());
update public.profiles set display_name = 'Maria' where id = auth.uid();
select 'B renomeia normal', (select display_name from public.profiles where id = auth.uid());
insert into public.posts (id, category, text, lat, lon, observed_at) values ('post-b1','fumaca','fumaça perto do lago',-3,-60,now());
insert into public.reports (post_id, reason) values ('post-b1','teste'); -- B denuncia o próprio? permitido
select 'B log', count(*), max(lat) from public.my_report_log();
set request.jwt.claim.sub = 'aaaaaaaa-0000-0000-0000-000000000001';
select 'A log (0)', count(*) from public.my_report_log();
update public.posts set status = 'oculto' where id = 'post-b1';
select 'A ocultou', status from public.posts where id = 'post-b1';
update public.profiles set display_name = 'Ana' where id = auth.uid();
update public.profiles set display_name = 'IgaraPost' where id = auth.uid();
select 'A volta ao nome', display_name from public.profiles where id = auth.uid();
delete from public.posts where id = 'post-b1';
select 'A excluiu de B', count(*) from public.posts;
\set ON_ERROR_STOP 0
insert into auth.users (id) values ('aaaaaaaa-0000-0000-0000-000000000001'),('bbbbbbbb-0000-0000-0000-000000000002');
set role authenticated;
set request.jwt.claim.sub = 'bbbbbbbb-0000-0000-0000-000000000002';
update profiles set handle = '@Maria_Rio' where id = auth.uid();
select 'B handle', handle from profiles where id = auth.uid();
insert into posts (id, category, text, lat, lon, observed_at) values ('post-b1','fumaca','fumaça perto do lago',-3,-60,now());
update posts set verified = true where id = 'post-b1';
select 'B tentou verificar (f)', verified from posts where id='post-b1';
set request.jwt.claim.sub = 'aaaaaaaa-0000-0000-0000-000000000001';
update profiles set handle = 'maria_rio' where id = auth.uid();
update profiles set handle = 'igarapost' where id = auth.uid();
update profiles set handle = 'x' where id = auth.uid();
update profiles set display_name = 'IgaraPost' where id = auth.uid();
select 'A admin', display_name, handle from profiles where id = auth.uid();
select 'fila nao verificados', count(*) from feed where verified = false and status = 'visivel';
update posts set verified = true where id = 'post-b1';
select 'A verificou', verified, verified_at is not null from posts where id='post-b1';
insert into posts (id, category, text, lat, lon, observed_at) values ('post-a1','outro','aviso da administração',-3,-60,now());
select 'post da adm nasce verificado', verified from posts where id='post-a1';
set request.jwt.claim.sub = 'bbbbbbbb-0000-0000-0000-000000000002';
update posts set text = 'fumaça perto do lago, editado' where id = 'post-b1';
select 'B editou: volta a nao verificado (f)', verified from posts where id='post-b1';
update profiles set avatar_path = 'bbbbbbbb-0000-0000-0000-000000000002/avatar-1.jpg' where id = auth.uid();
select 'avatar no feed', author_avatar from feed where id='post-b1';
