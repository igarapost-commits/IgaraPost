"""Testa process_nisar_gcov.py com arquivos SINTÉTICOS (nada aqui é dado real).

Cenário: data B tem (1) uma mancha com queda de 6 dB em HV, (2) grade deslocada 50 m em relação a A,
(3) uma faixa com mask=0 e (4) uma faixa com numberOfLooks baixo. O teste confere se o script alinha as
grades, aplica as máscaras, mede a área de queda esperada e grava os parâmetros.
Uso: python3 tests/test_gcov_pipeline.py <pasta-temporária>"""
import json, subprocess, sys
from pathlib import Path
import h5py, numpy as np
from pyproj import Transformer

tmp = Path(sys.argv[1]); tmp.mkdir(parents=True, exist_ok=True)
tr = Transformer.from_crs(4326, 32720, always_xy=True)
x0, y0 = tr.transform(-60.4, -2.8); x1, y1 = tr.transform(-58.8, -3.9)
dx = 100.0; rng = np.random.default_rng(0)

def make(path, shift, drop, maskband, looksband, crid="SYNTH"):
    x = np.arange(x0 + shift, x1, dx); y = np.arange(y0, y1, -dx)
    with h5py.File(path, "w") as h:
        g = h.create_group("/science/LSAR/GCOV/grids/frequencyA")
        g["xCoordinates"] = x; g["yCoordinates"] = y
        p = g.create_dataset("projection", data=np.uint32(32720)); p.attrs["epsg_code"] = np.uint32(32720)
        hh = rng.gamma(8, 0.1 / 8, (len(y), len(x))).astype(np.float32)
        hv = rng.gamma(8, 0.02 / 8, (len(y), len(x))).astype(np.float32)
        if drop: hv[400:600, 500:800] *= 10 ** (-6 / 10)
        g["HHHH"] = hh; g["HVHV"] = hv
        m = np.ones_like(hh, np.uint8); m[:, :30] = 255
        if maskband: m[700:750, :] = 0
        g["mask"] = m
        nl = np.full(hh.shape, 20, np.uint8)
        if looksband: nl[800:850, :] = 0
        g["numberOfLooks"] = nl
        idn = h.create_group("/science/LSAR/identification")
        idn["trackNumber"] = np.uint32(140); idn["frameNumber"] = np.uint16(90)
        idn["orbitPassDirection"] = np.bytes_("Descending"); idn["compositeReleaseId"] = np.bytes_(crid)
        idn["zeroDopplerStartTime"] = np.bytes_("2026-07-17T22:16:32" if not drop else "2026-10-09T22:16:29")

make(tmp / "A.h5", 0, False, False, False)
make(tmp / "B.h5", 50.0, True, True, True)
here = Path(__file__).resolve().parent.parent
r = subprocess.run([sys.executable, str(here / "scripts/process_nisar_gcov.py"), "--a", str(tmp / "A.h5"), "--b", str(tmp / "B.h5"), "--out", str(tmp / "out"), "--looks", "5"], capture_output=True, text=True)
assert r.returncode == 0, r.stderr
S = json.load(open(tmp / "out/gcov_summary.json"))
res = []
def check(name, cond, extra=""): res.append(("OK " if cond else "FALHOU", name, extra))
check("grades diferentes detectadas e B alinhada", not S["checks"]["mesma_grade"] and any("reprojetada" in w for w in S["warnings"]))
hv = S["stats"]["HVHV"]
check("área de queda ≈ 600 km² (mancha de 200×300 px de 100 m)", 540 <= hv["drop_km2"] <= 610, hv["drop_km2"])
check("sem aumento espúrio (HH e HV)", hv["rise_km2"] < 5 and S["stats"]["HHHH"]["drop_km2"] < 5 and S["stats"]["HHHH"]["rise_km2"] < 5, (hv["rise_km2"], S["stats"]["HHHH"]["drop_km2"]))
check("máscara mask=0 aplicada", S["b"]["invalid_pixels"]["mask"] > 0)
check("numberOfLooks baixo aplicado", S["b"]["invalid_pixels"]["poucos_looks"] > 0)
check("pixels inválidos viram 'sem dados' no resultado", hv["nodata_frac"] > 0.03, hv["nodata_frac"])
check("parâmetros gravados", set(S["params"]) >= {"looks", "min_looks", "invalid_mask", "threshold_db"})
check("GeoTIFFs gerados", all((tmp / "out" / f"HVHV_{n}.tif").exists() for n in ("A_dB", "B_dB", "diff_dB")))
make(tmp / "C.h5", 0, True, False, False, crid="OUTRA")
r2 = subprocess.run([sys.executable, str(here / "scripts/process_nisar_gcov.py"), "--a", str(tmp / "A.h5"), "--b", str(tmp / "C.h5"), "--out", str(tmp / "out2")], capture_output=True, text=True)
check("CRID diferente gera aviso", r2.returncode == 0 and "CRID" in json.load(open(tmp / "out2/gcov_summary.json"))["warnings"][0])
for x in res: print("  ".join(map(str, x)))
sys.exit(any(x[0] != "OK " for x in res))
