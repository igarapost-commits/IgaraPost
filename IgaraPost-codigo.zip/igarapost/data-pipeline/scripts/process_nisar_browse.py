"""IgaraPost — processamento das imagens BROWSE (públicas) de produtos NISAR L2 GCOV.

O que este script faz (e o que NÃO faz):
- Usa as imagens de pré-visualização *_LATLON.png publicadas pelo ASF para cada granule GCOV.
  Elas são renderizações em 8 bits (R=B=HH, G=HV, com realce de contraste), NÃO valores de gamma0.
- Estima o georreferenciamento de cada PNG (o KML que o acompanha exige login) em duas etapas:
  (1) ajuste afim usando o contorno (WKT) informado pelo ASF; (2) refinamento por registro das
  superfícies escuras (água) contra a camada NISAR GCOV do NASA GIBS (georreferência exata).
- Recorta a área de estudo e gera, para o navegador: imagem A, imagem B e uma camada de
  "superfície escura no radar" (provável água aberta) com as transições entre as datas.
- Gera série temporal da fração de superfície escura na área, para todas as datas da trilha.
A análise quantitativa (dB, razão logarítmica) fica em process_nisar_gcov.py, que lê o .h5.
"""
import io, json, math, re, sys, urllib.request
from pathlib import Path
import numpy as np
from PIL import Image

RAW = Path(sys.argv[1] if len(sys.argv) > 1 else "raw/browse")
OUT = Path(sys.argv[2] if len(sys.argv) > 2 else "out/nisar")
OUT.mkdir(parents=True, exist_ok=True)
AOI = dict(west=-60.35, east=-58.85, south=-3.85, north=-2.85)   # Manaus–Careiro da Várzea–Autazes
PAIR = ("2026-07-17", "2026-10-09")
GIBS = "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/NISAR_L2_Geocoded_Polarimetric_Covariance/default/{d}/GoogleMapsCompatible_Level13/{z}/{y}/{x}.png"
meta = {m["date"]: m for m in json.load(open(RAW / "meta.json"))}

def lum(a):
    return a[..., :3].astype(np.float32).mean(-1)

def otsu(v):
    h, e = np.histogram(v, 256, (0, 255)); p = h / h.sum(); w = np.cumsum(p); mu = np.cumsum(p * np.arange(256))
    s = (mu[-1] * w - mu) ** 2 / (w * (1 - w) + 1e-12); return float(np.argmax(s))

def poly(wkt):
    return np.array([tuple(map(float, p.split())) for p in re.findall(r"-?[\d.]+ -?[\d.]+", wkt)][:4])

# ---------- (1) ajuste afim inicial a partir dos contornos de todas as datas ----------
P, L = [], []
for d, m in meta.items():
    a = np.asarray(Image.open(RAW / f"{d}.png")); nz = a.sum(2) > 15; ys, xs = np.where(nz)
    pts = [(xs[ys == ys.min()].mean(), ys.min()), (xs.min(), ys[xs == xs.min()].mean()), (xs.max(), ys[xs == xs.max()].mean())]
    v = poly(m["wkt"]); geo = [v[v[:, 1].argmax()], v[v[:, 0].argmin()], v[v[:, 0].argmax()]]  # canto inferior é mal definido
    P += pts; L += geo
P, L = np.array(P), np.array(L); A = np.c_[L, np.ones(len(L))]
cx = np.linalg.lstsq(A, P[:, 0], rcond=None)[0]; cy = np.linalg.lstsq(A, P[:, 1], rcond=None)[0]
resid = np.abs(np.c_[A @ cx, A @ cy] - P)
print("afim inicial: resíduo médio (px)", resid.mean(0).round(1), file=sys.stderr)

# ---------- referência GIBS (zoom 9) sobre a AOI ampliada ----------
def tile_xy(lon, lat, z):
    n = 2 ** z; return (lon + 180) / 360 * n, (1 - math.asinh(math.tan(math.radians(lat))) / math.pi) / 2 * n

def gibs_mosaic(date, z=9, pad=0.15):
    x0, y0 = tile_xy(AOI["west"] - pad, AOI["north"] + pad, z); x1, y1 = tile_xy(AOI["east"] + pad, AOI["south"] - pad, z)
    X = range(int(x0), int(x1) + 1); Y = range(int(y0), int(y1) + 1)
    M = np.zeros((256 * len(Y), 256 * len(X), 3), np.uint8)
    for j, ty in enumerate(Y):
        for i, tx in enumerate(X):
            raw = urllib.request.urlopen(GIBS.format(d=date, z=z, y=ty, x=tx), timeout=60).read()
            M[j * 256:(j + 1) * 256, i * 256:(i + 1) * 256] = np.asarray(Image.open(io.BytesIO(raw)).convert("RGB"))
    n = 2 ** z; px = (np.arange(M.shape[1]) + 0.5) / 256 + X[0]; py = (np.arange(M.shape[0]) + 0.5) / 256 + Y[0]
    lon = px / n * 360 - 180; lat = np.degrees(np.arctan(np.sinh(math.pi * (1 - 2 * py / n))))
    return M, lon, lat

def sample(img, lon2, lat2, coef):
    cxx, cyy = coef
    c = cxx[0] * lon2 + cxx[1] * lat2 + cxx[2]; r = cyy[0] * lon2 + cyy[1] * lat2 + cyy[2]
    ci = np.clip(np.round(c).astype(int), 0, img.shape[1] - 1); ri = np.clip(np.round(r).astype(int), 0, img.shape[0] - 1)
    out = img[ri, ci]; valid = (c >= 0) & (c < img.shape[1]) & (r >= 0) & (r < img.shape[0])
    return out, valid

# ---------- (2) refinamento por registro contra o GIBS ----------
ref, glon, glat = gibs_mosaic(PAIR[1])
LON, LAT = np.meshgrid(glon, glat)
gl = lum(ref); gvalid = ref.sum(2) > 0
gwater = (gl < otsu(gl[gvalid])) & gvalid
results = {}
for d in PAIR:
    img = np.asarray(Image.open(RAW / f"{d}.png").convert("RGB"))
    best = (-1, 0, 0, 1.0)
    for s in (0.985, 0.99, 0.995, 1.0, 1.005, 1.01, 1.015):
        for dx in range(-24, 25, 2):
            for dy in range(-24, 25, 2):
                coef = (np.array([cx[0] * s, cx[1], cx[2] + dx + (s - 1) * (cx[0] * -59.2)]), np.array([cy[0], cy[1] * s, cy[2] + dy + (s - 1) * (cy[1] * -3.2)]))
                v, ok = sample(img, LON, LAT, coef); bl = lum(v); m = ok & gvalid & (v.sum(-1) > 0)
                bw = bl < otsu(bl[m]); inter = (bw & gwater & m).sum(); uni = ((bw | gwater) & m).sum()
                iou = inter / max(uni, 1)
                if iou > best[0]: best = (iou, dx, dy, s)
    iou, dx, dy, s = best
    results[d] = dict(iou=round(float(iou), 3), dx=dx, dy=dy, scale=s,
                      coef=([cx[0] * s, cx[1], cx[2] + dx + (s - 1) * (cx[0] * -59.2)], [cy[0], cy[1] * s, cy[2] + dy + (s - 1) * (cy[1] * -3.2)]))
    print(d, "registro vs GIBS:", results[d]["iou"], "IoU, deslocamento px", dx, dy, "escala", s, file=sys.stderr)

# ---------- recorte da AOI em grade lat/lon regular ----------
RES = 1 / 650  # ~170 m, próximo da resolução nativa do browse (vizinho mais próximo)
W = int((AOI["east"] - AOI["west"]) / RES); H = int((AOI["north"] - AOI["south"]) / RES)
lon = AOI["west"] + (np.arange(W) + 0.5) * RES; lat = AOI["north"] - (np.arange(H) + 0.5) * RES
LO, LA = np.meshgrid(lon, lat)
crops, water = {}, {}
for d in PAIR:
    img = np.asarray(Image.open(RAW / f"{d}.png").convert("RGB")); co = tuple(np.array(c) for c in results[d]["coef"])
    v, ok = sample(img, LO, LA, co); valid = ok & (v.sum(-1) > 0)
    crops[d] = (v, valid); l = lum(v); t = otsu(l[valid]); water[d] = (l < t) & valid
    results[d]["otsu_threshold"] = t
    rgba = np.dstack([v, np.where(valid, 255, 0).astype(np.uint8)])
    Image.fromarray(rgba, "RGBA").save(OUT / f"nisar_{d}.webp", quality=82, method=6)
    Image.fromarray(rgba, "RGBA").save(OUT / f"nisar_{d}.png", optimize=True)

a, b = PAIR; va = crops[a][1] & crops[b][1]
chg = np.zeros((H, W, 4), np.uint8)
lost = water[a] & ~water[b] & va      # escuro -> claro: possível recuo da água / exposição de margens
gain = ~water[a] & water[b] & va      # claro -> escuro: possível nova lâmina d'água ou superfície muito lisa
stay = water[a] & water[b] & va
chg[stay] = (30, 90, 160, 150); chg[lost] = (230, 120, 20, 230); chg[gain] = (40, 200, 230, 230)
chg[~va] = (128, 128, 128, 90)       # sem dados em uma das datas
Image.fromarray(chg, "RGBA").save(OUT / "nisar_change_dark.png", optimize=True)
px_km2 = (RES * 111.32) * (RES * 111.32 * math.cos(math.radians(-3.35)))
stats = dict(valid_km2=round(float(va.sum() * px_km2), 1), dark_A_km2=round(float((water[a] & va).sum() * px_km2), 1),
             dark_B_km2=round(float((water[b] & va).sum() * px_km2), 1), dark_to_bright_km2=round(float(lost.sum() * px_km2), 1),
             bright_to_dark_km2=round(float(gain.sum() * px_km2), 1), nodata_frac=round(float(1 - va.mean()), 3))
print(stats, file=sys.stderr)

# ---------- série temporal (todas as datas da trilha 140/frame 90, mesmo afim refinado médio) ----------
mdx = np.mean([results[d]["dx"] for d in PAIR]); mdy = np.mean([results[d]["dy"] for d in PAIR]); ms = np.mean([results[d]["scale"] for d in PAIR])
co_mean = (np.array([cx[0] * ms, cx[1], cx[2] + mdx + (ms - 1) * (cx[0] * -59.2)]), np.array([cy[0], cy[1] * ms, cy[2] + mdy + (ms - 1) * (cy[1] * -3.2)]))
series = []
common = None
cache = {}
for d in sorted(meta):
    img = np.asarray(Image.open(RAW / f"{d}.png").convert("RGB")); v, ok = sample(img, LO, LA, co_mean)
    cache[d] = (v, ok & (v.sum(-1) > 0)); common = cache[d][1] if common is None else common & cache[d][1]
for d in sorted(meta):
    v, _ = cache[d]; l = lum(v); t = otsu(l[common]); frac = float((l[common] < t).mean())
    series.append(dict(date=d, dark_frac=round(frac, 4), dark_km2=round(frac * common.sum() * px_km2, 1), crid=meta[d]["crid"]))
summary = dict(
    aoi=AOI, pair=PAIR, grid_res_deg=RES, px_km2=px_km2,
    registration={d: {k: results[d][k] for k in ("iou", "dx", "dy", "scale", "otsu_threshold")} for d in PAIR},
    affine_initial_residual_px=resid.mean(0).round(1).tolist(), stats=stats, series=series, series_common_km2=round(float(common.sum() * px_km2), 1),
    granules={d: {k: meta[d][k] for k in ("granule", "crid", "pge", "collection", "pol", "coverage", "dir", "path", "frame", "start", "stop", "download", "browse")} for d in sorted(meta)})
json.dump(summary, open(OUT / "nisar_summary.json", "w"), ensure_ascii=False, indent=1)
print("ok", file=sys.stderr)
