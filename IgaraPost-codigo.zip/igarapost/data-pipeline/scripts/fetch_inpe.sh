#!/bin/bash
# Baixa os CSVs mensais de focos (Brasil, todos os satélites) do INPE e gera dois recortes:
#   *.filt : retângulo da área do app (pontos para o mapa)
#   *.am   : todas as linhas do estado do Amazonas (contagens municipais completas, inclusive
#            de municípios que só em parte caem dentro do retângulo)
set -e
OUT=${1:-raw/inpe}; mkdir -p $OUT
for m in 202607 202608 202609 202610 202611; do
  f=$OUT/focos_mensal_br_$m.csv
  curl -sS --retry 4 https://dataserver-coids.inpe.br/queimadas/queimadas/focos/csv/mensal/Brasil/focos_mensal_br_$m.csv -o $f
  awk -F, 'NR==1 || ($3+0>=-61.5 && $3+0<=-57.0 && $2+0>=-5.0 && $2+0<=-1.0)' $f > $f.filt
  awk -F, 'NR==1 || $7=="AMAZONAS"' $f > $f.am
  rm $f
done
date -u +%Y-%m-%dT%H:%MZ > $OUT/retrieved.txt
echo done
