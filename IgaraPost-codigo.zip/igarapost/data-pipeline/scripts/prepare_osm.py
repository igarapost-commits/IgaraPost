"""Prepara camadas vetoriais leves do OpenStreetMap (© colaboradores do OpenStreetMap, licença ODbL)
para o mapa offline e para a busca de localidades.

Entradas (Overpass API, consultas em README do pipeline): raw/osm/places.json, rivers.json, roads.json (opcional)
Saídas: out/osm/places.json (nome, tipo, lat, lon), out/osm/lines.json (rios e vias simplificados)."""
import json, sys
from pathlib import Path
from shapely.geometry import LineString

RAW, OUT = Path(sys.argv[1]), Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
RANK = {"city": 0, "town": 1, "village": 2, "hamlet": 3, "locality": 4}
places = []
for e in json.load(open(RAW / "places.json"))["elements"]:
    t = e["tags"]; places.append([t["name"], t["place"], round(e["lat"], 4), round(e["lon"], 4)])
places.sort(key=lambda p: (RANK.get(p[1], 9), p[0]))
json.dump({"source": "© colaboradores do OpenStreetMap (ODbL), via Overpass API", "retrieved": sys.argv[3] if len(sys.argv) > 3 else "",
           "fields": ["nome", "tipo", "lat", "lon"], "places": places}, open(OUT / "places.json", "w"), ensure_ascii=False, separators=(",", ":"))

def lines(fn, kind, tol, min_len):
    p = RAW / fn
    if not p.exists(): return []
    out = []
    for e in json.load(open(p)).get("elements", []):
        g = e.get("geometry")
        if not g or len(g) < 2: continue
        ls = LineString([(q["lon"], q["lat"]) for q in g])
        if ls.length < min_len and "name" not in e.get("tags", {}): continue
        s = ls.simplify(tol)
        out.append({"k": kind, "n": e.get("tags", {}).get("name", ""), "c": [[round(x, 3), round(y, 3)] for x, y in s.coords]})
    return out
L = lines("rivers.json", "rio", 0.002, 0.05) + lines("roads.json", "via", 0.001, 0.0)
json.dump({"source": "© colaboradores do OpenStreetMap (ODbL), via Overpass API", "lines": L}, open(OUT / "lines.json", "w"), ensure_ascii=False, separators=(",", ":"))
print(len(places), "localidades;", sum(1 for l in L if l["k"] == "rio"), "rios;", sum(1 for l in L if l["k"] == "via"), "vias")
