"""Baixa as imagens browse *_LATLON.png (públicas) dos GCOV de uma trilha/frame e grava meta.json."""
import json, subprocess, sys
src, out, path, frame = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
d = json.load(open(src))["results"]
sel = sorted([x for x in d if x["path"] == path and x["frame"] == frame], key=lambda r: r["startTime"])
meta = []
for r in sel:
    date = r["startTime"][:10]
    png = [b for b in r["browse"] if b.endswith("_LATLON.png")][0]
    subprocess.run(["curl", "-sSL", "--retry", "3", "-o", f"{out}/{date}.png", png], check=True)
    meta.append(dict(date=date, granule=r["granuleName"], crid=r["nisar"]["crid"], pge=r["nisar"]["pgeVersion"], collection=r["collectionName"],
                     pol=r["nisar"]["mainBandPolarization"], coverage=r["nisar"]["frameCoverage"], dir=r["flightDirection"], path=r["path"],
                     frame=r["frame"], start=r["startTime"], stop=r["stopTime"], wkt=r["wkt"], download=r["downloadUrl"], browse=png))
    print(date, r["granuleName"])
json.dump(meta, open(f"{out}/meta.json", "w"), indent=1)
