"""Teste EXPLORATÓRIO: os focos NPP-375 (INPE) entre as duas datas NISAR caem mais perto de áreas
que mudaram no radar do que pontos sorteados ao acaso em terra firme? Isto indica uma relação a
investigar; NÃO estabelece causa (fogo pode não alterar o sinal; outras causas alteram)."""
import json, sys
import numpy as np
from PIL import Image
from scipy.ndimage import binary_dilation
out = sys.argv[1]
S = json.load(open(f"{out}/nisar/nisar_summary.json")); aoi = S["aoi"]; res = S["grid_res_deg"]
c = np.asarray(Image.open(f"{out}/nisar/nisar_change_dark.png").convert("RGBA")).astype(int)
H, W = c.shape[:2]
def is_(rgb): return (c[..., 0] == rgb[0]) & (c[..., 1] == rgb[1]) & (c[..., 2] == rgb[2]) & (c[..., 3] > 0)
lost, gain, stay = is_((230, 120, 20)), is_((40, 200, 230)), is_((30, 90, 160))
nodata = is_((128, 128, 128))
valid = ~nodata
land_A = valid & ~stay & ~lost        # claro em A (não escuro em julho)
R_M = 500; rpx = int(np.ceil(R_M / (res * 111320)))
yy, xx = np.mgrid[-rpx:rpx + 1, -rpx:rpx + 1]; disk = (xx ** 2 + yy ** 2) <= rpx ** 2
near_gain = binary_dilation(gain, disk); near_lost = binary_dilation(lost, disk)
F = json.load(open(f"{out}/fires_NPP-375.json"))
from datetime import datetime, timedelta, timezone
t0 = datetime(2026, 7, 1, tzinfo=timezone.utc)
a = datetime.fromisoformat(S["pair"][0] + "T22:16:00+00:00"); b = datetime.fromisoformat(S["pair"][1] + "T22:16:00+00:00")
pts = []
for r in F["rows"]:
    t = t0 + timedelta(minutes=r[2])
    if not (a <= t <= b): continue
    col = int((r[1] - aoi["west"]) / res); row = int((aoi["north"] - r[0]) / res)
    if 0 <= col < W and 0 <= row < H and land_A[row, col]: pts.append((row, col))
pts = np.array(pts)
fg = near_gain[pts[:, 0], pts[:, 1]].mean(); fl = near_lost[pts[:, 0], pts[:, 1]].mean()
rng = np.random.default_rng(42); idx = np.flatnonzero(land_A.ravel()); pick = rng.choice(idx, 20000, replace=False)
rg = near_gain.ravel()[pick].mean(); rl = near_lost.ravel()[pick].mean()
res_ = dict(satellite="NPP-375", period=S["pair"], n_fires=int(len(pts)), radius_m=R_M,
            frac_fires_near_bright_to_dark=round(float(fg), 3), frac_fires_near_dark_to_bright=round(float(fl), 3),
            frac_random_near_bright_to_dark=round(float(rg), 3), frac_random_near_dark_to_bright=round(float(rl), 3), n_random=20000,
            note="Focos e pontos aleatórios restritos a pixels válidos que não estavam escuros na data A.")
S["fire_overlap"] = res_; json.dump(S, open(f"{out}/nisar/nisar_summary.json", "w"), ensure_ascii=False, indent=1)
print(res_)
