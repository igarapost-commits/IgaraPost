"""Inventário dos produtos NISAR L2 GCOV que cobrem a área de estudo (metadados públicos da API do ASF).

Agrupa por características que precisam ser iguais para comparar retroespalhamento entre datas:
trilha (path), frame, direção da órbita, modo de banda, polarizações e versão de processamento (CRID).
Saídas: out/nisar/inventory.json e docs/NISAR_INVENTARIO.md. Também grava um resumo em nisar_summary.json.

Uso: python3 scripts/nisar_inventory.py raw/asf_gcov_aoi.json out ../docs
(raw/asf_gcov_aoi.json vem da busca na API do ASF; veja run_all.sh)"""
import json, sys
from collections import defaultdict
from pathlib import Path

src, OUT, DOCS = sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3])
d = json.load(open(src))["results"]
groups = defaultdict(list)
for r in d:
    n = r["nisar"]
    pol = "+".join(n.get("mainBandPolarization") or []) or "?"
    mode = r["granuleName"].split("_")[8]
    key = (r["path"], r["frame"], r["flightDirection"], mode, pol, n["crid"])
    groups[key].append({"date": r["startTime"][:10], "start": r["startTime"], "granule": r["granuleName"], "collection": r["collectionName"],
                        "coverage": n.get("frameCoverage"), "pge": n.get("pgeVersion"), "download": r["downloadUrl"]})
inv = []
for (path, frame, direction, mode, pol, crid), items in groups.items():
    items.sort(key=lambda x: x["date"])
    full = [x for x in items if x["coverage"] == "Full"]
    inv.append({"path": path, "frame": frame, "direction": direction, "mode": mode, "pol": pol, "crid": crid,
                "collections": sorted({x["collection"] for x in items}), "n": len(items), "n_full": len(full),
                "first": items[0]["date"], "last": items[-1]["date"], "dates": [x["date"] for x in items], "items": items})
inv.sort(key=lambda g: (-g["n_full"], g["path"], g["frame"]))

def best_pair(g, early=("2026-07-01", "2026-07-31"), late=("2026-09-25", "2026-10-20")):
    full = [x for x in g["items"] if x["coverage"] == "Full"]
    a = [x for x in full if early[0] <= x["date"] <= early[1]]
    b = [x for x in full if late[0] <= x["date"] <= late[1]]
    return (a[-1]["date"], b[-1]["date"]) if a and b else None

rec = []
for g in inv:
    bp = best_pair(g)
    if bp and "HV" in g["pol"]:
        rec.append({"path": g["path"], "frame": g["frame"], "direction": g["direction"], "crid": g["crid"], "pair": bp,
                    "why": "mesma trilha, frame, direção, modo, polarização HH+HV e CRID; julho (cheia) × fim de setembro/outubro (vazante e fogo); frames completos"})
json.dump({"source": "API de busca do ASF (metadados públicos)", "n_products": len(d), "groups": inv, "recommended_pairs": rec}, open(OUT / "nisar" / "inventory.json", "w"), ensure_ascii=False, indent=1)

S = json.load(open(OUT / "nisar" / "nisar_summary.json"))
S["inventory"] = {"n_products": len(d), "groups": [{k: g[k] for k in ("path", "frame", "direction", "mode", "pol", "crid", "n", "n_full", "first", "last", "collections")} for g in inv],
                  "recommended_pairs": rec}
json.dump(S, open(OUT / "nisar" / "nisar_summary.json", "w"), ensure_ascii=False, indent=1)

L = ["# Inventário NISAR L2 GCOV sobre a área de estudo", "",
     f"Fonte: API de busca do ASF (metadados públicos). {len(d)} produtos cruzam o recorte lon -60,35 a -58,85; lat -3,85 a -2,85.",
     "Para comparar retroespalhamento entre datas, use produtos do mesmo grupo (mesma trilha, frame, direção, modo, polarizações e versão de processamento).", "",
     "| Trilha | Frame | Direção | Modo | Polarização | CRID | Produtos (completos) | Período | Coleções |", "|---|---|---|---|---|---|---|---|---|"]
for g in inv:
    L.append(f"| {g['path']} | {g['frame']} | {g['direction'].lower()} | {g['mode']} | {g['pol']} | {g['crid']} | {g['n']} ({g['n_full']}) | {g['first']} a {g['last']} | {', '.join(c.replace('NISAR_L2_GCOV_', '') for c in g['collections'])} |")
L += ["", "## Pares recomendados para a análise calibrada (quando o acesso Earthdata funcionar)", ""]
for r in rec: L.append(f"- Trilha {r['path']}, frame {r['frame']} ({r['direction'].lower()}, {r['crid']}): **{r['pair'][0]} × {r['pair'][1]}**. {r['why']}.")
L += ["", "Observações:", "- CRID P05023 = coleção PROVISIONAL; P05036 = coleção V1 (validada a partir de nov/2026). Não misture versões na mesma comparação.",
      "- A qualidade de cada produto (QA_SUMMARY.csv, QA_REPORT.pdf) exige login Earthdata e não foi conferida.",
      "- O par usado nas prévias do app é trilha 140, frame 90: 2026-07-17 × 2026-10-09."]
(DOCS / "NISAR_INVENTARIO.md").write_text("\n".join(L) + "\n")
print(len(inv), "grupos;", "pares recomendados:", [(r["path"], r["frame"], r["pair"]) for r in rec])
