"""Baixa o Índice Integrado de Secas (IIS) municipal do Cemaden (GeoServer público
usado pelo portal https://alertasecas.cemaden.gov.br/) para o recorte de estudo.
Camadas: alertasecas:iis1, iis3, iis6 (WFS 1.0.0, parâmetro viewparams=y:AAAA;m:M).
nivel: 1 Excepcional, 2 Extrema, 3 Severa, 4 Moderada, 5 Fraca, 6 Normal (Ausente)."""
import json, sys, urllib.parse, urllib.request
from shapely.geometry import shape, mapping
B = "https://gsb.cemaden.gov.br/geoserver/alertasecas/wfs"
BBOX = (-60.8, -4.8, -57.5, -1.6)
MONTHS = [(2026, m) for m in (6, 7, 8, 9, 10)]
out = {"source": "Cemaden — Alerta Secas (IIS municipal)", "url": "https://alertasecas.cemaden.gov.br/",
       "wfs": B, "bbox": BBOX, "products": {}, "geometries": {}}
for prod in ("iis1", "iis3", "iis6"):
    out["products"][prod] = {}
    for y, m in MONTHS:
        q = {"service": "WFS", "version": "1.0.0", "request": "GetFeature", "typeName": f"alertasecas:{prod}",
             "outputFormat": "application/json", "viewparams": f"y:{y};m:{m}", "bbox": ",".join(map(str, BBOX)) + ",EPSG:4326"}
        d = json.load(urllib.request.urlopen(B + "?" + urllib.parse.urlencode(q, safe=":;,"), timeout=120))
        key = f"{y}-{m:02d}"
        out["products"][prod][key] = {}
        for f in d["features"]:
            p = f["properties"]; nome = p["nome"]
            out["products"][prod][key][nome] = {"nivel": p["nivel"], "referencia": p["referencia"]}
            if nome not in out["geometries"] and f.get("geometry"):
                g = shape(f["geometry"]).simplify(0.004, preserve_topology=True)
                out["geometries"][nome] = {"uf": p["uf"], "geometry": json.loads(json.dumps(mapping(g)), parse_float=lambda x: round(float(x), 4))}
        print(prod, key, len(d["features"]), file=sys.stderr)
json.dump(out, open(sys.argv[1], "w"), ensure_ascii=False, separators=(",", ":"))
