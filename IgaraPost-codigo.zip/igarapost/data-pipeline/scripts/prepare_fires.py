"""Prepara os FOCOS DE CALOR do Programa Queimadas/INPE para o app.

Entradas (geradas por fetch_inpe.sh):
  raw/inpe/*.csv.filt  linhas dentro do retângulo da área do app (pontos do mapa)
  raw/inpe/*.csv.am    todas as linhas do estado do Amazonas (contagens municipais completas)
  out/cemaden_iis.json nomes oficiais dos municípios da área (para padronizar a grafia)

Saídas:
  out/fires_<SAT>.json   pontos do mapa, um arquivo por satélite (carregado sob demanda)
  out/fires_summary.json contagens mensais por município (município inteiro, mesmo a parte fora do
                         retângulo) e da região (retângulo), por satélite. Arquivo pequeno, usado no feed.

Cada linha = 1 foco (pixel com fogo ativo detectado), NÃO um incêndio e NÃO área queimada.
Satélites: AQUA_M-T (satélite de referência do INPE) e NPP-375 (VIIRS). Nunca somamos satélites."""
import csv, glob, json, sys, unicodedata
from collections import defaultdict
from datetime import datetime

RAW, OUT = sys.argv[1], sys.argv[2]
SATS = ("AQUA_M-T", "NPP-375")
BBOX = (-60.8, -4.8, -57.5, -1.6)
T0 = datetime(2026, 7, 1)
retrieved = open(f"{RAW}/retrieved.txt").read().strip()

def norm(s):
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn").upper().strip()

cem = json.load(open(f"{OUT}/cemaden_iis.json"))
official = {norm(n): n for n in cem["geometries"]}           # 25 municípios da área (grafia do Cemaden)
SMALL = {"da", "de", "do", "das", "dos", "e"}
def nice(s):
    n = norm(s)
    if n in official: return official[n]
    return " ".join(w.lower() if w.lower() in SMALL and i else w.capitalize() for i, w in enumerate(s.lower().split()))

def num(x):
    try:
        v = float(x); return None if v < -900 else v
    except ValueError:
        return None

# ---------------- pontos do mapa (retângulo) ----------------
rows = {s: [] for s in SATS}; munis = []; mid = {}; last = None
regional = {s: defaultdict(int) for s in SATS}
filt = sorted(glob.glob(f"{RAW}/focos_mensal_br_*.csv.filt"))
for f in filt:
    for r in csv.DictReader(open(f, encoding="utf-8")):
        s = r["satelite"]
        if s not in SATS: continue
        lat, lon = float(r["lat"]), float(r["lon"])
        if not (BBOX[0] <= lon <= BBOX[2] and BBOX[1] <= lat <= BBOX[3]): continue
        t = datetime.strptime(r["data_hora_gmt"], "%Y-%m-%d %H:%M:%S")
        if t < T0: continue
        last = max(last or t, t)
        m = nice(r["municipio"])
        if m not in mid: mid[m] = len(munis); munis.append(m)
        rows[s].append([round(lat, 4), round(lon, 4), int((t - T0).total_seconds() // 60), mid[m], num(r["frp"]), num(r["numero_dias_sem_chuva"]), num(r["risco_fogo"])])
        regional[s][t.strftime("%Y-%m")] += 1

meta = {"source": "INPE — Programa Queimadas, dados abertos (focos mensais, Brasil, todos os satélites)",
        "url": "https://dataserver-coids.inpe.br/queimadas/queimadas/focos/csv/mensal/Brasil/",
        "files": [f.split("/")[-1].replace(".filt", "") for f in filt], "retrieved": retrieved,
        "update": "manual", "t0": T0.strftime("%Y-%m-%dT%H:%MZ"), "last_detection": last.strftime("%Y-%m-%d %H:%M UTC"), "bbox": BBOX}
for sat in SATS:
    o = dict(meta, satellite=sat, municipios=munis, rows=rows[sat],
             fields=["lat", "lon", "minutos_desde_t0_UTC", "municipio_idx", "frp_MW", "dias_sem_chuva", "risco_fogo"])
    json.dump(o, open(f"{OUT}/fires_{sat}.json", "w"), ensure_ascii=False, separators=(",", ":"))

# ---------------- contagens municipais completas (estado do AM) ----------------
municipal = {n: {s: defaultdict(int) for s in SATS} for n in official.values()}
for f in sorted(glob.glob(f"{RAW}/focos_mensal_br_*.csv.am")):
    for r in csv.DictReader(open(f, encoding="utf-8")):
        s = r["satelite"]; n = norm(r["municipio"])
        if s not in SATS or n not in official: continue
        t = datetime.strptime(r["data_hora_gmt"], "%Y-%m-%d %H:%M:%S")
        if t < T0: continue
        municipal[official[n]][s][t.strftime("%Y-%m")] += 1
summary = dict(meta, months=sorted({m for s in SATS for m in regional[s]}),
               regional={"scope": "Retângulo da área do app (lon -60,8 a -57,5; lat -4,8 a -1,6)", "counts": {s: dict(regional[s]) for s in SATS}},
               municipal={"scope": "Município inteiro, pelo campo 'municipio' do INPE (estado do Amazonas)",
                          "counts": {n: {s: dict(v[s]) for s in SATS} for n, v in municipal.items()}})
json.dump(summary, open(f"{OUT}/fires_summary.json", "w"), ensure_ascii=False, indent=0)
print({s: len(v) for s, v in rows.items()}, "último foco", last, file=sys.stderr)
print("Autazes", {s: dict(municipal["Autazes"][s]) for s in SATS}, file=sys.stderr)
