"""IgaraPost — análise quantitativa NISAR L2 GCOV (retroespalhamento gamma0 calibrado).

STATUS (14/11/2026): testado com arquivos SINTÉTICOS (tests/test_gcov_pipeline.py), que imitam a estrutura
da especificação JPL D-102274. NÃO foi executado com os .h5 reais: o login Earthdata configurado foi
recusado. Não apresente resultados deste script como obtidos até rodá-lo com os arquivos reais.

Uso (credenciais em ~/.netrc: machine urs.earthdata.nasa.gov login USUARIO password SENHA):
    python3 scripts/process_nisar_gcov.py --a <URL ou caminho .h5 data A> --b <URL ou caminho .h5 data B> \
        --out out/nisar_gcov [--fires out/fires_NPP-375.json]

Etapas e parâmetros (todos gravados em gcov_summary.json):
 1. Leitura parcial da janela da área de estudo (HHHH, HVHV, mask, numberOfLooks), sem baixar o arquivo todo.
 2. Comparabilidade: mesma trilha, frame, direção, polarizações e CRID. Diferença de trilha/direção
    interrompe (use --force só para exploração); diferença de CRID gera aviso.
 3. Alinhamento: se as grades das duas datas diferirem, B é reprojetado na grade de A (média em potência linear).
 4. Máscara de qualidade: inválido se valor <= 0 ou NaN, se mask tiver valor em --invalid-mask (padrão 0 e 255;
    confira o significado na especificação do produto) ou se numberOfLooks < --min-looks.
 5. Multi-look em blocos (média em potência linear) para reduzir o speckle; um bloco só vale se tiver pelo menos
    --min-valid-frac de pixels válidos.
 6. dB = 10·log10(gamma0); diferença = dB(B) − dB(A) (razão logarítmica). Classes: queda < −thr, aumento > +thr.
 7. Conferência independente (opcional): proporção de focos de calor (INPE) em pixels de queda versus pontos
    aleatórios. Indica relação a investigar, não causa.
O resultado é "mudança observada no retroespalhamento". Não é área queimada, seca nem mapa de água.
"""
import argparse, datetime as dt, json, sys
from pathlib import Path
import numpy as np

GRID = "/science/LSAR/GCOV/grids/frequencyA"
IDENT = "/science/LSAR/identification"


def open_h5(src):
    import h5py
    if src.startswith("http"):
        import earthaccess  # usa ~/.netrc ou EARTHDATA_USERNAME/EARTHDATA_PASSWORD
        earthaccess.login(strategy="netrc")
        return h5py.File(earthaccess.open([src])[0], "r")
    return h5py.File(src, "r")


def ident(h):
    out = {}
    for k in ("trackNumber", "frameNumber", "orbitPassDirection", "zeroDopplerStartTime", "productVersion", "compositeReleaseId", "processingCenter"):
        p = f"{IDENT}/{k}"
        if p in h:
            v = h[p][()]
            if isinstance(v, bytes): v = v.decode()
            if isinstance(v, np.generic): v = v.item()
            out[k] = v
    out["polarizations"] = sorted(k for k in h[GRID].keys() if len(k) == 4 and k.isupper())
    return out


def epsg_of(h):
    d = h[f"{GRID}/projection"]
    for key in ("epsg_code", "epsg"):
        if key in d.attrs: return int(np.array(d.attrs[key]).ravel()[0])
    return int(d[()])


def read(src, aoi, invalid_mask, min_looks):
    from pyproj import Transformer
    h = open_h5(src)
    meta = ident(h); epsg = epsg_of(h)
    tr = Transformer.from_crs(4326, epsg, always_xy=True)
    xs, ys = tr.transform([aoi["west"], aoi["east"], aoi["west"], aoi["east"]], [aoi["south"], aoi["south"], aoi["north"], aoi["north"]])
    x = h[f"{GRID}/xCoordinates"][:]; y = h[f"{GRID}/yCoordinates"][:]
    c0, c1 = max(0, np.searchsorted(x, min(xs)) - 1), min(len(x), np.searchsorted(x, max(xs)) + 1)
    yd = y[::-1] if y[0] > y[-1] else y
    r0, r1 = np.searchsorted(yd, min(ys)), np.searchsorted(yd, max(ys))
    if y[0] > y[-1]: r0, r1 = len(y) - r1, len(y) - r0
    rs, cs = slice(max(r0 - 1, 0), min(r1 + 1, len(y))), slice(c0, c1)
    valid = np.ones((rs.stop - rs.start, cs.stop - cs.start), bool)
    reasons = {}
    if f"{GRID}/mask" in h:
        mk = h[f"{GRID}/mask"][rs, cs]
        bad = np.isin(mk, invalid_mask); reasons["mask"] = int(bad.sum()); valid &= ~bad
    if f"{GRID}/numberOfLooks" in h and min_looks > 0:
        nl = h[f"{GRID}/numberOfLooks"][rs, cs]
        bad = ~(nl >= min_looks); reasons["poucos_looks"] = int((bad & valid).sum()); valid &= ~bad
    data = {}
    for pol in ("HHHH", "HVHV"):
        if pol not in meta["polarizations"]: continue
        v = h[f"{GRID}/{pol}"][rs, cs].astype(np.float32)
        bad = ~np.isfinite(v) | (v <= 0)
        reasons[f"valor_invalido_{pol}"] = int((bad & valid).sum())
        v[bad | ~valid] = np.nan
        data[pol] = v
    dx = float(x[1] - x[0]); dy = float(y[1] - y[0])
    transform = (dx, 0.0, float(x[cs.start]) - dx / 2, 0.0, dy, float(y[rs.start]) - dy / 2)
    meta.update(epsg=epsg, shape=list(valid.shape), pixel_m=[dx, dy], invalid_pixels=reasons, valid_frac=round(float(valid.mean()), 4))
    h.close()
    return data, meta, transform


def align(arr, src_t, src_epsg, dst_shape, dst_t, dst_epsg):
    from rasterio.warp import reproject, Resampling
    from rasterio.transform import Affine
    out = np.full(dst_shape, np.nan, np.float32)
    reproject(arr, out, src_transform=Affine(*src_t), src_crs=f"EPSG:{src_epsg}", src_nodata=np.nan, dst_transform=Affine(*dst_t), dst_crs=f"EPSG:{dst_epsg}", dst_nodata=np.nan, resampling=Resampling.average)
    return out


def multilook(a, n, min_valid_frac):
    H, W = (a.shape[0] // n) * n, (a.shape[1] // n) * n
    b = a[:H, :W].reshape(H // n, n, W // n, n)
    cnt = np.isfinite(b).sum(axis=(1, 3))
    with np.errstate(invalid="ignore"):
        m = np.nanmean(b, axis=(1, 3))
    m[cnt < min_valid_frac * n * n] = np.nan
    return m


def save_tif(path, arr, t, epsg):
    import rasterio
    from rasterio.transform import Affine
    with rasterio.open(path, "w", driver="GTiff", height=arr.shape[0], width=arr.shape[1], count=1, dtype="float32", crs=f"EPSG:{epsg}", transform=Affine(*t), nodata=np.nan, compress="deflate") as d:
        d.write(arr.astype(np.float32), 1)


def to_png_4326(arr, t, epsg, path, aoi, colorize, res=1 / 900):
    from rasterio.warp import reproject, Resampling
    from rasterio.transform import Affine, from_origin
    from PIL import Image
    W = int((aoi["east"] - aoi["west"]) / res); H = int((aoi["north"] - aoi["south"]) / res)
    dst = np.full((H, W), np.nan, np.float32)
    reproject(arr.astype(np.float32), dst, src_transform=Affine(*t), src_crs=f"EPSG:{epsg}", src_nodata=np.nan, dst_transform=from_origin(aoi["west"], aoi["north"], res, res), dst_crs="EPSG:4326", dst_nodata=np.nan, resampling=Resampling.bilinear)
    Image.fromarray(colorize(dst), "RGBA").save(path, optimize=True)


def gray_db(lo, hi):
    def f(db):
        v = np.clip(np.nan_to_num((db - lo) / (hi - lo)), 0, 1); g = (v * 255).astype(np.uint8)
        return np.dstack([g, g, g, np.where(np.isfinite(db), 255, 0).astype(np.uint8)])
    return f


def diverging(lim):
    """Queda = laranja; aumento = azul; sem dados = cinza; opacidade proporcional à magnitude."""
    def f(d):
        v = np.clip(np.nan_to_num(d) / lim, -1, 1)
        rgb = np.where(v[..., None] < 0, np.array([230, 110, 20], np.uint8), np.array([30, 120, 220], np.uint8))
        a = np.where(np.isfinite(d), (np.abs(v) * 230).clip(0, 230), 90).astype(np.uint8)
        rgb = np.where(np.isfinite(d)[..., None], rgb, np.array([128, 128, 128], np.uint8))
        return np.dstack([rgb.astype(np.uint8), a])
    return f


def fire_check(fires_path, d, t, epsg, thr, date_a, date_b, seed=42):
    """Proporção de focos em pixels de queda (raio de 1 pixel) versus pontos aleatórios em pixels válidos."""
    from pyproj import Transformer
    F = json.load(open(fires_path)); t0 = dt.datetime(2026, 7, 1, tzinfo=dt.timezone.utc)
    tr = Transformer.from_crs(4326, epsg, always_xy=True)
    a, b = dt.datetime.fromisoformat(date_a), dt.datetime.fromisoformat(date_b)
    drop = d < -thr; valid = np.isfinite(d)
    pts = []
    for r in F["rows"]:
        ts = t0 + dt.timedelta(minutes=r[2])
        if not (a <= ts <= b): continue
        x, y = tr.transform(r[1], r[0]); col = int((x - t[2]) / t[0]); row = int((y - t[5]) / t[4])
        if 0 <= row < d.shape[0] and 0 <= col < d.shape[1] and valid[row, col]: pts.append((row, col))
    if not pts: return {"n_fires": 0}
    from scipy.ndimage import binary_dilation
    near = binary_dilation(drop, np.ones((3, 3), bool))
    p = np.array(pts); ff = float(near[p[:, 0], p[:, 1]].mean())
    idx = np.flatnonzero(valid.ravel()); pick = np.random.default_rng(seed).choice(idx, min(20000, idx.size), replace=False)
    return {"satellite": F.get("satellite"), "n_fires": len(pts), "frac_fires_near_drop": round(ff, 3), "frac_random_near_drop": round(float(near.ravel()[pick].mean()), 3),
            "note": "Relação a investigar; não estabelece causa."}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--a", required=True); ap.add_argument("--b", required=True); ap.add_argument("--out", default="out/nisar_gcov")
    ap.add_argument("--aoi", default="-60.35,-3.85,-58.85,-2.85")
    ap.add_argument("--looks", type=int, default=5, help="tamanho do bloco do multi-look (pixels)")
    ap.add_argument("--min-looks", type=float, default=1.0, help="numberOfLooks mínimo por pixel")
    ap.add_argument("--invalid-mask", default="0,255", help="valores da camada mask tratados como inválidos")
    ap.add_argument("--min-valid-frac", type=float, default=0.5, help="fração mínima de pixels válidos num bloco")
    ap.add_argument("--thr", type=float, default=3.0, help="limiar de mudança em dB")
    ap.add_argument("--fires", help="arquivo fires_<SAT>.json do app para a conferência independente")
    ap.add_argument("--force", action="store_true", help="processa mesmo com trilha/direção diferentes (só exploração)")
    a = ap.parse_args()
    w, s, e, n = map(float, a.aoi.split(",")); aoi = dict(west=w, south=s, east=e, north=n)
    inv = [int(v) for v in a.invalid_mask.split(",") if v.strip()]
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    A, ma, ta = read(a.a, aoi, inv, a.min_looks); B, mb, tb = read(a.b, aoi, inv, a.min_looks)
    checks = {
        "mesma_trilha": ma.get("trackNumber") == mb.get("trackNumber"), "mesmo_frame": ma.get("frameNumber") == mb.get("frameNumber"),
        "mesma_direcao": ma.get("orbitPassDirection") == mb.get("orbitPassDirection"), "mesmo_crid": ma.get("compositeReleaseId") == mb.get("compositeReleaseId"),
        "polarizacoes_comuns": sorted(set(A) & set(B)), "mesma_grade": ta == tb and ma["epsg"] == mb["epsg"] and ma["shape"] == mb["shape"],
    }
    warnings = []
    if not (checks["mesma_trilha"] and checks["mesma_direcao"]):
        msg = "Trilha ou direção diferentes: geometria de visada diferente, retroespalhamento não diretamente comparável."
        if not a.force: sys.exit(f"ERRO: {msg} Use --force só para exploração.")
        warnings.append(msg)
    if not checks["mesmo_crid"]: warnings.append("Versões de processamento (CRID) diferentes: diferenças podem vir do processamento.")
    if not checks["mesma_grade"]:
        for pol in list(B): B[pol] = align(B[pol], tb, mb["epsg"], A[pol].shape, ta, ma["epsg"])
        warnings.append("Grades diferentes: data B reprojetada na grade da data A (média em potência linear).")
    L = a.looks; tl = (ta[0] * L, 0.0, ta[2], 0.0, ta[4] * L, ta[5]); px_km2 = abs(tl[0] * tl[4]) / 1e6
    res = {"status": "processado", "a": ma, "b": mb, "checks": checks, "warnings": warnings, "aoi": aoi,
           "params": {"looks": L, "min_looks": a.min_looks, "invalid_mask": inv, "min_valid_frac": a.min_valid_frac, "threshold_db": a.thr, "pixel_out_m": [tl[0], tl[4]]},
           "method": "log-ratio dB(B)-dB(A) sobre gamma0 calibrado, multi-look em blocos, máscara de qualidade", "generated": dt.datetime.now(dt.timezone.utc).isoformat(timespec="minutes"), "stats": {}}
    for pol in checks["polarizacoes_comuns"]:
        pa, pb = multilook(A[pol], L, a.min_valid_frac), multilook(B[pol], L, a.min_valid_frac)
        dba, dbb = 10 * np.log10(pa), 10 * np.log10(pb); d = dbb - dba
        lo, hi = (-25, -5) if pol == "HVHV" else (-18, 2)
        for nm, arr in (("A_dB", dba), ("B_dB", dbb), ("diff_dB", d)): save_tif(out / f"{pol}_{nm}.tif", arr, tl, ma["epsg"])
        to_png_4326(dba, tl, ma["epsg"], out / f"{pol}_A.png", aoi, gray_db(lo, hi))
        to_png_4326(dbb, tl, ma["epsg"], out / f"{pol}_B.png", aoi, gray_db(lo, hi))
        to_png_4326(d, tl, ma["epsg"], out / f"{pol}_diff.png", aoi, diverging(2 * a.thr))
        v = np.isfinite(d)
        st = {"valid_km2": round(float(v.sum() * px_km2), 2), "nodata_frac": round(float(1 - v.mean()), 4),
              "median_db_A": round(float(np.nanmedian(dba)), 2), "median_db_B": round(float(np.nanmedian(dbb)), 2), "median_diff_db": round(float(np.nanmedian(d)), 2),
              "drop_km2": round(float((d < -a.thr).sum() * px_km2), 2), "rise_km2": round(float((d > a.thr).sum() * px_km2), 2)}
        if pol == "HVHV" and np.nanmedian(dba) < -26: warnings.append("HV mediano abaixo de −26 dB: perto do nível de ruído; interprete com cautela.")
        if a.fires and pol == "HVHV":
            st["fire_check"] = fire_check(a.fires, d, tl, ma["epsg"], a.thr, str(ma.get("zeroDopplerStartTime", ""))[:19] + "+00:00" if ma.get("zeroDopplerStartTime") else "2026-07-01T00:00:00+00:00",
                                          str(mb.get("zeroDopplerStartTime", ""))[:19] + "+00:00" if mb.get("zeroDopplerStartTime") else "2026-12-31T00:00:00+00:00")
        res["stats"][pol] = st
    json.dump(res, open(out / "gcov_summary.json", "w"), ensure_ascii=False, indent=1, default=str)
    print(json.dumps({"checks": checks, "warnings": warnings, "stats": res["stats"]}, ensure_ascii=False, indent=1, default=str))


if __name__ == "__main__":
    main()
