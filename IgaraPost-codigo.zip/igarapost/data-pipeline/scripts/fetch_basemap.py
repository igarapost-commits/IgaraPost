"""Monta mosaicos estáticos (Web Mercator) de camadas públicas do NASA GIBS para a área do app,
para que o mapa funcione sem servidor de tiles externo (e com pouca internet).
Camada: BlueMarble_NextGeneration (z8, imagem de satélite composta, NASA). Saída: imagens + bounds.json (cantos em lat/lon dos mosaicos)."""
import io, json, math, sys, urllib.request
from pathlib import Path
from PIL import Image
OUT = Path(sys.argv[1]); OUT.mkdir(parents=True, exist_ok=True)
W, S, E, N = -61.0, -5.0, -57.3, -1.4
G = "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/{l}/default/{tms}/{z}/{y}/{x}.{ext}"
# Testado em 14/11/2026: OSM_Land_Water_Map vem uniforme (sem rios) nesta área e as camadas
# Reference_* devolvem tiles de erro; por isso só o Blue Marble é usado. Limites e nomes são
# desenhados pelo app (geometrias municipais do Cemaden + lista de localidades).
LAYERS = [("BlueMarble_NextGeneration", 8, "jpeg", "GoogleMapsCompatible_Level8", "bluemarble")]
def txy(lon, lat, z):
    n = 2 ** z; return int((lon + 180) / 360 * n), int((1 - math.asinh(math.tan(math.radians(lat))) / math.pi) / 2 * n)
def tile2ll(x, y, z):
    n = 2 ** z; return x / n * 360 - 180, math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * y / n))))
bounds = {}
for layer, z, ext, tms, name in LAYERS:
    x0, y0 = txy(W, N, z); x1, y1 = txy(E, S, z)
    im = Image.new("RGBA", ((x1 - x0 + 1) * 256, (y1 - y0 + 1) * 256))
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            raw = None
            for _ in range(3):  # o GIBS responde 500 para alguns tiles vazios das camadas de referência
                try: raw = urllib.request.urlopen(G.format(l=layer, tms=tms, z=z, y=y, x=x, ext=ext), timeout=60).read(); break
                except Exception: pass
            if raw: im.paste(Image.open(io.BytesIO(raw)).convert("RGBA"), ((x - x0) * 256, (y - y0) * 256))
    w, n = tile2ll(x0, y0, z); e, s = tile2ll(x1 + 1, y1 + 1, z)
    if ext == "jpeg": im.convert("RGB").save(OUT / f"{name}.jpg", quality=78, optimize=True); fn = f"{name}.jpg"
    else: im.save(OUT / f"{name}.png", optimize=True); fn = f"{name}.png"
    bounds[name] = dict(file=fn, layer=layer, zoom=z, bounds=[[s, w], [n, e]])
    print(name, im.size, file=sys.stderr)
json.dump(bounds, open(OUT / "basemap.json", "w"), indent=1)
