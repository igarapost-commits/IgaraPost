"""Gera out/manifest.json: para cada fonte, quando foi obtida, que período representa, cobertura,
escala e modo de atualização. O app mostra essas informações na tela "Sobre os dados"."""
import json, os, sys, datetime as dt
OUT = sys.argv[1]
def mtime(p): return dt.datetime.fromtimestamp(os.path.getmtime(p), dt.timezone.utc).strftime("%Y-%m-%dT%H:%MZ")
fs = json.load(open(f"{OUT}/fires_summary.json")); ni = json.load(open(f"{OUT}/nisar/nisar_summary.json"))
cem = json.load(open(f"{OUT}/cemaden_iis.json")); months = sorted(cem["products"]["iis3"])
m = {
  "generated": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%MZ"),
  "update_mode": "manual (pipeline em data-pipeline/run_all.sh); o app não atualiza sozinho",
  "sources": [
    {"id": "inpe", "name": "INPE, Programa Queimadas: focos de calor", "url": "https://data.inpe.br/queimadas/dados-abertos/",
     "retrieved": fs["retrieved"], "period": f"2026-07-01 a {fs['last_detection']}", "coverage": "Mapa: retângulo lon -60,8 a -57,5, lat -4,8 a -1,6. Contagens municipais: municípios do Amazonas inteiros.",
     "scale": "ponto (pixel de 1 km no AQUA_M-T, 375 m no NPP-375)", "update": "manual"},
    {"id": "cemaden", "name": "Cemaden, Alerta Secas: Índice Integrado de Secas (IIS-1, IIS-3, IIS-6)", "url": "https://alertasecas.cemaden.gov.br/",
     "retrieved": mtime(f"{OUT}/cemaden_iis.json"), "period": f"meses de referência {months[0]} a {months[-1]}", "coverage": f"{len(cem['geometries'])} municípios do entorno de Manaus",
     "scale": "município, mensal", "update": "manual"},
    {"id": "nisar", "name": "NASA/ISRO NISAR, L2 GCOV (prévias browse), via ASF", "url": "https://search.asf.alaska.edu/",
     "retrieved": mtime(f"{OUT}/nisar/nisar_summary.json"), "period": f"{len(ni['series'])} passagens de {ni['series'][0]['date']} a {ni['series'][-1]['date']}; par comparado {ni['pair'][0]} e {ni['pair'][1]}",
     "coverage": f"recorte lon {ni['aoi']['west']} a {ni['aoi']['east']}, lat {ni['aoi']['south']} a {ni['aoi']['north']}", "scale": "grade de ~170 m", "update": "manual"},
    {"id": "osm", "name": "OpenStreetMap: localidades, rios e vias", "url": "https://www.openstreetmap.org/copyright",
     "retrieved": mtime(f"{OUT}/osm/places.json"), "period": "estado do mapa colaborativo na data de obtenção", "coverage": "retângulo da área do app", "scale": "vetorial simplificado", "update": "manual"},
    {"id": "bluemarble", "name": "NASA Blue Marble Next Generation (GIBS)", "url": "https://earthdata.nasa.gov/gibs",
     "retrieved": mtime(f"{OUT}/basemap/bluemarble.jpg"), "period": "composição de imagens de 2004", "coverage": "área do app", "scale": "~600 m", "update": "fixo"},
  ],
}
json.dump(m, open(f"{OUT}/manifest.json", "w"), ensure_ascii=False, indent=1)
print(json.dumps(m, ensure_ascii=False, indent=1)[:600])
