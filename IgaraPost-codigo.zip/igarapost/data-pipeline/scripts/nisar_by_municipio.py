"""Recorta a camada de mudança NISAR (segmentação das prévias browse) por município.

Para cada município do Cemaden que cruza a área do estudo NISAR, calcula: área do município dentro
da área do estudo, área com dados nas duas datas e as áreas de cada classe da SEGMENTAÇÃO
(escuro→claro, claro→escuro, escuro nas duas). Os números descrevem a segmentação das imagens
de prévia, não área de água, queimada ou seca. Saída: campo "by_municipio" em nisar_summary.json."""
import json, math, sys
import numpy as np
from PIL import Image, ImageDraw

OUT = sys.argv[1]
S = json.load(open(f"{OUT}/nisar/nisar_summary.json")); aoi = S["aoi"]; res = S["grid_res_deg"]
C = json.load(open(f"{OUT}/cemaden_iis.json"))
c = np.asarray(Image.open(f"{OUT}/nisar/nisar_change_dark.png").convert("RGBA")).astype(int)
H, W = c.shape[:2]
def is_(rgb): return (c[..., 0] == rgb[0]) & (c[..., 1] == rgb[1]) & (c[..., 2] == rgb[2]) & (c[..., 3] > 0)
lost, gain, stay, nodata = is_((230, 120, 20)), is_((40, 200, 230)), is_((30, 90, 160)), is_((128, 128, 128))
px_km2 = S["px_km2"]
out = {}
for nome, g in C["geometries"].items():
    geom = g["geometry"]; polys = [geom["coordinates"]] if geom["type"] == "Polygon" else geom["coordinates"]
    mask_img = Image.new("L", (W, H), 0); d = ImageDraw.Draw(mask_img)
    for poly in polys:
        for k, ring in enumerate(poly):
            pts = [((lon - aoi["west"]) / res, (aoi["north"] - lat) / res) for lon, lat in ring]
            d.polygon(pts, fill=255 if k == 0 else 0)
    m = np.asarray(mask_img) > 0
    if m.sum() == 0: continue
    valid = m & ~nodata
    out[nome] = dict(in_study_km2=round(float(m.sum() * px_km2), 1), valid_km2=round(float(valid.sum() * px_km2), 1),
                     bright_to_dark_km2=round(float((gain & m).sum() * px_km2), 1), dark_to_bright_km2=round(float((lost & m).sum() * px_km2), 1),
                     dark_both_km2=round(float((stay & m).sum() * px_km2), 1))
S["by_municipio"] = out
S["by_municipio_note"] = "Áreas da segmentação claro/escuro das prévias (browse), por município, só a parte dentro do recorte do estudo."
json.dump(S, open(f"{OUT}/nisar/nisar_summary.json", "w"), ensure_ascii=False, indent=1)
for k, v in out.items(): print(k, v)
