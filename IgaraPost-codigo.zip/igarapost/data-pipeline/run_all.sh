#!/bin/bash
# Refaz todos os dados do app a partir das fontes (execute dentro de data-pipeline/). Requer internet.
# Atualização MANUAL: rode de novo para trazer dados mais recentes e gere um novo build do app.
# A análise NISAR calibrada (.h5) é separada e exige login Earthdata (~/.netrc); veja docs/NISAR_METODO.md.
set -e
mkdir -p raw/browse raw/inpe raw/osm out/osm ../docs
# 1) Cemaden: índice de seca municipal (usado também para padronizar nomes)
python3 -I scripts/fetch_cemaden.py out/cemaden_iis.json
# 2) INPE: focos (pontos da área do app + contagens municipais completas do Amazonas)
scripts/fetch_inpe.sh raw/inpe
python3 -I scripts/prepare_fires.py raw/inpe out
# 3) NISAR: inventário GCOV, prévias browse da trilha 140/frame 90, processamento experimental
curl -sS "https://api.daac.asf.alaska.edu/services/search/param?platform=NISAR&processingLevel=GCOV&intersectsWith=POINT(-60.02%20-3.10)&maxResults=500&output=jsonlite" -o raw/asf_gcov_manaus.json
curl -sS "https://api.daac.asf.alaska.edu/services/search/param?platform=NISAR&processingLevel=GCOV&intersectsWith=POLYGON((-60.35%20-3.85,-58.85%20-3.85,-58.85%20-2.85,-60.35%20-2.85,-60.35%20-3.85))&maxResults=1000&output=jsonlite" -o raw/asf_gcov_aoi.json
python3 -I scripts/download_browse.py raw/asf_gcov_manaus.json raw/browse 140 90
python3 -I scripts/fetch_basemap.py out/basemap
python3 -I scripts/process_nisar_browse.py raw/browse out/nisar
python3 -I scripts/fire_radar_overlap.py out
python3 -I scripts/nisar_by_municipio.py out
python3 -I scripts/nisar_inventory.py raw/asf_gcov_aoi.json out ../docs
# 4) OpenStreetMap (Overpass): localidades, rios e vias para o mapa offline e a busca
H=https://maps.mail.ru/osm/tools/overpass/api/interpreter   # espelho Overpass que respondeu em 14/11/2026
B="(-4.8,-60.8,-1.6,-57.5)"
curl -sS -m 200 --data-urlencode "data=[out:json][timeout:120];node[\"place\"~\"^(city|town|village|hamlet|locality)$\"][\"name\"]$B;out body;" $H -o raw/osm/places.json
curl -sS -m 200 --data-urlencode "data=[out:json][timeout:180];way[\"waterway\"=\"river\"]$B;out geom;" $H -o raw/osm/rivers.json
curl -sS -m 200 --data-urlencode "data=[out:json][timeout:180];way[\"highway\"~\"^(trunk|primary|secondary)$\"]$B;out geom;" $H -o raw/osm/roads.json
python3 -I scripts/prepare_osm.py raw/osm out/osm "$(date -u +%Y-%m-%d)"
# 5) Manifesto (origem, período e atualização de cada fonte) e cópia para o app
python3 -I scripts/make_manifest.py out
D=../app/public/data; mkdir -p $D/nisar $D/basemap $D/osm
cp out/cemaden_iis.json out/fires_*.json out/manifest.json $D/
cp out/nisar/*.webp out/nisar/nisar_change_dark.png out/nisar/nisar_summary.json $D/nisar/
cp out/basemap/* $D/basemap/; cp out/osm/*.json $D/osm/
echo "dados atualizados; gere um novo build do app"
