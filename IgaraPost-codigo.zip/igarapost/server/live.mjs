// IgaraPost — tempo real do SARS: focos de fogo ativo da NASA FIRMS (VIIRS NOAA-20 e NOAA-21).
//
// O servidor lê os CSV sem chave da NASA FIRMS (América do Sul, 48 h) a cada LIVE_POLL_MS,
// guarda na memória os focos das últimas 48 h e os entrega ao app:
//   GET /api/live/status            estado da fonte
//   GET /api/live/fires?since=ISO   focos (todos, ou só os detectados depois de "since")
//   GET /api/live/stream            Server-Sent Events: "snapshot" ao conectar, "fires" a cada foco novo,
//                                   "status" a cada 25 s (mantém a conexão viva através de proxies)
//
// Variáveis: LIVE=0 desliga; LIVE_POLL_MS (padrão 600000); LIVE_CSV = lista de CSV separada por vírgula
// (aceita {AAAAMMDD}, trocado por hoje e ontem em UTC, para fontes diárias como a do INPE);
// LIVE_BBOX=oeste,sul,leste,norte para guardar só uma região.

const WINDOW_MS = 48 * 3600_000;
const POLL_MS = Number(process.env.LIVE_POLL_MS || 600_000);
const CSV = (process.env.LIVE_CSV || "https://firms.modaps.eosdis.nasa.gov/data/active_fire/noaa-20-viirs-c2/csv/J1_VIIRS_C2_South_America_48h.csv,https://firms.modaps.eosdis.nasa.gov/data/active_fire/noaa-21-viirs-c2/csv/J2_VIIRS_C2_South_America_48h.csv").split(",");
const BBOX = (process.env.LIVE_BBOX || "").split(",").map(Number);
const HAS_BBOX = BBOX.length === 4 && BBOX.every(Number.isFinite);
export const SOURCE = "NASA FIRMS (VIIRS NOAA-20 e NOAA-21)";
const SAT = { N: "VIIRS Suomi NPP", N20: "VIIRS NOAA-20", N21: "VIIRS NOAA-21", 1: "VIIRS NOAA-20", Terra: "MODIS Terra", Aqua: "MODIS Aqua" };
const firmsTime = (d, t) => { const x = String(t || "0").replace(":", "").trim().padStart(4, "0"); return Date.parse(`${String(d).trim()}T${x.slice(0, 2)}:${x.slice(2, 4)}:00Z`); };

/* ------------------------------ leitura do CSV ------------------------------ */
const COLS = { id: ["id", "foco_id", "id_foco"], lat: ["lat", "latitude"], lon: ["lon", "longitude"], t: ["data_hora_gmt", "datahora", "data_hora", "data_pas"], date: ["acq_date"], time: ["acq_time"], sat: ["satelite", "satellite"], mun: ["municipio"], uf: ["estado", "uf"], frp: ["frp"] };
function splitLine(line) {
  const out = [];
  let cur = "", q = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (q) { if (c === '"' && line[i + 1] === '"') { cur += '"'; i++; } else if (c === '"') q = false; else cur += c; }
    else if (c === '"') q = true;
    else if (c === ",") { out.push(cur); cur = ""; }
    else cur += c;
  }
  out.push(cur);
  return out;
}
const parseGmt = (s) => { const v = (s || "").trim(); return v ? Date.parse(/[zZ]|[+-]\d\d:?\d\d$/.test(v) ? v : v.replace(" ", "T") + "Z") : NaN; };
const nice = (s) => s ? s.toLowerCase().replace(/(^|[\s-])(\p{L})/gu, (m, a, b) => a + b.toUpperCase()).replace(/\b(Da|De|Do|Das|Dos|E)\b/g, (w) => w.toLowerCase()) : undefined;

/** Lê o CSV pelo nome das colunas. Linhas sem coordenada ou data válida são ignoradas. */
export function parseCsv(text) {
  const lines = text.replace(/^﻿/, "").split(/\r?\n/).filter((l) => l.trim());
  if (lines.length < 2) return [];
  const head = splitLine(lines[0]).map((h) => h.trim().toLowerCase());
  const ix = Object.fromEntries(Object.entries(COLS).map(([k, names]) => [k, head.findIndex((h) => names.includes(h))]));
  if (ix.lat < 0 || ix.lon < 0 || (ix.t < 0 && ix.date < 0)) throw new Error("CSV sem as colunas de latitude, longitude e data");
  const out = [];
  for (let i = 1; i < lines.length; i++) {
    const r = splitLine(lines[i]);
    const lat = Number(r[ix.lat]), lon = Number(r[ix.lon]), t = ix.t >= 0 ? parseGmt(r[ix.t]) : firmsTime(r[ix.date], ix.time >= 0 ? r[ix.time] : "0000");
    if (!Number.isFinite(lat) || !Number.isFinite(lon) || !Number.isFinite(t)) continue;
    if (HAS_BBOX && (lon < BBOX[0] || lat < BBOX[1] || lon > BBOX[2] || lat > BBOX[3])) continue;
    const satRaw = (ix.sat >= 0 && r[ix.sat]?.trim()) || "?";
    const sat = SAT[satRaw] || satRaw;
    const frp = ix.frp >= 0 ? Number(r[ix.frp]) : NaN;
    out.push({
      id: (ix.id >= 0 && r[ix.id]?.trim()) || `${sat}:${lat.toFixed(4)}:${lon.toFixed(4)}:${t}`,
      lat: Math.round(lat * 1e5) / 1e5, lon: Math.round(lon * 1e5) / 1e5, t, sat,
      mun: ix.mun >= 0 ? nice(r[ix.mun]?.trim()) : undefined, uf: ix.uf >= 0 ? nice(r[ix.uf]?.trim()) : undefined,
      frp: Number.isFinite(frp) && frp > -900 ? frp : null,
    });
  }
  return out;
}

/* ------------------------------ estado e consulta ------------------------------ */
const fires = new Map(); // id -> foco
const clients = new Set();
let sourceAt = null; // última leitura com sucesso
let lastError = null;
let timer = null;

const ymd = (t) => new Date(t).toISOString().slice(0, 10).replace(/-/g, "");
const prune = (now = Date.now()) => { for (const [id, f] of fires) if (f.t < now - WINDOW_MS) fires.delete(id); };
const list = (since = 0) => [...fires.values()].filter((f) => f.t > since).sort((a, b) => b.t - a.t);

/** Lê a fonte (hoje e ontem, em UTC) e avisa os clientes conectados sobre os focos novos. */
export async function pollOnce(fetchText = defaultFetch) {
  const now = Date.now();
  const urls = CSV.flatMap((u) => (u.includes("{AAAAMMDD}") ? [ymd(now), ymd(now - 864e5)].map((d) => u.replace("{AAAAMMDD}", d)) : [u.trim()]));
  const res = await Promise.allSettled(urls.map(async (u) => parseCsv(await fetchText(u))));
  const ok = res.filter((r) => r.status === "fulfilled");
  if (!ok.length) {
    lastError = `Fonte indisponível: ${res[0].reason?.message || res[0].reason}`;
    broadcast("status", statusOut());
    return { added: 0, error: lastError };
  }
  const fresh = [];
  for (const r of ok) for (const f of r.value) if (f.t >= now - WINDOW_MS && !fires.has(f.id)) { fires.set(f.id, f); fresh.push(f); }
  prune(now);
  sourceAt = new Date().toISOString();
  lastError = null;
  if (fresh.length) broadcast("fires", { fires: fresh, sourceAt, source: SOURCE });
  else broadcast("status", statusOut());
  return { added: fresh.length };
}
async function defaultFetch(url) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 60_000);
  try {
    const r = await fetch(url, { signal: ctl.signal, headers: { "User-Agent": "IgaraPost/0.3.3 (monitoramento colaborativo; UEA)" } });
    if (r.status === 404) return ""; // arquivo do dia ainda não criado
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.text();
  } finally {
    clearTimeout(t);
  }
}

export function startLive() {
  if (process.env.LIVE === "0" || timer) return;
  const tick = () => pollOnce().catch((e) => { lastError = String(e.message || e); });
  tick();
  timer = setInterval(tick, POLL_MS);
  timer.unref?.();
  const hb = setInterval(() => broadcast("status", statusOut()), 25_000);
  hb.unref?.();
}

/** Para testes: injeta focos como se tivessem vindo da fonte. */
export function _inject(list_, at = new Date().toISOString()) {
  const fresh = list_.filter((f) => !fires.has(f.id));
  fresh.forEach((f) => fires.set(f.id, f));
  sourceAt = at;
  if (fresh.length) broadcast("fires", { fires: fresh, sourceAt, source: SOURCE });
}

const statusOut = () => ({ sourceAt, error: lastError || undefined, count: fires.size, pollMs: POLL_MS, source: SOURCE, enabled: process.env.LIVE !== "0" });

function broadcast(event, data) {
  const msg = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of clients) res.write(msg);
}

/* ------------------------------ rotas ------------------------------ */
export function liveStatus() { return statusOut(); }
export function liveFires(query) {
  const s = Date.parse(query.get("since") || "");
  prune();
  return { fires: list(Number.isFinite(s) ? s : 0), sourceAt: sourceAt || undefined, source: SOURCE, error: lastError || undefined };
}
/** Abre o canal SSE. `cors` são os cabeçalhos CORS do servidor principal. */
export function liveStream(req, res, cors) {
  res.writeHead(200, { "Content-Type": "text/event-stream; charset=utf-8", "Cache-Control": "no-store", Connection: "keep-alive", "X-Accel-Buffering": "no", ...cors });
  res.write("retry: 15000\n\n");
  prune();
  res.write(`event: snapshot\ndata: ${JSON.stringify({ fires: list(), sourceAt: sourceAt || undefined, source: SOURCE, error: lastError || undefined })}\n\n`);
  clients.add(res);
  req.on("close", () => clients.delete(res));
}
