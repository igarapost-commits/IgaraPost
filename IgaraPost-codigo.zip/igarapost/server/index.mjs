// IgaraPost — servidor da rede compartilhada (protótipo).
// Node 22+ sem dependências externas: node:http + node:sqlite (SQLite embutido no Node).
//
//   node server/index.mjs                       (porta 8787, banco server/igarapost.db)
//   PORT=8787 DB=/caminho/igarapost.db MODERATORS=ana,joao GEO=app/public/data/cemaden_iis.json node server/index.mjs
//   TRUST_PROXY=1 quando o servidor roda atrás do proxy de uma hospedagem (usa o IP do X-Forwarded-For nos limites)
//
// Segurança do protótipo: senhas com scrypt + sal; sessões por token aleatório (guardado como hash
// SHA-256); autoria verificada no servidor em toda edição/exclusão; limite de tentativas de login.
// Use sempre HTTPS em produção (ex.: atrás de um proxy reverso ou de uma plataforma que forneça TLS).
import http from "node:http";
import { DatabaseSync } from "node:sqlite";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { liveFires, liveStatus, liveStream, startLive } from "./live.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 8787);
const DB_PATH = process.env.DB || path.join(HERE, "igarapost.db");
const MODERATORS = new Set((process.env.MODERATORS || "").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean));
const TRUST_PROXY = process.env.TRUST_PROXY === "1";
const GEO_PATH = process.env.GEO || path.join(HERE, "..", "app", "public", "data", "cemaden_iis.json");
const VERSION = "8.0.0";
// Secas e cheias saíram do app na 0.5.0: "falta_chuva", "cheia" e "reducao_agua" não são mais aceitas e os relatos
// antigos dessas categorias deixam de aparecer no feed. "impacto" vem da 0.2 e continua aceito para relatos antigos.
const CATEGORIES = new Set(["fumaca", "queimada", "enchente", "outro", "impacto"]);
const REMOVED_CATEGORIES = ["falta_chuva", "cheia", "reducao_agua"];
const RADAR_STATUS = new Set(["no_radar", "fora_do_radar", "nao_verificado", "confirmado"]);
const AREA = { s: -34, n: 6, w: -75, e: -34 }; // Brasil (mesma regra do app)
const COMMUNITIES = new Set(["manaus-entorno", "careiro-varzea", "autazes", "iranduba", "fumaca-saude", "rios-enchente", "radar-nisar"]);
// publicações geradas no app a partir de dados (iguais em todos os aparelhos): aceitam comentários
const DATA_POST_ID = /^(inpe|nisar|exp)-[a-z0-9-]{1,80}$/;
const REPORT_REASONS = new Set(["Informação falsa ou enganosa", "Local ou data errados", "Expõe dados pessoais ou de terceiros", "Ofensivo, discriminatório ou assédio", "Propaganda ou spam"]);

/* ------------------------------ banco ------------------------------ */
const db = new DatabaseSync(DB_PATH);
db.exec(`
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY, handle TEXT UNIQUE NOT NULL, display_name TEXT NOT NULL,
  pass_salt TEXT NOT NULL, pass_hash TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL, last_seen TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS posts (
  id TEXT PRIMARY KEY, author_id TEXT NOT NULL REFERENCES users(id), category TEXT NOT NULL, text TEXT NOT NULL,
  lat REAL NOT NULL, lon REAL NOT NULL, approx INTEGER NOT NULL, municipio TEXT,
  observed_at TEXT NOT NULL, published_at TEXT NOT NULL, edited_at TEXT,
  community_ids TEXT NOT NULL DEFAULT '[]', photo_id TEXT, status TEXT NOT NULL DEFAULT 'visivel');
CREATE INDEX IF NOT EXISTS posts_pub ON posts(published_at);
CREATE TABLE IF NOT EXISTS photos (id TEXT PRIMARY KEY, mime TEXT NOT NULL, data BLOB NOT NULL);
CREATE TABLE IF NOT EXISTS comments (
  id TEXT PRIMARY KEY, post_id TEXT NOT NULL, author_id TEXT NOT NULL REFERENCES users(id),
  text TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS comments_post ON comments(post_id, created_at);
CREATE TABLE IF NOT EXISTS follows (user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, community_id TEXT NOT NULL, PRIMARY KEY (user_id, community_id));
CREATE TABLE IF NOT EXISTS reports (
  id TEXT PRIMARY KEY, post_id TEXT NOT NULL, reporter_id TEXT NOT NULL REFERENCES users(id), reason TEXT NOT NULL,
  created_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pendente', reviewed_by TEXT, reviewed_at TEXT);
`);

// 0.3.0: conferência com o SARS guardada junto do relato (JSON)
if (!db.prepare("PRAGMA table_info(posts)").all().some((c) => c.name === "radar")) db.exec("ALTER TABLE posts ADD COLUMN radar TEXT");

/* ------------------------- geografia (opcional) ------------------------- */
let GEOMS = [];
try {
  const g = JSON.parse(fs.readFileSync(GEO_PATH, "utf8")).geometries;
  GEOMS = Object.entries(g).map(([nome, v]) => ({ nome, polys: v.geometry.type === "Polygon" ? [v.geometry.coordinates] : v.geometry.coordinates }));
} catch {
  console.warn(`Aviso: geometrias municipais não carregadas de ${GEO_PATH}; o município informado pelo app será usado sem conferência.`);
}
function inRing(lon, lat, ring) {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [xi, yi] = ring[i], [xj, yj] = ring[j];
    if (yi > lat !== yj > lat && lon < ((xj - xi) * (lat - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}
function municipioAt(lat, lon) {
  for (const { nome, polys } of GEOMS) if (polys.some((p) => inRing(lon, lat, p[0]) && !p.slice(1).some((h) => inRing(lon, lat, h)))) return nome;
  return null;
}

/* ------------------------------ util ------------------------------ */
const now = () => new Date().toISOString();
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const newId = (p) => `${p}-${crypto.randomBytes(9).toString("base64url")}`;
class HttpError extends Error {
  constructor(status, message, code) { super(message); this.status = status; this.code = code; }
}
const bad = (m, code = "invalido") => new HttpError(400, m, code);
function hashPassword(pw, salt = crypto.randomBytes(16).toString("hex")) {
  return { salt, hash: crypto.scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 }).toString("hex") };
}
function checkPassword(pw, salt, hash) {
  const h = crypto.scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 });
  return crypto.timingSafeEqual(h, Buffer.from(hash, "hex"));
}
const rl = new Map(); // limite simples por chave
function limit(key, max, windowMs) {
  const t = Date.now(), e = rl.get(key) || { n: 0, t };
  if (t - e.t > windowMs) { e.n = 0; e.t = t; }
  e.n++; rl.set(key, e);
  if (e.n > max) throw new HttpError(429, "Muitas tentativas. Aguarde um minuto e tente de novo.", "limite");
}
const str = (v, name, min, max) => {
  if (typeof v !== "string") throw bad(`Campo ${name} ausente.`);
  const s = v.trim();
  if (s.length < min || s.length > max) throw bad(`O campo ${name} deve ter entre ${min} e ${max} caracteres.`);
  return s;
};
const isModerator = (u) => u && MODERATORS.has(u.handle);

function publicUser(u) {
  return { id: u.id, handle: u.handle, displayName: u.display_name, role: isModerator(u) ? "moderador" : "usuario", createdAt: u.created_at };
}
function postOut(r, viewer) {
  const commentCount = db.prepare("SELECT COUNT(*) n FROM comments WHERE post_id = ?").get(r.id).n;
  return {
    id: r.id, kind: "community", authorId: r.author_id,
    author: { id: r.author_id, handle: r.handle, displayName: r.display_name },
    category: r.category, text: r.text, lat: r.lat, lon: r.lon, approx: !!r.approx, municipio: r.municipio || undefined,
    observedAt: r.observed_at, publishedAt: r.published_at, editedAt: r.edited_at || undefined,
    communityIds: JSON.parse(r.community_ids), photoUrl: r.photo_id ? `/api/photos/${r.photo_id}` : undefined,
    status: r.status, commentCount, mine: viewer ? viewer.id === r.author_id : false,
    radar: r.radar ? JSON.parse(r.radar) : undefined,
  };
}
const POST_SELECT = "SELECT p.*, u.handle, u.display_name FROM posts p JOIN users u ON u.id = p.author_id";

function validatePost(b, partial = false) {
  const o = {};
  if (!partial || b.category !== undefined) { if (!CATEGORIES.has(b.category)) throw bad("Categoria inválida."); o.category = b.category; }
  if (!partial || b.text !== undefined) o.text = str(b.text, "descrição", 10, 1000);
  if (!partial || b.lat !== undefined || b.lon !== undefined) {
    const lat = Number(b.lat), lon = Number(b.lon);
    if (!isFinite(lat) || !isFinite(lon) || lat < AREA.s || lat > AREA.n || lon < AREA.w || lon > AREA.e) throw bad("Local fora do Brasil ou inválido.");
    o.lat = lat; o.lon = lon; o.approx = b.approx ? 1 : 0;
    o.municipio = GEOMS.length ? municipioAt(lat, lon) : typeof b.municipio === "string" ? b.municipio.slice(0, 60) : null;
  }
  if (!partial || b.observedAt !== undefined) {
    const t = Date.parse(b.observedAt);
    if (!isFinite(t) || t > Date.now() + 5 * 60000 || t < Date.parse("2020-01-01")) throw bad("Data da observação inválida.");
    o.observed_at = new Date(t).toISOString();
  }
  if (!partial || b.communityIds !== undefined) {
    const c = Array.isArray(b.communityIds) ? b.communityIds.filter((x) => COMMUNITIES.has(x)).slice(0, 7) : [];
    o.community_ids = JSON.stringify([...new Set(c)]);
  }
  return o;
}
/** Conferência com o SARS feita no aparelho: só os campos conhecidos, com tamanho limitado. */
function validateRadar(r) {
  if (r == null) return null;
  if (typeof r !== "object" || !RADAR_STATUS.has(r.status)) throw bad("Conferência com o SARS inválida.");
  const when = (v) => (typeof v === "string" && isFinite(Date.parse(v)) ? new Date(v).toISOString() : undefined);
  const ev = r.evidence && typeof r.evidence === "object" ? {
    kind: ["focos", "imagem"].includes(r.evidence.kind) ? r.evidence.kind : undefined,
    n: Number.isFinite(r.evidence.n) ? r.evidence.n : undefined,
    nearestKm: Number.isFinite(r.evidence.nearestKm) ? r.evidence.nearestKm : undefined,
    layer: typeof r.evidence.layer === "string" ? r.evidence.layer.slice(0, 80) : undefined,
    date: typeof r.evidence.date === "string" ? r.evidence.date.slice(0, 10) : undefined,
  } : undefined;
  const one = (x) => ({ status: x.status, detail: String(x.detail || "").slice(0, 400), checkedAt: when(x.checkedAt) || now(), recheckedAt: when(x.recheckedAt), evidence: ev });
  const out = one(r);
  if (r.firstCheck && typeof r.firstCheck === "object" && RADAR_STATUS.has(r.firstCheck.status)) out.firstCheck = { ...one(r.firstCheck), evidence: undefined };
  return JSON.stringify(out);
}
function savePhoto(dataUrl) {
  const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl || "");
  if (!m) throw bad("Foto em formato não aceito (use JPEG, PNG ou WebP).");
  const buf = Buffer.from(m[2], "base64");
  if (buf.length > 600 * 1024) throw bad("Foto muito grande (máximo 600 KB depois de reduzida).");
  const id = newId("f");
  db.prepare("INSERT INTO photos (id, mime, data) VALUES (?, ?, ?)").run(id, m[1], buf);
  return id;
}

/* ------------------------------ rotas ------------------------------ */
const routes = [];
const route = (method, pattern, fn, opts = {}) => routes.push({ method, re: new RegExp(`^${pattern}$`), fn, ...opts });

route("GET", "/api/health", () => ({ ok: true, version: VERSION, time: now(), geometrias: GEOMS.length, live: liveStatus() }));
route("GET", "/api/live/status", () => liveStatus());
route("GET", "/api/live/fires", ({ query }) => liveFires(query));

route("POST", "/api/auth/register", ({ body, ip }) => {
  limit(`reg:${ip}`, 10, 60000);
  const handle = str(body.handle, "usuário", 3, 30).toLowerCase();
  if (!/^[a-z0-9_.]+$/.test(handle)) throw bad("Usuário: use só letras minúsculas, números, ponto ou sublinhado.");
  const displayName = str(body.displayName, "nome de exibição", 1, 40);
  if (typeof body.password !== "string" || body.password.length < 8 || body.password.length > 200) throw bad("A senha precisa ter pelo menos 8 caracteres.");
  if (db.prepare("SELECT 1 FROM users WHERE handle = ?").get(handle)) throw new HttpError(409, "Esse usuário já existe. Escolha outro ou entre.", "existe");
  const { salt, hash } = hashPassword(body.password);
  const u = { id: newId("u"), handle, display_name: displayName, pass_salt: salt, pass_hash: hash, created_at: now() };
  db.prepare("INSERT INTO users (id, handle, display_name, pass_salt, pass_hash, created_at) VALUES (?, ?, ?, ?, ?, ?)").run(u.id, u.handle, u.display_name, salt, hash, u.created_at);
  return { token: createSession(u.id), user: publicUser(u) };
});
route("POST", "/api/auth/login", ({ body, ip }) => {
  limit(`login:${ip}`, 20, 60000);
  const handle = String(body.handle || "").trim().toLowerCase();
  const u = db.prepare("SELECT * FROM users WHERE handle = ?").get(handle);
  if (!u || typeof body.password !== "string" || !checkPassword(body.password, u.pass_salt, u.pass_hash)) throw new HttpError(401, "Usuário ou senha incorretos.", "credenciais");
  return { token: createSession(u.id), user: publicUser(u) };
});
function createSession(userId) {
  const token = crypto.randomBytes(32).toString("base64url");
  db.prepare("INSERT INTO sessions (token_hash, user_id, created_at, last_seen) VALUES (?, ?, ?, ?)").run(sha(token), userId, now(), now());
  return token;
}
route("POST", "/api/auth/logout", ({ token }) => { if (token) db.prepare("DELETE FROM sessions WHERE token_hash = ?").run(sha(token)); return { ok: true }; });

route("GET", "/api/me", ({ user }) => ({ user: publicUser(user), follows: follows(user.id) }), { auth: true });
route("PATCH", "/api/me", ({ user, body }) => {
  const dn = str(body.displayName, "nome de exibição", 1, 40);
  db.prepare("UPDATE users SET display_name = ? WHERE id = ?").run(dn, user.id);
  return { user: publicUser({ ...user, display_name: dn }) };
}, { auth: true });
const follows = (uid) => db.prepare("SELECT community_id FROM follows WHERE user_id = ? ORDER BY community_id").all(uid).map((r) => r.community_id);
route("PUT", "/api/me/follows", ({ user, body }) => {
  const ids = Array.isArray(body.communityIds) ? [...new Set(body.communityIds.filter((x) => COMMUNITIES.has(x)))] : null;
  if (!ids) throw bad("Lista de comunidades inválida.");
  db.exec("BEGIN");
  try {
    db.prepare("DELETE FROM follows WHERE user_id = ?").run(user.id);
    for (const c of ids) db.prepare("INSERT INTO follows (user_id, community_id) VALUES (?, ?)").run(user.id, c);
    db.exec("COMMIT");
  } catch (e) { db.exec("ROLLBACK"); throw e; }
  return { follows: follows(user.id) };
}, { auth: true });
route("GET", "/api/me/activity", ({ user }) => {
  const rows = db.prepare(`SELECT c.id, c.post_id, c.text, c.created_at, u.display_name, u.handle, p.text AS post_text
     FROM comments c JOIN posts p ON p.id = c.post_id JOIN users u ON u.id = c.author_id
     WHERE p.author_id = ? AND c.author_id != ? ORDER BY c.created_at DESC LIMIT 50`).all(user.id, user.id);
  return { items: rows.map((r) => ({ commentId: r.id, postId: r.post_id, text: r.text, at: r.created_at, author: { displayName: r.display_name, handle: r.handle }, postText: r.post_text.slice(0, 120) })) };
}, { auth: true });
route("GET", "/api/me/reports", ({ user }) => ({ items: db.prepare("SELECT id, post_id, reason, created_at, status, reviewed_at FROM reports WHERE reporter_id = ? ORDER BY created_at DESC").all(user.id) }), { auth: true });

route("GET", "/api/posts", ({ user, query }) => {
  const lim = Math.min(Number(query.get("limit")) || 200, 500);
  const rows = db
    .prepare(`${POST_SELECT} WHERE (p.status = 'visivel' OR p.author_id = ?) AND p.category NOT IN (${REMOVED_CATEGORIES.map(() => "?").join(",")}) ORDER BY p.published_at DESC LIMIT ?`)
    .all(user?.id ?? "", ...REMOVED_CATEGORIES, lim);
  return { posts: rows.map((r) => postOut(r, user)), time: now() };
});
route("GET", "/api/posts/([\\w-]+)", ({ user, m }) => {
  const r = db.prepare(`${POST_SELECT} WHERE p.id = ?`).get(m[1]);
  if (!r || (r.status !== "visivel" && r.author_id !== user?.id && !isModerator(user))) throw new HttpError(404, "Publicação não encontrada.", "nao_encontrado");
  return { post: postOut(r, user) };
});
route("POST", "/api/posts", ({ user, body }) => {
  limit(`post:${user.id}`, 30, 60000);
  const id = typeof body.id === "string" && /^p-[\w-]{6,40}$/.test(body.id) ? body.id : newId("p");
  const existing = db.prepare(`${POST_SELECT} WHERE p.id = ?`).get(id);
  if (existing) { // reenvio do mesmo relato (resposta anterior perdida): idempotente
    if (existing.author_id !== user.id) throw new HttpError(409, "Identificador já usado.", "conflito");
    return { post: postOut(existing, user), duplicate: true };
  }
  const v = validatePost(body);
  const radar = validateRadar(body.radar);
  const photoId = body.photo ? savePhoto(body.photo) : null;
  db.prepare(`INSERT INTO posts (id, author_id, category, text, lat, lon, approx, municipio, observed_at, published_at, community_ids, photo_id, radar)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(id, user.id, v.category, v.text, v.lat, v.lon, v.approx, v.municipio, v.observed_at, now(), v.community_ids, photoId, radar);
  return { post: postOut(db.prepare(`${POST_SELECT} WHERE p.id = ?`).get(id), user) };
}, { auth: true, status: 201 });
function ownPost(id, user) {
  const r = db.prepare("SELECT * FROM posts WHERE id = ?").get(id);
  if (!r) throw new HttpError(404, "Publicação não encontrada.", "nao_encontrado");
  if (r.author_id !== user.id) throw new HttpError(403, "Só quem publicou pode alterar esta publicação.", "proibido");
  return r;
}
route("PATCH", "/api/posts/([\\w-]+)", ({ user, body, m }) => {
  const r = ownPost(m[1], user);
  const v = validatePost(body, true);
  let photoId = r.photo_id;
  if (body.photo === null) photoId = null;
  else if (typeof body.photo === "string" && body.photo.startsWith("data:")) photoId = savePhoto(body.photo);
  if (photoId !== r.photo_id && r.photo_id) db.prepare("DELETE FROM photos WHERE id = ?").run(r.photo_id);
  const f = { ...{ category: r.category, text: r.text, lat: r.lat, lon: r.lon, approx: r.approx, municipio: r.municipio, observed_at: r.observed_at, community_ids: r.community_ids }, ...v };
  db.prepare(`UPDATE posts SET category=?, text=?, lat=?, lon=?, approx=?, municipio=?, observed_at=?, community_ids=?, photo_id=?, edited_at=? WHERE id=?`)
    .run(f.category, f.text, f.lat, f.lon, f.approx, f.municipio, f.observed_at, f.community_ids, photoId, now(), r.id);
  return { post: postOut(db.prepare(`${POST_SELECT} WHERE p.id = ?`).get(r.id), user) };
}, { auth: true });
// nova conferência com o SARS (Perfil › Meus relatos): não marca o relato como editado
route("PUT", "/api/posts/([\\w-]+)/radar", ({ user, body, m }) => {
  const r = ownPost(m[1], user);
  db.prepare("UPDATE posts SET radar = ? WHERE id = ?").run(validateRadar(body.radar), r.id);
  return { post: postOut(db.prepare(`${POST_SELECT} WHERE p.id = ?`).get(r.id), user) };
}, { auth: true });
route("DELETE", "/api/posts/([\\w-]+)", ({ user, m }) => {
  const r = db.prepare("SELECT * FROM posts WHERE id = ?").get(m[1]);
  if (!r) return { ok: true, alreadyDeleted: true };
  if (r.author_id !== user.id) throw new HttpError(403, "Só quem publicou pode excluir esta publicação.", "proibido");
  db.prepare("DELETE FROM comments WHERE post_id = ?").run(r.id);
  db.prepare("DELETE FROM posts WHERE id = ?").run(r.id);
  if (r.photo_id) db.prepare("DELETE FROM photos WHERE id = ?").run(r.photo_id);
  return { ok: true };
}, { auth: true });

route("GET", "/api/photos/([\\w-]+)", ({ m }) => {
  const p = db.prepare("SELECT mime, data FROM photos WHERE id = ?").get(m[1]);
  if (!p) throw new HttpError(404, "Foto não encontrada.", "nao_encontrado");
  return { __raw: Buffer.from(p.data), mime: p.mime };
});

function postExists(id) {
  if (DATA_POST_ID.test(id)) return true;
  const r = db.prepare("SELECT status FROM posts WHERE id = ?").get(id);
  return !!r && r.status === "visivel";
}
route("GET", "/api/posts/([\\w-]+)/comments", ({ m, user }) => {
  const rows = db.prepare(`SELECT c.*, u.handle, u.display_name FROM comments c JOIN users u ON u.id = c.author_id WHERE c.post_id = ? ORDER BY c.created_at`).all(m[1]);
  return { comments: rows.map((r) => ({ id: r.id, postId: r.post_id, authorId: r.author_id, author: { id: r.author_id, handle: r.handle, displayName: r.display_name }, text: r.text, at: r.created_at, mine: user?.id === r.author_id })) };
});
route("POST", "/api/posts/([\\w-]+)/comments", ({ m, user, body }) => {
  limit(`com:${user.id}`, 60, 60000);
  if (!postExists(m[1])) throw new HttpError(404, "Publicação não encontrada.", "nao_encontrado");
  const id = typeof body.id === "string" && /^c-[\w-]{6,40}$/.test(body.id) ? body.id : newId("c");
  const ex = db.prepare("SELECT * FROM comments WHERE id = ?").get(id);
  if (ex) { if (ex.author_id !== user.id) throw new HttpError(409, "Identificador já usado.", "conflito"); return { comment: { id, postId: ex.post_id, text: ex.text, at: ex.created_at }, duplicate: true }; }
  const text = str(body.text, "comentário", 1, 600);
  const at = now();
  db.prepare("INSERT INTO comments (id, post_id, author_id, text, created_at) VALUES (?, ?, ?, ?, ?)").run(id, m[1], user.id, text, at);
  return { comment: { id, postId: m[1], authorId: user.id, author: { id: user.id, handle: user.handle, displayName: user.display_name }, text, at, mine: true } };
}, { auth: true, status: 201 });
route("DELETE", "/api/comments/([\\w-]+)", ({ m, user }) => {
  const c = db.prepare("SELECT * FROM comments WHERE id = ?").get(m[1]);
  if (!c) return { ok: true, alreadyDeleted: true };
  if (c.author_id !== user.id) throw new HttpError(403, "Só quem comentou pode apagar este comentário.", "proibido");
  db.prepare("DELETE FROM comments WHERE id = ?").run(c.id);
  return { ok: true };
}, { auth: true });

route("POST", "/api/reports", ({ user, body }) => {
  limit(`rep:${user.id}`, 20, 60000);
  if (typeof body.postId !== "string" || !postExists(body.postId)) throw new HttpError(404, "Publicação não encontrada.", "nao_encontrado");
  if (!REPORT_REASONS.has(body.reason)) throw bad("Motivo inválido.");
  const dup = db.prepare("SELECT id FROM reports WHERE post_id = ? AND reporter_id = ? AND status = 'pendente'").get(body.postId, user.id);
  if (dup) return { id: dup.id, duplicate: true };
  const id = newId("r");
  db.prepare("INSERT INTO reports (id, post_id, reporter_id, reason, created_at) VALUES (?, ?, ?, ?, ?)").run(id, body.postId, user.id, body.reason, now());
  return { id };
}, { auth: true, status: 201 });
function requireMod(user) { if (!isModerator(user)) throw new HttpError(403, "Apenas moderadores podem revisar denúncias.", "proibido"); }
route("GET", "/api/moderation/reports", ({ user }) => {
  requireMod(user);
  const rows = db.prepare(`SELECT r.*, u.handle AS reporter, p.text AS post_text, p.status AS post_status FROM reports r JOIN users u ON u.id = r.reporter_id
     LEFT JOIN posts p ON p.id = r.post_id ORDER BY (r.status = 'pendente') DESC, r.created_at DESC LIMIT 200`).all();
  return { items: rows };
}, { auth: true });
route("POST", "/api/moderation/reports/([\\w-]+)", ({ user, body, m }) => {
  requireMod(user);
  const r = db.prepare("SELECT * FROM reports WHERE id = ?").get(m[1]);
  if (!r) throw new HttpError(404, "Denúncia não encontrada.", "nao_encontrado");
  const action = body.action;
  if (!["manter", "ocultar", "reexibir"].includes(action)) throw bad("Ação inválida.");
  const status = action === "ocultar" ? "ocultado" : "mantido";
  db.prepare("UPDATE reports SET status = ?, reviewed_by = ?, reviewed_at = ? WHERE post_id = ? AND status = 'pendente' OR id = ?").run(status, user.id, now(), r.post_id, r.id);
  db.prepare("UPDATE posts SET status = ? WHERE id = ?").run(action === "ocultar" ? "oculto" : "visivel", r.post_id);
  return { ok: true, status };
}, { auth: true });

/* ------------------------------ http ------------------------------ */
const CORS = {
  "Access-Control-Allow-Origin": "*", // autenticação por token (não por cookie), então qualquer origem é segura aqui
  "Access-Control-Allow-Methods": "GET, POST, PATCH, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Authorization, Content-Type",
  "Access-Control-Max-Age": "600",
};
function send(res, status, obj, extra = {}) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...CORS, ...extra });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on("data", (c) => { size += c.length; if (size > 1.5 * 1024 * 1024) { reject(new HttpError(413, "Envio grande demais.", "grande")); req.destroy(); } else chunks.push(c); });
    req.on("end", () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString("utf8"))); } catch { reject(bad("JSON inválido.")); }
    });
    req.on("error", reject);
  });
}
function userFromToken(token) {
  if (!token) return null;
  const s = db.prepare("SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?").get(sha(token));
  if (s) db.prepare("UPDATE sessions SET last_seen = ? WHERE token_hash = ?").run(now(), sha(token));
  return s || null;
}

export const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://x");
  if (req.method === "OPTIONS") { res.writeHead(204, CORS); return res.end(); }
  if (req.method === "GET" && url.pathname === "/api/live/stream") return liveStream(req, res, CORS);
  const r = routes.find((x) => x.method === req.method && x.re.test(url.pathname));
  if (!r) return send(res, 404, { error: "Rota não encontrada.", code: "rota" });
  try {
    const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "") || null;
    const user = userFromToken(token);
    if (r.auth && !user) throw new HttpError(401, "Entre na sua conta para continuar.", "sessao");
    const body = ["POST", "PATCH", "PUT"].includes(req.method) ? await readBody(req) : {};
    // atrás do proxy de uma hospedagem (Render, Fly, Railway), o IP real vem no X-Forwarded-For
    const fwd = TRUST_PROXY ? String(req.headers["x-forwarded-for"] || "").split(",")[0].trim() : "";
    const ip = fwd || req.socket.remoteAddress || "?";
    const out = await r.fn({ req, body, user, token, ip, query: url.searchParams, m: url.pathname.match(r.re) });
    if (out && out.__raw) {
      res.writeHead(200, { "Content-Type": out.mime, "Cache-Control": "public, max-age=31536000, immutable", ...CORS });
      return res.end(out.__raw);
    }
    send(res, r.status || 200, out);
  } catch (e) {
    if (e instanceof HttpError) return send(res, e.status, { error: e.message, code: e.code });
    console.error(e);
    send(res, 500, { error: "Erro interno do servidor.", code: "interno" });
  }
});

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  startLive();
  server.listen(PORT, () => console.log(`IgaraPost servidor ${VERSION} em http://0.0.0.0:${PORT} · banco ${DB_PATH} · moderadores: ${[...MODERATORS].join(", ") || "(nenhum)"}`));
}
