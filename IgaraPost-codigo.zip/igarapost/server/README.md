# Servidor do IgaraPost (rede compartilhada)

É um servidor pequeno, sem dependências externas: Node.js 22 ou mais novo, com `node:http` e o SQLite embutido no Node (`node:sqlite`). Ele guarda:
- contas e perfis;
- relatos e fotos;
- comentários;
- comunidades acompanhadas;
- denúncias, com uma fila de moderação;
- a conferência de cada relato com o SARS ("fora do radar");
- os focos de calor do INPE das últimas 48 h, para o tempo real do app.

## Executar
```bash
node server/index.mjs
```
Por padrão escuta na porta 8787 e grava em `server/igarapost.db`. Variáveis opcionais:

| Variável | Para quê | Padrão |
|---|---|---|
| `PORT` | porta | 8787 |
| `DB` | arquivo do banco SQLite | `server/igarapost.db` |
| `MODERATORS` | usuários (separados por vírgula) que podem revisar denúncias | nenhum |
| `GEO` | geometrias municipais, usadas para calcular o município de cada relato no servidor | `app/public/data/cemaden_iis.json` |
| `LIVE` | `0` desliga a leitura dos focos em tempo real | ligado |
| `LIVE_POLL_MS` | intervalo de leitura da fonte de focos | `300000` (5 min) |
| `LIVE_CSV` | endereço do CSV de focos, com `{AAAAMMDD}` no lugar da data (UTC) | CSV diário Brasil do INPE |
| `LIVE_BBOX` | `oeste,sul,leste,norte`: guarda só os focos dessa região | todos |

Exemplo:
```bash
MODERATORS=ana,joao node server/index.mjs
```

## Tempo real (SARS)

| Rota | O que entrega |
|---|---|
| `GET /api/live/status` | data da última leitura da fonte, erro (se houver) e número de focos guardados |
| `GET /api/live/fires?since=ISO` | focos das últimas 48 h; com `since`, só os detectados depois dessa hora |
| `GET /api/live/stream` | Server-Sent Events: `snapshot` ao conectar, `fires` a cada foco novo, `status` a cada 25 s |

Atrás de um proxy (nginx), desligue o buffer na rota do SSE. O servidor já envia `X-Accel-Buffering: no`.

## Testar
```bash
node server/test.mjs
```
São 20 verificações. As 15 da 0.2.0 cobrem:
- cadastro e login;
- publicação e idempotência;
- visualização por outra pessoa;
- comentário e atividade do autor;
- bloqueio de edição e exclusão por outra pessoa (403);
- comunidades seguidas;
- moderação.

As 5 novas cobrem:
- tipos enchente e cheia;
- recusa de local fora do Brasil;
- conferência "fora do radar" e reconferência só pelo autor;
- leitura do CSV do INPE;
- SSE com snapshot e focos novos.

## Ligar o app ao servidor
No app, abra Perfil › Conta, informe o endereço (ex.: `https://igarapost.exemplo.org`) e toque em "Testar e salvar". Depois crie a conta ou entre.

Para gerar um app que já venha com o endereço configurado:
```bash
cd app && VITE_API_URL=https://igarapost.exemplo.org npm run android:apk
```

### Teste com celulares na mesma rede Wi-Fi
1. Rode o servidor num computador e descubra o IP dele (ex.: `192.168.0.10`).
2. Nos celulares, use o endereço `http://192.168.0.10:8787`.

O APK 0.2.0 aceita HTTP sem criptografia só para esse tipo de teste. Em produção use **HTTPS**: coloque o servidor atrás de um proxy com TLS ou numa plataforma que forneça HTTPS. Depois desligue `allowMixedContent` e `usesCleartextTraffic` no projeto Android.

## Segurança e limites do protótipo
- Senhas guardadas com scrypt e sal. Sessões por token aleatório, guardado no servidor só como hash SHA-256.
- Autoria verificada no servidor: só quem publicou edita ou exclui o próprio relato ou comentário (403 para as outras pessoas).
- Limite de tentativas de login e de cadastro por IP, e de publicações por conta.
- Não há recuperação de senha, verificação de e-mail nem backup automático. Faça cópia do arquivo `.db`.
- O município de cada relato é calculado no servidor a partir das coordenadas.
- Exemplos fictícios do app nunca são enviados ao servidor.
