// Teste da API do servidor (sem navegador). Uso: node server/test.mjs
// Sobe o servidor numa porta temporária com banco em memória e confere o percurso social e as permissões.
import assert from "node:assert/strict";
process.env.DB = ":memory:";
process.env.MODERATORS = "mod_ana";
const { server } = await import("./index.mjs");
await new Promise((r) => server.listen(0, r));
const base = `http://127.0.0.1:${server.address().port}`;
const results = [];
async function call(method, path, body, token) {
  const r = await fetch(base + path, { method, headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, json: await r.json().catch(() => ({})) };
}
async function check(name, fn) {
  try { await fn(); results.push(["OK ", name]); } catch (e) { results.push(["FALHOU", name, e.message]); }
}
let A, B, M, postId;
await check("cadastro de duas pessoas e de um moderador", async () => {
  A = (await call("POST", "/api/auth/register", { handle: "raimunda", displayName: "Raimunda", password: "senha-segura-1" })).json.token;
  B = (await call("POST", "/api/auth/register", { handle: "josue", displayName: "Josué", password: "senha-segura-2" })).json.token;
  M = (await call("POST", "/api/auth/register", { handle: "mod_ana", displayName: "Ana (moderação)", password: "senha-segura-3" })).json.token;
  assert.ok(A && B && M);
});
await check("usuário repetido é recusado", async () => assert.equal((await call("POST", "/api/auth/register", { handle: "josue", displayName: "X", password: "12345678" })).status, 409));
await check("senha errada é recusada", async () => assert.equal((await call("POST", "/api/auth/login", { handle: "josue", password: "errada123" })).status, 401));
await check("publicar exige conta", async () => assert.equal((await call("POST", "/api/posts", { category: "fumaca" })).status, 401));
await check("A publica relato (município calculado no servidor)", async () => {
  const r = await call("POST", "/api/posts", { id: "p-teste-000001", category: "fumaca", text: "Fumaça forte perto do porto do Careiro.", lat: -3.2, lon: -59.83, approx: true, observedAt: new Date(Date.now() - 3600e3).toISOString(), communityIds: ["careiro-varzea", "inexistente"] }, A);
  assert.equal(r.status, 201); postId = r.json.post.id;
  assert.equal(r.json.post.municipio, "Careiro da Várzea"); assert.deepEqual(r.json.post.communityIds, ["careiro-varzea"]);
});
await check("reenvio com o mesmo id não duplica", async () => {
  const r = await call("POST", "/api/posts", { id: "p-teste-000001", category: "fumaca", text: "Fumaça forte perto do porto do Careiro.", lat: -3.2, lon: -59.83, observedAt: new Date().toISOString() }, A);
  assert.equal(r.json.duplicate, true);
  assert.equal((await call("GET", "/api/posts")).json.posts.length, 1);
});
await check("B vê o relato de A", async () => assert.ok((await call("GET", "/api/posts", null, B)).json.posts.some((p) => p.id === postId && p.author.handle === "raimunda")));
await check("B comenta; A vê o comentário na atividade", async () => {
  assert.equal((await call("POST", `/api/posts/${postId}/comments`, { id: "c-teste-000001", text: "Aqui também está com fumaça." }, B)).status, 201);
  const act = (await call("GET", "/api/me/activity", null, A)).json.items;
  assert.equal(act.length, 1); assert.equal(act[0].author.handle, "josue");
});
await check("B não edita nem exclui o relato de A (403)", async () => {
  assert.equal((await call("PATCH", `/api/posts/${postId}`, { text: "texto alterado indevidamente" }, B)).status, 403);
  assert.equal((await call("DELETE", `/api/posts/${postId}`, null, B)).status, 403);
});
await check("A não apaga o comentário de B (403)", async () => assert.equal((await call("DELETE", "/api/comments/c-teste-000001", null, A)).status, 403));
await check("A edita o próprio relato", async () => {
  const r = await call("PATCH", `/api/posts/${postId}`, { text: "Fumaça forte perto do porto do Careiro, desde cedo." }, A);
  assert.equal(r.status, 200); assert.ok(r.json.post.editedAt);
});
await check("comentário em publicação gerada de dados oficiais é aceito", async () => assert.equal((await call("POST", "/api/posts/inpe-2026-09/comments", { text: "Setembro foi o pior mês." }, B)).status, 201));
await check("comunidades seguidas ficam na conta", async () => {
  await call("PUT", "/api/me/follows", { communityIds: ["autazes", "rios-enchente", "x"] }, B);
  assert.deepEqual((await call("GET", "/api/me", null, B)).json.follows, ["autazes", "rios-enchente"]);
});
await check("denúncia vai para a fila; só moderador revisa", async () => {
  const rep = await call("POST", "/api/reports", { postId, reason: "Local ou data errados" }, B);
  assert.equal(rep.status, 201);
  assert.equal((await call("GET", "/api/moderation/reports", null, A)).status, 403);
  const q = (await call("GET", "/api/moderation/reports", null, M)).json.items;
  assert.equal(q[0].status, "pendente");
  assert.equal((await call("POST", `/api/moderation/reports/${q[0].id}`, { action: "ocultar" }, M)).json.status, "ocultado");
  assert.equal((await call("GET", "/api/posts", null, B)).json.posts.length, 0, "oculto para os outros");
  assert.equal((await call("GET", "/api/posts", null, A)).json.posts[0].status, "oculto", "autor vê o status");
  assert.equal((await call("GET", "/api/me/reports", null, B)).json.items[0].status, "ocultado", "quem denunciou vê o resultado");
});

/* ---------------- 0.3.0: novos tipos, conferência com o SARS e tempo real ---------------- */
const live = await import("./live.mjs");
let p2;
await check("enchente com conferência 'fora do radar'; seca e cheia recusadas", async () => {
  const radar = { status: "fora_do_radar", detail: "Nenhum foco a até 5 km.", checkedAt: new Date().toISOString(), evidence: { kind: "focos", n: 0 }, lixo: "x".repeat(5000) };
  const r = await call("POST", "/api/posts", { id: "p-teste-000002", category: "enchente", text: "A água subiu de madrugada na escola.", lat: -3.12, lon: -60.02, approx: false, observedAt: new Date(Date.now() - 600e3).toISOString(), radar }, A);
  assert.equal(r.status, 201); p2 = r.json.post;
  assert.equal(p2.category, "enchente");
  assert.equal(p2.radar.status, "fora_do_radar");
  assert.equal(p2.radar.lixo, undefined, "campos desconhecidos descartados");
  for (const category of ["cheia", "falta_chuva", "reducao_agua"])
    assert.equal((await call("POST", "/api/posts", { category, text: "Rio acima do normal há semanas.", lat: -3.1, lon: -60, observedAt: new Date().toISOString() }, B)).status, 400, category);
});
await check("local fora do Brasil e conferência inválida são recusados (400)", async () => {
  assert.equal((await call("POST", "/api/posts", { category: "fumaca", text: "Fumaça forte aqui no centro.", lat: 40.4, lon: -3.7, observedAt: new Date().toISOString() }, A)).status, 400);
  assert.equal((await call("POST", "/api/posts", { category: "fumaca", text: "Fumaça forte aqui no centro.", lat: -15.8, lon: -47.9, observedAt: new Date().toISOString(), radar: { status: "talvez" } }, A)).status, 400);
});
await check("reconferência: só o autor; vira 'confirmado' sem marcar como editado", async () => {
  const radar = { status: "confirmado", detail: "Inundação marcada a até 3 km.", checkedAt: new Date().toISOString(), firstCheck: p2.radar };
  assert.equal((await call("PUT", `/api/posts/${p2.id}/radar`, { radar }, B)).status, 403);
  const r = await call("PUT", `/api/posts/${p2.id}/radar`, { radar }, A);
  assert.equal(r.status, 200);
  assert.equal(r.json.post.radar.status, "confirmado");
  assert.equal(r.json.post.radar.firstCheck.status, "fora_do_radar");
  assert.equal(r.json.post.editedAt, undefined);
});
await check("leitura do CSV do INPE pelo nome das colunas", async () => {
  const csv = "﻿id,lat,lon,data_hora_gmt,satelite,municipio,estado,pais,frp\n" +
    'a1,-3.1,-60.0,2026-11-14 16:10:00,NPP-375,MANAUS,AMAZONAS,Brasil,12.5\n' +
    'a2,-3.2,"-59,9",2026-11-14 16:10:00,AQUA_M-T,CAREIRO DA VÁRZEA,AMAZONAS,Brasil,-999\n' +
    "a3,x,-59.9,2026-11-14 16:10:00,AQUA_M-T,X,Y,Brasil,1\n";
  const f = live.parseCsv(csv);
  assert.equal(f.length, 1, "linha com coordenada inválida e linha com vírgula decimal entre aspas são ignoradas");
  assert.equal(f[0].t, Date.parse("2026-11-14T16:10:00Z"));
  assert.equal(f[0].mun, "Manaus");
  assert.throws(() => live.parseCsv("a,b\n1,2"));
});
await check("leitura do CSV da NASA FIRMS (acq_date + acq_time)", async () => {
  const csv = "latitude,longitude,bright_ti4,scan,track,acq_date,acq_time,satellite,instrument,confidence,version,bright_ti5,frp,daynight\n" +
    "-3.123,-60.01,330.1,0.4,0.37,2026-11-14,1652,N20,VIIRS,n,2.0NRT,290.2,5.4,D\n" +
    "-3.2,-59.9,331,0.4,0.4,2026-11-14,0418,N,VIIRS,l,2.0NRT,289,1.1,N\n";
  const f = live.parseCsv(csv);
  assert.equal(f.length, 2);
  assert.equal(f[0].t, Date.parse("2026-11-14T16:52:00Z")); assert.equal(f[0].sat, "VIIRS NOAA-20"); assert.equal(f[1].sat, "VIIRS Suomi NPP"); assert.equal(f[0].frp, 5.4);
});
await check("tempo real: /api/live/fires e SSE (snapshot + focos novos)", async () => {
  const t = Date.now() - 3600e3;
  live._inject([{ id: "f1", lat: -3.1, lon: -60, t, sat: "NPP-375" }]);
  const r = await call("GET", "/api/live/fires");
  assert.equal(r.status, 200); assert.equal(r.json.fires.length, 1);
  assert.equal((await call("GET", `/api/live/fires?since=${new Date(t).toISOString()}`)).json.fires.length, 0);
  const ctl = new AbortController();
  const res = await fetch(base + "/api/live/stream", { signal: ctl.signal });
  assert.equal(res.headers.get("content-type"), "text/event-stream; charset=utf-8");
  const reader = res.body.getReader(); const dec = new TextDecoder(); let buf = "";
  const until = async (re) => { while (!re.test(buf)) { const { value, done } = await reader.read(); if (done) break; buf += dec.decode(value); } };
  await until(/event: snapshot\ndata: .*\n\n/);
  assert.match(buf, /"id":"f1"/);
  live._inject([{ id: "f2", lat: -3.3, lon: -59.8, t: Date.now() - 60e3, sat: "AQUA_M-T" }]);
  await until(/event: fires\ndata: .*"f2".*\n\n/);
  ctl.abort();
});
await check("A exclui o próprio relato", async () => assert.equal((await call("DELETE", `/api/posts/${postId}`, null, A)).status, 200));
server.close();
for (const r of results) console.log(r.join("  "));
process.exit(results.some((r) => r[0] !== "OK ") ? 1 : 0);
